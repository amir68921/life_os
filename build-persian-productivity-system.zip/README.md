# LIFE OS — سیستم شخصی مدیریت زندگی

A Persian-first (RTL, Jalali calendar) personal productivity system built with **Next.js 16 (App Router)**, **PostgreSQL** and **Drizzle ORM**.

## Features (Phase 1 + parts of Phase 2)

| Area | Status |
| --- | --- |
| Auth (email + password, scrypt hashing, DB sessions, httpOnly cookies) | ✅ |
| Dashboard (current priority, today's tasks, focus, sleep, habits, goals, deadlines, remaining plan) | ✅ |
| Goals (hierarchy, milestones, linked projects/tasks/notes, progress log, filters, archive/delete) | ✅ |
| Tasks (list / day / week / Jalali calendar / overdue / upcoming, filters, sorting, recurrence, explicit rescheduling, estimate vs actual) | ✅ |
| Daily & weekly planner (time blocks, recurring blocks, overlap warning with explicit confirmation, planned vs actual) | ✅ |
| Focus timer (server-persisted state, pause/resume/finish early/cancel, interruptions & distractions, full screen, break timer, reflection, corrections) | ✅ |
| Sleep (cross-midnight nights, consistency, adherence, trends; labelled as manual estimates) | ✅ |
| Habits (daily / custom weekdays / N per week, 4 occurrence states, schedule-aware streaks, pause periods) | ✅ |
| Activity log (manual + automatic from focus timer, duplicate prevention, overlap detection & trim) | ✅ |
| Projects (status, milestones, tasks, linked goals, actual time spent) | ✅ |
| Notes (Markdown with safe renderer, tags, links, full-text search via SQL `ILIKE`) | ✅ |
| Daily review, weekly review (data-backed report, rule-based suggestions: accept / edit / dismiss) | ✅ |
| Analytics (10 charts, date-range filters, explained calculations, no composite score) | ✅ |
| Settings (theme, time zone, calendar, week start, focus/break defaults, sleep targets, notifications, dashboard widgets, password, account deletion) | ✅ |
| Data export (JSON) | ✅ |
| Data import | ⛔ not yet (labelled “unavailable” in the UI) |
| Scheduled reminders (daily review / habits) | ⛔ not yet (preference stored, clearly labelled) |
| AI assistant | 🧩 architecture only (`src/lib/ai`), optional |
| English UI | 🧩 dictionary-ready (`src/lib/i18n.ts`) |

## Ubuntu (one command)

```bash
cd ~/lifeos                      # the extracted project folder
chmod +x scripts/*.sh
./scripts/setup-ubuntu.sh --service   # installs Node 22 + PostgreSQL, builds, auto-starts at boot
```

Open http://localhost:3000. After replacing the project files with a newer version run `./scripts/setup-ubuntu.sh --app-only`.
Backups: `./scripts/backup.sh` (creates `backups/*.sql`), restore with `./scripts/backup.sh restore <file>`.
Service control: `sudo systemctl status|restart|stop lifeos`, logs: `journalctl -u lifeos -f`.

## Setup

```bash
npm install
cp .env .env.local   # or edit .env
npx drizzle-kit push # apply schema to an existing dev DB
npm run dev
```

### Environment variables

| Name | Required | Purpose |
| --- | --- | --- |
| `DATABASE_URL` | yes | PostgreSQL connection string |
| `AI_API_KEY` | no | Enables the (future) AI assistant – server-side only |
| `AI_BASE_URL` | no | OpenAI-compatible endpoint (default `https://api.openai.com/v1`) |
| `AI_MODEL` | no | Model name (default `gpt-4o-mini`) |
| `INSECURE_COOKIES` | no | Set to `1` only if you must serve production over plain HTTP (not recommended) |

No secret is ever exposed to the browser (nothing uses the `NEXT_PUBLIC_` prefix).

## Database & migrations

- Schema: `src/db/schema.ts` (all tables have `user_id` with `ON DELETE CASCADE`; cross-entity links use `ON DELETE SET NULL` so deleting a goal/project never destroys historical tasks, sessions, activities or notes).
- Constraints: unique one-active-focus-session per user (partial index), idempotent focus `client_id`, unique `(series_id, due_date)` for recurring tasks, unique sleep record per wake date, duplicate-activity unique index, check constraints for ranges and time ordering.
- Migrations: SQL files in `./drizzle` (generated with `npx drizzle-kit generate`).
  - Fresh database: `npx drizzle-kit migrate`
  - Development: `npx drizzle-kit push`
  - After changing the schema: `npx drizzle-kit generate --name <change>` and commit the SQL. Avoid destructive changes (drop/rename) without a data migration.

## Time zones & calendar

- All instants are stored as `timestamptz` (UTC). Local dates (`date` columns) and clock times are interpreted in the user's configured IANA time zone (`src/lib/time.ts`, DST-safe).
- The UI displays Jalali dates by default (`src/lib/jalali.ts`, pure conversion) and can switch to Gregorian in settings. Date pickers navigate Jalali months but submit ISO dates.
- Sessions/activities that cross midnight are split proportionally across days in analytics; sleep entered as “23:30 → 07:00” is placed on the previous night automatically.

## Security model

- Passwords: scrypt with random salt; sessions: random 256-bit token in an `httpOnly`, `SameSite=Lax`, `Secure` (production) cookie, only its SHA-256 hash stored in DB; 30-day expiry.
- Every page calls `requireUser()` server-side; every server action re-authenticates and scopes **all** queries with `user_id`. Linked IDs (goal/project/task) are verified to belong to the user (`ownedLinks`) so IDs can't be forged across accounts.
- Input validation on the server (`reader()` in `src/lib/server-utils.ts`), length limits, Persian-digit normalisation. Markdown is rendered without HTML injection.
- Basic login throttling (in-memory, per process). Errors are logged without request payloads.
- Account deletion (password + typed confirmation) removes all user data; JSON export available.

## AI architecture

`src/lib/ai/index.ts` defines a provider-agnostic `AIProvider` interface and an OpenAI-compatible implementation. `getAIProvider()` returns `null` when `AI_API_KEY` is missing, and the app works normally. Future features must pass only server-side, user-scoped data and store generated plans as *pending suggestions* that require explicit approval (the weekly-review suggestion model already supports `pending / accepted / dismissed`).

## Localization

UI strings for navigation, enums and common actions live in `src/lib/i18n.ts` (`fa`). Add an `en` dictionary with the same keys and switch `dir`/`lang` in `src/app/layout.tsx` based on `preferences.language`. Some page-specific copy is still inline Persian and should be moved into the dictionary when English is added.

## Testing

```bash
npx vitest run
```

- `tests/logic.test.ts` – Jalali conversion (3-year round-trip), time-zone/DST math, midnight splitting, habit streaks/rates/pauses/skips, recurrence rules, overlap detection (incl. recurring blocks), sleep across midnight & circular bedtime statistics, focus timer math (pause/resume/refresh), suggestion thresholds, password hashing.
- `tests/data-access.test.ts` – runs against PostgreSQL: cross-user authorization (read/update/complete/reschedule/delete by foreign ID), recurring-task completion idempotency & history preservation, postponement counting, FK `SET NULL` behaviour, single active focus session, client-ID dedupe, duplicate activity/sleep prevention, check constraints.

Validation used for releases:

```bash
npx next typegen
npm exec tsc -- --noEmit
npx vitest run
npm run build
```

## Deployment

1. Provision PostgreSQL and set `DATABASE_URL`.
2. `npm ci && npx drizzle-kit migrate && npm run build && npm start` behind HTTPS.
3. Health check: `GET /api/health`.
