import { describe, expect, it } from "vitest";
import { isoToJalali, jalaliMonthLength, jalaliToIso, isJalaliLeap } from "@/lib/jalali";
import { addDays, addMonths, dayBoundsUtc, localDate, localTime, splitByLocalDay, startOfWeek, weekdayOf, zonedToUtc } from "@/lib/time";
import { computeHabitStats, type HabitStatus } from "@/lib/habits";
import { nextOccurrence } from "@/lib/recurrence";
import { blockConflicts, overlappingPairs } from "@/lib/overlap";
import { clockDistance, computeSleepStats, estimateSleepMinutes } from "@/lib/sleep";
import { clampFocused, elapsedSeconds, remainingSeconds, resumedPausedSeconds } from "@/lib/focus";
import { generateSuggestions, type WeeklyMetrics } from "@/lib/suggestions";
import { fa, formatMinutes, formatDateShort, toLatinDigits } from "@/lib/format";
import { hashPassword, verifyPassword, hashToken } from "@/lib/password";

describe("jalali calendar", () => {
  it("converts Nowruz dates", () => {
    expect(isoToJalali("2024-03-20")).toEqual({ jy: 1403, jm: 1, jd: 1 });
    expect(isoToJalali("2025-03-21")).toEqual({ jy: 1404, jm: 1, jd: 1 });
    expect(jalaliToIso(1402, 12, 29)).toBe("2024-03-19");
  });
  it("round-trips every day of a year", () => {
    for (let d = "2023-01-01"; d < "2026-01-01"; d = addDays(d, 1)) {
      const { jy, jm, jd } = isoToJalali(d);
      expect(jalaliToIso(jy, jm, jd)).toBe(d);
    }
  });
  it("knows month lengths and leap years", () => {
    expect(jalaliMonthLength(1403, 1)).toBe(31);
    expect(jalaliMonthLength(1403, 7)).toBe(30);
    expect(isJalaliLeap(1403)).toBe(true);
    expect(jalaliMonthLength(1403, 12)).toBe(30);
    expect(jalaliMonthLength(1404, 12)).toBe(29);
  });
  it("formats with Persian digits", () => {
    expect(formatDateShort("2024-03-20")).toBe("۱۴۰۳/۰۱/۰۱");
    expect(fa(2024)).toBe("۲۰۲۴");
    expect(toLatinDigits("۱۲:۳۰")).toBe("12:30");
    expect(formatMinutes(135)).toBe("۲ ساعت و ۱۵ دقیقه");
  });
});

describe("time zones", () => {
  it("converts local wall time to UTC (Tehran, no DST since 2022)", () => {
    expect(zonedToUtc("2024-06-01", "08:00", "Asia/Tehran").toISOString()).toBe("2024-06-01T04:30:00.000Z");
  });
  it("handles DST in New York", () => {
    expect(zonedToUtc("2024-01-15", "09:00", "America/New_York").toISOString()).toBe("2024-01-15T14:00:00.000Z");
    expect(zonedToUtc("2024-07-15", "09:00", "America/New_York").toISOString()).toBe("2024-07-15T13:00:00.000Z");
    const { start, end } = dayBoundsUtc("2024-03-10", "America/New_York"); // 23-hour day
    expect((end.getTime() - start.getTime()) / 3600000).toBe(23);
  });
  it("computes local date/time of an instant", () => {
    const d = new Date("2024-06-01T21:00:00Z");
    expect(localDate(d, "Asia/Tehran")).toBe("2024-06-02");
    expect(localTime(d, "Asia/Tehran")).toBe("00:30");
    expect(localDate(d, "UTC")).toBe("2024-06-01");
  });
  it("splits intervals crossing midnight", () => {
    const start = zonedToUtc("2024-06-01", "23:00", "Asia/Tehran");
    const end = zonedToUtc("2024-06-02", "01:30", "Asia/Tehran");
    expect(splitByLocalDay(start, end, "Asia/Tehran")).toEqual([
      { date: "2024-06-01", minutes: 60 },
      { date: "2024-06-02", minutes: 90 },
    ]);
  });
  it("calculates week starts and month math", () => {
    expect(weekdayOf("2024-06-01")).toBe(6); // Saturday
    expect(startOfWeek("2024-06-05", 6)).toBe("2024-06-01");
    expect(startOfWeek("2024-06-05", 0)).toBe("2024-06-02");
    expect(addMonths("2024-01-31", 1)).toBe("2024-02-29");
  });
});

describe("habit streaks & rates", () => {
  const daily = { frequency: "daily", weekdays: null, timesPerWeek: null, startDate: "2024-06-01", endDate: null };
  const m = (o: Record<string, HabitStatus>) => new Map(Object.entries(o));
  it("counts streaks and keeps history after a miss", () => {
    const s = computeHabitStats(daily, m({ "2024-06-01": "completed", "2024-06-02": "completed", "2024-06-03": "missed", "2024-06-04": "completed" }), [], "2024-06-01", "2024-06-04");
    expect(s.currentStreak).toBe(1);
    expect(s.longestStreak).toBe(2);
    expect(s.completionRate).toBe(75);
  });
  it("does not count today as a failure while unrecorded", () => {
    const s = computeHabitStats(daily, m({ "2024-06-01": "completed", "2024-06-02": "completed" }), [], "2024-06-01", "2024-06-03");
    expect(s.currentStreak).toBe(2);
    expect(s.completionRate).toBe(100);
  });
  it("treats skips and pauses as neutral", () => {
    const s = computeHabitStats(
      daily,
      m({ "2024-06-01": "completed", "2024-06-02": "skipped", "2024-06-06": "completed" }),
      [{ startDate: "2024-06-03", endDate: "2024-06-05" }],
      "2024-06-01",
      "2024-06-06",
    );
    expect(s.currentStreak).toBe(2);
    expect(s.eligible).toBe(2);
    expect(s.completionRate).toBe(100);
  });
  it("uses the custom schedule (only scheduled weekdays count)", () => {
    // Mon/Wed only; 2024-06-03 is Monday
    const h = { ...daily, frequency: "custom", weekdays: [1, 3] };
    const s = computeHabitStats(h, m({ "2024-06-03": "completed", "2024-06-05": "completed" }), [], "2024-06-01", "2024-06-09");
    expect(s.currentStreak).toBe(2);
    expect(s.unrecorded).toBe(0);
  });
  it("evaluates weekly targets per week", () => {
    const h = { ...daily, frequency: "weekly", timesPerWeek: 2 };
    const s = computeHabitStats(h, m({ "2024-06-01": "completed", "2024-06-02": "completed", "2024-06-08": "completed" }), [], "2024-06-01", "2024-06-09", 6);
    expect(s.streakUnit).toBe("week");
    expect(s.currentStreak).toBe(1); // current week pending, not a failure
  });
});

describe("recurring tasks", () => {
  it("computes next daily/monthly occurrence", () => {
    expect(nextOccurrence({ freq: "daily", interval: 1 }, "2024-06-01")).toBe("2024-06-02");
    expect(nextOccurrence({ freq: "daily", interval: 3 }, "2024-06-01")).toBe("2024-06-04");
    expect(nextOccurrence({ freq: "monthly", interval: 1 }, "2024-01-31")).toBe("2024-02-29");
  });
  it("computes weekly occurrences with weekdays and intervals", () => {
    // 2024-06-03 Monday; weekdays Mon(1), Thu(4)
    expect(nextOccurrence({ freq: "weekly", interval: 1, weekdays: [1, 4] }, "2024-06-03")).toBe("2024-06-06");
    expect(nextOccurrence({ freq: "weekly", interval: 1, weekdays: [1, 4] }, "2024-06-06")).toBe("2024-06-10");
    expect(nextOccurrence({ freq: "weekly", interval: 2, weekdays: [1] }, "2024-06-03")).toBe("2024-06-17");
  });
  it("stops after the until date", () => {
    expect(nextOccurrence({ freq: "daily", interval: 1, until: "2024-06-01" }, "2024-06-01")).toBeNull();
  });
});

describe("overlap detection", () => {
  const b = (id: string, date: string, s: number, e: number, rep: number[] | null = null) => ({ id, title: id, date, startMinute: s, endMinute: e, repeatWeekdays: rep, repeatUntil: null });
  it("detects one-off conflicts but allows touching blocks", () => {
    expect(blockConflicts(b("new", "2024-06-01", 600, 660), [b("a", "2024-06-01", 630, 700)])).toHaveLength(1);
    expect(blockConflicts(b("new", "2024-06-01", 600, 660), [b("a", "2024-06-01", 660, 700)])).toHaveLength(0);
  });
  it("detects conflicts with recurring blocks", () => {
    // recurring every Saturday 9-10 from 2024-06-01; candidate on Sat 2024-06-15 9:30
    expect(blockConflicts(b("new", "2024-06-15", 570, 620), [b("r", "2024-06-01", 540, 600, [6])])).toHaveLength(1);
    expect(blockConflicts(b("new", "2024-06-16", 570, 620), [b("r", "2024-06-01", 540, 600, [6])])).toHaveLength(0);
  });
  it("lists overlapping activity pairs", () => {
    expect(overlappingPairs([{ id: "1", start: 0, end: 10 }, { id: "2", start: 5, end: 15 }, { id: "3", start: 20, end: 30 }])).toHaveLength(1);
  });
});

describe("sleep", () => {
  it("handles nights crossing midnight", () => {
    const bed = zonedToUtc("2024-06-01", "23:30", "Asia/Tehran");
    const asleep = zonedToUtc("2024-06-02", "00:00", "Asia/Tehran");
    const wake = zonedToUtc("2024-06-02", "07:00", "Asia/Tehran");
    expect(estimateSleepMinutes(bed, asleep, wake)).toBe(420);
    expect(estimateSleepMinutes(bed, null, wake)).toBe(450);
  });
  it("compares bedtimes on a circular clock", () => {
    expect(clockDistance(23 * 60 + 50, 10)).toBe(20);
    const recs = [
      { bedTime: zonedToUtc("2024-06-01", "23:50", "UTC"), sleepStart: null, wakeTime: zonedToUtc("2024-06-02", "07:00", "UTC"), durationMinutes: 430 },
      { bedTime: zonedToUtc("2024-06-03", "00:10", "UTC"), sleepStart: null, wakeTime: zonedToUtc("2024-06-03", "07:00", "UTC"), durationMinutes: 410 },
    ];
    const s = computeSleepStats(recs, "UTC", { bed: "00:00", wake: "07:00", minutes: 480 });
    expect(Math.round(s.bedtimeStdDev!)).toBe(14); // not ~1000 minutes
    expect(s.bedtimeAdherence).toBe(100);
    expect(s.targetDurationHitRate).toBe(0);
  });
});

describe("focus timer math", () => {
  const base = { startedAt: new Date("2024-06-01T10:00:00Z"), plannedMinutes: 25, pausedSeconds: 0, pausedAt: null as Date | null, status: "running" };
  it("excludes paused time and survives refresh (pure function of stored state)", () => {
    const now = new Date("2024-06-01T10:10:00Z").getTime();
    expect(elapsedSeconds(base, now)).toBe(600);
    const paused = { ...base, status: "paused", pausedAt: new Date("2024-06-01T10:05:00Z") };
    expect(elapsedSeconds(paused, now)).toBe(300);
    const resumed = { ...base, pausedSeconds: resumedPausedSeconds(paused, now) };
    expect(elapsedSeconds(resumed, now)).toBe(300);
    expect(remainingSeconds(resumed, now)).toBe(1200);
  });
  it("never lets self-reported focus exceed measured time", () => {
    expect(clampFocused(40, 25 * 60)).toBe(25);
    expect(clampFocused(null, 100)).toBeNull();
  });
});

describe("suggestions", () => {
  const empty: WeeklyMetrics = { tasksPlanned: 0, tasksCompleted: 0, focusMinutes: 0, focusSessions: 0, sleepNights: 0, avgSleepMinutes: null, sleepTargetMinutes: 480, bedtimeStdDev: null, habitEligible: 0, habitCompleted: 0, topInterruption: null, postponedTasks: [], estimateRatio: null, estimateSamples: 0 };
  it("produces nothing without sufficient data", () => {
    expect(generateSuggestions(empty)).toEqual([]);
    expect(generateSuggestions({ ...empty, tasksPlanned: 3, tasksCompleted: 0 })).toEqual([]);
  });
  it("produces evidence-backed suggestions when data supports them", () => {
    const s = generateSuggestions({ ...empty, tasksPlanned: 10, tasksCompleted: 3, sleepNights: 5, avgSleepMinutes: 360 });
    expect(s.map((x) => x.id)).toEqual(["plan-load", "sleep-duration"]);
    expect(s.every((x) => x.basis.length > 0)).toBe(true);
  });
});

describe("passwords & tokens", () => {
  it("hashes and verifies with scrypt", async () => {
    const h = await hashPassword("correct horse");
    expect(h.startsWith("scrypt$")).toBe(true);
    expect(h).not.toContain("correct horse");
    expect(await verifyPassword("correct horse", h)).toBe(true);
    expect(await verifyPassword("wrong", h)).toBe(false);
    expect(hashToken("a")).toHaveLength(64);
  });
});
