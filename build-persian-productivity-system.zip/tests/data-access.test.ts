// Integration tests against the real PostgreSQL database (DATABASE_URL).
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { and, eq, inArray } from "drizzle-orm";
import { db, pool } from "@/db";
import { activities, focusSessions, goals, sleepRecords, tasks, users } from "@/db/schema";
import * as dal from "@/lib/dal/tasks";

let alice = "";
let bob = "";
const stamp = Date.now();

beforeAll(async () => {
  const [a] = await db.insert(users).values({ email: `alice-${stamp}@test.local`, name: "Alice", passwordHash: "x" }).returning();
  const [b] = await db.insert(users).values({ email: `bob-${stamp}@test.local`, name: "Bob", passwordHash: "x" }).returning();
  alice = a.id;
  bob = b.id;
});

afterAll(async () => {
  await db.delete(users).where(inArray(users.id, [alice, bob]));
  await pool.end();
});

describe("authorization scoping", () => {
  it("prevents another user from reading, updating, completing or deleting a task by ID", async () => {
    const t = await dal.createTask(alice, { title: "Alice's task" });
    expect(await dal.getTask(bob, t.id)).toBeNull();
    expect(await dal.updateTask(bob, t.id, { title: "hacked" })).toBeNull();
    expect(await dal.completeTask(bob, t.id)).toBeNull();
    expect(await dal.setTaskStatus(bob, t.id, "cancelled")).toBeNull();
    expect(await dal.rescheduleTask(bob, t.id, "2030-01-01")).toBeNull();
    expect(await dal.deleteTask(bob, t.id)).toBe(false);
    const still = await dal.getTask(alice, t.id);
    expect(still?.title).toBe("Alice's task");
    expect(still?.status).toBe("todo");
  });
});

describe("recurring tasks", () => {
  it("creates exactly one next occurrence and leaves history untouched", async () => {
    const t = await dal.createTask(alice, { title: "Daily review", dueDate: "2024-06-01", recurrence: { freq: "daily", interval: 1 } });
    const r1 = await dal.completeTask(alice, t.id);
    expect(r1?.nextId).toBeTruthy();
    // completing again is idempotent – no duplicate future occurrence
    const r2 = await dal.completeTask(alice, t.id);
    expect(r2?.nextId).toBeNull();
    const series = await db.select().from(tasks).where(and(eq(tasks.userId, alice), eq(tasks.seriesId, t.id)));
    expect(series.map((s) => s.dueDate).sort()).toEqual(["2024-06-01", "2024-06-02"]);
    const original = series.find((s) => s.id === t.id)!;
    expect(original.status).toBe("done");
    expect(original.completedAt).toBeTruthy();
    const next = series.find((s) => s.id !== t.id)!;
    expect(next.status).toBe("todo");
    // reopening the old occurrence does not delete the future one; re-completing doesn't duplicate
    await dal.setTaskStatus(alice, t.id, "todo");
    await dal.completeTask(alice, t.id);
    const again = await db.select().from(tasks).where(eq(tasks.seriesId, t.id));
    expect(again).toHaveLength(2);
  });

  it("counts postponements only when moved later", async () => {
    const t = await dal.createTask(alice, { title: "Postpone me", dueDate: "2024-06-01" });
    await dal.rescheduleTask(alice, t.id, "2024-06-03");
    await dal.rescheduleTask(alice, t.id, "2024-06-02");
    const row = await dal.getTask(alice, t.id);
    expect(row?.postponeCount).toBe(1);
    expect(row?.dueDate).toBe("2024-06-02");
  });
});

describe("data integrity constraints", () => {
  it("deleting a goal keeps linked tasks (link set to null)", async () => {
    const [g] = await db.insert(goals).values({ userId: alice, title: "Goal" }).returning();
    const t = await dal.createTask(alice, { title: "Linked", goalId: g.id });
    await db.delete(goals).where(eq(goals.id, g.id));
    const row = await dal.getTask(alice, t.id);
    expect(row).not.toBeNull();
    expect(row?.goalId).toBeNull();
  });

  it("allows only one active focus session per user and dedupes client IDs", async () => {
    const clientId = crypto.randomUUID();
    await db.insert(focusSessions).values({ userId: alice, clientId, plannedMinutes: 25, startedAt: new Date(), status: "running" });
    await expect(db.insert(focusSessions).values({ userId: alice, clientId: crypto.randomUUID(), plannedMinutes: 25, startedAt: new Date(), status: "running" })).rejects.toThrow();
    await expect(db.insert(focusSessions).values({ userId: alice, clientId, plannedMinutes: 25, startedAt: new Date(), status: "completed" })).rejects.toThrow();
    // another user is unaffected
    await db.insert(focusSessions).values({ userId: bob, clientId: crypto.randomUUID(), plannedMinutes: 25, startedAt: new Date(), status: "running" });
  });

  it("rejects duplicate activities and one sleep record per wake date", async () => {
    const startAt = new Date("2024-06-01T08:00:00Z");
    const endAt = new Date("2024-06-01T09:00:00Z");
    await db.insert(activities).values({ userId: alice, title: "Run", startAt, endAt });
    await expect(db.insert(activities).values({ userId: alice, title: "Run", startAt, endAt })).rejects.toThrow();
    await expect(db.insert(activities).values({ userId: alice, title: "Backwards", startAt: endAt, endAt: startAt })).rejects.toThrow();
    const night = { userId: alice, wakeDate: "2024-06-02", bedTime: new Date("2024-06-01T20:00:00Z"), wakeTime: new Date("2024-06-02T03:30:00Z"), durationMinutes: 450 };
    await db.insert(sleepRecords).values(night);
    await expect(db.insert(sleepRecords).values(night)).rejects.toThrow();
  });
});
