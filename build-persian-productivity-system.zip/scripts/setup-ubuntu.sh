#!/usr/bin/env bash
# LIFE OS – one-step installer for Ubuntu 22.04 / 24.04 (also works on WSL).
#
#   ./scripts/setup-ubuntu.sh             install everything and build the app
#   ./scripts/setup-ubuntu.sh --service   ...and auto-start LIFE OS at boot (systemd)
#   ./scripts/setup-ubuntu.sh --app-only  only (re)install packages, migrate DB and rebuild
#                                         (use after updating the project files)
#
# Run it as your normal user (NOT with sudo); it asks for your password when needed.
set -euo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DB_NAME="app_db"
DB_URL="postgresql://postgres:postgres@127.0.0.1:5432/${DB_NAME}"
PORT="${PORT:-3000}"
INSTALL_SERVICE=0
APP_ONLY=0
for arg in "$@"; do
  case "$arg" in
    --service) INSTALL_SERVICE=1 ;;
    --app-only) APP_ONLY=1 ;;
    *) echo "Unknown option: $arg" >&2; exit 2 ;;
  esac
done

say() { printf '\n\033[1;36m==> %s\033[0m\n' "$1"; }
ok() { printf '\033[1;32m    OK: %s\033[0m\n' "$1"; }
die() { printf '\n\033[1;31mERROR: %s\033[0m\n' "$1" >&2; exit 1; }

if [ "$(id -u)" -eq 0 ] && [ -n "${SUDO_USER:-}" ]; then
  die "Run this script WITHOUT sudo:  ./scripts/setup-ubuntu.sh"
fi
SUDO=""
if [ "$(id -u)" -ne 0 ]; then
  command -v sudo >/dev/null 2>&1 || die "'sudo' is not installed."
  SUDO="sudo"
fi
RUN_USER="$(id -un)"
cd "$APP_DIR"

# ---------------------------------------------------------------- 1. project files
say "Checking project files in $APP_DIR"
for f in package.json src/app src/db/schema.ts next.config.ts tsconfig.json postcss.config.mjs; do
  [ -e "$f" ] || die "Missing '$f'. The project folder is incomplete - download/extract the FULL project again."
done
ok "project files found"

if [ "$APP_ONLY" -eq 0 ]; then
  # -------------------------------------------------------------- 2. system packages
  say "Installing system packages (curl, PostgreSQL)"
  $SUDO apt-get update -y
  $SUDO apt-get install -y curl ca-certificates gnupg postgresql postgresql-contrib
  ok "packages installed"

  # -------------------------------------------------------------- 3. Node.js 22
  need_node=1
  if command -v node >/dev/null 2>&1; then
    major="$(node -p 'process.versions.node.split(".")[0]')"
    [ "$major" -ge 20 ] && need_node=0
  fi
  if [ "$need_node" -eq 1 ]; then
    say "Installing Node.js 22 (NodeSource)"
    $SUDO apt-get remove -y nodejs npm libnode-dev >/dev/null 2>&1 || true
    curl -fsSL https://deb.nodesource.com/setup_22.x | $SUDO -E bash -
    $SUDO apt-get install -y nodejs
  fi
  ok "node $(node -v), npm $(npm -v)"

  # -------------------------------------------------------------- 4. PostgreSQL
  say "Starting PostgreSQL and creating the database"
  $SUDO service postgresql start >/dev/null 2>&1 || $SUDO systemctl start postgresql
  [ -d /run/systemd/system ] && $SUDO systemctl enable postgresql >/dev/null 2>&1 || true
  pg() { (cd /tmp && $SUDO -u postgres "$@"); }
  for _ in $(seq 1 30); do pg psql -tAc "select 1" >/dev/null 2>&1 && break; sleep 1; done
  pg psql -tAc "select 1" >/dev/null 2>&1 || die "PostgreSQL did not start. Try: sudo service postgresql start"
  # Local-only database (PostgreSQL listens on localhost by default).
  pg psql -v ON_ERROR_STOP=1 -qc "ALTER USER postgres WITH PASSWORD 'postgres';"
  if ! pg psql -tAc "SELECT 1 FROM pg_database WHERE datname='${DB_NAME}'" | grep -q 1; then
    pg createdb "$DB_NAME"
  fi
  ok "database '${DB_NAME}' ready"
fi

command -v node >/dev/null 2>&1 || die "Node.js is not installed. Run the script without --app-only."

# ---------------------------------------------------------------- 5. configuration
say "Writing configuration"
if [ ! -f .env ] || ! grep -q '^DATABASE_URL=' .env; then
  echo "DATABASE_URL=${DB_URL}" >> .env
  ok ".env created"
else
  ok ".env already exists"
fi
if [ ! -f drizzle.config.json ]; then
  cat > drizzle.config.json <<EOF
{
  "dialect": "postgresql",
  "schema": "./src/db/schema.ts",
  "out": "./drizzle",
  "dbCredentials": { "url": "${DB_URL}" }
}
EOF
  ok "drizzle.config.json created"
fi

# ---------------------------------------------------------------- 6. dependencies
say "Installing app dependencies (npm) - this can take a few minutes"
export NEXT_TELEMETRY_DISABLED=1
if [ -f package-lock.json ]; then
  npm ci --no-audit --no-fund || npm install --no-audit --no-fund
else
  npm install --no-audit --no-fund
fi
ok "dependencies installed"

# ---------------------------------------------------------------- 7. database tables
say "Creating / upgrading database tables"
if [ -f drizzle/meta/_journal.json ]; then
  npx drizzle-kit migrate || npx drizzle-kit push --force
else
  npx drizzle-kit push --force
fi
ok "database tables ready"

# ---------------------------------------------------------------- 8. build
say "Building LIFE OS (production)"
npm run build
ok "build finished"

# ---------------------------------------------------------------- 9. auto-start service
SERVICE_FILE=/etc/systemd/system/lifeos.service
if [ "$INSTALL_SERVICE" -eq 1 ]; then
  if [ ! -d /run/systemd/system ]; then
    echo "    systemd is not available here (common on WSL) - skipping the service."
    echo "    Start the app manually with:  cd \"$APP_DIR\" && npm start"
  else
    say "Installing the 'lifeos' service (auto-start at boot)"
    NODE_BIN="$(command -v node)"
    $SUDO tee "$SERVICE_FILE" >/dev/null <<EOF
[Unit]
Description=LIFE OS
After=network.target postgresql.service
Wants=postgresql.service

[Service]
Type=simple
User=${RUN_USER}
WorkingDirectory=${APP_DIR}
Environment=NODE_ENV=production
Environment=NEXT_TELEMETRY_DISABLED=1
# Allows login over plain http (localhost / home network). Remove when serving over HTTPS.
Environment=INSECURE_COOKIES=1
ExecStart="${NODE_BIN}" "${APP_DIR}/node_modules/next/dist/bin/next" start -H 0.0.0.0 -p ${PORT}
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF
    $SUDO systemctl daemon-reload
    $SUDO systemctl enable lifeos >/dev/null 2>&1
    $SUDO systemctl restart lifeos
    ok "service installed and started"
  fi
elif [ -f "$SERVICE_FILE" ] && [ -d /run/systemd/system ]; then
  say "Restarting the existing 'lifeos' service"
  $SUDO systemctl restart lifeos
  ok "service restarted"
fi

# ---------------------------------------------------------------- done
LAN_IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
printf '\n\033[1;32m======================================================\033[0m\n'
printf '\033[1;32m  LIFE OS is installed!\033[0m\n'
if [ "$INSTALL_SERVICE" -eq 1 ] && [ -d /run/systemd/system ]; then
  printf '  It is running now and starts automatically at boot.\n'
else
  printf '  Start it with:   cd "%s" && npm start\n' "$APP_DIR"
fi
printf '  Open:            http://localhost:%s\n' "$PORT"
[ -n "$LAN_IP" ] && printf '  Other devices:   http://%s:%s  (same Wi-Fi)\n' "$LAN_IP" "$PORT"
printf '\033[1;32m======================================================\033[0m\n'
