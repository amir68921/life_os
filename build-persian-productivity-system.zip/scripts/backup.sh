#!/usr/bin/env bash
# LIFE OS – database backup / restore (Ubuntu install).
#
#   ./scripts/backup.sh                      create backups/lifeos-YYYY-MM-DD_HHMM.sql
#   ./scripts/backup.sh restore <file.sql>   restore a backup (REPLACES current data)
set -euo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DB_URL="postgresql://postgres:postgres@127.0.0.1:5432/app_db"
if [ -f "$APP_DIR/.env" ]; then
  line="$(grep '^DATABASE_URL=' "$APP_DIR/.env" | tail -1 || true)"
  [ -n "$line" ] && DB_URL="${line#DATABASE_URL=}"
fi

if [ "${1:-}" = "restore" ]; then
  file="${2:-}"
  [ -f "$file" ] || { echo "Usage: $0 restore <backup.sql>" >&2; exit 1; }
  read -r -p "This REPLACES all current LIFE OS data with '$file'. Type yes to continue: " answer
  [ "$answer" = "yes" ] || { echo "Cancelled."; exit 0; }
  psql "$DB_URL" -v ON_ERROR_STOP=1 -q -c "DROP SCHEMA public CASCADE; CREATE SCHEMA public; DROP SCHEMA IF EXISTS drizzle CASCADE;"
  psql "$DB_URL" -v ON_ERROR_STOP=1 -q -f "$file"
  echo "Restored from $file"
  exit 0
fi

mkdir -p "$APP_DIR/backups"
out="$APP_DIR/backups/lifeos-$(date +%F_%H%M).sql"
pg_dump "$DB_URL" --no-owner --no-privileges > "$out"
echo "Backup saved: $out"
