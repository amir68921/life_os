import "server-only";
import { and, eq, gte, inArray, lt, lte, ne } from "drizzle-orm";
import { db } from "@/db";
import { activities, focusSessions, goalProgressLog, goals, habitOccurrences, habitPauses, habits, interruptions, projects, sleepRecords, tasks, timeBlocks } from "@/db/schema";
import { computeHabitStats, type HabitStatus } from "./habits";
import { blocksOn } from "./overlap";
import { computeSleepStats } from "./sleep";
import type { WeeklyMetrics } from "./suggestions";
import { addDays, dateRange, rangeBoundsUtc, splitByLocalDay } from "./time";
import type { Prefs } from "./auth";

export async function weeklyReport(userId: string, prefs: Prefs, weekStart: string, today: string) {
  const tz = prefs.timezone;
  const weekEnd = addDays(weekStart, 6);
  const { start, end } = rangeBoundsUtc(weekStart, weekEnd, tz);
  const [weekTasks, sessions, ints, sleep, habitRows, occ, pauses, acts, blocks, gLog, goalRows, projectRows] = await Promise.all([
    db.select().from(tasks).where(and(eq(tasks.userId, userId), gte(tasks.dueDate, weekStart), lte(tasks.dueDate, weekEnd), ne(tasks.status, "cancelled"))),
    db.select().from(focusSessions).where(and(eq(focusSessions.userId, userId), eq(focusSessions.status, "completed"), gte(focusSessions.startedAt, start), lt(focusSessions.startedAt, end))),
    db.select().from(interruptions).where(and(eq(interruptions.userId, userId), gte(interruptions.occurredAt, start), lt(interruptions.occurredAt, end))),
    db.select().from(sleepRecords).where(and(eq(sleepRecords.userId, userId), gte(sleepRecords.wakeDate, weekStart), lte(sleepRecords.wakeDate, weekEnd))),
    db.select().from(habits).where(eq(habits.userId, userId)),
    db.select().from(habitOccurrences).where(and(eq(habitOccurrences.userId, userId), gte(habitOccurrences.date, weekStart), lte(habitOccurrences.date, weekEnd))),
    db.select({ habitId: habitPauses.habitId, startDate: habitPauses.startDate, endDate: habitPauses.endDate }).from(habitPauses).innerJoin(habits, eq(habits.id, habitPauses.habitId)).where(eq(habits.userId, userId)),
    db.select().from(activities).where(and(eq(activities.userId, userId), lt(activities.startAt, end), gte(activities.endAt, start))),
    db.select().from(timeBlocks).where(eq(timeBlocks.userId, userId)),
    db.select().from(goalProgressLog).where(and(eq(goalProgressLog.userId, userId), lt(goalProgressLog.recordedAt, end))),
    db.select({ id: goals.id, title: goals.title, progress: goals.progress, status: goals.status }).from(goals).where(and(eq(goals.userId, userId), inArray(goals.status, ["active", "completed"]))),
    db.select({ id: projects.id, name: projects.name, progress: projects.progress }).from(projects).where(eq(projects.userId, userId)),
  ]);

  const tasksCompleted = weekTasks.filter((t) => t.status === "done").length;
  const focusMinutes = sessions.reduce((a, s) => a + (s.elapsedSeconds ?? 0), 0) / 60;
  const reportedFocus = sessions.filter((s) => s.focusedMinutes !== null);

  const intCount = new Map<string, number>();
  ints.forEach((i) => intCount.set(i.reason.trim(), (intCount.get(i.reason.trim()) ?? 0) + 1));
  const topInterruptions = [...intCount.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5).map(([reason, count]) => ({ reason, count }));

  const sleepStats = computeSleepStats(sleep, tz, { bed: prefs.sleepTargetBed, wake: prefs.sleepTargetWake, minutes: prefs.sleepTargetMinutes });

  const effectiveEnd = weekEnd < today ? weekEnd : today;
  let habitEligible = 0;
  let habitCompleted = 0;
  const habitBreakdown: { name: string; rate: number | null }[] = [];
  for (const h of habitRows) {
    if (h.startDate > effectiveEnd) continue;
    const map = new Map<string, HabitStatus>(occ.filter((o) => o.habitId === h.id).map((o) => [o.date, o.status as HabitStatus]));
    const s = computeHabitStats({ ...h, endDate: h.endDate && h.endDate < effectiveEnd ? h.endDate : effectiveEnd }, map, pauses.filter((p) => p.habitId === h.id), weekStart, effectiveEnd, prefs.weekStart);
    if (h.frequency !== "weekly") {
      habitEligible += s.eligible;
      habitCompleted += s.completed;
    }
    habitBreakdown.push({ name: h.name, rate: s.completionRate });
  }

  const days = dateRange(weekStart, weekEnd);
  const plannedMinutes = days.reduce((a, d) => a + blocksOn(blocks, d).filter((b) => b.kind !== "break").reduce((m, b) => m + b.endMinute - b.startMinute, 0), 0);
  let actualMinutes = 0;
  let learningMinutes = 0;
  const plannedFocusMinutes = days.reduce((a, d) => a + blocksOn(blocks, d).filter((b) => b.kind === "focus").reduce((m, b) => m + b.endMinute - b.startMinute, 0), 0);
  for (const a of acts) {
    const mins = splitByLocalDay(a.startAt, a.endAt, tz).filter((s) => s.date >= weekStart && s.date <= weekEnd).reduce((m, s) => m + s.minutes, 0);
    if (a.category !== "sleep") actualMinutes += mins;
    if (a.category === "learning") learningMinutes += mins;
  }

  const withBoth = weekTasks.filter((t) => t.status === "done" && t.estimatedMinutes && t.actualMinutes);
  const estimateRatio = withBoth.length ? withBoth.reduce((a, t) => a + t.actualMinutes!, 0) / withBoth.reduce((a, t) => a + t.estimatedMinutes!, 0) : null;

  // Goal progress change during the week (from the progress log)
  const goalChanges = goalRows
    .map((g) => {
      const logs = gLog.filter((l) => l.goalId === g.id).sort((a, b) => a.recordedAt.getTime() - b.recordedAt.getTime());
      const before = [...logs].filter((l) => l.recordedAt < start).pop()?.progress ?? null;
      const after = [...logs].pop()?.progress ?? null;
      return { title: g.title, from: before, to: after ?? g.progress };
    })
    .filter((g) => g.from !== g.to || g.from === null);

  const projectTime = new Map<string, number>();
  acts.forEach((a) => {
    if (a.projectId) projectTime.set(a.projectId, (projectTime.get(a.projectId) ?? 0) + (a.endAt.getTime() - a.startAt.getTime()) / 60000);
  });

  const postponed = await db
    .select({ title: tasks.title, count: tasks.postponeCount })
    .from(tasks)
    .where(and(eq(tasks.userId, userId), gte(tasks.postponeCount, 2), inArray(tasks.status, ["todo", "in_progress"])))
    .limit(10);

  const metrics: WeeklyMetrics = {
    tasksPlanned: weekTasks.length,
    tasksCompleted,
    focusMinutes,
    focusSessions: sessions.length,
    sleepNights: sleep.length,
    avgSleepMinutes: sleepStats.avgDuration,
    sleepTargetMinutes: prefs.sleepTargetMinutes,
    bedtimeStdDev: sleepStats.bedtimeStdDev,
    habitEligible,
    habitCompleted,
    topInterruption: topInterruptions[0] ?? null,
    postponedTasks: postponed.sort((a, b) => b.count - a.count),
    estimateRatio,
    estimateSamples: withBoth.length,
  };

  return {
    metrics,
    reportedFocusMinutes: reportedFocus.reduce((a, s) => a + (s.focusedMinutes ?? 0), 0),
    reportedFocusSessions: reportedFocus.length,
    topInterruptions,
    sleepStats,
    habitBreakdown,
    plannedMinutes,
    actualMinutes,
    plannedFocusMinutes,
    learningMinutes,
    goalChanges,
    projectTime: projectRows.filter((p) => projectTime.has(p.id)).map((p) => ({ name: p.name, minutes: projectTime.get(p.id)!, progress: p.progress })),
  };
}
