// Central dictionary. The UI is Persian (fa) by default; add an `en` object with
// the same keys to enable English later (see README → Localization).

export const fa = {
  appName: "لایف اواس",
  nav: {
    dashboard: "داشبورد",
    planner: "برنامه‌ریز روزانه",
    tasks: "کارها",
    goals: "اهداف",
    projects: "پروژه‌ها",
    focus: "تایمر تمرکز",
    sleep: "خواب",
    habits: "عادت‌ها",
    activity: "گزارش فعالیت",
    notes: "یادداشت‌ها",
    analytics: "تحلیل‌ها",
    review: "مرور روزانه",
    weekly: "مرور هفتگی",
    settings: "تنظیمات",
  },
  priority: { low: "کم", medium: "متوسط", high: "زیاد", critical: "بحرانی" },
  taskStatus: { todo: "شروع‌نشده", in_progress: "در حال انجام", done: "انجام‌شده", cancelled: "لغوشده" },
  goalStatus: { active: "فعال", paused: "متوقف", completed: "محقق‌شده", archived: "بایگانی", abandoned: "کنارگذاشته" },
  horizon: { long: "بلندمدت", medium: "میان‌مدت", short: "کوتاه‌مدت" },
  projectStatus: { planned: "برنامه‌ریزی‌شده", active: "فعال", on_hold: "معلق", completed: "تکمیل‌شده", archived: "بایگانی" },
  energy: { low: "انرژی کم", medium: "انرژی متوسط", high: "انرژی زیاد" },
  habitStatus: { completed: "انجام شد", partial: "ناقص", missed: "انجام نشد", skipped: "رد عمدی" },
  habitFrequency: { daily: "هر روز", custom: "روزهای مشخص", weekly: "چند بار در هفته" },
  blockKind: { task: "کار", focus: "تمرکز", break: "استراحت", personal: "تعهد شخصی", other: "سایر" },
  activityCategory: {
    work: "کار",
    learning: "یادگیری",
    personal_projects: "پروژه‌های شخصی",
    health: "سلامت و ورزش",
    sleep: "خواب",
    social: "خانواده و اجتماع",
    entertainment: "سرگرمی",
    chores: "مسئولیت‌های روزمره",
    other: "سایر",
  },
  activitySource: { manual: "ثبت دستی", focus: "تایمر تمرکز", import: "ورود از منبع دیگر" },
  noteKind: { note: "یادداشت", lesson: "درس آموخته", reflection: "تأمل روزانه", idea: "ایده" },
  achieved: { yes: "بله", partly: "تا حدی", no: "خیر" },
  common: {
    save: "ذخیره",
    cancel: "انصراف",
    delete: "حذف",
    edit: "ویرایش",
    add: "افزودن",
    close: "بستن",
    confirmDelete: "آیا از حذف مطمئن هستید؟ این کار قابل بازگشت نیست.",
    none: "—",
    loading: "در حال بارگذاری…",
    saved: "ذخیره شد",
    error: "خطایی رخ داد. لطفاً دوباره تلاش کنید.",
  },
} as const;

export type Dict = typeof fa;
export const t = fa;

export function label<T extends Record<string, string>>(map: T, key: string | null | undefined): string {
  if (!key) return "—";
  return (map as Record<string, string>)[key] ?? key;
}

export function options<T extends Record<string, string>>(map: T) {
  return Object.entries(map).map(([value, text]) => ({ value, label: text }));
}
