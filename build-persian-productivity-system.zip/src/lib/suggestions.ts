import type { Suggestion } from "@/db/schema";

export type WeeklyMetrics = {
  tasksPlanned: number;
  tasksCompleted: number;
  focusMinutes: number;
  focusSessions: number;
  sleepNights: number;
  avgSleepMinutes: number | null;
  sleepTargetMinutes: number;
  bedtimeStdDev: number | null;
  habitEligible: number;
  habitCompleted: number;
  topInterruption: { reason: string; count: number } | null;
  postponedTasks: { title: string; count: number }[];
  estimateRatio: number | null; // actual/estimated, from tasks with both
  estimateSamples: number;
};

/**
 * Rule-based, transparent suggestions. Each rule requires a minimum amount of
 * data; if the threshold isn't met, no suggestion is produced. Wording is
 * supportive and never guilt-based. Each suggestion carries its evidence (basis).
 */
export function generateSuggestions(m: WeeklyMetrics): Omit<Suggestion, "status">[] {
  const out: Omit<Suggestion, "status">[] = [];
  const fa = (n: number) => String(Math.round(n)).replace(/\d/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[Number(d)]);

  if (m.tasksPlanned >= 5 && m.tasksCompleted / m.tasksPlanned < 0.6) {
    out.push({
      id: "plan-load",
      text: "برای هفته بعد تعداد کمتری کار برنامه‌ریزی کنید یا کارهای بزرگ را به گام‌های کوچک‌تر بشکنید.",
      basis: `${fa(m.tasksCompleted)} از ${fa(m.tasksPlanned)} کار برنامه‌ریزی‌شده انجام شد.`,
    });
  }
  if (m.estimateSamples >= 3 && m.estimateRatio !== null && m.estimateRatio > 1.3) {
    out.push({
      id: "estimates",
      text: `کارها به‌طور میانگین حدود ${fa((m.estimateRatio - 1) * 100)}٪ بیشتر از تخمین طول کشیده‌اند؛ در تخمین‌ها حاشیهٔ زمانی بگذارید.`,
      basis: `بر اساس ${fa(m.estimateSamples)} کار دارای زمان تخمینی و واقعی (تخمینی است).`,
    });
  }
  if (m.sleepNights >= 4 && m.avgSleepMinutes !== null && m.avgSleepMinutes < m.sleepTargetMinutes - 30) {
    out.push({
      id: "sleep-duration",
      text: "میانگین خواب کمتر از هدف شما بوده است؛ شاید جلو انداختن زمان خواب به‌مدت ۱۵ تا ۳۰ دقیقه کمک کند.",
      basis: `میانگین ${(m.avgSleepMinutes / 60).toFixed(1).replace(/\d/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[Number(d)])} ساعت در ${fa(m.sleepNights)} شب ثبت‌شده (برآورد دستی).`,
    });
  }
  if (m.sleepNights >= 4 && m.bedtimeStdDev !== null && m.bedtimeStdDev > 60) {
    out.push({
      id: "sleep-consistency",
      text: "زمان رفتن به رختخواب نوسان زیادی داشته است؛ یک ساعت ثابت برای آماده‌شدن برای خواب امتحان کنید.",
      basis: `انحراف معیار زمان خواب حدود ${fa(m.bedtimeStdDev)} دقیقه.`,
    });
  }
  if (m.topInterruption && m.topInterruption.count >= 3) {
    out.push({
      id: "interruptions",
      text: `«${m.topInterruption.reason}» رایج‌ترین عامل وقفه بوده است؛ پیش از جلسهٔ تمرکز برای آن برنامه‌ای داشته باشید.`,
      basis: `${fa(m.topInterruption.count)} بار در جلسات تمرکز این هفته ثبت شده.`,
    });
  }
  const repeat = m.postponedTasks.filter((p) => p.count >= 3);
  if (repeat.length > 0) {
    out.push({
      id: "postponed",
      text: `کار «${repeat[0].title}» چند بار جابه‌جا شده است؛ آن را کوچک‌تر کنید، به شخص دیگری بسپارید یا آگاهانه حذفش کنید.`,
      basis: `${fa(repeat[0].count)} بار زمان‌بندی مجدد.`,
    });
  }
  if (m.habitEligible >= 7 && m.habitCompleted / m.habitEligible < 0.5) {
    out.push({
      id: "habits",
      text: "برای عادت‌هایی که سخت پیش می‌روند، حداقل هدف را کوچک‌تر کنید تا انجامشان ساده‌تر شود.",
      basis: `${fa(m.habitCompleted)} از ${fa(m.habitEligible)} نوبت برنامه‌ریزی‌شده انجام شد.`,
    });
  }
  if (m.focusSessions >= 5 && m.focusMinutes / m.focusSessions < 15) {
    out.push({
      id: "short-sessions",
      text: "جلسات تمرکز کوتاه بوده‌اند؛ یک جلسهٔ طولانی‌تر در ساعات پرانرژی روز را امتحان کنید.",
      basis: `میانگین ${fa(m.focusMinutes / m.focusSessions)} دقیقه در ${fa(m.focusSessions)} جلسه.`,
    });
  }
  return out;
}
