import { addDays, dateRange, diffDays, startOfWeek, weekdayOf, type ISODate } from "./time";

export type HabitStatus = "completed" | "partial" | "missed" | "skipped";

export type HabitDef = {
  frequency: "daily" | "custom" | "weekly" | string;
  weekdays: number[] | null;
  timesPerWeek: number | null;
  startDate: ISODate;
  endDate: ISODate | null;
};

export type Pause = { startDate: ISODate; endDate: ISODate | null };

export function isPaused(date: ISODate, pauses: Pause[]) {
  return pauses.some((p) => date >= p.startDate && (p.endDate === null || date <= p.endDate));
}

/** Is the habit scheduled on a specific date (ignores pauses)? Weekly habits can be done any day. */
export function isScheduled(h: HabitDef, date: ISODate) {
  if (date < h.startDate) return false;
  if (h.endDate && date > h.endDate) return false;
  if (h.frequency === "custom") return (h.weekdays ?? []).includes(weekdayOf(date));
  return true;
}

export type HabitStats = {
  currentStreak: number;
  longestStreak: number;
  streakUnit: "day" | "week";
  completed: number;
  partial: number;
  missed: number;
  skipped: number;
  unrecorded: number;
  eligible: number;
  /** completed / eligible — null when nothing is eligible yet */
  completionRate: number | null;
};

/**
 * Streak & rate rules (shown to the user in the UI):
 * - Only scheduled days count. Paused periods and intentional skips are neutral.
 * - "completed" extends a streak; "partial" keeps it alive without extending it.
 * - "missed" or an unrecorded past scheduled day ends the current streak – but never
 *   erases history: longest streak and completion rates are preserved.
 * - Today is never counted as a failure while it is still unrecorded.
 * - Weekly habits (N times/week) are evaluated per week; the current week is pending.
 */
export function computeHabitStats(
  h: HabitDef,
  occurrences: Map<ISODate, HabitStatus>,
  pauses: Pause[],
  from: ISODate,
  today: ISODate,
  weekStart = 6,
): HabitStats {
  const start = from > h.startDate ? from : h.startDate;
  const stats: HabitStats = {
    currentStreak: 0,
    longestStreak: 0,
    streakUnit: h.frequency === "weekly" ? "week" : "day",
    completed: 0,
    partial: 0,
    missed: 0,
    skipped: 0,
    unrecorded: 0,
    eligible: 0,
    completionRate: null,
  };
  if (start > today) return stats;
  const end = h.endDate && h.endDate < today ? h.endDate : today;

  if (h.frequency === "weekly") {
    const target = Math.max(1, h.timesPerWeek ?? 1);
    let run = 0;
    const currentWeek = startOfWeek(today, weekStart);
    for (let ws = startOfWeek(start, weekStart); ws <= end; ws = addDays(ws, 7)) {
      const days = dateRange(ws, addDays(ws, 6)).filter((d) => d >= start && d <= end);
      const activeDays = days.filter((d) => !isPaused(d, pauses));
      let done = 0;
      for (const d of days) {
        const s = occurrences.get(d);
        if (s === "completed") done++;
        if (s === "partial") stats.partial++;
        if (s === "skipped") stats.skipped++;
        if (s === "missed") stats.missed++;
      }
      stats.completed += done;
      if (activeDays.length === 0) continue; // fully paused week → neutral
      const isCurrent = ws === currentWeek;
      if (done >= target) {
        run++;
        stats.eligible++;
        stats.longestStreak = Math.max(stats.longestStreak, run);
      } else if (!isCurrent) {
        stats.eligible++;
        run = 0;
      }
    }
    stats.currentStreak = run;
    const metWeeks = stats.longestStreak >= 0 ? countMetWeeks(h, occurrences, pauses, start, end, today, weekStart) : 0;
    stats.completionRate = stats.eligible > 0 ? (metWeeks / stats.eligible) * 100 : null;
    return stats;
  }

  let run = 0;
  for (const d of dateRange(start, end)) {
    if (!isScheduled(h, d) || isPaused(d, pauses)) continue;
    const s = occurrences.get(d);
    if (s === "completed") {
      stats.completed++;
      stats.eligible++;
      run++;
      stats.longestStreak = Math.max(stats.longestStreak, run);
    } else if (s === "partial") {
      stats.partial++;
      stats.eligible++;
    } else if (s === "skipped") {
      stats.skipped++;
    } else if (s === "missed") {
      stats.missed++;
      stats.eligible++;
      run = 0;
    } else if (d !== today) {
      stats.unrecorded++;
      stats.eligible++;
      run = 0;
    }
  }
  stats.currentStreak = run;
  stats.completionRate = stats.eligible > 0 ? (stats.completed / stats.eligible) * 100 : null;
  return stats;
}

function countMetWeeks(
  h: HabitDef,
  occ: Map<ISODate, HabitStatus>,
  pauses: Pause[],
  start: ISODate,
  end: ISODate,
  today: ISODate,
  weekStart: number,
) {
  const target = Math.max(1, h.timesPerWeek ?? 1);
  let met = 0;
  for (let ws = startOfWeek(start, weekStart); ws <= end; ws = addDays(ws, 7)) {
    const days = dateRange(ws, addDays(ws, 6)).filter((d) => d >= start && d <= end);
    if (days.every((d) => isPaused(d, pauses))) continue;
    const done = days.filter((d) => occ.get(d) === "completed").length;
    if (done >= target) met++;
  }
  void today;
  return met;
}

/** Number of days since the habit started (for the "consistency" label). */
export function habitAgeDays(h: HabitDef, today: ISODate) {
  return Math.max(0, diffDays(today, h.startDate) + 1);
}
