// Time-zone aware helpers. All timestamps are stored as UTC (timestamptz).
// "Local dates" (YYYY-MM-DD) and "local times" (HH:MM) are always relative to
// the user's configured IANA time zone.

export type ISODate = string; // YYYY-MM-DD

const dtfCache = new Map<string, Intl.DateTimeFormat>();
function partsFormatter(tz: string) {
  let f = dtfCache.get(tz);
  if (!f) {
    f = new Intl.DateTimeFormat("en-US", {
      timeZone: tz,
      hourCycle: "h23",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    });
    dtfCache.set(tz, f);
  }
  return f;
}

export function isValidTimeZone(tz: string) {
  try {
    new Intl.DateTimeFormat("en-US", { timeZone: tz });
    return true;
  } catch {
    return false;
  }
}

function zonedParts(date: Date, tz: string) {
  const parts: Record<string, string> = {};
  for (const p of partsFormatter(tz).formatToParts(date)) parts[p.type] = p.value;
  return {
    year: Number(parts.year),
    month: Number(parts.month),
    day: Number(parts.day),
    hour: Number(parts.hour) % 24,
    minute: Number(parts.minute),
    second: Number(parts.second),
  };
}

/** Offset (ms) of the zone from UTC at a given instant. */
export function tzOffsetMs(date: Date, tz: string) {
  const p = zonedParts(date, tz);
  const asUtc = Date.UTC(p.year, p.month - 1, p.day, p.hour, p.minute, p.second);
  return asUtc - Math.floor(date.getTime() / 1000) * 1000;
}

/** Convert a local wall-clock date + time in `tz` into a UTC Date. */
export function zonedToUtc(dateStr: ISODate, timeStr: string, tz: string): Date {
  const [y, m, d] = dateStr.split("-").map(Number);
  const [hh, mm] = timeStr.split(":").map(Number);
  const guess = Date.UTC(y, m - 1, d, hh || 0, mm || 0);
  const off1 = tzOffsetMs(new Date(guess), tz);
  let result = guess - off1;
  const off2 = tzOffsetMs(new Date(result), tz);
  if (off2 !== off1) result = guess - off2;
  return new Date(result);
}

const pad = (n: number) => String(n).padStart(2, "0");

/** Local calendar date of an instant in `tz`. */
export function localDate(date: Date, tz: string): ISODate {
  const p = zonedParts(date, tz);
  return `${p.year}-${pad(p.month)}-${pad(p.day)}`;
}

/** Local HH:MM of an instant in `tz`. */
export function localTime(date: Date, tz: string): string {
  const p = zonedParts(date, tz);
  return `${pad(p.hour)}:${pad(p.minute)}`;
}

/** Minutes since local midnight. */
export function localMinuteOfDay(date: Date, tz: string) {
  const p = zonedParts(date, tz);
  return p.hour * 60 + p.minute;
}

export function todayIn(tz: string): ISODate {
  return localDate(new Date(), tz);
}

export function addDays(dateStr: ISODate, n: number): ISODate {
  const [y, m, d] = dateStr.split("-").map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d + n));
  return `${dt.getUTCFullYear()}-${pad(dt.getUTCMonth() + 1)}-${pad(dt.getUTCDate())}`;
}

export function addMonths(dateStr: ISODate, n: number): ISODate {
  const [y, m, d] = dateStr.split("-").map(Number);
  const target = new Date(Date.UTC(y, m - 1 + n, 1));
  const lastDay = new Date(Date.UTC(target.getUTCFullYear(), target.getUTCMonth() + 1, 0)).getUTCDate();
  return `${target.getUTCFullYear()}-${pad(target.getUTCMonth() + 1)}-${pad(Math.min(d, lastDay))}`;
}

/** 0 = Sunday … 6 = Saturday */
export function weekdayOf(dateStr: ISODate) {
  const [y, m, d] = dateStr.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, d)).getUTCDay();
}

export function diffDays(a: ISODate, b: ISODate) {
  const [y1, m1, d1] = a.split("-").map(Number);
  const [y2, m2, d2] = b.split("-").map(Number);
  return Math.round((Date.UTC(y1, m1 - 1, d1) - Date.UTC(y2, m2 - 1, d2)) / 86400000);
}

export function startOfWeek(dateStr: ISODate, weekStart: number): ISODate {
  const wd = weekdayOf(dateStr);
  const back = (wd - weekStart + 7) % 7;
  return addDays(dateStr, -back);
}

export function dateRange(from: ISODate, to: ISODate): ISODate[] {
  const out: ISODate[] = [];
  for (let d = from; d <= to; d = addDays(d, 1)) out.push(d);
  return out;
}

/** UTC bounds [start, end) of a local day. Handles DST correctly. */
export function dayBoundsUtc(dateStr: ISODate, tz: string) {
  return { start: zonedToUtc(dateStr, "00:00", tz), end: zonedToUtc(addDays(dateStr, 1), "00:00", tz) };
}

/** UTC bounds [start, end) of a local date range (inclusive dates). */
export function rangeBoundsUtc(from: ISODate, to: ISODate, tz: string) {
  return { start: zonedToUtc(from, "00:00", tz), end: zonedToUtc(addDays(to, 1), "00:00", tz) };
}

export function isIsoDate(s: unknown): s is ISODate {
  return typeof s === "string" && /^\d{4}-\d{2}-\d{2}$/.test(s) && !Number.isNaN(Date.parse(s + "T00:00:00Z"));
}

export function isHHMM(s: unknown): s is string {
  return typeof s === "string" && /^([01]\d|2[0-3]):[0-5]\d$/.test(s);
}

export function hhmmToMinutes(s: string) {
  const [h, m] = s.split(":").map(Number);
  return h * 60 + m;
}

export function minutesToHHMM(min: number) {
  const m = ((min % 1440) + 1440) % 1440;
  return `${pad(Math.floor(m / 60))}:${pad(m % 60)}`;
}

/** Split an interval across local days (for sessions/activities crossing midnight). */
export function splitByLocalDay(start: Date, end: Date, tz: string): { date: ISODate; minutes: number }[] {
  const out: { date: ISODate; minutes: number }[] = [];
  let cursor = start;
  let guard = 0;
  while (cursor < end && guard++ < 400) {
    const d = localDate(cursor, tz);
    const { end: dayEnd } = dayBoundsUtc(d, tz);
    const segEnd = dayEnd < end ? dayEnd : end;
    out.push({ date: d, minutes: (segEnd.getTime() - cursor.getTime()) / 60000 });
    cursor = segEnd;
  }
  return out;
}

export const COMMON_TIMEZONES = [
  "Asia/Tehran",
  "UTC",
  "Europe/London",
  "Europe/Berlin",
  "Europe/Istanbul",
  "Asia/Dubai",
  "Asia/Kabul",
  "Asia/Dushanbe",
  "America/New_York",
  "America/Los_Angeles",
  "America/Toronto",
  "Australia/Sydney",
];
