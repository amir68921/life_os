import "server-only";
import { and, eq, gte, lte, desc, asc, ne } from "drizzle-orm";
import { db } from "@/db";
import {
  tasks, goals, milestones, focusSessions, sleepRecords, habits,
  habitOccurrences, dailyReviews, weeklyReviews,
} from "@/db/schema";
import type { User } from "@/lib/auth";
import {
  todayIso, addDaysIso, diffDaysIso, startOfWeekIso, faWeekdayOfIso, isoInTz, fmtTimeInTz,
} from "@/lib/jalali";

type Task = typeof tasks.$inferSelect;
type Goal = typeof goals.$inferSelect;
type Focus = typeof focusSessions.$inferSelect;
type Sleep = typeof sleepRecords.$inferSelect;
type Habit = typeof habits.$inferSelect;
type Occ = typeof habitOccurrences.$inferSelect;

// ======================= DASHBOARD =======================

export async function getDashboardData(user: User & { settings: { timezone: string; weekStart: number } }) {
  const uid = user.id;
  const tz = user.settings.timezone;
  const today = todayIso(tz);
  const tomorrow = addDaysIso(today, 1);
  const in7 = addDaysIso(today, 7);
  const weekStart = startOfWeekIso(today, user.settings.weekStart);
  const last30 = addDaysIso(today, -29);

  const [todayTasks, upcoming, activeGoals, focusToday, lastSleep, userHabits, occRecent, todayReview] = await Promise.all([
    db.select().from(tasks).where(and(eq(tasks.userId, uid), eq(tasks.dueDate, today), ne(tasks.status, "cancelled"))),
    db.select().from(tasks).where(and(eq(tasks.userId, uid), gte(tasks.dueDate, tomorrow), lte(tasks.dueDate, in7), ne(tasks.status, "done"), ne(tasks.status, "cancelled")))
      .orderBy(asc(tasks.dueDate)).limit(10),
    db.select().from(goals).where(and(eq(goals.userId, uid), eq(goals.status, "active"))).orderBy(desc(goals.priority)).limit(6),
    db.select().from(focusSessions).where(and(
      eq(focusSessions.userId, uid), gte(focusSessions.localDate, today), lte(focusSessions.localDate, today),
      eq(focusSessions.status, "completed"))),
    db.select().from(sleepRecords).where(eq(sleepRecords.userId, uid)).orderBy(desc(sleepRecords.wakeDate)).limit(1),
    db.select().from(habits).where(and(eq(habits.userId, uid), eq(habits.status, "active"))),
    db.select().from(habitOccurrences)
      .innerJoin(habits, eq(habits.id, habitOccurrences.habitId))
      .where(and(eq(habits.userId, uid), gte(habitOccurrences.date, last30), lte(habitOccurrences.date, today)))
      .then((r) => r.map((x) => x.habit_occurrences)),
    db.select().from(dailyReviews).where(and(eq(dailyReviews.userId, uid), eq(dailyReviews.date, today))).limit(1),
  ]);

  const pending = todayTasks.filter((t) => t.status !== "done");
  const doneToday = todayTasks.filter((t) => t.status === "done");
  const prRank = (p: string) => (p === "high" ? 0 : p === "medium" ? 1 : 2);
  const topTask = pending.sort((a, b) => prRank(a.priority) - prRank(b.priority))[0] ?? null;

  const focusSeconds = focusToday.reduce((acc, s) => acc + (s.elapsedSeconds ?? 0), 0);

  const todayHabits = userHabits.filter((h) => isScheduledOn(h, today));
  const occBy = new Map(occRecent.filter((o) => o.date === today).map((o) => [o.habitId, o]));
  const habitsDone = todayHabits.filter((h) => {
    const s = occBy.get(h.id)?.status;
    return s === "done" || s === "partial";
  }).length;

  const plannedRemaining = pending
    .filter((t) => t.plannedStart && t.plannedEnd)
    .reduce((acc, t) => {
      const [sh, sm] = t.plannedStart!.split(":").map(Number);
      const [eh, em] = t.plannedEnd!.split(":").map(Number);
      let d = eh * 60 + em - (sh * 60 + sm);
      if (d <= 0) d += 1440;
      return acc + d;
    }, 0);
  const estRemaining = pending
    .filter((t) => !(t.plannedStart && t.plannedEnd) && t.estimatedMinutes)
    .reduce((acc, t) => acc + (t.estimatedMinutes ?? 0), 0);

  return {
    today, tz, todayTasks, pendingCount: pending.length, doneCount: doneToday.length,
    topTask, upcoming, activeGoals,
    focusMinutesToday: Math.round(focusSeconds / 60), focusSessionsToday: focusToday.length,
    lastSleep: lastSleep[0] ?? null,
    habitsScheduled: todayHabits.length, habitsDone,
    plannedMinutesRemaining: plannedRemaining + estRemaining,
    hasReviewToday: todayReview.length > 0,
    weekStart,
    hasAnyData: todayTasks.length > 0 || activeGoals.length > 0 || focusToday.length > 0 || userHabits.length > 0 || lastSleep.length > 0,
  };
}

// ======================= HABITS =======================

export function isScheduledOn(h: Habit, iso: string): boolean {
  if (iso < h.startDate) return false;
  if (h.endDate && iso > h.endDate) return false;
  return h.weekdays.includes(faWeekdayOfIso(iso));
}

export function habitStats(h: Habit, occs: Occ[], today: string) {
  const byDate = new Map(occs.map((o) => [o.date, o]));
  const extend = (s?: string) => s === "done" || s === "partial";
  const breaks = (s?: string) => s === "missed";

  // زنجیرهٔ فعلی
  let current = 0;
  let d = today;
  let guard = 0;
  while (guard++ < 366) {
    if (!isScheduledOn(h, d)) { d = addDaysIso(d, -1); continue; }
    const st = byDate.get(d)?.status;
    if (st === "skipped") { d = addDaysIso(d, -1); continue; } // رد شدنِ عمدی زنجیره را نمی‌شکند
    if (extend(st)) { current++; d = addDaysIso(d, -1); continue; }
    if (d === today && !st) { d = addDaysIso(d, -1); continue; } // امروز هنوز ثبت نشده
    break; // missed یا روز ثبت‌نشدهٔ گذشته
  }

  // طولانی‌ترین زنجیره
  let longest = 0, run = 0;
  let cursor = h.startDate;
  guard = 0;
  while (cursor <= today && guard++ < 3660) {
    if (isScheduledOn(h, cursor)) {
      const st = byDate.get(cursor)?.status;
      if (extend(st) || st === "skipped") { if (extend(st)) run++; longest = Math.max(longest, run); }
      else if (breaks(st) || cursor < today) run = 0;
    }
    cursor = addDaysIso(cursor, 1);
  }

  // نرخ ۷ و ۳۰ روز (رد شده‌ها از مخرج حذف می‌شوند؛ روزهای آینده هم)
  const rate = (days: number) => {
    let scheduled = 0, did = 0;
    for (let i = 0; i < days; i++) {
      const dd = addDaysIso(today, -i);
      if (!isScheduledOn(h, dd)) continue;
      const st = byDate.get(dd)?.status;
      if (st === "skipped") continue;
      scheduled++;
      if (extend(st)) did++;
      else if (!st && dd === today) scheduled--; // امروز هنوز تمام نشده
    }
    return scheduled > 0 ? Math.round((did / scheduled) * 100) : null;
  };

  return { current, longest, weeklyRate: rate(7), monthRate: rate(30) };
}

// ======================= ANALYTICS =======================

export async function getAnalytics(user: User & { settings: { timezone: string; weekStart: number } }, days: number) {
  const uid = user.id;
  const tz = user.settings.timezone;
  const today = todayIso(tz);
  const start = addDaysIso(today, -(days - 1));

  const [focus, sleep, doneTasks, plannedTasks, userHabits, occs] = await Promise.all([
    db.select().from(focusSessions).where(and(
      eq(focusSessions.userId, uid), eq(focusSessions.status, "completed"),
      gte(focusSessions.localDate, start), lte(focusSessions.localDate, today))),
    db.select().from(sleepRecords).where(and(
      eq(sleepRecords.userId, uid), gte(sleepRecords.wakeDate, start), lte(sleepRecords.wakeDate, today)))
      .orderBy(asc(sleepRecords.wakeDate)),
    db.select().from(tasks).where(and(
      eq(tasks.userId, uid), eq(tasks.status, "done"),
      gte(tasks.completedDate, start), lte(tasks.completedDate, today))),
    db.select().from(tasks).where(and(
      eq(tasks.userId, uid), gte(tasks.dueDate, start), lte(tasks.dueDate, today), ne(tasks.status, "cancelled"))),
    db.select().from(habits).where(eq(habits.userId, uid)),
    db.select().from(habitOccurrences)
      .innerJoin(habits, eq(habits.id, habitOccurrences.habitId))
      .where(and(eq(habits.userId, uid), gte(habitOccurrences.date, start), lte(habitOccurrences.date, today)))
      .then((r) => r.map((x) => x.habit_occurrences)),
  ]);

  // تمرکز روزانه
  const dayList = Array.from({ length: days }, (_, i) => addDaysIso(start, i));
  const focusPerDay = new Map<string, number>();
  for (const s of focus) {
    focusPerDay.set(s.localDate, (focusPerDay.get(s.localDate) ?? 0) + Math.round((s.elapsedSeconds ?? 0) / 60));
  }
  const focusSeries = dayList.map((d) => ({ date: d, value: focusPerDay.get(d) ?? 0 }));

  // خواب
  const sleepSeries = sleep.map((s) => ({ date: s.wakeDate, value: s.durationMinutes, quality: s.quality }));
  const durations = sleep.map((s) => s.durationMinutes).filter((v): v is number => v != null);
  const avgSleep = durations.length ? Math.round(durations.reduce((a, b) => a + b, 0) / durations.length) : null;

  // وظایف: برنامه‌ریزی‌شده در برابر انجام‌شده، هفتگی
  const weeks: { start: string; planned: number; done: number }[] = [];
  const firstWeek = startOfWeekIso(start, user.settings.weekStart);
  for (let w = firstWeek; w <= today; w = addDaysIso(w, 7)) {
    const we = addDaysIso(w, 6);
    weeks.push({
      start: w,
      planned: plannedTasks.filter((t) => t.dueDate && t.dueDate >= w && t.dueDate <= we).length,
      done: doneTasks.filter((t) => t.completedDate && t.completedDate >= w && t.completedDate <= we).length,
    });
  }

  // برآورد در برابر واقعیت
  const estVsActual = doneTasks
    .filter((t) => t.estimatedMinutes && t.actualMinutes)
    .map((t) => ({ title: t.title, est: t.estimatedMinutes!, act: t.actualMinutes! }));

  // تخصیص زمان بر اساس دسته‌بندی وظایف انجام‌شده (زمان واقعی؛ در نبودش، برآورد — با برچسب)
  const catMinutes = new Map<string, number>();
  for (const t of doneTasks) {
    const mins = t.actualMinutes ?? t.estimatedMinutes;
    if (!mins) continue;
    const cat = t.category ?? "بدون دسته";
    catMinutes.set(cat, (catMinutes.get(cat) ?? 0) + mins);
  }
  const categoryShare = [...catMinutes.entries()].map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);

  // عادت‌ها
  const habitReports = userHabits.map((h) => ({
    habit: h,
    stats: habitStats(h, occs.filter((o) => o.habitId === h.id), today),
  }));

  const totalFocusMin = focus.reduce((a, s) => a + Math.round((s.elapsedSeconds ?? 0) / 60), 0);
  const interruptionsTotal = focus.reduce((a, s) => a + s.interruptionsCount, 0);
  const distractionCount = new Map<string, number>();
  for (const s of focus) for (const d of s.distractions) distractionCount.set(d, (distractionCount.get(d) ?? 0) + 1);
  const topDistractions = [...distractionCount.entries()].sort((a, b) => b[1] - a[1]).slice(0, 6);

  return {
    today, start, days, focusSeries, totalFocusMin,
    focusCount: focus.length, interruptionsTotal,
    sleepSeries, avgSleep, sleepCount: sleep.length,
    weeks, estVsActual, categoryShare, habitReports, topDistractions,
    selfFocusedMin: focus.reduce((a, s) => a + (s.focusedMinutesSelf ?? 0), 0),
  };
}

// ======================= WEEKLY REVIEW =======================

export async function getWeeklyReviewData(user: User & { settings: { timezone: string; weekStart: number } }, weekStartParam?: string) {
  const uid = user.id;
  const tz = user.settings.timezone;
  const today = todayIso(tz);
  const currentWeekStart = startOfWeekIso(today, user.settings.weekStart);
  const weekStart = weekStartParam && /^\d{4}-\d{2}-\d{2}$/.test(weekStartParam)
    ? startOfWeekIso(weekStartParam, user.settings.weekStart)
    : currentWeekStart;
  const weekEnd = addDaysIso(weekStart, 6);
  const effectiveEnd = weekEnd > today ? today : weekEnd;

  const [plannedAll, doneInWeek, focus, sleep, review, userHabits, occs, activeGoals] = await Promise.all([
    db.select().from(tasks).where(and(eq(tasks.userId, uid), gte(tasks.dueDate, weekStart), lte(tasks.dueDate, weekEnd), ne(tasks.status, "cancelled"))),
    db.select().from(tasks).where(and(eq(tasks.userId, uid), eq(tasks.status, "done"), gte(tasks.completedDate, weekStart), lte(tasks.completedDate, weekEnd))),
    db.select().from(focusSessions).where(and(eq(focusSessions.userId, uid), eq(focusSessions.status, "completed"), gte(focusSessions.localDate, weekStart), lte(focusSessions.localDate, weekEnd))),
    db.select().from(sleepRecords).where(and(eq(sleepRecords.userId, uid), gte(sleepRecords.wakeDate, weekStart), lte(sleepRecords.wakeDate, weekEnd))),
    db.select().from(weeklyReviews).where(and(eq(weeklyReviews.userId, uid), eq(weeklyReviews.weekStart, weekStart))).limit(1),
    db.select().from(habits).where(and(eq(habits.userId, uid), eq(habits.status, "active"))),
    db.select().from(habitOccurrences)
      .innerJoin(habits, eq(habits.id, habitOccurrences.habitId))
      .where(and(eq(habits.userId, uid), gte(habitOccurrences.date, weekStart), lte(habitOccurrences.date, weekEnd)))
      .then((r) => r.map((x) => x.habit_occurrences)),
    db.select().from(goals).where(and(eq(goals.userId, uid), eq(goals.status, "active"))),
  ]);

  const overdue = await db.select().from(tasks).where(and(
    eq(tasks.userId, uid), lte(tasks.dueDate, addDaysIso(today, -1)), ne(tasks.status, "done"), ne(tasks.status, "cancelled")));

  const focusMin = focus.reduce((a, s) => a + Math.round((s.elapsedSeconds ?? 0) / 60), 0);
  const durations = sleep.map((s) => s.durationMinutes).filter((v): v is number => v != null);

  let habitScheduled = 0, habitDone = 0;
  for (const h of userHabits) {
    for (let d = weekStart; d <= effectiveEnd; d = addDaysIso(d, 1)) {
      if (!isScheduledOn(h, d)) continue;
      const st = occs.find((o) => o.habitId === h.id && o.date === d)?.status;
      if (st === "skipped") continue;
      habitScheduled++;
      if (st === "done" || st === "partial") habitDone++;
    }
  }
  const habitRate = habitScheduled > 0 ? Math.round((habitDone / habitScheduled) * 100) : null;

  const distractionCount = new Map<string, number>();
  for (const s of focus) for (const d of s.distractions) distractionCount.set(d, (distractionCount.get(d) ?? 0) + 1);
  const topDistractions = [...distractionCount.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5);

  // وظایفی که بارها عقب افتاده‌اند: در انتظار و سررسید گذشتهٔ چندروزه
  const postponed = overdue.filter((t) => t.dueDate && diffDaysIso(t.dueDate, today) >= 3).slice(0, 5);

  const hasData = plannedAll.length > 0 || focus.length > 0 || sleep.length > 0 || habitScheduled > 0;

  const suggestions: { key: string; text: string }[] = [];
  if (hasData) {
    if (focus.length > 0 && focus.length < 3)
      suggestions.push({ key: "focus-low", text: "این هفته کمتر از ۳ جلسهٔ تمرکز داشته‌اید. شاید باکتنی یک جلسهٔ کوتاه ۱۵ دقیقه‌ای در روز، نقطهٔ شروع خوبی باشد." });
    if (sleep.length === 0)
      suggestions.push({ key: "sleep-none", text: "هیچ رکورد خوابی برای این هفته ثبت نشده. ثبت سادهٔ ساعت خواب و بیداری، تصویر روشن‌تری از انرژی‌تان می‌دهد." });
    if (habitRate !== null && habitRate < 50)
      suggestions.push({ key: "habits-low", text: `نرخ انجام عادت‌ها ${habitRate}٪ بوده. شاید کوچک‌تر کردن هدف حداقلی عادت‌ها، ادامه‌دادن را آسان‌تر کند.` });
    if (postponed.length > 2)
      suggestions.push({ key: "postponed", text: `${postponed.length} وظیفه بیش از چند روز معوق مانده‌اند. می‌توانید هرکدام را کوچک‌تر کنید، زمان‌بندی کنید یا آگاهانه حذفشان کنید.` });
    if (plannedAll.length > 0 && doneInWeek.length / plannedAll.length < 0.6)
      suggestions.push({ key: "plan-heavy", text: "نسبت انجام به برنامه زیر ۶۰٪ است. شاید برنامهٔ روزانه کمی سبک‌تر و واقع‌بینانه‌تر شود." });
  }

  return {
    today, weekStart, weekEnd, currentWeekStart,
    planned: plannedAll.length, done: doneInWeek.length,
    focusMin, focusCount: focus.length,
    sleepCount: sleep.length, avgSleep: durations.length ? Math.round(durations.reduce((a, b) => a + b) / durations.length) : null,
    habitRate, habitDone, habitScheduled,
    topDistractions, postponed: postponed.map((t) => ({ id: t.id, title: t.title, dueDate: t.dueDate })),
    goalsProgress: activeGoals.slice(0, 5).map((g) => ({ id: g.id, title: g.title, progress: g.progress })),
    reflection: review[0]?.reflection ?? "",
    dismissed: review[0]?.dismissedSuggestions ?? [],
    suggestions, hasData,
  };
}

// ======================= misc helpers =======================

export async function getGoalsMilestones(goalIds: string[]) {
  if (!goalIds.length) return new Map<string, (typeof milestones.$inferSelect)[]>();
  const rows = await db.select().from(milestones);
  const map = new Map<string, (typeof milestones.$inferSelect)[]>();
  for (const m of rows) {
    if (!goalIds.includes(m.goalId)) continue;
    const arr = map.get(m.goalId) ?? [];
    arr.push(m);
    map.set(m.goalId, arr);
  }
  for (const arr of map.values()) arr.sort((a, b) => a.sortOrder - b.sortOrder || a.title.localeCompare(b.title));
  return map;
}

export function fmtSleepSummary(s: Sleep | null, tz: string) {
  if (!s) return null;
  return {
    bed: fmtTimeInTz(s.bedTime, tz),
    wake: fmtTimeInTz(s.wakeTime, tz),
    duration: s.durationMinutes,
    quality: s.quality,
    wakeDate: s.wakeDate,
  };
}

export { todayIso, addDaysIso, isoInTz };
