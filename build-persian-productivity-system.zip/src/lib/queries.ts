import "server-only";
import { and, asc, desc, eq, inArray, ne, notInArray } from "drizzle-orm";
import { db } from "@/db";
import { goals, projects, tasks } from "@/db/schema";

export type LinkOptions = {
  goals: { id: string; title: string }[];
  projects: { id: string; name: string }[];
  tasks: { id: string; title: string }[];
};

/** Options for "link to goal / project / task" selects – scoped to the user. */
export async function getLinkOptions(userId: string): Promise<LinkOptions> {
  const [g, p, t] = await Promise.all([
    db
      .select({ id: goals.id, title: goals.title })
      .from(goals)
      .where(and(eq(goals.userId, userId), ne(goals.status, "archived")))
      .orderBy(asc(goals.title)),
    db
      .select({ id: projects.id, name: projects.name })
      .from(projects)
      .where(and(eq(projects.userId, userId), notInArray(projects.status, ["archived"])))
      .orderBy(asc(projects.name)),
    db
      .select({ id: tasks.id, title: tasks.title })
      .from(tasks)
      .where(and(eq(tasks.userId, userId), inArray(tasks.status, ["todo", "in_progress"])))
      .orderBy(desc(tasks.createdAt))
      .limit(200),
  ]);
  return { goals: g, projects: p, tasks: t };
}

export type TaskRowData = typeof tasks.$inferSelect;
