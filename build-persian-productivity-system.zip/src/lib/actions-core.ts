"use server";

import { revalidatePath } from "next/cache";
import { and, eq, asc } from "drizzle-orm";
import { db } from "@/db";
import { tasks, goals, milestones } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import {
  cleanStr, reqStr, oneOf, intInRange, validIsoDate, validTime, errMsg,
  type ActionResult,
} from "@/lib/utils";
import { todayIso, addDaysIso, faWeekdayOfIso } from "@/lib/jalali";

function refresh() {
  revalidatePath("/", "layout");
}

// ======================= TASKS =======================

export type TaskInput = {
  title?: unknown; description?: unknown; dueDate?: unknown;
  plannedStart?: unknown; plannedEnd?: unknown; estimatedMinutes?: unknown;
  actualMinutes?: unknown; priority?: unknown; status?: unknown; category?: unknown;
  goalId?: unknown; energy?: unknown; tags?: unknown; recurrence?: unknown; notes?: unknown;
  force?: unknown;
};

function parseTaskInput(input: TaskInput) {
  return {
    title: reqStr(input.title, "عنوان وظیفه را بنویسید.", 200),
    description: cleanStr(input.description, 2000),
    dueDate: validIsoDate(input.dueDate),
    plannedStart: validTime(input.plannedStart),
    plannedEnd: validTime(input.plannedEnd),
    estimatedMinutes: intInRange(input.estimatedMinutes ?? null, 1, 24 * 60),
    actualMinutes: intInRange(input.actualMinutes ?? null, 1, 24 * 60),
    priority: oneOf(input.priority, ["low", "medium", "high"] as const, "medium"),
    category: cleanStr(input.category, 80),
    energy: input.energy ? oneOf(input.energy, ["low", "medium", "high"] as const, "medium") : null,
    tags: cleanStr(input.tags, 200),
    recurrence: oneOf(input.recurrence, ["none", "daily", "weekly", "weekdays"] as const, "none"),
    goalId: typeof input.goalId === "string" && input.goalId.length > 10 ? input.goalId : null,
    notes: cleanStr(input.notes, 2000),
  };
}

async function findOverlap(userId: string, excludeId: string | null, dueDate: string, start: string, end: string) {
  const dayTasks = await db
    .select({ id: tasks.id, title: tasks.title, plannedStart: tasks.plannedStart, plannedEnd: tasks.plannedEnd })
    .from(tasks)
    .where(and(eq(tasks.userId, userId), eq(tasks.dueDate, dueDate)));
  const toMin = (t: string) => { const [h, m] = t.split(":").map(Number); return h * 60 + m; };
  const s = toMin(start), e = toMin(end) <= s ? toMin(end) + 1440 : toMin(end);
  for (const t of dayTasks) {
    if (!t.plannedStart || !t.plannedEnd) continue;
    if (excludeId && t.id === excludeId) continue;
    const ts = toMin(t.plannedStart), te = toMin(t.plannedEnd) <= ts ? toMin(t.plannedEnd) + 1440 : toMin(t.plannedEnd);
    if (s < te && ts < e) return t.title;
  }
  return null;
}

export async function createTask(input: TaskInput): Promise<ActionResult & { conflict?: string; id?: string }> {
  const user = await requireUser();
  try {
    const data = parseTaskInput(input);
    if ((data.plannedStart && !data.plannedEnd) || (!data.plannedStart && data.plannedEnd)) {
      return { error: "برای زمان‌بندی، هم ساعت شروع و هم پایان لازم است." };
    }
    if (data.dueDate && data.plannedStart && data.plannedEnd && input.force !== true) {
      const conflict = await findOverlap(user.id, null, data.dueDate, data.plannedStart, data.plannedEnd);
      if (conflict) return { conflict };
    }
    const inserted = await db.insert(tasks).values({ ...data, userId: user.id }).returning({ id: tasks.id });
    refresh();
    return { success: "وظیفه ثبت شد.", id: inserted[0]?.id };
  } catch (e) {
    return { error: errMsg(e) };
  }
}

export async function updateTask(id: string, input: TaskInput): Promise<ActionResult & { conflict?: string }> {
  const user = await requireUser();
  try {
    const data = parseTaskInput(input);
    if ((data.plannedStart && !data.plannedEnd) || (!data.plannedStart && data.plannedEnd)) {
      return { error: "برای زمان‌بندی، هم ساعت شروع و هم پایان لازم است." };
    }
    if (data.dueDate && data.plannedStart && data.plannedEnd && input.force !== true) {
      const conflict = await findOverlap(user.id, id, data.dueDate, data.plannedStart, data.plannedEnd);
      if (conflict) return { conflict };
    }
    const res = await db.update(tasks).set({ ...data, updatedAt: new Date() })
      .where(and(eq(tasks.id, id), eq(tasks.userId, user.id))).returning({ id: tasks.id });
    if (!res.length) return { error: "وظیفه پیدا نشد." };
    refresh();
    return { success: "وظیفه به‌روزرسانی شد." };
  } catch (e) {
    return { error: errMsg(e) };
  }
}

export async function deleteTask(id: string): Promise<ActionResult> {
  const user = await requireUser();
  await db.delete(tasks).where(and(eq(tasks.id, id), eq(tasks.userId, user.id)));
  refresh();
  return { success: "وظیفه حذف شد." };
}

export async function moveTask(id: string, newDate: unknown): Promise<ActionResult> {
  const user = await requireUser();
  const date = validIsoDate(newDate);
  if (!date) return { error: "تاریخ نامعتبر است." };
  const res = await db.update(tasks).set({ dueDate: date, updatedAt: new Date() })
    .where(and(eq(tasks.id, id), eq(tasks.userId, user.id))).returning({ id: tasks.id });
  if (!res.length) return { error: "وظیفه پیدا نشد." };
  refresh();
  return { success: "وظیفه منتقل شد." };
}

export async function setTaskStatus(id: string, status: unknown, actualMinutes?: unknown): Promise<ActionResult> {
  const user = await requireUser();
  const st = oneOf(status, ["pending", "in_progress", "done", "cancelled"] as const, "pending");
  const tz = user.settings.timezone;
  try {
    await db.transaction(async (tx) => {
      const rows = await tx.select().from(tasks).where(and(eq(tasks.id, id), eq(tasks.userId, user.id))).limit(1);
      const task = rows[0];
      if (!task) throw new Error("وظیفه پیدا نشد.");
      const now = new Date();
      const actual = intInRange(actualMinutes ?? null, 1, 24 * 60);
      await tx.update(tasks).set({
        status: st,
        completedAt: st === "done" ? now : null,
        completedDate: st === "done" ? todayIso(tz) : null,
        actualMinutes: st === "done" && actual ? actual : task.actualMinutes,
        updatedAt: now,
      }).where(eq(tasks.id, id));
      // ایجاد نمونهٔ بعدی وظیفهٔ تکرارشونده بدون دست‌کاری نمونهٔ فعلی
      if (st === "done" && task.recurrence !== "none" && task.dueDate) {
        let next = task.dueDate;
        if (task.recurrence === "daily") next = addDaysIso(task.dueDate, 1);
        else if (task.recurrence === "weekly") next = addDaysIso(task.dueDate, 7);
        else if (task.recurrence === "weekdays") {
          do { next = addDaysIso(next, 1); } while (faWeekdayOfIso(next) === 6); // جمعه را رد کن
        }
        await tx.insert(tasks).values({
          userId: user.id, goalId: task.goalId, title: task.title, description: task.description,
          dueDate: next, plannedStart: task.plannedStart, plannedEnd: task.plannedEnd,
          estimatedMinutes: task.estimatedMinutes, priority: task.priority, status: "pending",
          category: task.category, energy: task.energy, tags: task.tags, recurrence: task.recurrence,
          notes: task.notes,
        });
      }
    });
    refresh();
    return { success: st === "done" ? "وظیفه انجام شد. آفرین!" : "وضعیت به‌روزرسانی شد." };
  } catch (e) {
    return { error: errMsg(e) };
  }
}

export async function listTodayTasks(): Promise<{ id: string; title: string; dueDate: string | null }[]> {
  const user = await requireUser();
  return db.select({ id: tasks.id, title: tasks.title, dueDate: tasks.dueDate })
    .from(tasks).where(eq(tasks.userId, user.id)).orderBy(asc(tasks.createdAt)).limit(500);
}

// ======================= GOALS =======================

export type GoalInput = {
  title?: unknown; description?: unknown; category?: unknown; timeframe?: unknown;
  priority?: unknown; status?: unknown; startDate?: unknown; targetDate?: unknown;
  successCriteria?: unknown; progress?: unknown; notes?: unknown; parentId?: unknown;
};

function parseGoalInput(input: GoalInput) {
  return {
    title: reqStr(input.title, "عنوان هدف را بنویسید.", 200),
    description: cleanStr(input.description, 2000),
    category: cleanStr(input.category, 80),
    timeframe: oneOf(input.timeframe, ["short", "medium", "long"] as const, "medium"),
    priority: oneOf(input.priority, ["low", "medium", "high"] as const, "medium"),
    status: oneOf(input.status, ["active", "paused", "completed", "archived"] as const, "active"),
    startDate: validIsoDate(input.startDate),
    targetDate: validIsoDate(input.targetDate),
    successCriteria: cleanStr(input.successCriteria, 500),
    progress: intInRange(input.progress ?? 0, 0, 100) ?? 0,
    notes: cleanStr(input.notes, 2000),
    parentId: typeof input.parentId === "string" && input.parentId.length > 10 ? input.parentId : null,
  };
}

export async function createGoal(input: GoalInput): Promise<ActionResult> {
  const user = await requireUser();
  try {
    await db.insert(goals).values({ ...parseGoalInput(input), userId: user.id });
    refresh();
    return { success: "هدف ساخته شد." };
  } catch (e) {
    return { error: errMsg(e) };
  }
}

export async function updateGoal(id: string, input: GoalInput): Promise<ActionResult> {
  const user = await requireUser();
  try {
    const res = await db.update(goals).set({ ...parseGoalInput(input), updatedAt: new Date() })
      .where(and(eq(goals.id, id), eq(goals.userId, user.id))).returning({ id: goals.id });
    if (!res.length) return { error: "هدف پیدا نشد." };
    refresh();
    return { success: "هدف به‌روزرسانی شد." };
  } catch (e) {
    return { error: errMsg(e) };
  }
}

export async function setGoalStatus(id: string, status: unknown): Promise<ActionResult> {
  const user = await requireUser();
  const st = oneOf(status, ["active", "paused", "completed", "archived"] as const, "active");
  await db.update(goals).set({ status: st, updatedAt: new Date() })
    .where(and(eq(goals.id, id), eq(goals.userId, user.id)));
  refresh();
  return { success: st === "archived" ? "هدف بایگانی شد. سوابق فعالیت‌ها حفظ می‌ماند." : "به‌روزرسانی شد." };
}

export async function setGoalProgress(id: string, progress: unknown): Promise<ActionResult> {
  const user = await requireUser();
  const p = intInRange(progress, 0, 100) ?? 0;
  const status = p >= 100 ? "completed" : undefined;
  await db.update(goals).set({ progress: p, updatedAt: new Date(), ...(status ? { status } : {}) })
    .where(and(eq(goals.id, id), eq(goals.userId, user.id)));
  refresh();
  return { success: "پیشرفت ثبت شد." };
}

export async function deleteGoal(id: string): Promise<ActionResult> {
  const user = await requireUser();
  // با onDelete: set null در وظایف/جلسات، سوابق تاریخی حفظ می‌شود؛ سنگ‌نماها همراه هدف حذف می‌شوند
  await db.delete(goals).where(and(eq(goals.id, id), eq(goals.userId, user.id)));
  refresh();
  return { success: "هدف حذف شد." };
}

// ---------- milestones ----------

export async function addMilestone(goalId: string, title: unknown, dueDate?: unknown): Promise<ActionResult> {
  const user = await requireUser();
  try {
    const t = reqStr(title, "عنوان سنگ‌نما را بنویسید.", 200);
    const g = await db.select({ id: goals.id }).from(goals)
      .where(and(eq(goals.id, goalId), eq(goals.userId, user.id))).limit(1);
    if (!g.length) return { error: "هدف پیدا نشد." };
    await db.insert(milestones).values({ goalId, title: t, dueDate: validIsoDate(dueDate) });
    refresh();
    return { success: "سنگ‌نما اضافه شد." };
  } catch (e) {
    return { error: errMsg(e) };
  }
}

export async function toggleMilestone(id: string, goalId: string): Promise<ActionResult> {
  const user = await requireUser();
  const g = await db.select({ id: goals.id }).from(goals)
    .where(and(eq(goals.id, goalId), eq(goals.userId, user.id))).limit(1);
  if (!g.length) return { error: "دسترسی مجاز نیست." };
  const rows = await db.select().from(milestones).where(eq(milestones.id, id)).limit(1);
  const m = rows[0];
  if (!m) return { error: "سنگ‌نما پیدا نشد." };
  await db.update(milestones).set({ done: !m.done, doneAt: !m.done ? new Date() : null })
    .where(eq(milestones.id, id));
  refresh();
  return { success: "به‌روزرسانی شد." };
}

export async function deleteMilestone(id: string, goalId: string): Promise<ActionResult> {
  const user = await requireUser();
  const g = await db.select({ id: goals.id }).from(goals)
    .where(and(eq(goals.id, goalId), eq(goals.userId, user.id))).limit(1);
  if (!g.length) return { error: "دسترسی مجاز نیست." };
  await db.delete(milestones).where(eq(milestones.id, id));
  refresh();
  return { success: "حذف شد." };
}
