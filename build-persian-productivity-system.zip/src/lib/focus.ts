export type FocusState = {
  status: string;
  startedAt: Date | string;
  pausedAt: Date | string | null;
  pausedSeconds: number;
  plannedMinutes: number;
};

const ts = (d: Date | string) => (typeof d === "string" ? new Date(d).getTime() : d.getTime());

/** Measured elapsed seconds, excluding pauses. Uses server timestamps, so it survives refreshes. */
export function elapsedSeconds(s: FocusState, now: number = Date.now()) {
  const end = s.status === "paused" && s.pausedAt ? ts(s.pausedAt) : now;
  return Math.max(0, Math.floor((end - ts(s.startedAt)) / 1000) - s.pausedSeconds);
}

export function remainingSeconds(s: FocusState, now: number = Date.now()) {
  return s.plannedMinutes * 60 - elapsedSeconds(s, now);
}

/** Pause adds to the paused counter once resumed. */
export function resumedPausedSeconds(s: FocusState, now: number = Date.now()) {
  if (!s.pausedAt) return s.pausedSeconds;
  return s.pausedSeconds + Math.max(0, Math.floor((now - ts(s.pausedAt)) / 1000));
}

/** Self-reported focused minutes can never exceed measured elapsed minutes. */
export function clampFocused(focusedMinutes: number | null | undefined, elapsedSec: number) {
  if (focusedMinutes === null || focusedMinutes === undefined || Number.isNaN(focusedMinutes)) return null;
  return Math.max(0, Math.min(Math.round(focusedMinutes), Math.ceil(elapsedSec / 60)));
}
