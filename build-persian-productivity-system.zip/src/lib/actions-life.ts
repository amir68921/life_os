"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { and, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import {
  users, userSettings, goals, milestones, tasks, focusSessions, interruptions,
  sleepRecords, habits, habitOccurrences, dailyReviews, weeklyReviews,
} from "@/db/schema";
import { requireUser, destroySession, checkPassword, hashPassword } from "@/lib/auth";
import { cleanStr, oneOf, intInRange, validIsoDate, validTime, errMsg, parseDigitsSafe, type ActionResult } from "@/lib/utils";
import { todayIso, isoInTz } from "@/lib/jalali";

function refresh() {
  revalidatePath("/", "layout");
}

/** تبدیل تاریخ/ساعت محلیِ کاربر به لحظهٔ UTC با توجه به منطقهٔ زمانی */
function zonedTimeToUtc(iso: string, hhmm: string, tz: string): Date {
  const guess = new Date(`${iso}T${hhmm}:00.000Z`);
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", hourCycle: "h23",
  }).formatToParts(guess);
  const get = (t: string) => parts.find((p) => p.type === t)?.value ?? "";
  const asUtc = Date.UTC(+get("year"), +get("month") - 1, +get("day"), (+get("hour")) % 24, +get("minute"));
  return new Date(guess.getTime() + (guess.getTime() - asUtc));
}

// ======================= FOCUS =======================

export type ActiveFocus = {
  id: string; objective: string | null; plannedMinutes: number;
  status: string; startedAt: string; pausedSeconds: number; pauseStartedAt: string | null;
  taskTitle: string | null; goalTitle: string | null; localDate: string;
};

export async function getActiveFocus(): Promise<ActiveFocus | null> {
  const user = await requireUser();
  const rows = await db
    .select({ s: focusSessions, taskTitle: tasks.title, goalTitle: goals.title })
    .from(focusSessions)
    .leftJoin(tasks, eq(tasks.id, focusSessions.taskId))
    .leftJoin(goals, eq(goals.id, focusSessions.goalId))
    .where(and(eq(focusSessions.userId, user.id), inArray(focusSessions.status, ["active", "paused"])))
    .limit(1);
  const r = rows[0];
  if (!r) return null;
  return {
    id: r.s.id, objective: r.s.objective, plannedMinutes: r.s.plannedMinutes,
    status: r.s.status, startedAt: r.s.startedAt.toISOString(), pausedSeconds: r.s.pausedSeconds,
    pauseStartedAt: r.s.pauseStartedAt ? r.s.pauseStartedAt.toISOString() : null,
    taskTitle: r.taskTitle, goalTitle: r.goalTitle, localDate: r.s.localDate,
  };
}

export async function startFocus(input: {
  taskId?: unknown; goalId?: unknown; objective?: unknown; plannedMinutes?: unknown;
  energyStart?: unknown; focusRatingStart?: unknown;
}): Promise<ActionResult & { id?: string }> {
  const user = await requireUser();
  try {
    const existing = await db.select({ id: focusSessions.id }).from(focusSessions)
      .where(and(eq(focusSessions.userId, user.id), inArray(focusSessions.status, ["active", "paused"]))).limit(1);
    if (existing.length) return { error: "یک جلسهٔ تمرکزِ ناتمام دارید؛ ابتدا آن را تمام یا لغو کنید.", id: existing[0].id };
    const planned = intInRange(input.plannedMinutes, 5, 480) ?? user.settings.defaultFocusMinutes;
    const inserted = await db.insert(focusSessions).values({
      userId: user.id,
      taskId: typeof input.taskId === "string" && input.taskId.length > 10 ? input.taskId : null,
      goalId: typeof input.goalId === "string" && input.goalId.length > 10 ? input.goalId : null,
      objective: cleanStr(input.objective, 300),
      plannedMinutes: planned,
      energyStart: intInRange(input.energyStart ?? null, 1, 5),
      focusRatingStart: intInRange(input.focusRatingStart ?? null, 1, 5),
      localDate: todayIso(user.settings.timezone),
      status: "active",
      startedAt: new Date(),
    }).returning({ id: focusSessions.id });
    refresh();
    return { success: "جلسه شروع شد. موفق باشید!", id: inserted[0]?.id };
  } catch (e) {
    return { error: errMsg(e) };
  }
}

async function ownSession(id: string, userId: string) {
  const rows = await db.select().from(focusSessions)
    .where(and(eq(focusSessions.id, id), eq(focusSessions.userId, userId))).limit(1);
  return rows[0] ?? null;
}

function elapsedOf(s: typeof focusSessions.$inferSelect, now: Date): number {
  let paused = s.pausedSeconds;
  if (s.status === "paused" && s.pauseStartedAt) {
    paused += Math.max(0, Math.round((now.getTime() - s.pauseStartedAt.getTime()) / 1000));
  }
  return Math.max(0, Math.round((now.getTime() - s.startedAt.getTime()) / 1000) - paused);
}

export async function pauseFocus(id: string): Promise<ActionResult> {
  const user = await requireUser();
  const s = await ownSession(id, user.id);
  if (!s || s.status !== "active") return { error: "جلسهٔ فعالی پیدا نشد." };
  await db.update(focusSessions).set({ status: "paused", pauseStartedAt: new Date() })
    .where(eq(focusSessions.id, id));
  refresh();
  return { success: "مکث شد." };
}

export async function resumeFocus(id: string): Promise<ActionResult> {
  const user = await requireUser();
  const s = await ownSession(id, user.id);
  if (!s || s.status !== "paused" || !s.pauseStartedAt) return { error: "جلسهٔ متوقف‌شده‌ای پیدا نشد." };
  const extra = Math.max(0, Math.round((Date.now() - s.pauseStartedAt.getTime()) / 1000));
  await db.update(focusSessions).set({
    status: "active", pauseStartedAt: null, pausedSeconds: s.pausedSeconds + extra,
  }).where(eq(focusSessions.id, id));
  refresh();
  return { success: "ادامهٔ جلسه." };
}

export async function interruptFocus(id: string, note: unknown): Promise<ActionResult> {
  const user = await requireUser();
  const s = await ownSession(id, user.id);
  if (!s || (s.status !== "active" && s.status !== "paused")) return { error: "جلسهٔ فعالی پیدا نشد." };
  await db.transaction(async (tx) => {
    await tx.insert(interruptions).values({ sessionId: id, note: cleanStr(note, 300) });
    await tx.update(focusSessions).set({ interruptionsCount: s.interruptionsCount + 1 })
      .where(eq(focusSessions.id, id));
  });
  refresh();
  return { success: "وقفه ثبت شد." };
}

export async function finishFocus(id: string, report: {
  achievedObjective?: unknown; focusRatingEnd?: unknown; focusedMinutesSelf?: unknown;
  energyEnd?: unknown; interruptionsNote?: unknown; nextSteps?: unknown; distractions?: unknown;
}): Promise<ActionResult> {
  const user = await requireUser();
  const s = await ownSession(id, user.id);
  if (!s || (s.status !== "active" && s.status !== "paused")) return { error: "این جلسه قبلاً بسته شده است." };
  const now = new Date();
  let paused = s.pausedSeconds;
  if (s.status === "paused" && s.pauseStartedAt) {
    paused += Math.max(0, Math.round((now.getTime() - s.pauseStartedAt.getTime()) / 1000));
  }
  const elapsed = elapsedOf({ ...s, pausedSeconds: paused, status: "active" }, now);
  const distractions = Array.isArray(report.distractions)
    ? report.distractions.map((d) => cleanStr(d, 60)).filter((d): d is string => Boolean(d)).slice(0, 10)
    : [];
  await db.update(focusSessions).set({
    status: "completed", endedAt: now, pauseStartedAt: null, pausedSeconds: paused,
    elapsedSeconds: elapsed,
    achievedObjective: typeof report.achievedObjective === "boolean" ? report.achievedObjective : null,
    focusRatingEnd: intInRange(report.focusRatingEnd ?? null, 1, 5),
    energyEnd: intInRange(report.energyEnd ?? null, 1, 5),
    focusedMinutesSelf: intInRange(report.focusedMinutesSelf ?? null, 0, Math.max(1, Math.ceil(elapsed / 60))),
    interruptionsNote: cleanStr(report.interruptionsNote, 500),
    nextSteps: cleanStr(report.nextSteps, 500),
    distractions,
  }).where(eq(focusSessions.id, id));
  refresh();
  return { success: "جلسه ثبت شد. دستتان درد نکند!" };
}

export async function cancelFocus(id: string): Promise<ActionResult> {
  const user = await requireUser();
  const s = await ownSession(id, user.id);
  if (!s || (s.status !== "active" && s.status !== "paused")) return { error: "جلسهٔ فعالی پیدا نشد." };
  const now = new Date();
  await db.update(focusSessions).set({
    status: "cancelled", endedAt: now, pauseStartedAt: null, elapsedSeconds: elapsedOf(s, now),
  }).where(eq(focusSessions.id, id));
  refresh();
  return { success: "جلسه لغو شد (به‌عنوان کار تمرکزی شمرده نمی‌شود)." };
}

export async function correctFocus(id: string, input: {
  focusedMinutesSelf?: unknown; interruptionsNote?: unknown; nextSteps?: unknown; distractions?: unknown;
}): Promise<ActionResult> {
  const user = await requireUser();
  const s = await ownSession(id, user.id);
  if (!s || s.status !== "completed") return { error: "فقط جلسات تمام‌شده قابل اصلاح‌اند." };
  const distractions = Array.isArray(input.distractions)
    ? input.distractions.map((d) => cleanStr(d, 60)).filter((d): d is string => Boolean(d)).slice(0, 10)
    : s.distractions;
  const maxSelf = Math.max(1, Math.ceil((s.elapsedSeconds ?? 0) / 60));
  await db.update(focusSessions).set({
    focusedMinutesSelf: intInRange(input.focusedMinutesSelf ?? s.focusedMinutesSelf, 0, maxSelf),
    interruptionsNote: cleanStr(input.interruptionsNote, 500) ?? s.interruptionsNote,
    nextSteps: cleanStr(input.nextSteps, 500) ?? s.nextSteps,
    distractions,
  }).where(eq(focusSessions.id, id));
  refresh();
  return { success: "رکورد جلسه اصلاح شد." };
}

export async function deleteFocus(id: string): Promise<ActionResult> {
  const user = await requireUser();
  await db.delete(focusSessions).where(and(eq(focusSessions.id, id), eq(focusSessions.userId, user.id)));
  refresh();
  return { success: "رکورد جلسه حذف شد." };
}

// ======================= SLEEP =======================

export async function saveSleep(input: {
  id?: unknown; bedDate?: unknown; bedTime?: unknown; wakeDate?: unknown; wakeTime?: unknown;
  fallAsleepMinutes?: unknown; quality?: unknown; morningEnergy?: unknown; awakenings?: unknown; notes?: unknown;
}): Promise<ActionResult> {
  const user = await requireUser();
  try {
    const tz = user.settings.timezone;
    const bedDate = validIsoDate(input.bedDate);
    const bedT = validTime(input.bedTime);
    const wakeDate = validIsoDate(input.wakeDate);
    const wakeT = validTime(input.wakeTime);
    if (!bedDate || !bedT || !wakeDate || !wakeT) return { error: "تاریخ و ساعت خواب و بیداری را کامل وارد کنید." };
    const bed = zonedTimeToUtc(bedDate, bedT, tz);
    const wake = zonedTimeToUtc(wakeDate, wakeT, tz);
    if (wake.getTime() <= bed.getTime()) return { error: "زمان بیدار شدن باید بعد از خوابیدن باشد (عبور از نیمه‌شب درست است)." };
    if (wake.getTime() - bed.getTime() > 24 * 3600 * 1000) return { error: "بازهٔ خواب بیشتر از ۲۴ ساعت است؛ ورودی‌ها را بررسی کنید." };
    const latency = intInRange(input.fallAsleepMinutes ?? null, 0, 300);
    const fallAsleep = latency != null ? new Date(bed.getTime() + latency * 60000) : null;
    const duration = fallAsleep ? Math.round((wake.getTime() - fallAsleep.getTime()) / 60000) : null;
    const values = {
      bedTime: bed, wakeTime: wake, fallAsleepTime: fallAsleep, durationMinutes: duration,
      quality: intInRange(input.quality ?? null, 1, 5),
      morningEnergy: intInRange(input.morningEnergy ?? null, 1, 5),
      awakenings: intInRange(input.awakenings ?? null, 0, 50),
      notes: cleanStr(input.notes, 1000),
      source: "manual" as const,
    };
    if (typeof input.id === "string" && input.id.length > 10) {
      const res = await db.update(sleepRecords).set(values)
        .where(and(eq(sleepRecords.id, input.id), eq(sleepRecords.userId, user.id))).returning({ id: sleepRecords.id });
      if (!res.length) return { error: "رکورد خواب پیدا نشد." };
    } else {
      await db.insert(sleepRecords).values({ ...values, userId: user.id, wakeDate })
        .onConflictDoUpdate({ target: [sleepRecords.userId, sleepRecords.wakeDate], set: values });
    }
    refresh();
    return { success: "خواب ثبت شد." };
  } catch (e) {
    return { error: errMsg(e) };
  }
}

export async function deleteSleep(id: string): Promise<ActionResult> {
  const user = await requireUser();
  await db.delete(sleepRecords).where(and(eq(sleepRecords.id, id), eq(sleepRecords.userId, user.id)));
  refresh();
  return { success: "رکورد خواب حذف شد." };
}

// ======================= HABITS =======================

export async function saveHabit(input: {
  id?: unknown; name?: unknown; description?: unknown; category?: unknown; frequency?: unknown;
  weekdays?: unknown; minTarget?: unknown; idealTarget?: unknown; unit?: unknown;
  startDate?: unknown; endDate?: unknown;
}): Promise<ActionResult> {
  const user = await requireUser();
  try {
    const name = typeof input.name === "string" ? input.name.trim().slice(0, 120) : "";
    if (!name) return { error: "نام عادت را بنویسید." };
    const frequency = oneOf(input.frequency, ["daily", "custom"] as const, "daily");
    let weekdays = Array.isArray(input.weekdays)
      ? input.weekdays.map(Number).filter((n) => n >= 0 && n <= 6)
      : [];
    weekdays = [...new Set(weekdays)];
    if (frequency === "custom" && weekdays.length === 0) return { error: "برای برنامهٔ دلخواه، دست‌کم یک روز هفته را انتخاب کنید." };
    const values = {
      name,
      description: cleanStr(input.description, 1000),
      category: cleanStr(input.category, 80),
      frequency,
      weekdays: frequency === "daily" ? [0, 1, 2, 3, 4, 5, 6] : weekdays,
      minTarget: intInRange(input.minTarget ?? 1, 1, 10000) ?? 1,
      idealTarget: intInRange(input.idealTarget ?? null, 1, 10000),
      unit: cleanStr(input.unit, 40),
      startDate: validIsoDate(input.startDate) ?? todayIso(user.settings.timezone),
      endDate: validIsoDate(input.endDate),
    };
    if (typeof input.id === "string" && input.id.length > 10) {
      const res = await db.update(habits).set(values)
        .where(and(eq(habits.id, input.id), eq(habits.userId, user.id))).returning({ id: habits.id });
      if (!res.length) return { error: "عادت پیدا نشد." };
    } else {
      await db.insert(habits).values({ ...values, userId: user.id });
    }
    refresh();
    return { success: "عادت ذخیره شد." };
  } catch (e) {
    return { error: errMsg(e) };
  }
}

export async function toggleHabitPause(id: string): Promise<ActionResult> {
  const user = await requireUser();
  const rows = await db.select().from(habits).where(and(eq(habits.id, id), eq(habits.userId, user.id))).limit(1);
  const h = rows[0];
  if (!h) return { error: "عادت پیدا نشد." };
  const next = h.status === "active" ? "paused" : "active";
  await db.update(habits).set({ status: next }).where(eq(habits.id, id));
  refresh();
  return { success: next === "paused" ? "عادت متوقف شد؛ این دوره به‌حساب قصور نمی‌آید." : "عادت دوباره فعال شد." };
}

export async function deleteHabit(id: string): Promise<ActionResult> {
  const user = await requireUser();
  await db.delete(habits).where(and(eq(habits.id, id), eq(habits.userId, user.id)));
  refresh();
  return { success: "عادت حذف شد." };
}

export async function setOccurrence(input: {
  habitId?: unknown; date?: unknown; status?: unknown; value?: unknown;
}): Promise<ActionResult> {
  const user = await requireUser();
  try {
    const habitId = typeof input.habitId === "string" ? input.habitId : "";
    const date = validIsoDate(input.date);
    if (!habitId || !date) return { error: "ورودی نامعتبر است." };
    const owned = await db.select({ id: habits.id }).from(habits)
      .where(and(eq(habits.id, habitId), eq(habits.userId, user.id))).limit(1);
    if (!owned.length) return { error: "دسترسی مجاز نیست." };
    const status = oneOf(input.status, ["done", "partial", "missed", "skipped"] as const, "done");
    await db.insert(habitOccurrences).values({
      habitId, date, status, value: intInRange(input.value ?? null, 0, 100000),
    }).onConflictDoUpdate({
      target: [habitOccurrences.habitId, habitOccurrences.date],
      set: { status, value: intInRange(input.value ?? null, 0, 100000) },
    });
    refresh();
    return { success: "ثبت شد." };
  } catch (e) {
    return { error: errMsg(e) };
  }
}

// ======================= REVIEWS =======================

export async function saveDailyReview(input: {
  date?: unknown; accomplishment?: unknown; goalProgress?: unknown; distractions?: unknown;
  wentWell?: unknown; improve?: unknown; tomorrowPriority?: unknown; energy?: unknown;
}): Promise<ActionResult> {
  const user = await requireUser();
  try {
    const date = validIsoDate(input.date) ?? todayIso(user.settings.timezone);
    const values = {
      accomplishment: cleanStr(input.accomplishment, 1000),
      goalProgress: cleanStr(input.goalProgress, 1000),
      distractions: cleanStr(input.distractions, 1000),
      wentWell: cleanStr(input.wentWell, 1000),
      improve: cleanStr(input.improve, 1000),
      tomorrowPriority: cleanStr(input.tomorrowPriority, 1000),
      energy: intInRange(input.energy ?? null, 1, 5),
      updatedAt: new Date(),
    };
    await db.insert(dailyReviews).values({ ...values, userId: user.id, date })
      .onConflictDoUpdate({ target: [dailyReviews.userId, dailyReviews.date], set: values });
    refresh();
    return { success: "مرور روزانه ذخیره شد." };
  } catch (e) {
    return { error: errMsg(e) };
  }
}

export async function saveWeeklyReview(input: { weekStart?: unknown; reflection?: unknown }): Promise<ActionResult> {
  const user = await requireUser();
  try {
    const weekStart = validIsoDate(input.weekStart);
    if (!weekStart) return { error: "هفته نامعتبر است." };
    await db.insert(weeklyReviews).values({
      userId: user.id, weekStart, reflection: cleanStr(input.reflection, 3000), updatedAt: new Date(),
    }).onConflictDoUpdate({
      target: [weeklyReviews.userId, weeklyReviews.weekStart],
      set: { reflection: cleanStr(input.reflection, 3000), updatedAt: new Date() },
    });
    refresh();
    return { success: "مرور هفتگی ذخیره شد." };
  } catch (e) {
    return { error: errMsg(e) };
  }
}

export async function dismissSuggestion(weekStart: string, key: string): Promise<ActionResult> {
  const user = await requireUser();
  const ws = validIsoDate(weekStart);
  const k = cleanStr(key, 60);
  if (!ws || !k) return { error: "ورودی نامعتبر است." };
  const rows = await db.select().from(weeklyReviews)
    .where(and(eq(weeklyReviews.userId, user.id), eq(weeklyReviews.weekStart, ws))).limit(1);
  const current = rows[0];
  const dismissed = current ? [...current.dismissedSuggestions, k] : [k];
  await db.insert(weeklyReviews).values({
    userId: user.id, weekStart: ws, dismissedSuggestions: dismissed, updatedAt: new Date(),
  }).onConflictDoUpdate({
    target: [weeklyReviews.userId, weeklyReviews.weekStart],
    set: { dismissedSuggestions: dismissed, updatedAt: new Date() },
  });
  refresh();
  return { success: "پیشنهاد کنار گذاشته شد." };
}

// ======================= SETTINGS =======================

export async function updateSettings(input: {
  theme?: unknown; timezone?: unknown; weekStart?: unknown;
  defaultFocusMinutes?: unknown; defaultBreakMinutes?: unknown;
  targetBedTime?: unknown; targetWakeTime?: unknown; targetSleepMinutes?: unknown;
}): Promise<ActionResult> {
  const user = await requireUser();
  try {
    const values = {
      theme: oneOf(input.theme, ["light", "dark", "system"] as const, "system"),
      timezone: cleanStr(input.timezone, 60) ?? "Asia/Tehran",
      weekStart: intInRange(input.weekStart ?? 0, 0, 6) ?? 0,
      defaultFocusMinutes: intInRange(input.defaultFocusMinutes ?? 25, 5, 480) ?? 25,
      defaultBreakMinutes: intInRange(input.defaultBreakMinutes ?? 5, 0, 120) ?? 5,
      targetBedTime: validTime(parseDigitsSafe(input.targetBedTime)) ?? "23:00",
      targetWakeTime: validTime(parseDigitsSafe(input.targetWakeTime)) ?? "07:00",
      targetSleepMinutes: intInRange(input.targetSleepMinutes ?? 480, 60, 960) ?? 480,
    };
    await db.insert(userSettings).values({ ...values, userId: user.id })
      .onConflictDoUpdate({ target: userSettings.userId, set: values });
    refresh();
    return { success: "تنظیمات ذخیره شد." };
  } catch (e) {
    return { error: errMsg(e) };
  }
}

export async function updateProfile(input: { displayName?: unknown }): Promise<ActionResult> {
  const user = await requireUser();
  await db.update(users).set({ displayName: cleanStr(input.displayName, 80) }).where(eq(users.id, user.id));
  refresh();
  return { success: "نام نمایشی ذخیره شد." };
}

export async function changePassword(input: { current?: unknown; next?: unknown }): Promise<ActionResult> {
  const user = await requireUser();
  const cur = typeof input.current === "string" ? input.current : "";
  const nxt = typeof input.next === "string" ? input.next : "";
  if (!checkPassword(cur, user.passwordHash)) return { error: "رمز فعلی اشتباه است." };
  if (nxt.length < 8) return { error: "رمز جدید باید دست‌کم ۸ نویسه باشد." };
  await db.update(users).set({ passwordHash: hashPassword(nxt) }).where(eq(users.id, user.id));
  return { success: "رمز عبور تغییر کرد." };
}

export async function exportData(): Promise<{ json?: string; error?: string }> {
  const user = await requireUser();
  const uid = user.id;
  const grab = <T>(q: Promise<T[]>) => q;
  const [g, m, t, fs, sl, h, ho, dr, wr] = await Promise.all([
    grab(db.select().from(goals).where(eq(goals.userId, uid))),
    db.select().from(milestones)
      .innerJoin(goals, eq(goals.id, milestones.goalId)).where(eq(goals.userId, uid))
      .then((r) => r.map((x) => x.milestones)),
    grab(db.select().from(tasks).where(eq(tasks.userId, uid))),
    grab(db.select().from(focusSessions).where(eq(focusSessions.userId, uid))),
    grab(db.select().from(sleepRecords).where(eq(sleepRecords.userId, uid))),
    grab(db.select().from(habits).where(eq(habits.userId, uid))),
    db.select().from(habitOccurrences)
      .innerJoin(habits, eq(habits.id, habitOccurrences.habitId)).where(eq(habits.userId, uid))
      .then((r) => r.map((x) => x.habit_occurrences)),
    grab(db.select().from(dailyReviews).where(eq(dailyReviews.userId, uid))),
    grab(db.select().from(weeklyReviews).where(eq(weeklyReviews.userId, uid))),
  ]);
  return {
    json: JSON.stringify({
      exportedAt: new Date().toISOString(), app: "LIFE OS", version: 1,
      user: { username: user.username, displayName: user.displayName },
      settings: user.settings, goals: g, milestones: m, tasks: t, focusSessions: fs,
      sleepRecords: sl, habits: h, habitOccurrences: ho, dailyReviews: dr, weeklyReviews: wr,
    }, null, 2),
  };
}

export async function deleteAccount(input: { password?: unknown }): Promise<ActionResult> {
  const user = await requireUser();
  const pw = typeof input.password === "string" ? input.password : "";
  if (!checkPassword(pw, user.passwordHash)) return { error: "برای حذف حساب، رمز عبور درست را وارد کنید." };
  await db.delete(users).where(eq(users.id, user.id)); // همهٔ داده‌ها با cascade حذف می‌شوند
  await destroySession();
  redirect("/login");
}
