import { toJalaali, toGregorian, isLeapJalaaliYear, jalaaliMonthLength } from "jalaali-js";

const FA_DIGITS = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];

export function faDigits(input: string | number): string {
  return String(input).replace(/[0-9]/g, (d) => FA_DIGITS[Number(d)]);
}

export function parseDigits(input: string): string {
  return input
    .replace(/[۰-۹]/g, (d) => String(FA_DIGITS.indexOf(d)))
    .replace(/[٠-٩]/g, (d) => String("٠١٢٣٤٥٦٧٨٩".indexOf(d)));
}

export function faNumber(n: number): string {
  return faDigits(n.toLocaleString("en-US"));
}

export function faDuration(minutes: number): string {
  const m = Math.round(minutes);
  const h = Math.floor(m / 60);
  const rest = m % 60;
  if (h === 0) return `${faDigits(rest)} دقیقه`;
  if (rest === 0) return `${faDigits(h)} ساعت`;
  return `${faDigits(h)} ساعت و ${faDigits(rest)} دقیقه`;
}

export function faClock(minutes: number): string {
  const h = Math.floor(minutes / 60);
  const m = Math.round(minutes % 60);
  return faDigits(`${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`);
}

export const FA_WEEKDAYS = ["شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه"];
export const FA_WEEKDAYS_SHORT = ["ش", "ی", "د", "س", "چ", "پ", "ج"];
export const FA_MONTHS = [
  "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
  "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند",
];

// shamsi weekday index of a gregorian Date: 0=Sat … 6=Fri
export function faWeekdayIndex(d: Date): number {
  return (d.getUTCDay() + 1) % 7;
}

/** ISO date string (YYYY-MM-DD) of `d` as seen in timezone `tz` */
export function isoInTz(d: Date, tz: string): string {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit",
  }).formatToParts(d);
  const get = (t: string) => parts.find((p) => p.type === t)?.value ?? "";
  return `${get("year")}-${get("month")}-${get("day")}`;
}

export function todayIso(tz: string): string {
  return isoInTz(new Date(), tz);
}

export function addDaysIso(iso: string, days: number): string {
  const [y, m, dd] = iso.split("-").map(Number);
  const d = new Date(Date.UTC(y, m - 1, dd));
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

export function diffDaysIso(a: string, b: string): number {
  const pa = a.split("-").map(Number);
  const pb = b.split("-").map(Number);
  const da = Date.UTC(pa[0], pa[1] - 1, pa[2]);
  const db = Date.UTC(pb[0], pb[1] - 1, pb[2]);
  return Math.round((db - da) / 86400000);
}

export type JalaliParts = { jy: number; jm: number; jd: number };

export function jalaliOfGregorian(gy: number, gm: number, gd: number): JalaliParts {
  return toJalaali(gy, gm, gd);
}

export function jalaliOfIso(iso: string): JalaliParts {
  const [y, m, d] = iso.split("-").map(Number);
  return toJalaali(y, m, d);
}

export function isoOfJalali(jy: number, jm: number, jd: number): string {
  const g = toGregorian(jy, jm, jd);
  return `${g.gy}-${String(g.gm).padStart(2, "0")}-${String(g.gd).padStart(2, "0")}`;
}

export function jalaliOfDate(d: Date, tz: string): JalaliParts {
  return jalaliOfIso(isoInTz(d, tz));
}

export function jalaliMonthLen(jy: number, jm: number): number {
  return jalaaliMonthLength(jy, jm);
}

export function isJalaliLeap(jy: number): boolean {
  return isLeapJalaaliYear(jy);
}

/** short: ۱۴۰۳/۰۸/۱۵ */
export function faDateShort(iso: string | null | undefined): string {
  if (!iso) return "—";
  const { jy, jm, jd } = jalaliOfIso(iso);
  return faDigits(`${jy}/${String(jm).padStart(2, "0")}/${String(jd).padStart(2, "0")}`);
}

/** medium: ۱۵ آبان ۱۴۰۳ */
export function faDateMed(iso: string | null | undefined): string {
  if (!iso) return "—";
  const { jy, jm, jd } = jalaliOfIso(iso);
  return `${faDigits(jd)} ${FA_MONTHS[jm - 1]} ${faDigits(jy)}`;
}

/** long: جمعه ۱۵ آبان ۱۴۰۳ */
export function faDateLong(iso: string | null | undefined): string {
  if (!iso) return "—";
  const { jy, jm, jd } = jalaliOfIso(iso);
  const wd = FA_WEEKDAYS[faWeekdayIndex(new Date(Date.UTC(Number(iso.slice(0, 4)), Number(iso.slice(5, 7)) - 1, Number(iso.slice(8, 10)))))];
  return `${wd} ${faDigits(jd)} ${FA_MONTHS[jm - 1]} ${faDigits(jy)}`;
}

export function faWeekdayName(iso: string): string {
  const [y, m, d] = iso.split("-").map(Number);
  return FA_WEEKDAYS[faWeekdayIndex(new Date(Date.UTC(y, m - 1, d)))];
}

export function faWeekdayOfIso(iso: string): number {
  const [y, m, d] = iso.split("-").map(Number);
  return faWeekdayIndex(new Date(Date.UTC(y, m - 1, d)));
}

/** Jalali month grid: rows of weeks, each cell ISO date or null; weeks start شنبه */
export function jalaliMonthGrid(jy: number, jm: number): (string | null)[][] {
  const len = jalaliMonthLen(jy, jm);
  const firstIso = isoOfJalali(jy, jm, 1);
  const firstWd = faWeekdayOfIso(firstIso);
  const cells: (string | null)[] = [];
  for (let i = 0; i < firstWd; i++) cells.push(null);
  for (let d = 1; d <= len; d++) cells.push(isoOfJalali(jy, jm, d));
  while (cells.length % 7 !== 0) cells.push(null);
  const rows: (string | null)[][] = [];
  for (let i = 0; i < cells.length; i += 7) rows.push(cells.slice(i, i + 7));
  return rows;
}

export function fmtTimeInTz(d: Date | null | undefined, tz: string): string {
  if (!d) return "—";
  const s = new Intl.DateTimeFormat("en-GB", {
    timeZone: tz, hour: "2-digit", minute: "2-digit", hourCycle: "h23",
  }).format(d);
  return faDigits(s);
}

/** Persian relative day label: امروز / دیروز / فردا / N روز دیگر / N روز پیش */
export function faRelativeDay(iso: string, today: string): string {
  const diff = diffDaysIso(today, iso);
  if (diff === 0) return "امروز";
  if (diff === 1) return "فردا";
  if (diff === -1) return "دیروز";
  if (diff > 1) return `${faDigits(diff)} روز دیگر`;
  return `${faDigits(-diff)} روز پیش`;
}

/** start of week ISO for a given date; weekStartIdx: 0=شنبه … 6=جمعه (تقویم جلالی) */
export function startOfWeekIso(iso: string, weekStart = 0): string {
  const wd = faWeekdayOfIso(iso);
  const diff = (wd - weekStart + 7) % 7;
  return addDaysIso(iso, -diff);
}

export function weekDaysIso(iso: string, weekStart = 0): string[] {
  const start = startOfWeekIso(iso, weekStart);
  return Array.from({ length: 7 }, (_, i) => addDaysIso(start, i));
}

/** Jalali month/year heading like آبان ۱۴۰۳ */
export function faMonthTitle(jy: number, jm: number): string {
  return `${FA_MONTHS[jm - 1]} ${faDigits(jy)}`;
}

/** minutes between two HH:mm strings (end may cross midnight) */
export function minutesBetween(startHHmm: string, endHHmm: string): number {
  const [sh, sm] = startHHmm.split(":").map(Number);
  const [eh, em] = endHHmm.split(":").map(Number);
  let diff = eh * 60 + em - (sh * 60 + sm);
  if (diff <= 0) diff += 24 * 60;
  return diff;
}

export { toGregorian, toJalaali };
