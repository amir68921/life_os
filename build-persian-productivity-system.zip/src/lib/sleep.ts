import { hhmmToMinutes, localMinuteOfDay } from "./time";

export type SleepLike = {
  bedTime: Date;
  sleepStart: Date | null;
  wakeTime: Date;
  durationMinutes: number;
};

/** Estimated sleep in minutes: from falling asleep (or bed time) until waking. */
export function estimateSleepMinutes(bed: Date, sleepStart: Date | null, wake: Date) {
  const from = sleepStart ?? bed;
  return Math.max(0, Math.round((wake.getTime() - from.getTime()) / 60000));
}

/**
 * Bedtimes around midnight must be compared on a circular clock. We shift times
 * so that the day "starts" at noon: 23:30 → -30, 00:30 → 30.
 */
export function bedtimeMinuteCentered(d: Date, tz: string) {
  const m = localMinuteOfDay(d, tz);
  return m >= 720 ? m - 1440 : m;
}

export function mean(xs: number[]) {
  return xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : null;
}

export function stdDev(xs: number[]) {
  const m = mean(xs);
  if (m === null || xs.length < 2) return null;
  return Math.sqrt(xs.reduce((a, b) => a + (b - m) ** 2, 0) / (xs.length - 1));
}

/** Circular distance between two clock minutes. */
export function clockDistance(a: number, b: number) {
  const d = Math.abs(a - b) % 1440;
  return Math.min(d, 1440 - d);
}

export type SleepStats = {
  count: number;
  avgDuration: number | null;
  bedtimeStdDev: number | null; // minutes – lower = more consistent
  wakeStdDev: number | null;
  avgBedtime: number | null; // centered minutes
  avgWake: number | null;
  targetDurationHitRate: number | null; // % of nights within 30 min of target or above
  bedtimeAdherence: number | null; // % within 30 min of target bedtime
  wakeAdherence: number | null;
};

export function computeSleepStats(
  records: SleepLike[],
  tz: string,
  target: { bed: string; wake: string; minutes: number },
  toleranceMin = 30,
): SleepStats {
  const n = records.length;
  if (n === 0)
    return {
      count: 0,
      avgDuration: null,
      bedtimeStdDev: null,
      wakeStdDev: null,
      avgBedtime: null,
      avgWake: null,
      targetDurationHitRate: null,
      bedtimeAdherence: null,
      wakeAdherence: null,
    };
  const beds = records.map((r) => bedtimeMinuteCentered(r.bedTime, tz));
  const wakes = records.map((r) => localMinuteOfDay(r.wakeTime, tz));
  const tb = hhmmToMinutes(target.bed);
  const tw = hhmmToMinutes(target.wake);
  const pct = (k: number) => (k / n) * 100;
  return {
    count: n,
    avgDuration: mean(records.map((r) => r.durationMinutes)),
    bedtimeStdDev: stdDev(beds),
    wakeStdDev: stdDev(wakes),
    avgBedtime: mean(beds),
    avgWake: mean(wakes),
    targetDurationHitRate: pct(records.filter((r) => r.durationMinutes >= target.minutes - toleranceMin).length),
    bedtimeAdherence: pct(records.filter((r) => clockDistance(localMinuteOfDay(r.bedTime, tz), tb) <= toleranceMin).length),
    wakeAdherence: pct(records.filter((r) => clockDistance(localMinuteOfDay(r.wakeTime, tz), tw) <= toleranceMin).length),
  };
}
