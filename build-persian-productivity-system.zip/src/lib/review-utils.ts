import { faDateMed } from "@/lib/jalali";

export function validParamDate(v?: string): string | null {
  if (!v || !/^\d{4}-\d{2}-\d{2}$/.test(v)) return null;
  const d = new Date(v + "T00:00:00Z");
  return Number.isNaN(d.getTime()) ? null : v;
}

export { faDateMed };
