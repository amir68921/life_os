import type { Recurrence } from "@/db/schema";
import { addDays, addMonths, diffDays, startOfWeek, weekdayOf, type ISODate } from "./time";

/**
 * Next due date of a recurring task after `from` (exclusive). Returns null when
 * the series has ended. Pure – used when a recurring occurrence is completed so
 * a new, separate occurrence row is created and history is never mutated.
 */
export function nextOccurrence(rule: Recurrence, from: ISODate): ISODate | null {
  const interval = Math.max(1, Math.floor(rule.interval || 1));
  let next: ISODate | null = null;
  if (rule.freq === "daily") next = addDays(from, interval);
  else if (rule.freq === "monthly") next = addMonths(from, interval);
  else if (rule.freq === "weekly") {
    const days = (rule.weekdays ?? []).filter((d) => d >= 0 && d <= 6);
    if (days.length === 0) next = addDays(from, 7 * interval);
    else {
      // Weeks are counted relative to the week (Sunday-based) containing `from`;
      // only weeks whose index is a multiple of `interval` are eligible.
      const baseWeek = startOfWeek(from, 0);
      for (let i = 1; i <= 7 * interval + 7; i++) {
        const d = addDays(from, i);
        const weekIndex = diffDays(startOfWeek(d, 0), baseWeek) / 7;
        if (weekIndex % interval === 0 && days.includes(weekdayOf(d))) {
          next = d;
          break;
        }
      }
    }
  }
  if (next && rule.until && next > rule.until) return null;
  return next;
}

export function describeRecurrence(rule: Recurrence | null | undefined): string {
  if (!rule) return "";
  const n = rule.interval > 1 ? `هر ${rule.interval} ` : "هر ";
  if (rule.freq === "daily") return rule.interval > 1 ? `${n}روز` : "هر روز";
  if (rule.freq === "monthly") return rule.interval > 1 ? `${n}ماه` : "هر ماه";
  const names = ["یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه"];
  const days = (rule.weekdays ?? []).map((d) => names[d]).join("، ");
  return `${rule.interval > 1 ? `${n}هفته` : "هر هفته"}${days ? ` (${days})` : ""}`;
}
