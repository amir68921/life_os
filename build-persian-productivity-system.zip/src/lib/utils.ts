// ---------- shared domain constants (safe for client & server) ----------

export type ActionResult = { error?: string; success?: string };

export const PRIORITIES = [
  { value: "high", label: "زیاد" },
  { value: "medium", label: "متوسط" },
  { value: "low", label: "کم" },
] as const;
export const priorityLabel = (v: string) => PRIORITIES.find((p) => p.value === v)?.label ?? v;

export const TASK_STATUSES = [
  { value: "pending", label: "شروع‌نشده" },
  { value: "in_progress", label: "در حال انجام" },
  { value: "done", label: "انجام‌شده" },
  { value: "cancelled", label: "لغوشده" },
] as const;
export const taskStatusLabel = (v: string) => TASK_STATUSES.find((s) => s.value === v)?.label ?? v;

export const GOAL_STATUSES = [
  { value: "active", label: "فعال" },
  { value: "paused", label: "متوقف" },
  { value: "completed", label: "تکمیل‌شده" },
  { value: "archived", label: "بایگانی" },
] as const;
export const goalStatusLabel = (v: string) => GOAL_STATUSES.find((s) => s.value === v)?.label ?? v;

export const TIMEFRAMES = [
  { value: "short", label: "کوتاه‌مدت" },
  { value: "medium", label: "میان‌مدت" },
  { value: "long", label: "بلندمدت" },
] as const;
export const timeframeLabel = (v: string) => TIMEFRAMES.find((t) => t.value === v)?.label ?? v;

export const ENERGIES = [
  { value: "high", label: "زیاد" },
  { value: "medium", label: "متوسط" },
  { value: "low", label: "کم" },
] as const;
export const energyLabel = (v: string) => ENERGIES.find((e) => e.value === v)?.label ?? v;

export const RECURRENCES = [
  { value: "none", label: "بدون تکرار" },
  { value: "daily", label: "روزانه" },
  { value: "weekdays", label: "روزهای کاری (شنبه تا پنجشنبه)" },
  { value: "weekly", label: "هفتگی" },
] as const;
export const recurrenceLabel = (v: string) => RECURRENCES.find((r) => r.value === v)?.label ?? v;

export const HABIT_STATUS = [
  { value: "done", label: "انجام شد", color: "text-emerald-500" },
  { value: "partial", label: "نیمه‌تمام", color: "text-amber-500" },
  { value: "missed", label: "از دست رفت", color: "text-rose-500" },
  { value: "skipped", label: "رد شد (عمدی)", color: "text-stone-400" },
] as const;
export const habitStatusLabel = (v: string) => HABIT_STATUS.find((s) => s.value === v)?.label ?? v;

export const TASK_CATEGORIES = ["کار", "یادگیری", "پروژه شخصی", "سلامت و ورزش", "خانواده و دوستان", "مسئولیت‌های روزانه", "استراحت", "شخصی", "متفرقه"];
export const GOAL_CATEGORIES = ["شغلی", "تحصیلی", "سلامت", "مالی", "روابط", "رشد فردی", "سرگرمی", "متفرقه"];

// ---------- small validation helpers (server use) ----------

export function cleanStr(v: unknown, max = 500): string | null {
  if (typeof v !== "string") return null;
  const t = v.trim().slice(0, max);
  return t === "" ? null : t;
}

export function reqStr(v: unknown, message: string, max = 500): string {
  const t = cleanStr(v, max);
  if (!t) throw new Error(message);
  return t;
}

export function oneOf<T extends string>(v: unknown, allowed: readonly T[], fallback: T): T {
  return typeof v === "string" && (allowed as readonly string[]).includes(v) ? (v as T) : fallback;
}

export function intInRange(v: unknown, min: number, max: number): number | null {
  const n = typeof v === "string" ? Number(v.replace(/[۰-۹]/g, (d) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d)))) : Number(v);
  if (!Number.isFinite(n)) return null;
  const r = Math.round(n);
  if (r < min) return min;
  if (r > max) return max;
  return r;
}

export function validIsoDate(v: unknown): string | null {
  if (typeof v !== "string") return null;
  const t = v.trim();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(t)) return null;
  const d = new Date(t + "T00:00:00Z");
  return Number.isNaN(d.getTime()) ? null : t;
}

export function validTime(v: unknown): string | null {
  if (typeof v !== "string") return null;
  const t = v.trim();
  return /^([01]?\d|2[0-3]):[0-5]\d$/.test(t) ? t.padStart(5, "0") : null;
}

export function parseDigitsSafe(v: unknown): unknown {
  if (typeof v !== "string") return v;
  return v.replace(/[۰-۹]/g, (d) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d)));
}

export function errMsg(e: unknown): string {
  if (e instanceof Error) {
    if (e.message.includes("unique") || e.message.includes("duplicate")) return "این مورد قبلاً ثبت شده است.";
    return e.message;
  }
  return "خطایی رخ داد. دوباره تلاش کنید.";
}
