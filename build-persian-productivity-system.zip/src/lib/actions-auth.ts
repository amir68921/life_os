"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users, userSettings } from "@/db/schema";
import { createSession, destroySession, hashPassword, checkPassword } from "@/lib/auth";
import { cleanStr, errMsg } from "@/lib/utils";

export type AuthState = { error?: string };

export async function loginAction(_prev: AuthState, formData: FormData): Promise<AuthState> {
  const username = cleanStr(formData.get("username"), 60);
  const password = typeof formData.get("password") === "string" ? String(formData.get("password")) : "";
  if (!username || !password) return { error: "نام کاربری و رمز عبور را وارد کنید." };
  const rows = await db.select().from(users).where(eq(users.username, username)).limit(1);
  const user = rows[0];
  // پیام یکسان برای جلوگیری از حدس‌زدن نام کاربری
  if (!user || !checkPassword(password, user.passwordHash)) {
    return { error: "نام کاربری یا رمز عبور اشتباه است." };
  }
  await createSession(user.id);
  redirect("/");
}

export async function registerAction(_prev: AuthState, formData: FormData): Promise<AuthState> {
  const username = cleanStr(formData.get("username"), 60);
  const displayName = cleanStr(formData.get("displayName"), 80);
  const password = typeof formData.get("password") === "string" ? String(formData.get("password")) : "";
  if (!username || username.length < 3) return { error: "نام کاربری باید دست‌کم ۳ نویسه باشد." };
  if (!/^[a-zA-Z0-9_.\-آ-ی]+$/.test(username)) return { error: "نام کاربری فقط می‌تواند شامل حروف، عدد، نقطه و خط تیره باشد." };
  if (password.length < 8) return { error: "رمز عبور باید دست‌کم ۸ نویسه باشد." };
  try {
    const created = await db.transaction(async (tx) => {
      const inserted = await tx.insert(users).values({ username, passwordHash: hashPassword(password), displayName }).returning();
      const u = inserted[0];
      await tx.insert(userSettings).values({ userId: u.id }).onConflictDoNothing();
      return u;
    });
    await createSession(created.id);
  } catch (e) {
    return { error: errMsg(e) };
  }
  redirect("/");
}

export async function logoutAction() {
  await destroySession();
  revalidatePath("/", "layout");
  redirect("/login");
}
