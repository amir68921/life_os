// Task data-access layer. Every function takes the authenticated userId and
// scopes all reads/writes to it, so IDs from other accounts never match.
import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { tasks } from "@/db/schema";
import { nextOccurrence } from "@/lib/recurrence";

export type TaskInsert = Omit<typeof tasks.$inferInsert, "id" | "userId" | "createdAt" | "updatedAt">;

export async function createTask(userId: string, values: TaskInsert) {
  const [row] = await db.insert(tasks).values({ ...values, userId }).returning();
  return row;
}

export async function updateTask(userId: string, id: string, values: Partial<TaskInsert>) {
  return db.transaction(async (tx) => {
    const [current] = await tx.select().from(tasks).where(and(eq(tasks.id, id), eq(tasks.userId, userId))).limit(1);
    if (!current) return null;
    const postponed =
      values.dueDate !== undefined && current.dueDate && values.dueDate && values.dueDate > current.dueDate ? 1 : 0;
    const [row] = await tx
      .update(tasks)
      .set({ ...values, postponeCount: current.postponeCount + postponed, updatedAt: new Date() })
      .where(and(eq(tasks.id, id), eq(tasks.userId, userId)))
      .returning();
    return row;
  });
}

/**
 * Complete a task. For recurring tasks a *new* occurrence row is created for the
 * next due date inside the same transaction; the completed occurrence keeps its
 * own history untouched. The unique (series_id, due_date) index prevents
 * duplicate future occurrences if completion is triggered twice.
 */
export async function completeTask(userId: string, id: string, now = new Date()) {
  return db.transaction(async (tx) => {
    const [t] = await tx.select().from(tasks).where(and(eq(tasks.id, id), eq(tasks.userId, userId))).limit(1);
    if (!t) return null;
    if (t.status === "done") return { task: t, nextId: null as string | null };
    const seriesId = t.recurrence ? (t.seriesId ?? t.id) : t.seriesId;
    const [done] = await tx
      .update(tasks)
      .set({ status: "done", completedAt: now, seriesId, updatedAt: now })
      .where(eq(tasks.id, t.id))
      .returning();
    let nextId: string | null = null;
    if (t.recurrence && t.dueDate) {
      const next = nextOccurrence(t.recurrence, t.dueDate);
      if (next) {
        const inserted = await tx
          .insert(tasks)
          .values({
            userId,
            title: t.title,
            description: t.description,
            dueDate: next,
            plannedStart: t.plannedStart,
            estimatedMinutes: t.estimatedMinutes,
            priority: t.priority,
            category: t.category,
            goalId: t.goalId,
            projectId: t.projectId,
            milestoneId: t.milestoneId,
            energy: t.energy,
            tags: t.tags,
            recurrence: t.recurrence,
            seriesId,
            notes: t.notes,
          })
          .onConflictDoNothing()
          .returning({ id: tasks.id });
        nextId = inserted[0]?.id ?? null;
      }
    }
    return { task: done, nextId };
  });
}

export async function setTaskStatus(userId: string, id: string, status: "todo" | "in_progress" | "done" | "cancelled") {
  if (status === "done") return (await completeTask(userId, id))?.task ?? null;
  const [row] = await db
    .update(tasks)
    .set({ status, completedAt: null, updatedAt: new Date() })
    .where(and(eq(tasks.id, id), eq(tasks.userId, userId)))
    .returning();
  return row ?? null;
}

/** Explicit, user-initiated rescheduling. Never called automatically. */
export async function rescheduleTask(userId: string, id: string, dueDate: string | null, plannedStart?: string | null) {
  const [row] = await db
    .update(tasks)
    .set({
      dueDate,
      ...(plannedStart !== undefined ? { plannedStart } : {}),
      postponeCount: sql`${tasks.postponeCount} + case when ${tasks.dueDate} is not null and ${dueDate}::date > ${tasks.dueDate} then 1 else 0 end`,
      updatedAt: new Date(),
    })
    .where(and(eq(tasks.id, id), eq(tasks.userId, userId)))
    .returning();
  return row ?? null;
}

export async function deleteTask(userId: string, id: string) {
  const r = await db.delete(tasks).where(and(eq(tasks.id, id), eq(tasks.userId, userId))).returning({ id: tasks.id });
  return r.length > 0;
}

export async function getTask(userId: string, id: string) {
  const [row] = await db.select().from(tasks).where(and(eq(tasks.id, id), eq(tasks.userId, userId))).limit(1);
  return row ?? null;
}
