import "server-only";

/**
 * AI assistant – architecture only (not required for the app to work).
 *
 * - Provider-agnostic interface; implementations run ONLY on the server.
 * - Credentials come from environment variables (AI_API_KEY, AI_BASE_URL,
 *   AI_MODEL) and are never sent to the browser.
 * - Callers must pass data already scoped to the authenticated user.
 * - Any plan returned by the model is a *suggestion*: persist it with
 *   status "pending" and require explicit user approval before applying.
 */

export type AIMessage = { role: "system" | "user" | "assistant"; content: string };

export interface AIProvider {
  readonly name: string;
  complete(messages: AIMessage[], opts?: { maxTokens?: number; temperature?: number }): Promise<string>;
}

export type AICapability = "weekly-summary" | "schedule-suggestion" | "obstacles" | "goal-breakdown" | "prioritize" | "history-qa";

/** OpenAI-compatible chat completions provider (works with many vendors). */
class OpenAICompatibleProvider implements AIProvider {
  readonly name = "openai-compatible";
  constructor(
    private apiKey: string,
    private baseUrl: string,
    private model: string,
  ) {}
  async complete(messages: AIMessage[], opts?: { maxTokens?: number; temperature?: number }) {
    const res = await fetch(`${this.baseUrl.replace(/\/$/, "")}/chat/completions`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${this.apiKey}` },
      body: JSON.stringify({ model: this.model, messages, max_tokens: opts?.maxTokens ?? 800, temperature: opts?.temperature ?? 0.3 }),
      signal: AbortSignal.timeout(30000),
    });
    if (!res.ok) throw new Error(`AI provider error ${res.status}`);
    const json = (await res.json()) as { choices?: { message?: { content?: string } }[] };
    return json.choices?.[0]?.message?.content ?? "";
  }
}

/** Returns null when AI is not configured – the rest of the app keeps working. */
export function getAIProvider(): AIProvider | null {
  const key = process.env.AI_API_KEY;
  if (!key) return null;
  return new OpenAICompatibleProvider(key, process.env.AI_BASE_URL ?? "https://api.openai.com/v1", process.env.AI_MODEL ?? "gpt-4o-mini");
}

export function aiStatus() {
  return { configured: !!process.env.AI_API_KEY, provider: process.env.AI_API_KEY ? "openai-compatible" : null };
}
