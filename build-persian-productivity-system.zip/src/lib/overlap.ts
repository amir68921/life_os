import { weekdayOf, type ISODate } from "./time";

export type Interval = { id: string; start: number; end: number; title?: string };

/** Half-open interval overlap: [a.start, a.end) ∩ [b.start, b.end) ≠ ∅ */
export function overlaps(a: { start: number; end: number }, b: { start: number; end: number }) {
  return a.start < b.end && b.start < a.end;
}

export function findOverlaps<T extends Interval>(candidate: { id?: string; start: number; end: number }, items: T[]) {
  return items.filter((i) => i.id !== candidate.id && overlaps(candidate, i));
}

/** All overlapping pairs in a list (for the activity log conflict view). */
export function overlappingPairs<T extends Interval>(items: T[]): [T, T][] {
  const sorted = [...items].sort((a, b) => a.start - b.start);
  const pairs: [T, T][] = [];
  for (let i = 0; i < sorted.length; i++) {
    for (let j = i + 1; j < sorted.length && sorted[j].start < sorted[i].end; j++) {
      pairs.push([sorted[i], sorted[j]]);
    }
  }
  return pairs;
}

export type BlockLike = {
  id: string;
  title: string;
  date: ISODate;
  startMinute: number;
  endMinute: number;
  repeatWeekdays: number[] | null;
  repeatUntil: ISODate | null;
};

/** Does a (possibly recurring) block occur on a given local date? */
export function blockOccursOn(b: BlockLike, date: ISODate) {
  if (!b.repeatWeekdays || b.repeatWeekdays.length === 0) return b.date === date;
  if (date < b.date) return false;
  if (b.repeatUntil && date > b.repeatUntil) return false;
  return b.repeatWeekdays.includes(weekdayOf(date));
}

export function blocksOn<T extends BlockLike>(blocks: T[], date: ISODate): T[] {
  return blocks.filter((b) => blockOccursOn(b, date)).sort((a, b) => a.startMinute - b.startMinute);
}

/**
 * Conflicts for a candidate block. For recurring candidates we check the next
 * 8 weeks of occurrences (a pragmatic horizon).
 */
export function blockConflicts<T extends BlockLike>(candidate: BlockLike, existing: T[], horizonDays = 56) {
  const dates: ISODate[] = [];
  if (!candidate.repeatWeekdays || candidate.repeatWeekdays.length === 0) dates.push(candidate.date);
  else {
    const [y, m, d] = candidate.date.split("-").map(Number);
    for (let i = 0; i < horizonDays; i++) {
      const dt = new Date(Date.UTC(y, m - 1, d + i));
      const iso = dt.toISOString().slice(0, 10);
      if (blockOccursOn(candidate, iso)) dates.push(iso);
    }
  }
  const conflicts = new Map<string, { block: T; date: ISODate }>();
  for (const date of dates) {
    for (const b of existing) {
      if (b.id === candidate.id || conflicts.has(b.id)) continue;
      if (blockOccursOn(b, date) && overlaps({ start: candidate.startMinute, end: candidate.endMinute }, { start: b.startMinute, end: b.endMinute })) {
        conflicts.set(b.id, { block: b, date });
      }
    }
  }
  return [...conflicts.values()];
}
