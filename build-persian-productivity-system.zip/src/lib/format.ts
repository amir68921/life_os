import { isoToJalali, JALALI_MONTHS, GREGORIAN_MONTHS_FA, WEEKDAYS_FA } from "./jalali";
import { localDate, localTime, weekdayOf, type ISODate } from "./time";

export type DateMode = "jalali" | "gregorian";

const FA_DIGITS = "۰۱۲۳۴۵۶۷۸۹";

/** Convert latin digits to Persian digits. */
export function fa(input: string | number | null | undefined): string {
  if (input === null || input === undefined) return "";
  return String(input).replace(/\d/g, (d) => FA_DIGITS[Number(d)]);
}

/** Persian digits → latin (for parsing user input). */
export function toLatinDigits(s: string) {
  return s
    .replace(/[۰-۹]/g, (d) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d)))
    .replace(/[٠-٩]/g, (d) => String("٠١٢٣٤٥٦٧٨٩".indexOf(d)));
}

export function formatNumber(n: number, digits = 0) {
  return fa(n.toFixed(digits));
}

export function formatPercent(n: number | null | undefined) {
  if (n === null || n === undefined || Number.isNaN(n)) return "—";
  return fa(Math.round(n)) + "٪";
}

/** Short date e.g. ۱۴۰۳/۰۱/۱۵ */
export function formatDateShort(iso: ISODate | null | undefined, mode: DateMode = "jalali") {
  if (!iso) return "—";
  if (mode === "gregorian") return fa(iso.replaceAll("-", "/"));
  const { jy, jm, jd } = isoToJalali(iso);
  return fa(`${jy}/${String(jm).padStart(2, "0")}/${String(jd).padStart(2, "0")}`);
}

/** Long date e.g. ۱۵ فروردین ۱۴۰۳ */
export function formatDateLong(iso: ISODate | null | undefined, mode: DateMode = "jalali", withWeekday = false) {
  if (!iso) return "—";
  const wd = withWeekday ? WEEKDAYS_FA[weekdayOf(iso)] + "، " : "";
  if (mode === "gregorian") {
    const [y, m, d] = iso.split("-").map(Number);
    return wd + fa(`${d} ${GREGORIAN_MONTHS_FA[m - 1]} ${y}`);
  }
  const { jy, jm, jd } = isoToJalali(iso);
  return wd + fa(`${jd} ${JALALI_MONTHS[jm - 1]} ${jy}`);
}

/** Day + month only */
export function formatDayMonth(iso: ISODate, mode: DateMode = "jalali") {
  if (mode === "gregorian") {
    const [, m, d] = iso.split("-").map(Number);
    return fa(`${d} ${GREGORIAN_MONTHS_FA[m - 1]}`);
  }
  const { jm, jd } = isoToJalali(iso);
  return fa(`${jd} ${JALALI_MONTHS[jm - 1]}`);
}

export function formatDateTime(date: Date | string | null | undefined, tz: string, mode: DateMode = "jalali") {
  if (!date) return "—";
  const d = typeof date === "string" ? new Date(date) : date;
  return `${formatDateShort(localDate(d, tz), mode)} ${fa(localTime(d, tz))}`;
}

export function formatTime(date: Date | string | null | undefined, tz: string) {
  if (!date) return "—";
  const d = typeof date === "string" ? new Date(date) : date;
  return fa(localTime(d, tz));
}

/** 135 → «۲ ساعت و ۱۵ دقیقه» */
export function formatMinutes(total: number | null | undefined, compact = false) {
  if (total === null || total === undefined || Number.isNaN(total)) return "—";
  const m = Math.round(total);
  const h = Math.floor(m / 60);
  const r = m % 60;
  if (compact) return fa(`${h}:${String(r).padStart(2, "0")}`);
  if (h === 0) return fa(`${r} دقیقه`);
  if (r === 0) return fa(`${h} ساعت`);
  return fa(`${h} ساعت و ${r} دقیقه`);
}

export function formatClock(seconds: number) {
  const s = Math.max(0, Math.floor(seconds));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  const mm = String(m).padStart(2, "0");
  const ss = String(sec).padStart(2, "0");
  return fa(h > 0 ? `${h}:${mm}:${ss}` : `${mm}:${ss}`);
}

export function relativeDays(iso: ISODate, today: ISODate, diff: number) {
  if (iso === today) return "امروز";
  if (diff === 1) return "فردا";
  if (diff === -1) return "دیروز";
  if (diff > 0) return fa(`${diff} روز دیگر`);
  return fa(`${-diff} روز پیش`);
}
