import "server-only";
import { and, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { goals, milestones, projects, tasks } from "@/db/schema";
import { toLatinDigits } from "./format";
import { isHHMM, isIsoDate } from "./time";

export type ActionResult<T = unknown> =
  | { ok: true; id?: string; data?: T; message?: string }
  | { ok: false; error: string; conflicts?: { title: string; detail: string }[]; needsConfirm?: boolean };

export class ValidationError extends Error {}

/** Tiny typed reader around FormData with validation & Persian-digit normalisation. */
export function reader(formData: FormData) {
  const raw = (k: string) => {
    const v = formData.get(k);
    return typeof v === "string" ? toLatinDigits(v).trim() : "";
  };
  return {
    has: (k: string) => formData.has(k),
    str(k: string, label: string, max = 500) {
      const v = raw(k);
      if (!v) throw new ValidationError(`«${label}» الزامی است.`);
      if (v.length > max) throw new ValidationError(`«${label}» نباید بیشتر از ${max} نویسه باشد.`);
      return v;
    },
    optStr(k: string, max = 20000) {
      const v = raw(k);
      if (v.length > max) throw new ValidationError(`متن بیش از حد طولانی است (حداکثر ${max} نویسه).`);
      return v || null;
    },
    optInt(k: string, label: string, min = 0, max = 100000) {
      const v = raw(k);
      if (!v) return null;
      const n = Number(v);
      if (!Number.isFinite(n) || !Number.isInteger(n)) throw new ValidationError(`«${label}» باید عدد صحیح باشد.`);
      if (n < min || n > max) throw new ValidationError(`«${label}» باید بین ${min} و ${max} باشد.`);
      return n;
    },
    int(k: string, label: string, min = 0, max = 100000) {
      const n = this.optInt(k, label, min, max);
      if (n === null) throw new ValidationError(`«${label}» الزامی است.`);
      return n;
    },
    optNum(k: string, label: string) {
      const v = raw(k);
      if (!v) return null;
      const n = Number(v);
      if (!Number.isFinite(n)) throw new ValidationError(`«${label}» باید عدد باشد.`);
      return n;
    },
    optDate(k: string, label: string) {
      const v = raw(k);
      if (!v) return null;
      if (!isIsoDate(v)) throw new ValidationError(`تاریخ «${label}» معتبر نیست.`);
      return v;
    },
    date(k: string, label: string) {
      const v = this.optDate(k, label);
      if (!v) throw new ValidationError(`«${label}» الزامی است.`);
      return v;
    },
    optTime(k: string, label: string) {
      const v = raw(k);
      if (!v) return null;
      if (!isHHMM(v)) throw new ValidationError(`ساعت «${label}» معتبر نیست.`);
      return v;
    },
    time(k: string, label: string) {
      const v = this.optTime(k, label);
      if (!v) throw new ValidationError(`«${label}» الزامی است.`);
      return v;
    },
    oneOf<T extends string>(k: string, allowed: readonly T[], fallback: T): T {
      const v = raw(k);
      return (allowed as readonly string[]).includes(v) ? (v as T) : fallback;
    },
    optOneOf<T extends string>(k: string, allowed: readonly T[]): T | null {
      const v = raw(k);
      return (allowed as readonly string[]).includes(v) ? (v as T) : null;
    },
    bool(k: string) {
      const v = raw(k);
      return v === "on" || v === "true" || v === "1";
    },
    ints(k: string, min = 0, max = 6) {
      return formData
        .getAll(k)
        .map((x) => Number(x))
        .filter((n) => Number.isInteger(n) && n >= min && n <= max);
    },
    tags(k: string) {
      return [
        ...new Set(
          raw(k)
            .split(/[,،#\n]/)
            .map((s) => s.trim())
            .filter(Boolean)
            .slice(0, 20)
            .map((s) => s.slice(0, 40)),
        ),
      ];
    },
    uuid(k: string) {
      const v = raw(k);
      return /^[0-9a-f-]{36}$/i.test(v) ? v : null;
    },
  };
}

export function fail(e: unknown): ActionResult {
  if (e instanceof ValidationError) return { ok: false, error: e.message };
  // Avoid leaking internals; log minimal info server-side.
  const msg = e instanceof Error ? e.message : String(e);
  if (msg.includes("NEXT_REDIRECT")) throw e;
  if (/duplicate key|unique/i.test(msg)) return { ok: false, error: "این مورد قبلاً ثبت شده است (رکورد تکراری)." };
  console.error("[action-error]", msg.slice(0, 200));
  return { ok: false, error: "خطایی رخ داد. لطفاً دوباره تلاش کنید." };
}

/**
 * Validate that linked records belong to the user. Returns null for links that
 * don't exist or belong to someone else, so IDs can't be forged across accounts.
 */
export async function ownedLinks(
  userId: string,
  links: { goalId?: string | null; projectId?: string | null; taskId?: string | null; milestoneId?: string | null },
) {
  const out = { goalId: null as string | null, projectId: null as string | null, taskId: null as string | null, milestoneId: null as string | null };
  if (links.goalId) {
    const r = await db.select({ id: goals.id }).from(goals).where(and(eq(goals.id, links.goalId), eq(goals.userId, userId))).limit(1);
    out.goalId = r[0]?.id ?? null;
  }
  if (links.projectId) {
    const r = await db.select({ id: projects.id }).from(projects).where(and(eq(projects.id, links.projectId), eq(projects.userId, userId))).limit(1);
    out.projectId = r[0]?.id ?? null;
  }
  if (links.taskId) {
    const r = await db.select({ id: tasks.id }).from(tasks).where(and(eq(tasks.id, links.taskId), eq(tasks.userId, userId))).limit(1);
    out.taskId = r[0]?.id ?? null;
  }
  if (links.milestoneId) {
    const r = await db.select({ id: milestones.id }).from(milestones).where(and(eq(milestones.id, links.milestoneId), eq(milestones.userId, userId))).limit(1);
    out.milestoneId = r[0]?.id ?? null;
  }
  return out;
}

export async function ownedGoalIds(userId: string, ids: string[]) {
  if (ids.length === 0) return [];
  const r = await db.select({ id: goals.id }).from(goals).where(and(eq(goals.userId, userId), inArray(goals.id, ids)));
  return r.map((x) => x.id);
}
