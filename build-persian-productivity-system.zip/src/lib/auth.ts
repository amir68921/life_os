import "server-only";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { randomUUID, createHash } from "crypto";
import bcrypt from "bcryptjs";
import { eq, lt } from "drizzle-orm";
import { db } from "@/db";
import { users, authSessions, userSettings } from "@/db/schema";
import type { InferSelectModel } from "drizzle-orm";

export type User = InferSelectModel<typeof users>;
export type Settings = InferSelectModel<typeof userSettings>;

const COOKIE = "lifeos_session";
const SESSION_DAYS = 30;

export function hashPassword(pw: string): string {
  return bcrypt.hashSync(pw, 10);
}

export function checkPassword(pw: string, hash: string): boolean {
  try {
    return bcrypt.compareSync(pw, hash);
  } catch {
    return false;
  }
}

export async function createSession(userId: string) {
  const token = randomUUID() + randomUUID();
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 86400000);
  await db.insert(authSessions).values({ token, userId, expiresAt });
  // جاروی نشست‌های منقضی‌شده، به‌صورت فرصت‌طلبانه
  db.delete(authSessions).where(lt(authSessions.expiresAt, new Date())).catch(() => {});
  const store = await cookies();
  store.set(COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    expires: expiresAt,
    path: "/",
  });
}

export async function destroySession() {
  const store = await cookies();
  const token = store.get(COOKIE)?.value;
  if (token) {
    await db.delete(authSessions).where(eq(authSessions.token, token)).catch(() => {});
  }
  store.delete(COOKIE);
}

export async function getUser(): Promise<(User & { settings: Settings }) | null> {
  const store = await cookies();
  const token = store.get(COOKIE)?.value;
  if (!token) return null;
  const rows = await db
    .select({ user: users, session: authSessions })
    .from(authSessions)
    .innerJoin(users, eq(users.id, authSessions.userId))
    .where(eq(authSessions.token, token))
    .limit(1);
  const row = rows[0];
  if (!row) return null;
  if (row.session.expiresAt < new Date()) {
    await db.delete(authSessions).where(eq(authSessions.token, token)).catch(() => {});
    return null;
  }
  const settingsRows = await db.select().from(userSettings).where(eq(userSettings.userId, row.user.id)).limit(1);
  return { ...row.user, settings: settingsRows[0] ?? defaultSettings(row.user.id) };
}

function defaultSettings(userId: string): Settings {
  return {
    userId, theme: "system", timezone: "Asia/Tehran", weekStart: 0,
    defaultFocusMinutes: 25, defaultBreakMinutes: 5,
    targetBedTime: "23:00", targetWakeTime: "07:00", targetSleepMinutes: 480,
  };
}

export async function requireUser(): Promise<User & { settings: Settings }> {
  const user = await getUser();
  if (!user) redirect("/login");
  return user;
}

/** fingerprint hash used only for safe logging (never log raw tokens) */
export function tokenFp(token: string): string {
  return createHash("sha256").update(token).digest("hex").slice(0, 8);
}
