import "server-only";
import { cache } from "react";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { and, eq, gt, lt } from "drizzle-orm";
import { db } from "@/db";
import { preferences, sessions, users } from "@/db/schema";
import { hashToken, newSessionToken } from "./password";

export const SESSION_COOKIE = "lifeos_session";
const SESSION_DAYS = 30;

export async function createSession(userId: string) {
  const token = newSessionToken();
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 86400000);
  await db.insert(sessions).values({ id: hashToken(token), userId, expiresAt });
  // opportunistic cleanup of expired sessions
  await db.delete(sessions).where(lt(sessions.expiresAt, new Date()));
  const jar = await cookies();
  jar.set(SESSION_COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production" && process.env.INSECURE_COOKIES !== "1",
    sameSite: "lax",
    path: "/",
    expires: expiresAt,
  });
}

export async function destroySession() {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (token) await db.delete(sessions).where(eq(sessions.id, hashToken(token)));
  jar.delete(SESSION_COOKIE);
}

export type CurrentUser = { id: string; email: string; name: string };

export const getCurrentUser = cache(async (): Promise<CurrentUser | null> => {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  const rows = await db
    .select({ id: users.id, email: users.email, name: users.name })
    .from(sessions)
    .innerJoin(users, eq(users.id, sessions.userId))
    .where(and(eq(sessions.id, hashToken(token)), gt(sessions.expiresAt, new Date())))
    .limit(1);
  return rows[0] ?? null;
});

/** Server-side guard: every page and action that touches private data calls this. */
export async function requireUser(): Promise<CurrentUser> {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  return user;
}

export type Prefs = typeof preferences.$inferSelect;

export const getPrefs = cache(async (userId: string): Promise<Prefs> => {
  const rows = await db.select().from(preferences).where(eq(preferences.userId, userId)).limit(1);
  if (rows[0]) return rows[0];
  const inserted = await db.insert(preferences).values({ userId }).onConflictDoNothing().returning();
  if (inserted[0]) return inserted[0];
  const again = await db.select().from(preferences).where(eq(preferences.userId, userId)).limit(1);
  return again[0];
});

/** Convenience: user + prefs in one call. */
export async function requireContext() {
  const user = await requireUser();
  const prefs = await getPrefs(user.id);
  return { user, prefs, tz: prefs.timezone, mode: prefs.dateFormat as "jalali" | "gregorian" };
}
