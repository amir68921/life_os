import { sql } from "drizzle-orm";
import {
  pgTable,
  uuid,
  text,
  timestamp,
  integer,
  boolean,
  date,
  jsonb,
  index,
  uniqueIndex,
  primaryKey,
  check,
  real,
} from "drizzle-orm/pg-core";

const createdAt = () => timestamp("created_at", { withTimezone: true }).notNull().defaultNow();
const updatedAt = () => timestamp("updated_at", { withTimezone: true }).notNull().defaultNow();

/* ----------------------------- Users & auth ----------------------------- */

export const users = pgTable("users", {
  id: uuid("id").primaryKey().defaultRandom(),
  email: text("email").notNull().unique(),
  name: text("name").notNull(),
  passwordHash: text("password_hash").notNull(),
  createdAt: createdAt(),
});

export const sessions = pgTable(
  "sessions",
  {
    // sha256 hash of the session token – raw token only lives in the httpOnly cookie
    id: text("id").primaryKey(),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    createdAt: createdAt(),
  },
  (t) => [index("sessions_user_idx").on(t.userId)],
);

export type NotificationPrefs = { focusEnd: boolean; dailyReview: boolean; habitReminder: boolean };

export const preferences = pgTable("preferences", {
  userId: uuid("user_id").primaryKey().references(() => users.id, { onDelete: "cascade" }),
  language: text("language").notNull().default("fa"),
  theme: text("theme").notNull().default("system"), // light | dark | system
  timezone: text("timezone").notNull().default("Asia/Tehran"),
  dateFormat: text("date_format").notNull().default("jalali"), // jalali | gregorian
  weekStart: integer("week_start").notNull().default(6), // 0=Sunday … 6=Saturday
  focusMinutes: integer("focus_minutes").notNull().default(25),
  breakMinutes: integer("break_minutes").notNull().default(5),
  sleepTargetBed: text("sleep_target_bed").notNull().default("23:00"),
  sleepTargetWake: text("sleep_target_wake").notNull().default("07:00"),
  sleepTargetMinutes: integer("sleep_target_minutes").notNull().default(480),
  notifications: jsonb("notifications")
    .$type<NotificationPrefs>()
    .notNull()
    .default({ focusEnd: true, dailyReview: false, habitReminder: false }),
  dashboardWidgets: jsonb("dashboard_widgets")
    .$type<string[]>()
    .notNull()
    .default(["tasks", "focus", "sleep", "habits", "goals", "deadlines"]),
  updatedAt: updatedAt(),
});

/* -------------------------------- Goals -------------------------------- */

export const goals = pgTable(
  "goals",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    parentId: uuid("parent_id"),
    title: text("title").notNull(),
    description: text("description"),
    category: text("category"),
    horizon: text("horizon").notNull().default("medium"), // long | medium | short
    startDate: date("start_date"),
    targetDate: date("target_date"),
    priority: text("priority").notNull().default("medium"),
    status: text("status").notNull().default("active"), // active | paused | completed | archived | abandoned
    successCriteria: text("success_criteria"),
    progress: integer("progress").notNull().default(0),
    notes: text("notes"),
    archivedAt: timestamp("archived_at", { withTimezone: true }),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (t) => [
    index("goals_user_idx").on(t.userId, t.status),
    check("goals_progress_range", sql`${t.progress} between 0 and 100`),
  ],
);

export const goalProgressLog = pgTable(
  "goal_progress_log",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    goalId: uuid("goal_id").notNull().references(() => goals.id, { onDelete: "cascade" }),
    progress: integer("progress").notNull(),
    recordedAt: timestamp("recorded_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("gpl_goal_idx").on(t.goalId, t.recordedAt)],
);

/* ------------------------------- Projects ------------------------------ */

export const projects = pgTable(
  "projects",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    name: text("name").notNull(),
    description: text("description"),
    objective: text("objective"),
    startDate: date("start_date"),
    targetDate: date("target_date"),
    priority: text("priority").notNull().default("medium"),
    status: text("status").notNull().default("planned"), // planned | active | on_hold | completed | archived
    progress: integer("progress").notNull().default(0),
    notes: text("notes"),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (t) => [
    index("projects_user_idx").on(t.userId, t.status),
    check("projects_progress_range", sql`${t.progress} between 0 and 100`),
  ],
);

export const projectGoals = pgTable(
  "project_goals",
  {
    projectId: uuid("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
    goalId: uuid("goal_id").notNull().references(() => goals.id, { onDelete: "cascade" }),
  },
  (t) => [primaryKey({ columns: [t.projectId, t.goalId] })],
);

export const milestones = pgTable(
  "milestones",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    goalId: uuid("goal_id").references(() => goals.id, { onDelete: "cascade" }),
    projectId: uuid("project_id").references(() => projects.id, { onDelete: "cascade" }),
    title: text("title").notNull(),
    dueDate: date("due_date"),
    completedAt: timestamp("completed_at", { withTimezone: true }),
    createdAt: createdAt(),
  },
  (t) => [index("milestones_goal_idx").on(t.goalId), index("milestones_project_idx").on(t.projectId)],
);

/* -------------------------------- Tasks -------------------------------- */

export type Recurrence = {
  freq: "daily" | "weekly" | "monthly";
  interval: number;
  weekdays?: number[]; // 0=Sunday … 6=Saturday (weekly only)
  until?: string | null; // YYYY-MM-DD
};

export const tasks = pgTable(
  "tasks",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    title: text("title").notNull(),
    description: text("description"),
    dueDate: date("due_date"),
    plannedStart: text("planned_start"), // HH:MM local time on dueDate
    estimatedMinutes: integer("estimated_minutes"),
    actualMinutes: integer("actual_minutes"),
    priority: text("priority").notNull().default("medium"), // low | medium | high | critical
    status: text("status").notNull().default("todo"), // todo | in_progress | done | cancelled
    category: text("category"),
    goalId: uuid("goal_id").references(() => goals.id, { onDelete: "set null" }),
    projectId: uuid("project_id").references(() => projects.id, { onDelete: "set null" }),
    milestoneId: uuid("milestone_id").references(() => milestones.id, { onDelete: "set null" }),
    energy: text("energy"), // low | medium | high
    tags: text("tags").array().notNull().default(sql`'{}'::text[]`),
    recurrence: jsonb("recurrence").$type<Recurrence | null>(),
    seriesId: uuid("series_id"), // shared by all occurrences of a recurring task
    isMit: boolean("is_mit").notNull().default(false), // most important task of its day
    postponeCount: integer("postpone_count").notNull().default(0),
    completedAt: timestamp("completed_at", { withTimezone: true }),
    notes: text("notes"),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (t) => [
    index("tasks_user_due_idx").on(t.userId, t.dueDate),
    index("tasks_user_status_idx").on(t.userId, t.status),
    index("tasks_goal_idx").on(t.goalId),
    index("tasks_project_idx").on(t.projectId),
    uniqueIndex("tasks_series_due_uq").on(t.seriesId, t.dueDate),
  ],
);

/* ---------------------------- Planner blocks ---------------------------- */

export const timeBlocks = pgTable(
  "time_blocks",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    title: text("title").notNull(),
    kind: text("kind").notNull().default("task"), // task | focus | break | personal | other
    date: date("date").notNull(), // first (or only) date, local
    startMinute: integer("start_minute").notNull(), // minutes since local midnight
    endMinute: integer("end_minute").notNull(),
    repeatWeekdays: integer("repeat_weekdays").array(), // null = one-off
    repeatUntil: date("repeat_until"),
    taskId: uuid("task_id").references(() => tasks.id, { onDelete: "set null" }),
    notes: text("notes"),
    createdAt: createdAt(),
  },
  (t) => [
    index("blocks_user_date_idx").on(t.userId, t.date),
    check("blocks_range", sql`${t.startMinute} >= 0 and ${t.endMinute} <= 1440 and ${t.endMinute} > ${t.startMinute}`),
  ],
);

/* ----------------------------- Focus sessions ---------------------------- */

export const focusSessions = pgTable(
  "focus_sessions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    clientId: uuid("client_id").notNull(), // idempotency key generated by the browser
    taskId: uuid("task_id").references(() => tasks.id, { onDelete: "set null" }),
    projectId: uuid("project_id").references(() => projects.id, { onDelete: "set null" }),
    goalId: uuid("goal_id").references(() => goals.id, { onDelete: "set null" }),
    objective: text("objective"),
    plannedMinutes: integer("planned_minutes").notNull(),
    breakMinutes: integer("break_minutes").notNull().default(0),
    status: text("status").notNull().default("running"), // running | paused | completed | cancelled
    startedAt: timestamp("started_at", { withTimezone: true }).notNull(),
    pausedAt: timestamp("paused_at", { withTimezone: true }),
    pausedSeconds: integer("paused_seconds").notNull().default(0),
    endedAt: timestamp("ended_at", { withTimezone: true }),
    elapsedSeconds: integer("elapsed_seconds"), // measured, excludes pauses
    focusedMinutes: integer("focused_minutes"), // self-reported, never assumed
    energyBefore: integer("energy_before"),
    focusBefore: integer("focus_before"),
    energyAfter: integer("energy_after"),
    focusRating: integer("focus_rating"),
    objectiveAchieved: text("objective_achieved"), // yes | partly | no
    nextStep: text("next_step"),
    reflection: text("reflection"),
    finishedEarly: boolean("finished_early").notNull().default(false),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (t) => [
    uniqueIndex("focus_client_uq").on(t.userId, t.clientId),
    uniqueIndex("focus_one_active_uq").on(t.userId).where(sql`status in ('running','paused')`),
    index("focus_user_started_idx").on(t.userId, t.startedAt),
  ],
);

export const interruptions = pgTable(
  "interruptions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    sessionId: uuid("session_id").notNull().references(() => focusSessions.id, { onDelete: "cascade" }),
    kind: text("kind").notNull().default("interruption"), // interruption | distraction
    reason: text("reason").notNull(),
    occurredAt: timestamp("occurred_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("interruptions_session_idx").on(t.sessionId), index("interruptions_user_idx").on(t.userId, t.occurredAt)],
);

/* --------------------------------- Sleep -------------------------------- */

export const sleepRecords = pgTable(
  "sleep_records",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    wakeDate: date("wake_date").notNull(), // local date of waking up – one main record per night
    bedTime: timestamp("bed_time", { withTimezone: true }).notNull(),
    sleepStart: timestamp("sleep_start", { withTimezone: true }),
    wakeTime: timestamp("wake_time", { withTimezone: true }).notNull(),
    durationMinutes: integer("duration_minutes").notNull(), // estimated sleep
    quality: integer("quality"),
    morningEnergy: integer("morning_energy"),
    awakenings: integer("awakenings"),
    notes: text("notes"),
    source: text("source").notNull().default("manual"), // manual | device
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (t) => [
    uniqueIndex("sleep_user_wake_uq").on(t.userId, t.wakeDate),
    check("sleep_order", sql`${t.wakeTime} > ${t.bedTime}`),
  ],
);

/* -------------------------------- Habits -------------------------------- */

export const habits = pgTable(
  "habits",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    name: text("name").notNull(),
    description: text("description"),
    category: text("category"),
    frequency: text("frequency").notNull().default("daily"), // daily | custom | weekly
    weekdays: integer("weekdays").array(), // custom: scheduled weekdays
    timesPerWeek: integer("times_per_week"), // weekly: target count per week
    minTarget: real("min_target"),
    idealTarget: real("ideal_target"),
    unit: text("unit"),
    startDate: date("start_date").notNull(),
    endDate: date("end_date"),
    status: text("status").notNull().default("active"), // active | paused
    createdAt: createdAt(),
  },
  (t) => [index("habits_user_idx").on(t.userId)],
);

export const habitPauses = pgTable(
  "habit_pauses",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    habitId: uuid("habit_id").notNull().references(() => habits.id, { onDelete: "cascade" }),
    startDate: date("start_date").notNull(),
    endDate: date("end_date"), // null = still paused
  },
  (t) => [index("habit_pauses_habit_idx").on(t.habitId)],
);

export const habitOccurrences = pgTable(
  "habit_occurrences",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    habitId: uuid("habit_id").notNull().references(() => habits.id, { onDelete: "cascade" }),
    date: date("date").notNull(),
    status: text("status").notNull(), // completed | partial | missed | skipped
    value: real("value"),
    note: text("note"),
    createdAt: createdAt(),
  },
  (t) => [uniqueIndex("habit_occ_uq").on(t.habitId, t.date), index("habit_occ_user_idx").on(t.userId, t.date)],
);

/* ------------------------------- Activities ------------------------------ */

export const activities = pgTable(
  "activities",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    title: text("title").notNull(),
    category: text("category").notNull().default("other"),
    startAt: timestamp("start_at", { withTimezone: true }).notNull(),
    endAt: timestamp("end_at", { withTimezone: true }).notNull(),
    taskId: uuid("task_id").references(() => tasks.id, { onDelete: "set null" }),
    projectId: uuid("project_id").references(() => projects.id, { onDelete: "set null" }),
    goalId: uuid("goal_id").references(() => goals.id, { onDelete: "set null" }),
    focusSessionId: uuid("focus_session_id").references(() => focusSessions.id, { onDelete: "set null" }),
    notes: text("notes"),
    source: text("source").notNull().default("manual"), // manual | focus | import
    createdAt: createdAt(),
  },
  (t) => [
    index("activities_user_start_idx").on(t.userId, t.startAt),
    uniqueIndex("activities_dup_uq").on(t.userId, t.title, t.startAt),
    uniqueIndex("activities_focus_uq").on(t.focusSessionId),
    check("activities_order", sql`${t.endAt} > ${t.startAt}`),
  ],
);

/* --------------------------------- Notes -------------------------------- */

export const notes = pgTable(
  "notes",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    title: text("title").notNull(),
    content: text("content").notNull().default(""),
    kind: text("kind").notNull().default("note"), // note | lesson | reflection | idea
    tags: text("tags").array().notNull().default(sql`'{}'::text[]`),
    projectId: uuid("project_id").references(() => projects.id, { onDelete: "set null" }),
    goalId: uuid("goal_id").references(() => goals.id, { onDelete: "set null" }),
    taskId: uuid("task_id").references(() => tasks.id, { onDelete: "set null" }),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (t) => [index("notes_user_idx").on(t.userId, t.updatedAt)],
);

/* -------------------------------- Reviews ------------------------------- */

export const dailyReviews = pgTable(
  "daily_reviews",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    date: date("date").notNull(),
    accomplishment: text("accomplishment"),
    goalProgress: text("goal_progress"),
    distractions: text("distractions"),
    wentWell: text("went_well"),
    improve: text("improve"),
    tomorrowPriority: text("tomorrow_priority"),
    energy: integer("energy"),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (t) => [uniqueIndex("daily_review_uq").on(t.userId, t.date)],
);

export type Suggestion = {
  id: string;
  text: string;
  basis: string;
  status: "pending" | "accepted" | "dismissed";
};

export const weeklyReviews = pgTable(
  "weekly_reviews",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    weekStart: date("week_start").notNull(),
    wins: text("wins"),
    challenges: text("challenges"),
    reflection: text("reflection"),
    nextWeekFocus: text("next_week_focus"),
    suggestions: jsonb("suggestions").$type<Suggestion[]>().notNull().default([]),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (t) => [uniqueIndex("weekly_review_uq").on(t.userId, t.weekStart)],
);
