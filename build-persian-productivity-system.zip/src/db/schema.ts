import {
  pgTable, uuid, text, integer, boolean, timestamp, date,
  uniqueIndex, index, type AnyPgColumn,
} from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";

// ---------- Auth ----------
export const users = pgTable("users", {
  id: uuid("id").defaultRandom().primaryKey(),
  username: text("username").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  displayName: text("display_name"),
  createdAt: timestamp("created_at", { withTimezone: true, mode: "date" }).notNull().defaultNow(),
});

export const authSessions = pgTable("auth_sessions", {
  token: text("token").primaryKey(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  expiresAt: timestamp("expires_at", { withTimezone: true, mode: "date" }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true, mode: "date" }).notNull().defaultNow(),
});

export const userSettings = pgTable("user_settings", {
  userId: uuid("user_id").primaryKey().references(() => users.id, { onDelete: "cascade" }),
  theme: text("theme").notNull().default("system"), // light | dark | system
  timezone: text("timezone").notNull().default("Asia/Tehran"),
  weekStart: integer("week_start").notNull().default(0), // 0 = شنبه (روزِ هفتهٔ جلالی) ، 6 = جمعه
  defaultFocusMinutes: integer("default_focus_minutes").notNull().default(25),
  defaultBreakMinutes: integer("default_break_minutes").notNull().default(5),
  targetBedTime: text("target_bed_time").notNull().default("23:00"),
  targetWakeTime: text("target_wake_time").notNull().default("07:00"),
  targetSleepMinutes: integer("target_sleep_minutes").notNull().default(480),
});

// ---------- Goals ----------
export const goals = pgTable("goals", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  parentId: uuid("parent_id").references((): AnyPgColumn => goals.id, { onDelete: "set null" }),
  title: text("title").notNull(),
  description: text("description"),
  category: text("category"),
  timeframe: text("timeframe").notNull().default("medium"), // short | medium | long
  priority: text("priority").notNull().default("medium"), // low | medium | high
  status: text("status").notNull().default("active"), // active | paused | completed | archived
  startDate: date("start_date", { mode: "string" }),
  targetDate: date("target_date", { mode: "string" }),
  successCriteria: text("success_criteria"),
  progress: integer("progress").notNull().default(0), // 0-100
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true, mode: "date" }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true, mode: "date" }).notNull().defaultNow(),
}, (t) => [index("goals_user_idx").on(t.userId), index("goals_target_idx").on(t.userId, t.targetDate)]);

export const milestones = pgTable("milestones", {
  id: uuid("id").defaultRandom().primaryKey(),
  goalId: uuid("goal_id").notNull().references(() => goals.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  dueDate: date("due_date", { mode: "string" }),
  done: boolean("done").notNull().default(false),
  doneAt: timestamp("done_at", { withTimezone: true, mode: "date" }),
  sortOrder: integer("sort_order").notNull().default(0),
}, (t) => [index("milestones_goal_idx").on(t.goalId)]);

// ---------- Tasks ----------
export const tasks = pgTable("tasks", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  goalId: uuid("goal_id").references(() => goals.id, { onDelete: "set null" }),
  title: text("title").notNull(),
  description: text("description"),
  dueDate: date("due_date", { mode: "string" }),
  plannedStart: text("planned_start"), // HH:mm
  plannedEnd: text("planned_end"), // HH:mm
  estimatedMinutes: integer("estimated_minutes"),
  actualMinutes: integer("actual_minutes"),
  priority: text("priority").notNull().default("medium"),
  status: text("status").notNull().default("pending"), // pending | in_progress | done | cancelled
  category: text("category"),
  energy: text("energy"), // low | medium | high
  tags: text("tags"),
  recurrence: text("recurrence").notNull().default("none"), // none | daily | weekly | weekdays
  completedAt: timestamp("completed_at", { withTimezone: true, mode: "date" }),
  completedDate: date("completed_date", { mode: "string" }),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true, mode: "date" }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true, mode: "date" }).notNull().defaultNow(),
}, (t) => [index("tasks_user_due_idx").on(t.userId, t.dueDate), index("tasks_user_idx").on(t.userId)]);

// ---------- Focus ----------
export const focusSessions = pgTable("focus_sessions", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  taskId: uuid("task_id").references(() => tasks.id, { onDelete: "set null" }),
  goalId: uuid("goal_id").references(() => goals.id, { onDelete: "set null" }),
  objective: text("objective"),
  plannedMinutes: integer("planned_minutes").notNull().default(25),
  localDate: date("local_date", { mode: "string" }).notNull(), // روزِ شروع به تقویم کاربر
  status: text("status").notNull().default("active"), // active | paused | completed | cancelled
  startedAt: timestamp("started_at", { withTimezone: true, mode: "date" }).notNull().defaultNow(),
  endedAt: timestamp("ended_at", { withTimezone: true, mode: "date" }),
  pausedSeconds: integer("paused_seconds").notNull().default(0),
  pauseStartedAt: timestamp("pause_started_at", { withTimezone: true, mode: "date" }),
  elapsedSeconds: integer("elapsed_seconds"), // مدت واقعی نهایی
  focusedMinutesSelf: integer("focused_minutes_self"), // گزارش خودِ کاربر — با مدت واقعی یکی نیست
  energyStart: integer("energy_start"), // 1-5
  focusRatingStart: integer("focus_rating_start"), // 1-5
  achievedObjective: boolean("achieved_objective"),
  focusRatingEnd: integer("focus_rating_end"), // 1-5
  energyEnd: integer("energy_end"), // 1-5
  interruptionsNote: text("interruptions_note"),
  nextSteps: text("next_steps"),
  interruptionsCount: integer("interruptions_count").notNull().default(0),
  distractions: text("distractions").array().notNull().default(sql`ARRAY[]::text[]`),
  createdAt: timestamp("created_at", { withTimezone: true, mode: "date" }).notNull().defaultNow(),
}, (t) => [index("focus_user_date_idx").on(t.userId, t.localDate)]);

export const interruptions = pgTable("interruptions", {
  id: uuid("id").defaultRandom().primaryKey(),
  sessionId: uuid("session_id").notNull().references(() => focusSessions.id, { onDelete: "cascade" }),
  occurredAt: timestamp("occurred_at", { withTimezone: true, mode: "date" }).notNull().defaultNow(),
  note: text("note"),
}, (t) => [index("interruptions_session_idx").on(t.sessionId)]);

// ---------- Sleep ----------
export const sleepRecords = pgTable("sleep_records", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  wakeDate: date("wake_date", { mode: "string" }).notNull(), // تاریخ بیدار شدن — مرجع رکورد
  bedTime: timestamp("bed_time", { withTimezone: true, mode: "date" }).notNull(),
  fallAsleepTime: timestamp("fall_asleep_time", { withTimezone: true, mode: "date" }),
  wakeTime: timestamp("wake_time", { withTimezone: true, mode: "date" }).notNull(),
  durationMinutes: integer("duration_minutes"), // تخمین کاربر از خواب واقعی (ممکن است از نیمه‌شب بگذرد)
  quality: integer("quality"), // 1-5
  morningEnergy: integer("morning_energy"), // 1-5
  awakenings: integer("awakenings"),
  notes: text("notes"),
  source: text("source").notNull().default("manual"), // manual | جهت توسعهٔ آینده
  createdAt: timestamp("created_at", { withTimezone: true, mode: "date" }).notNull().defaultNow(),
}, (t) => [uniqueIndex("sleep_user_wakedate_idx").on(t.userId, t.wakeDate)]);

// ---------- Habits ----------
export const habits = pgTable("habits", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  description: text("description"),
  category: text("category"),
  frequency: text("frequency").notNull().default("daily"), // daily | custom
  weekdays: integer("weekdays").array().notNull().default(sql`ARRAY[]::integer[]`), // 0=شنبه … 6=جمعه
  minTarget: integer("min_target").notNull().default(1),
  idealTarget: integer("ideal_target"),
  unit: text("unit"), // مثلاً «دقیقه»، «بار»، «صفحه»
  startDate: date("start_date", { mode: "string" }).notNull(),
  endDate: date("end_date", { mode: "string" }),
  status: text("status").notNull().default("active"), // active | paused
  createdAt: timestamp("created_at", { withTimezone: true, mode: "date" }).notNull().defaultNow(),
}, (t) => [index("habits_user_idx").on(t.userId)]);

export const habitOccurrences = pgTable("habit_occurrences", {
  id: uuid("id").defaultRandom().primaryKey(),
  habitId: uuid("habit_id").notNull().references(() => habits.id, { onDelete: "cascade" }),
  date: date("date", { mode: "string" }).notNull(),
  status: text("status").notNull().default("done"), // done | partial | missed | skipped
  value: integer("value"),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true, mode: "date" }).notNull().defaultNow(),
}, (t) => [uniqueIndex("habit_occ_unique_idx").on(t.habitId, t.date)]);

// ---------- Reviews ----------
export const dailyReviews = pgTable("daily_reviews", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  date: date("date", { mode: "string" }).notNull(),
  accomplishment: text("accomplishment"),
  goalProgress: text("goal_progress"),
  distractions: text("distractions"),
  wentWell: text("went_well"),
  improve: text("improve"),
  tomorrowPriority: text("tomorrow_priority"),
  energy: integer("energy"), // 1-5
  createdAt: timestamp("created_at", { withTimezone: true, mode: "date" }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true, mode: "date" }).notNull().defaultNow(),
}, (t) => [uniqueIndex("daily_review_user_date_idx").on(t.userId, t.date)]);

export const weeklyReviews = pgTable("weekly_reviews", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  weekStart: date("week_start", { mode: "string" }).notNull(),
  reflection: text("reflection"),
  dismissedSuggestions: text("dismissed_suggestions").array().notNull().default(sql`ARRAY[]::text[]`),
  createdAt: timestamp("created_at", { withTimezone: true, mode: "date" }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true, mode: "date" }).notNull().defaultNow(),
}, (t) => [uniqueIndex("weekly_review_user_week_idx").on(t.userId, t.weekStart)]);
