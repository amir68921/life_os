"use client";

import React, { useState } from "react";
import { Field, Spinner } from "@/components/ui";
import { JalaliDatePicker, TimeField, Segmented } from "@/components/pickers";
import { createTask, updateTask } from "@/lib/actions-core";
import { PRIORITIES, ENERGIES, RECURRENCES, TASK_CATEGORIES } from "@/lib/utils";
import { useToast } from "@/components/ui";
import { addDaysIso, todayIso, faDateMed } from "@/lib/jalali";
import { AlertTriangle } from "lucide-react";

export type TaskFormInit = {
  id?: string;
  title?: string;
  description?: string | null;
  dueDate?: string | null;
  plannedStart?: string | null;
  plannedEnd?: string | null;
  estimatedMinutes?: number | null;
  actualMinutes?: number | null;
  priority?: string;
  category?: string | null;
  energy?: string | null;
  recurrence?: string;
  tags?: string | null;
  goalId?: string | null;
  notes?: string | null;
};

export function TaskForm({
  init, goals, onDone, defaultDate, defaultCategory,
}: {
  init?: TaskFormInit;
  goals: { id: string; title: string }[];
  onDone: () => void;
  defaultDate?: string;
  defaultCategory?: string;
}) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const [title, setTitle] = useState(init?.title ?? "");
  const [description, setDescription] = useState(init?.description ?? "");
  const [dueDate, setDueDate] = useState<string | null>(init?.dueDate ?? defaultDate ?? null);
  const [plannedStart, setPlannedStart] = useState(init?.plannedStart ?? "");
  const [plannedEnd, setPlannedEnd] = useState(init?.plannedEnd ?? "");
  const [est, setEst] = useState(init?.estimatedMinutes ? String(init.estimatedMinutes) : "");
  const [act, setAct] = useState(init?.actualMinutes ? String(init.actualMinutes) : "");
  const [priority, setPriority] = useState(init?.priority ?? "medium");
  const [category, setCategory] = useState(init?.category ?? defaultCategory ?? "");
  const [energy, setEnergy] = useState<string | null>(init?.energy ?? null);
  const [recurrence, setRecurrence] = useState(init?.recurrence ?? "none");
  const [tags, setTags] = useState(init?.tags ?? "");
  const [goalId, setGoalId] = useState(init?.goalId ?? "");
  const [notes, setNotes] = useState(init?.notes ?? "");
  const [conflict, setConflict] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [more, setMore] = useState(Boolean(init && (init.description || init.tags || init.notes || init.goalId)));

  const submit = async (force: boolean) => {
    setBusy(true);
    setError(null);
    setConflict(null);
    const payload = {
      title, description, dueDate, plannedStart: plannedStart || null, plannedEnd: plannedEnd || null,
      estimatedMinutes: est ? Number(est) : null, actualMinutes: act ? Number(act) : null,
      priority, category, energy, recurrence, tags, goalId: goalId || null, notes, force,
    };
    const r = init?.id
      ? await updateTask(init.id, payload)
      : await createTask(payload);
    setBusy(false);
    if (r.conflict) { setConflict(r.conflict); return; }
    if (r.error) { setError(r.error); return; }
    toast.push("ok", r.success ?? "ذخیره شد.");
    onDone();
  };

  return (
    <form
      className="space-y-4"
      onSubmit={(e) => { e.preventDefault(); void submit(false); }}
    >
      <Field label="عنوان وظیفه">
        <input className="input" value={title} onChange={(e) => setTitle(e.target.value)} required autoFocus placeholder="مثلاً: مطالعهٔ فصل سوم" />
      </Field>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Field label="روز انجام">
          <JalaliDatePicker value={dueDate} onChange={setDueDate} placeholder="بدون تاریخ" />
          <div className="mt-1.5 flex gap-1.5">
            {[["امروز", 0], ["فردا", 1]].map(([lbl, d]) => (
              <button key={lbl} type="button" className="chip transition-colors hover:opacity-80"
                onClick={() => setDueDate(addDaysIso(todayIso("Asia/Tehran"), d as number))}>
                {lbl}
              </button>
            ))}
            {dueDate && <span className="chip" style={{ background: "var(--accent-soft)", color: "var(--accent)", borderColor: "transparent" }}>{faDateMed(dueDate)}</span>}
          </div>
        </Field>
        <Field label="برآورد مدت (دقیقه)">
          <input className="input" type="number" min={1} max={480} inputMode="numeric" value={est} onChange={(e) => setEst(e.target.value)} placeholder="مثلاً ۴۵" />
        </Field>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <Field label="شروع برنامه‌ریزی‌شده">
          <TimeField value={plannedStart} onChange={setPlannedStart} />
        </Field>
        <Field label="پایان برنامه‌ریزی‌شده">
          <TimeField value={plannedEnd} onChange={setPlannedEnd} />
        </Field>
      </div>

      <Field label="اولویت">
        <Segmented options={[...PRIORITIES]} value={priority} onChange={setPriority} />
      </Field>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Field label="دسته‌بندی">
          <input className="input" list="task-cats" value={category} onChange={(e) => setCategory(e.target.value)} placeholder="انتخاب یا تایپ کنید" />
          <datalist id="task-cats">
            {TASK_CATEGORIES.map((c) => <option key={c} value={c} />)}
          </datalist>
        </Field>
        <Field label="انرژی لازم">
          <Segmented options={[{ value: "", label: "—" }, ...ENERGIES]} value={energy ?? ""} onChange={(v) => setEnergy(v || null)} />
        </Field>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Field label="تکرار">
          <select className="input" value={recurrence} onChange={(e) => setRecurrence(e.target.value)}>
            {RECURRENCES.map((r) => <option key={r.value} value={r.value}>{r.label}</option>)}
          </select>
        </Field>
        <Field label="هدف مرتبط">
          <select className="input" value={goalId} onChange={(e) => setGoalId(e.target.value)}>
            <option value="">— بدون هدف —</option>
            {goals.map((g) => <option key={g.id} value={g.id}>{g.title}</option>)}
          </select>
        </Field>
      </div>

      {init?.id && (
        <Field label="مدت واقعی (دقیقه)" hint="برای مقایسهٔ برآورد با واقعیت در تحلیل‌ها">
          <input className="input" type="number" min={1} max={1440} inputMode="numeric" value={act} onChange={(e) => setAct(e.target.value)} />
        </Field>
      )}

      <button type="button" className="text-xs font-medium" style={{ color: "var(--accent)" }} onClick={() => setMore((m) => !m)}>
        {more ? "کمتر ▴" : "جزئیات بیشتر (توضیح، برچسب، یادداشت) ▾"}
      </button>
      {more && (
        <div className="space-y-4">
          <Field label="توضیحات">
            <textarea className="input min-h-16" value={description} onChange={(e) => setDescription(e.target.value)} />
          </Field>
          <Field label="برچسب‌ها (با ویرگول)">
            <input className="input" value={tags} onChange={(e) => setTags(e.target.value)} placeholder="مثلاً: مطالعه، مهم" />
          </Field>
          <Field label="یادداشت">
            <textarea className="input min-h-16" value={notes} onChange={(e) => setNotes(e.target.value)} />
          </Field>
        </div>
      )}

      {conflict && (
        <div className="flex items-start gap-2 rounded-xl px-3 py-2.5 text-xs leading-6" style={{ background: "var(--warn-soft)", color: "var(--warn)" }} role="alert">
          <AlertTriangle className="mt-0.5 size-4 shrink-0" />
          <div className="flex-1">
            این زمان با «{conflict}» در همان روز هم‌پوشانی دارد.
            <button type="button" className="mr-2 font-bold underline underline-offset-4" onClick={() => void submit(true)}>
              باز هم ذخیره کن
            </button>
          </div>
        </div>
      )}
      {error && (
        <p className="rounded-xl px-3 py-2 text-xs font-medium" style={{ background: "var(--danger-soft)", color: "var(--danger)" }} role="alert">{error}</p>
      )}

      <div className="flex justify-end gap-2 pt-1">
        <button type="button" className="btn btn-ghost" onClick={onDone}>انصراف</button>
        <button type="submit" className="btn btn-primary" disabled={busy}>
          {busy ? <Spinner /> : init?.id ? "ذخیرهٔ تغییرات" : "ثبت وظیفه"}
        </button>
      </div>
    </form>
  );
}
