"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { deleteHabit, logHabit, saveHabit, toggleHabitPause } from "@/app/actions/habits";
import { fa, formatDayMonth } from "@/lib/format";
import { label, options, t } from "@/lib/i18n";
import { WEEKDAYS_FA_SHORT } from "@/lib/jalali";
import { weekdayOf } from "@/lib/time";
import { ActionButton, ActionForm, DateInput, Field, Select, WeekdayPicker } from "./forms";
import { Modal } from "./modal";
import { usePrefs } from "./prefs";

const NEXT: Record<string, string | null> = { none: "completed", completed: "partial", partial: "missed", missed: "skipped", skipped: null };
const STYLE: Record<string, string> = {
  completed: "bg-accent-600 text-white border-accent-600",
  partial: "bg-accent-100 text-accent-800 border-accent-300 dark:bg-accent-900/50 dark:text-accent-200 dark:border-accent-700",
  missed: "bg-red-50 text-red-700 border-red-200 dark:bg-red-950/40 dark:text-red-300 dark:border-red-900",
  skipped: "bg-zinc-100 text-zinc-500 border-zinc-300 dark:bg-zinc-800 dark:border-zinc-700",
  none: "border-zinc-300 dark:border-zinc-700",
  off: "border-transparent text-zinc-300 dark:text-zinc-700",
  paused: "border-dashed border-zinc-300 text-zinc-400 dark:border-zinc-700",
};
const SYMBOL: Record<string, string> = { completed: "✓", partial: "½", missed: "✗", skipped: "–", none: "", off: "·", paused: "‖" };

export function HabitTodayList({ date, habits }: { date: string; habits: { id: string; name: string; status: string | null }[] }) {
  const [pending, start] = useTransition();
  const router = useRouter();
  return (
    <ul className="space-y-2">
      {habits.map((h) => (
        <li key={h.id} className="flex items-center justify-between gap-2">
          <span className={`text-sm ${h.status === "completed" ? "text-zinc-400 line-through" : ""}`}>{h.name}</span>
          <div className="flex gap-1">
            {(["completed", "partial", "skipped"] as const).map((s) => (
              <button
                key={s}
                type="button"
                disabled={pending}
                aria-pressed={h.status === s}
                aria-label={`${h.name}: ${t.habitStatus[s]}`}
                title={t.habitStatus[s]}
                onClick={() =>
                  start(async () => {
                    const r = await logHabit(h.id, date, h.status === s ? null : s);
                    if (!r.ok) alert(r.error);
                    router.refresh();
                  })
                }
                className={`h-9 w-9 rounded-lg border text-sm ${h.status === s ? STYLE[s] : STYLE.none}`}
              >
                {SYMBOL[s]}
              </button>
            ))}
          </div>
        </li>
      ))}
    </ul>
  );
}

export type HabitCell = { date: string; state: "completed" | "partial" | "missed" | "skipped" | "none" | "off" | "paused" };

export function HabitGrid({ habitId, name, cells }: { habitId: string; name: string; cells: HabitCell[] }) {
  const { mode, today } = usePrefs();
  const [pending, start] = useTransition();
  const router = useRouter();
  return (
    <div className="flex flex-wrap gap-1" role="group" aria-label={`ثبت روزانهٔ ${name}`}>
      {cells.map((c) => {
        const clickable = c.state !== "off" && c.state !== "paused" && c.date <= today;
        return (
          <button
            key={c.date}
            type="button"
            disabled={!clickable || pending}
            title={`${formatDayMonth(c.date, mode)} — ${c.state === "none" ? "ثبت‌نشده" : c.state === "off" ? "برنامه‌ریزی‌نشده" : c.state === "paused" ? "متوقف" : label(t.habitStatus, c.state)}`}
            aria-label={`${formatDayMonth(c.date, mode)}: ${c.state === "none" ? "ثبت‌نشده" : c.state === "off" ? "برنامه‌ریزی‌نشده" : c.state === "paused" ? "متوقف" : label(t.habitStatus, c.state)}`}
            onClick={() =>
              start(async () => {
                const r = await logHabit(habitId, c.date, NEXT[c.state] ?? null);
                if (!r.ok) alert(r.error);
                router.refresh();
              })
            }
            className={`flex h-10 w-10 flex-col items-center justify-center rounded-lg border text-xs leading-none ${STYLE[c.state]} ${c.date === today ? "ring-2 ring-accent-400 ring-offset-1 dark:ring-offset-zinc-900" : ""}`}
          >
            <span className="text-[9px] opacity-70">{WEEKDAYS_FA_SHORT[weekdayOf(c.date)]}</span>
            <span>{SYMBOL[c.state] || fa(Number(c.date.slice(8)))}</span>
          </button>
        );
      })}
    </div>
  );
}

type HabitRow = {
  id: string;
  name: string;
  description: string | null;
  category: string | null;
  frequency: string;
  weekdays: number[] | null;
  timesPerWeek: number | null;
  minTarget: number | null;
  idealTarget: number | null;
  unit: string | null;
  startDate: string;
  endDate: string | null;
  status: string;
};

export function HabitForm({ habit, onDone }: { habit?: HabitRow; onDone?: () => void }) {
  const [freq, setFreq] = useState(habit?.frequency ?? "daily");
  return (
    <ActionForm action={saveHabit} onSuccess={onDone}>
      {habit && <input type="hidden" name="id" value={habit.id} />}
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="نام عادت *" className="sm:col-span-2">
          <input name="name" required maxLength={120} defaultValue={habit?.name} className="input" />
        </Field>
        <Field label="دسته‌بندی">
          <input name="category" maxLength={60} defaultValue={habit?.category ?? ""} className="input" />
        </Field>
        <Field label="تناوب">
          <Select name="frequency" options={options(t.habitFrequency)} defaultValue={freq} onChange={setFreq} />
        </Field>
        {freq === "custom" && (
          <div className="sm:col-span-2">
            <WeekdayPicker name="weekdays" legend="روزهای برنامه‌ریزی‌شده" defaultValue={habit?.weekdays ?? []} />
          </div>
        )}
        {freq === "weekly" && (
          <Field label="تعداد دفعات در هفته">
            <input name="timesPerWeek" type="number" min={1} max={7} defaultValue={habit?.timesPerWeek ?? 3} className="input" />
          </Field>
        )}
        <Field label="حداقل هدف">
          <input name="minTarget" type="number" step="any" defaultValue={habit?.minTarget ?? ""} className="input" />
        </Field>
        <Field label="هدف ایده‌آل">
          <input name="idealTarget" type="number" step="any" defaultValue={habit?.idealTarget ?? ""} className="input" />
        </Field>
        <Field label="واحد" hint="مثلاً دقیقه، صفحه، لیوان">
          <input name="unit" maxLength={30} defaultValue={habit?.unit ?? ""} className="input" />
        </Field>
        <DateInput name="startDate" label="تاریخ شروع" defaultValue={habit?.startDate ?? null} />
        <DateInput name="endDate" label="تاریخ پایان (اختیاری)" defaultValue={habit?.endDate ?? null} />
        <Field label="توضیحات" className="sm:col-span-2">
          <textarea name="description" rows={2} defaultValue={habit?.description ?? ""} className="input" />
        </Field>
      </div>
    </ActionForm>
  );
}

export function NewHabitButton() {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button type="button" className="btn btn-primary" onClick={() => setOpen(true)}>
        + عادت جدید
      </button>
      <Modal open={open} onClose={() => setOpen(false)} title="عادت جدید" wide>
        <HabitForm onDone={() => setOpen(false)} />
      </Modal>
    </>
  );
}

export function HabitActions({ habit }: { habit: HabitRow }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="flex gap-1">
      <ActionButton run={() => toggleHabitPause(habit.id)} className="btn btn-ghost btn-sm">
        {habit.status === "active" ? "توقف موقت" : "ادامه"}
      </ActionButton>
      <button type="button" className="btn btn-ghost btn-sm" onClick={() => setOpen(true)}>
        ویرایش
      </button>
      <Modal open={open} onClose={() => setOpen(false)} title="ویرایش عادت" wide>
        <HabitForm habit={habit} onDone={() => setOpen(false)} />
        <div className="mt-4 border-t border-zinc-200 pt-4 dark:border-zinc-800">
          <ActionButton run={() => deleteHabit(habit.id)} confirm="عادت و تمام سابقهٔ ثبت‌های آن حذف می‌شود. ادامه می‌دهید؟" className="btn btn-danger btn-sm">
            حذف عادت
          </ActionButton>
        </div>
      </Modal>
    </div>
  );
}
