"use client";

import { useState } from "react";
import { deleteSleep, saveSleep } from "@/app/actions/sleep";
import { fa, formatDateLong, formatMinutes, formatTime } from "@/lib/format";
import { localTime } from "@/lib/time";
import { ActionButton, ActionForm, DateInput, Field, RatingInput } from "./forms";
import { Modal } from "./modal";
import { usePrefs } from "./prefs";

export type SleepRow = {
  id: string;
  wakeDate: string;
  bedTime: Date;
  sleepStart: Date | null;
  wakeTime: Date;
  durationMinutes: number;
  quality: number | null;
  morningEnergy: number | null;
  awakenings: number | null;
  notes: string | null;
  source: string;
};

export function SleepForm({ record, onDone }: { record?: SleepRow; onDone?: () => void }) {
  const { tz, today } = usePrefs();
  return (
    <ActionForm action={saveSleep} onSuccess={onDone}>
      {record && <input type="hidden" name="id" value={record.id} />}
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="sm:col-span-2">
          <DateInput name="wakeDate" label="تاریخ بیدار شدن" required defaultValue={record?.wakeDate ?? today} allowClear={false} />
          <p className="hint">اگر ساعت خواب از ساعت بیداری دیرتر باشد (مثلاً ۲۳:۳۰ و ۰۷:۰۰)، خواب به‌طور خودکار از شب قبل حساب می‌شود.</p>
        </div>
        <Field label="رفتن به رختخواب *">
          <input name="bedTime" type="time" required defaultValue={record ? localTime(record.bedTime, tz) : "23:00"} className="input" />
        </Field>
        <Field label="به خواب رفتن (تخمینی)">
          <input name="sleepStart" type="time" defaultValue={record?.sleepStart ? localTime(record.sleepStart, tz) : ""} className="input" />
        </Field>
        <Field label="بیدار شدن *">
          <input name="wakeTime" type="time" required defaultValue={record ? localTime(record.wakeTime, tz) : "07:00"} className="input" />
        </Field>
        <Field label="مدت خواب (دقیقه)" hint="خالی = محاسبه از زمان به خواب رفتن تا بیداری">
          <input name="durationMinutes" type="number" min={0} max={1200} defaultValue={record?.durationMinutes ?? ""} className="input" />
        </Field>
        <RatingInput name="quality" label="کیفیت خواب" defaultValue={record?.quality} />
        <RatingInput name="morningEnergy" label="انرژی صبحگاهی" defaultValue={record?.morningEnergy} />
        <Field label="دفعات بیدار شدن در شب">
          <input name="awakenings" type="number" min={0} max={50} defaultValue={record?.awakenings ?? ""} className="input" />
        </Field>
        <Field label="یادداشت" className="sm:col-span-2">
          <textarea name="notes" rows={2} defaultValue={record?.notes ?? ""} className="input" />
        </Field>
      </div>
    </ActionForm>
  );
}

export function NewSleepButton() {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button type="button" className="btn btn-primary" onClick={() => setOpen(true)}>
        + ثبت خواب
      </button>
      <Modal open={open} onClose={() => setOpen(false)} title="ثبت خواب" wide>
        <SleepForm onDone={() => setOpen(false)} />
      </Modal>
    </>
  );
}

export function SleepRowItem({ r }: { r: SleepRow }) {
  const { tz, mode } = usePrefs();
  const [open, setOpen] = useState(false);
  return (
    <li className="flex items-center justify-between gap-3 py-3">
      <div>
        <div className="text-sm font-medium">{formatDateLong(r.wakeDate, mode, true)}</div>
        <div className="text-xs muted">
          {formatTime(r.bedTime, tz)} ← {formatTime(r.wakeTime, tz)} · {formatMinutes(r.durationMinutes)}
          {r.quality ? ` · کیفیت ${fa(r.quality)}/۵` : ""}
          {r.morningEnergy ? ` · انرژی ${fa(r.morningEnergy)}/۵` : ""}
          {r.awakenings !== null ? ` · ${fa(r.awakenings)} بار بیداری` : ""} · {r.source === "manual" ? "برآورد دستی" : "دستگاه"}
        </div>
        {r.notes && <div className="mt-0.5 text-xs muted">{r.notes}</div>}
      </div>
      <button type="button" className="btn btn-ghost btn-sm" onClick={() => setOpen(true)}>
        ویرایش
      </button>
      <Modal open={open} onClose={() => setOpen(false)} title="ویرایش ثبت خواب" wide>
        <SleepForm record={r} onDone={() => setOpen(false)} />
        <div className="mt-4 border-t border-zinc-200 pt-4 dark:border-zinc-800">
          <ActionButton run={() => deleteSleep(r.id)} confirm="این رکورد خواب حذف شود؟" className="btn btn-danger btn-sm" onDone={() => setOpen(false)}>
            حذف
          </ActionButton>
        </div>
      </Modal>
    </li>
  );
}
