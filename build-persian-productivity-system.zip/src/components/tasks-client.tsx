"use client";

import React, { useMemo, useState } from "react";
import {
  Plus, Search, Pencil, Trash2, Check, Ban, RotateCcw, ChevronRight, ChevronLeft, CalendarClock,
} from "lucide-react";
import { Modal, Confirm, EmptyState, useRun, useToast, Field, Spinner } from "@/components/ui";
import { JalaliDatePicker, Segmented } from "@/components/pickers";
import { TaskForm } from "@/components/task-form";
import { setTaskStatus, deleteTask, moveTask } from "@/lib/actions-core";
import { priorityLabel, taskStatusLabel, recurrenceLabel } from "@/lib/utils";
import {
  faDigits, faDateMed, faRelativeDay, faWeekdayName, addDaysIso, faDuration,
} from "@/lib/jalali";

export type TaskRow = {
  id: string; title: string; description: string | null; dueDate: string | null;
  plannedStart: string | null; plannedEnd: string | null; estimatedMinutes: number | null;
  actualMinutes: number | null; priority: string; status: string; category: string | null;
  energy: string | null; tags: string | null; recurrence: string; goalId: string | null;
  notes: string | null; completedDate: string | null;
};

const STATUS_OPTS = [
  { value: "all", label: "همه" },
  { value: "pending", label: "شروع‌نشده" },
  { value: "in_progress", label: "در حال انجام" },
  { value: "done", label: "انجام‌شده" },
  { value: "cancelled", label: "لغوشده" },
];

const VIEWS = [
  { value: "list", label: "لیست" },
  { value: "day", label: "روزانه" },
  { value: "week", label: "هفتگی" },
];

function priorityChipStyle(p: string): React.CSSProperties {
  if (p === "high") return { background: "var(--danger-soft)", color: "var(--danger)", borderColor: "transparent" };
  if (p === "medium") return { background: "var(--warn-soft)", color: "var(--warn)", borderColor: "transparent" };
  return {};
}

export function TasksClient({
  tasks, goals, today, weekDays,
}: {
  tasks: TaskRow[];
  goals: { id: string; title: string }[];
  today: string;
  weekDays: string[];
}) {
  const toast = useToast();
  const { run, busy } = useRun();
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [view, setView] = useState<"list" | "day" | "week">("list");
  const [day, setDay] = useState(today);
  const [weekAnchor, setWeekAnchor] = useState(today);
  const [editTask, setEditTask] = useState<TaskRow | null>(null);
  const [createOpen, setCreateOpen] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [minDone, setMinDone] = useState(false);

  const goalMap = useMemo(() => new Map(goals.map((g) => [g.id, g.title])), [goals]);

  const filtered = useMemo(() => {
    const q = query.trim();
    return tasks.filter((t) => {
      if (statusFilter !== "all" && t.status !== statusFilter) return false;
      if (q && !(t.title.includes(q) || (t.description ?? "").includes(q) || (t.tags ?? "").includes(q))) return false;
      return true;
    });
  }, [tasks, query, statusFilter]);

  const overdue = filtered.filter((t) => t.dueDate && t.dueDate < today && t.status !== "done" && t.status !== "cancelled");
  const dueToday = filtered.filter((t) => t.dueDate === today && t.status !== "done" && t.status !== "cancelled");
  const upcoming = filtered.filter((t) => t.dueDate && t.dueDate > today && t.status !== "done" && t.status !== "cancelled")
    .sort((a, b) => a.dueDate!.localeCompare(b.dueDate!));
  const noDate = filtered.filter((t) => !t.dueDate && t.status !== "done" && t.status !== "cancelled");
  const done = filtered.filter((t) => t.status === "done" || t.status === "cancelled");

  const renderRow = (t: TaskRow, opts?: { muteStatus?: boolean }) => {
    const isDone = t.status === "done";
    const isCancelled = t.status === "cancelled";
    const isOverdue = t.dueDate && t.dueDate < today && !isDone && !isCancelled;
    return (
      <div key={t.id} className="group flex items-start gap-3 rounded-xl px-2 py-2.5 transition-colors hover:bg-(--bg-soft)">
        <button
          disabled={busy}
          onClick={() => void run(() => setTaskStatus(t.id, isDone ? "pending" : "done"), { silent: false })}
          className="mt-0.5 grid size-6 shrink-0 place-items-center rounded-full border transition-all hover:scale-105"
          style={{
            borderColor: isDone ? "transparent" : "var(--border-strong)",
            background: isDone ? "var(--ok)" : "transparent",
            color: "white",
          }}
          aria-label={isDone ? "برگرداندن" : "انجام شد"}
          aria-pressed={isDone}
        >
          {isDone && <Check className="size-3.5" />}
        </button>
        <div className="min-w-0 flex-1">
          <p className="text-[13px] font-medium leading-6" style={{
            color: isDone ? "var(--fg-faint)" : "var(--fg)",
            textDecoration: isDone ? "line-through" : isCancelled ? "line-through" : "none",
            opacity: isCancelled ? 0.6 : 1,
          }}>
            {t.title}
          </p>
          <div className="mt-1 flex flex-wrap items-center gap-1.5">
            {t.status !== "pending" && !isDone && !opts?.muteStatus && (
              <span className="chip">{taskStatusLabel(t.status)}</span>
            )}
            {t.dueDate && (
              <span className="chip" style={isOverdue ? { background: "var(--danger-soft)", color: "var(--danger)", borderColor: "transparent" } : {}}>
                <CalendarClock className="size-3" />
                {faDateMed(t.dueDate)} · {faRelativeDay(t.dueDate, today)}
              </span>
            )}
            {t.plannedStart && <span className="chip" dir="ltr">{t.plannedStart}{t.plannedEnd ? `–${t.plannedEnd}` : ""}</span>}
            {t.estimatedMinutes != null && (
              <span className="chip">
                برآورد {faDuration(t.estimatedMinutes)}
                {t.actualMinutes != null && ` · واقعی ${faDuration(t.actualMinutes)}`}
              </span>
            )}
            {t.category && <span className="chip">{t.category}</span>}
            {t.goalId && goalMap.get(t.goalId) && <span className="chip" style={{ background: "var(--accent-soft)", color: "var(--accent)", borderColor: "transparent" }}>{goalMap.get(t.goalId)}</span>}
            {t.recurrence !== "none" && <span className="chip">تکرار: {recurrenceLabel(t.recurrence)}</span>}
            <span className="chip" style={priorityChipStyle(t.priority)}>{priorityLabel(t.priority)}</span>
          </div>
        </div>
        <div className="flex shrink-0 items-center gap-0.5 opacity-100 transition-opacity lg:opacity-0 lg:group-hover:opacity-100">
          {t.status === "pending" && (
            <button className="btn btn-ghost !min-h-0 !p-1.5" title="شروع انجام" aria-label="در حال انجام"
              onClick={() => void run(() => setTaskStatus(t.id, "in_progress"))}>
              <RotateCcw className="size-4" />
            </button>
          )}
          {(t.status === "in_progress") && (
            <button className="btn btn-ghost !min-h-0 !p-1.5" title="لغو" aria-label="لغو وظیفه"
              onClick={() => void run(() => setTaskStatus(t.id, "cancelled"))}>
              <Ban className="size-4" />
            </button>
          )}
          <button className="btn btn-ghost !min-h-0 !p-1.5" title="ویرایش" aria-label="ویرایش" onClick={() => setEditTask(t)}>
            <Pencil className="size-4" />
          </button>
          <button className="btn btn-ghost !min-h-0 !p-1.5" title="حذف" aria-label="حذف" onClick={() => setDeleteId(t.id)}>
            <Trash2 className="size-4" />
          </button>
        </div>
      </div>
    );
  };

  const weekList = useMemo(() => {
    const idx = weekDays.indexOf(weekAnchor);
    const base = idx >= 0 ? weekDays[0] : weekAnchor;
    return Array.from({ length: 7 }, (_, i) => addDaysIso(base, i));
  }, [weekAnchor, weekDays]);

  const dayTasks = filtered.filter((t) => t.dueDate === day);

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-2">
        <button className="btn btn-primary" onClick={() => setCreateOpen(true)}>
          <Plus className="size-4" /> وظیفهٔ جدید
        </button>
        <Segmented options={VIEWS as { value: "list" | "day" | "week"; label: string }[]} value={view} onChange={(v) => setView(v)} size="sm" />
        <div className="relative min-w-40 flex-1">
          <Search className="absolute right-3 top-1/2 size-4 -translate-y-1/2" style={{ color: "var(--fg-faint)" }} />
          <input
            className="input !pr-9"
            placeholder="جستجو در عنوان، توضیح و برچسب…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            aria-label="جستجوی وظایف"
          />
        </div>
        <Segmented options={STATUS_OPTS} value={statusFilter} onChange={setStatusFilter} size="sm" />
      </div>

      {view === "list" && (
        <div className="space-y-4">
          {filtered.length === 0 && (
            <EmptyState
              title="وظیفه‌ای پیدا نشد"
              hint="با دکمهٔ «وظیفهٔ جدید» اولین وظیفه‌ات را بساز؛ می‌توانی به آن هدف، زمان و تکرار هم وصل کنی."
              action={<button className="btn btn-primary" onClick={() => setCreateOpen(true)}><Plus className="size-4" /> ساخت وظیفه</button>}
            />
          )}
          {overdue.length > 0 && (
            <section className="card p-3" style={{ borderColor: "var(--danger)" }}>
              <h2 className="mb-1 px-2 pt-1 text-xs font-bold" style={{ color: "var(--danger)" }}>
                سررسید گذشته ({faDigits(overdue.length)})
              </h2>
              <p className="mb-1 px-2 text-[11px]" style={{ color: "var(--fg-muted)" }}>
                بدون جابه‌جایی خودکار؛ خودت تصمیم بگیر: انجام، ویرایش تاریخ، یا حذف.
              </p>
              {overdue.map((t) => renderRow(t))}
            </section>
          )}
          {dueToday.length > 0 && (
            <section className="card p-3">
              <h2 className="mb-1 px-2 pt-1 text-xs font-bold">امروز ({faDigits(dueToday.length)})</h2>
              {dueToday.map((t) => renderRow(t, { muteStatus: true }))}
            </section>
          )}
          {upcoming.length > 0 && (
            <section className="card p-3">
              <h2 className="mb-1 px-2 pt-1 text-xs font-bold">پیشِ رو ({faDigits(upcoming.length)})</h2>
              {upcoming.map((t) => renderRow(t))}
            </section>
          )}
          {noDate.length > 0 && (
            <section className="card p-3">
              <h2 className="mb-1 px-2 pt-1 text-xs font-bold">بدون تاریخ ({faDigits(noDate.length)})</h2>
              {noDate.map((t) => renderRow(t))}
            </section>
          )}
          {done.length > 0 && (
            <section className="card p-3">
              <button className="mb-1 flex w-full items-center justify-between px-2 pt-1 text-xs font-bold"
                onClick={() => setMinDone((v) => !v)} style={{ color: "var(--fg-muted)" }}>
                <span>انجام‌شده و لغوشده ({faDigits(done.length)})</span>
                <span>{minDone ? "▾" : "◂"}</span>
              </button>
              {!minDone && done.map((t) => renderRow(t))}
            </section>
          )}
        </div>
      )}

      {view === "day" && (
        <div className="space-y-3">
          <div className="flex flex-wrap items-center gap-3">
            <div className="w-56"><JalaliDatePicker value={day} onChange={(v) => v && setDay(v)} clearable={false} /></div>
            <div className="flex items-center gap-1">
              <button className="btn btn-ghost !min-h-0 !p-1.5" onClick={() => setDay(addDaysIso(day, 1))} aria-label="روز بعد"><ChevronRight className="size-4" /></button>
              <button className="btn btn-ghost !min-h-0 !p-1.5" onClick={() => setDay(addDaysIso(day, -1))} aria-label="روز قبل"><ChevronLeft className="size-4" /></button>
              <button className="btn btn-soft !min-h-8 !py-1 !text-xs" onClick={() => setDay(today)}>امروز</button>
            </div>
            <span className="text-sm font-bold">{faDateMed(day)} · {faWeekdayName(day)}</span>
          </div>
          <section className="card p-3">
            {dayTasks.length === 0 ? (
              <EmptyState title="این روز خالی است" hint="با دکمهٔ «وظیفهٔ جدید» کاری برای این روز بساز، یا از نمای هفتگی چیزی را به این روز منتقل کن." />
            ) : (
              dayTasks
                .sort((a, b) => (a.plannedStart ?? "99").localeCompare(b.plannedStart ?? "99"))
                .map((t) => renderRow(t))
            )}
          </section>
        </div>
      )}

      {view === "week" && (
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <button className="btn btn-ghost !min-h-0 !p-1.5" onClick={() => setWeekAnchor(addDaysIso(weekList[0], 7))} aria-label="هفتهٔ بعد"><ChevronRight className="size-4" /></button>
            <button className="btn btn-ghost !min-h-0 !p-1.5" onClick={() => setWeekAnchor(addDaysIso(weekList[0], -7))} aria-label="هفتهٔ قبل"><ChevronLeft className="size-4" /></button>
            <button className="btn btn-soft !min-h-8 !py-1 !text-xs" onClick={() => setWeekAnchor(today)}>این هفته</button>
            <span className="text-xs" style={{ color: "var(--fg-muted)" }}>
              {faDateMed(weekList[0])} تا {faDateMed(weekList[6])}
            </span>
          </div>
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-7">
            {weekList.map((d) => {
              const inWeek = filtered.filter((t) => t.dueDate === d);
              const isToday = d === today;
              return (
                <div key={d} className="card min-h-28 !p-2" style={isToday ? { borderColor: "var(--accent)" } : {}}>
                  <p className="mb-1.5 px-1 text-[11px] font-bold" style={{ color: isToday ? "var(--accent)" : "var(--fg-muted)" }}>
                    {faWeekdayName(d)} <span style={{ color: "var(--fg-faint)", fontWeight: 400 }}>{faDateMed(d).split(" ").slice(0, -1).join(" ")}</span>
                  </p>
                  <div className="space-y-1">
                    {inWeek.map((t) => (
                      <WeekItem key={t.id} task={t} onEdit={() => setEditTask(t)} onMove={(dir) => void run(() => moveTask(t.id, addDaysIso(d, dir)), { silent: true })} />
                    ))}
                    {inWeek.length === 0 && (
                      <button className="w-full rounded-lg border border-dashed py-2 text-[10px] transition-colors hover:opacity-80"
                        style={{ borderColor: "var(--border-strong)", color: "var(--fg-faint)" }}
                        onClick={() => { setCreateOpen(true); }}>
                        + افزودن
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Modals */}
      <Modal open={createOpen} onClose={() => setCreateOpen(false)} title="وظیفهٔ جدید" wide>
        <TaskForm goals={goals} onDone={() => setCreateOpen(false)} defaultDate={view === "day" ? day : undefined} />
      </Modal>
      <Modal open={!!editTask} onClose={() => setEditTask(null)} title="ویرایش وظیفه" wide>
        {editTask && (
          <TaskForm
            goals={goals}
            init={{
              id: editTask.id, title: editTask.title, description: editTask.description,
              dueDate: editTask.dueDate, plannedStart: editTask.plannedStart, plannedEnd: editTask.plannedEnd,
              estimatedMinutes: editTask.estimatedMinutes, actualMinutes: editTask.actualMinutes,
              priority: editTask.priority, category: editTask.category, energy: editTask.energy,
              recurrence: editTask.recurrence, tags: editTask.tags, goalId: editTask.goalId, notes: editTask.notes,
            }}
            onDone={() => setEditTask(null)}
          />
        )}
      </Modal>
      <Confirm
        open={!!deleteId}
        onClose={() => setDeleteId(null)}
        title="حذف وظیفه"
        message="این وظیفه برای همیشه حذف می‌شود. مطمئنی؟"
        danger
        onConfirm={async () => {
          const r = await deleteTask(deleteId!);
          if (r.error) toast.push("err", r.error); else toast.push("ok", "حذف شد.");
        }}
      />
    </div>
  );
}

function WeekItem({ task, onEdit, onMove }: { task: TaskRow; onEdit: () => void; onMove: (dir: number) => void }) {
  const done = task.status === "done";
  return (
    <div className="group flex items-center gap-1 rounded-lg border px-2 py-1.5" style={{ borderColor: "var(--border)", background: "var(--card-soft)" }}>
      <button onClick={onEdit} className="min-w-0 flex-1 truncate text-start text-[11px] font-medium"
        style={{ color: done ? "var(--fg-faint)" : "var(--fg)", textDecoration: done ? "line-through" : "none" }}
        title={task.title}>
        {task.plannedStart && <span className="ml-1" style={{ color: "var(--fg-faint)" }} dir="ltr">{task.plannedStart}</span>}
        {task.title}
      </button>
      <span className="flex opacity-0 transition-opacity group-hover:opacity-100">
        <button className="p-0.5" onClick={() => onMove(1)} aria-label="یک روز جلو" title="یک روز جلو"><ChevronRight className="size-3" style={{ color: "var(--fg-faint)" }} /></button>
        <button className="p-0.5" onClick={() => onMove(-1)} aria-label="یک روز عقب" title="یک روز عقب"><ChevronLeft className="size-3" style={{ color: "var(--fg-faint)" }} /></button>
      </span>
    </div>
  );
}
