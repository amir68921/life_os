"use client";

import { useState } from "react";
import { deleteBlock, saveBlock } from "@/app/actions/planner";
import { fa } from "@/lib/format";
import { label, options, t } from "@/lib/i18n";
import { minutesToHHMM } from "@/lib/time";
import { ActionButton, ActionForm, DateInput, Field, Select, WeekdayPicker } from "./forms";
import { Modal } from "./modal";

export type Block = {
  id: string;
  title: string;
  kind: string;
  date: string;
  startMinute: number;
  endMinute: number;
  repeatWeekdays: number[] | null;
  repeatUntil: string | null;
  taskId: string | null;
  notes: string | null;
};

const KIND_STYLE: Record<string, string> = {
  task: "border-accent-300 bg-accent-50 dark:border-accent-800 dark:bg-accent-900/30",
  focus: "border-indigo-300 bg-indigo-50 dark:border-indigo-800 dark:bg-indigo-900/30",
  break: "border-emerald-300 bg-emerald-50 dark:border-emerald-800 dark:bg-emerald-900/30",
  personal: "border-amber-300 bg-amber-50 dark:border-amber-800 dark:bg-amber-900/30",
  other: "border-zinc-300 bg-zinc-50 dark:border-zinc-700 dark:bg-zinc-800/50",
};
export const kindStyle = (k: string) => KIND_STYLE[k] ?? KIND_STYLE.other;

function BlockForm({ block, date, tasks, onDone }: { block?: Block; date: string; tasks: { id: string; title: string }[]; onDone: () => void }) {
  const [repeat, setRepeat] = useState(!!block?.repeatWeekdays?.length);
  return (
    <ActionForm action={saveBlock} onSuccess={onDone}>
      {block && <input type="hidden" name="id" value={block.id} />}
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="عنوان *" className="sm:col-span-2">
          <input name="title" required maxLength={200} defaultValue={block?.title} className="input" autoFocus />
        </Field>
        <Field label="نوع">
          <Select name="kind" options={options(t.blockKind)} defaultValue={block?.kind ?? "task"} />
        </Field>
        <DateInput name="date" label="تاریخ" required defaultValue={block?.date ?? date} allowClear={false} />
        <Field label="شروع *">
          <input name="start" type="time" required defaultValue={block ? minutesToHHMM(block.startMinute) : "09:00"} className="input" />
        </Field>
        <Field label="پایان *">
          <input name="end" type="time" required defaultValue={block ? minutesToHHMM(block.endMinute) : "10:00"} className="input" />
        </Field>
        <Field label="کار مرتبط" className="sm:col-span-2">
          <Select name="taskId" options={tasks.map((x) => ({ value: x.id, label: x.title }))} defaultValue={block?.taskId} empty="بدون کار" />
        </Field>
        <label className="flex items-center gap-2 text-sm sm:col-span-2">
          <input type="checkbox" name="repeat" checked={repeat} onChange={(e) => setRepeat(e.target.checked)} className="h-4 w-4 accent-[var(--color-accent-600)]" />
          بلوک تکرارشونده
        </label>
        {repeat && (
          <>
            <div className="sm:col-span-2">
              <WeekdayPicker name="repeatWeekdays" legend="روزهای تکرار" defaultValue={block?.repeatWeekdays ?? []} />
            </div>
            <DateInput name="repeatUntil" label="تکرار تا (اختیاری)" defaultValue={block?.repeatUntil} />
          </>
        )}
        <Field label="یادداشت" className="sm:col-span-2">
          <input name="notes" maxLength={2000} defaultValue={block?.notes ?? ""} className="input" />
        </Field>
      </div>
      <p className="hint mt-3">پیش از ذخیره، هم‌پوشانی با برنامه‌های موجود بررسی می‌شود و در صورت تداخل از شما تأیید گرفته می‌شود.</p>
    </ActionForm>
  );
}

export function NewBlockButton({ date, tasks, className = "btn btn-primary" }: { date: string; tasks: { id: string; title: string }[]; className?: string }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button type="button" className={className} onClick={() => setOpen(true)}>
        + بلوک زمانی
      </button>
      <Modal open={open} onClose={() => setOpen(false)} title="بلوک زمانی جدید" wide>
        <BlockForm date={date} tasks={tasks} onDone={() => setOpen(false)} />
      </Modal>
    </>
  );
}

export function BlockItem({ block, tasks, compact = false }: { block: Block; tasks: { id: string; title: string }[]; compact?: boolean }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button type="button" onClick={() => setOpen(true)} className={`w-full rounded-xl border px-3 py-2 text-start text-sm transition-colors hover:brightness-95 ${kindStyle(block.kind)}`}>
        <div className="flex items-center justify-between gap-2">
          <span className="font-medium">{block.title}</span>
          {!compact && <span className="text-xs muted">{label(t.blockKind, block.kind)}{block.repeatWeekdays?.length ? " · ↻" : ""}</span>}
        </div>
        <div className="text-xs tabular-nums muted">
          {fa(`${minutesToHHMM(block.startMinute)}–${block.endMinute === 1440 ? "24:00" : minutesToHHMM(block.endMinute)}`)}
        </div>
      </button>
      <Modal open={open} onClose={() => setOpen(false)} title="ویرایش بلوک" wide>
        {block.repeatWeekdays?.length ? <p className="mb-3 text-sm muted">این بلوک تکرارشونده است؛ تغییرات روی همهٔ تکرارها اعمال می‌شود.</p> : null}
        <BlockForm block={block} date={block.date} tasks={tasks} onDone={() => setOpen(false)} />
        <div className="mt-4 border-t border-zinc-200 pt-4 dark:border-zinc-800">
          <ActionButton run={() => deleteBlock(block.id)} confirm="این بلوک (و همهٔ تکرارهایش) حذف شود؟" className="btn btn-danger btn-sm" onDone={() => setOpen(false)}>
            حذف بلوک
          </ActionButton>
        </div>
      </Modal>
    </>
  );
}
