"use client";

import React, { useState } from "react";
import { Plus, Pencil, Trash2, Pause, Play, Flame, Check, ChevronDown, ChevronUp } from "lucide-react";
import { Modal, Confirm, EmptyState, Field, Spinner, useRun, useToast, ProgressBar } from "@/components/ui";
import { JalaliDatePicker, Segmented } from "@/components/pickers";
import { saveHabit, toggleHabitPause, deleteHabit, setOccurrence } from "@/lib/actions-life";
import { HABIT_STATUS, habitStatusLabel } from "@/lib/utils";
import { FA_WEEKDAYS, faDigits, faDateMed, faDateShort } from "@/lib/jalali";

export type HabitRow = {
  id: string; name: string; description: string | null; category: string | null;
  frequency: string; weekdays: number[]; minTarget: number; idealTarget: number | null;
  unit: string | null; startDate: string; endDate: string | null; status: string;
};

export type OccRow = { habitId: string; date: string; status: string; value: number | null };

export type HabitView = {
  habit: HabitRow;
  stats: { current: number; longest: number; weeklyRate: number | null; monthRate: number | null };
  todayStatus: string | null;
  todayValue: number | null;
  scheduledToday: boolean;
};

const STATUS_DOT: Record<string, string> = {
  done: "var(--ok)", partial: "var(--warn)", missed: "var(--danger)", skipped: "var(--fg-faint)",
};

export function HabitsClient({
  views, occ, weekDays, today,
}: {
  views: HabitView[];
  occ: OccRow[];
  weekDays: string[];
  today: string;
}) {
  const [creating, setCreating] = useState(false);
  const [editing, setEditing] = useState<HabitRow | null>(null);

  const scheduledToday = views.filter((v) => v.scheduledToday && v.habit.status === "active");
  const doneToday = scheduledToday.filter((v) => v.todayStatus === "done" || v.todayStatus === "partial").length;

  return (
    <div className="space-y-5">
      {/* امروز */}
      <div className="card p-5">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <div>
            <h2 className="text-sm font-bold">چک‌لیست امروز</h2>
            <p className="mt-0.5 text-xs" style={{ color: "var(--fg-muted)" }}>
              {faDigits(doneToday)} از {faDigits(scheduledToday.length)} انجام شده
            </p>
          </div>
          <button className="btn btn-primary" onClick={() => setCreating(true)}>
            <Plus className="size-4" /> عادت جدید
          </button>
        </div>
        {scheduledToday.length === 0 ? (
          <EmptyState
            title="برای امروز عادتی برنامه‌ریزی نشده"
            hint="عادت بساز و روزهای هفته‌اش را مشخص کن؛ فقط روزهای برنامه‌ریزی‌شده حساب می‌شوند."
            action={<button className="btn btn-soft" onClick={() => setCreating(true)}><Plus className="size-4" /> ساخت عادت</button>}
          />
        ) : (
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
            {scheduledToday.map((v) => <TodayCard key={v.habit.id} view={v} />)}
          </div>
        )}
      </div>

      {/* همهٔ عادت‌ها */}
      <div className="space-y-3">
        {views.length === 0 && !creating && (
          <EmptyState title="هنوز عادتی نساختی" hint="عادت‌های کوچکِ قابل‌تکرار، موتور رشد بلندمدت‌اند." />
        )}
        {views.map((v) => (
          <HabitCard
            key={v.habit.id}
            view={v}
            occ={occ.filter((o) => o.habitId === v.habit.id)}
            weekDays={weekDays}
            today={today}
            onEdit={() => setEditing(v.habit)}
          />
        ))}
      </div>

      <Modal open={creating} onClose={() => setCreating(false)} title="عادت جدید" wide>
        <HabitForm onDone={() => setCreating(false)} today={today} />
      </Modal>
      <Modal open={!!editing} onClose={() => setEditing(null)} title="ویرایش عادت" wide>
        {editing && <HabitForm init={editing} onDone={() => setEditing(null)} today={today} />}
      </Modal>
    </div>
  );
}

function TodayCard({ view }: { view: HabitView }) {
  const { run, busy } = useRun();
  const [value, setValue] = useState(view.todayValue != null ? String(view.todayValue) : "");
  const st = view.todayStatus;
  return (
    <div className="rounded-2xl border p-3" style={{ borderColor: "var(--border)", background: "var(--card-soft)" }}>
      <div className="flex items-center justify-between gap-2">
        <p className="min-w-0 flex-1 truncate text-[13px] font-bold">{view.habit.name}</p>
        {view.stats.current > 0 && (
          <span className="chip" style={{ background: "var(--warn-soft)", color: "var(--warn)", borderColor: "transparent" }}>
            <Flame className="size-3" /> {faDigits(view.stats.current)} روز پیاپی
          </span>
        )}
      </div>
      <p className="mt-1 text-[11px]" style={{ color: "var(--fg-muted)" }}>
        هدف حداقلی: {faDigits(view.habit.minTarget)}{view.habit.unit ? ` ${view.habit.unit}` : ""}
        {view.habit.idealTarget ? ` · ایده‌آل: ${faDigits(view.habit.idealTarget)}` : ""}
      </p>
      {view.habit.unit && (
        <div className="mt-2 flex items-center gap-2">
          <label className="text-[10px]" style={{ color: "var(--fg-faint)" }}>مقدار امروز:</label>
          <input
            className="input !min-h-8 w-20 !px-2 !py-1 !text-xs"
            type="number" min={0} inputMode="numeric"
            value={value} onChange={(e) => setValue(e.target.value)}
            aria-label="مقدار امروز"
          />
        </div>
      )}
      <TodayButtons habitId={view.habit.id} value={value} busy={busy} st={st} />
    </div>
  );
}

function TodayButtons({ habitId, value, busy, st }: { habitId: string; value: string; busy: boolean; st: string | null }) {
  const { run } = useRun();
  const toast = useToast();
  const todayStr = new Date().toLocaleDateString("en-CA", { timeZone: "Asia/Tehran" });
  return (
    <div className="grid grid-cols-4 gap-1.5">
      {HABIT_STATUS.map((s) => {
        const active = st === s.value;
        return (
          <button
            key={s.value}
            disabled={busy}
            title={s.label}
            aria-pressed={active}
            onClick={async () => {
              const r = await run(() => setOccurrence({
                habitId,
                date: todayStr,
                status: s.value,
                value: value ? Number(value) : null,
              }), { silent: true });
              if (r?.error) toast.push("err", r.error);
            }}
            className="rounded-lg border px-1 py-1.5 text-[10px] font-semibold transition-all hover:scale-[1.02]"
            style={{
              borderColor: active ? "transparent" : "var(--border)",
              background: active ? "var(--accent)" : "var(--card)",
              color: active ? "var(--accent-fg)" : "var(--fg-muted)",
            }}
          >
            {s.label}
          </button>
        );
      })}
    </div>
  );
}

function HabitCard({ view, occ, weekDays, today, onEdit }: {
  view: HabitView; occ: OccRow[]; weekDays: string[]; today: string; onEdit: () => void;
}) {
  const toast = useToast();
  const [del, setDel] = useState(false);
  const [calOpen, setCalOpen] = useState(false);
  const { run } = useRun();
  const h = view.habit;
  const occMap = new Map(occ.map((o) => [o.date, o]));

  return (
    <div className="card p-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <p className="truncate text-sm font-bold">{h.name}</p>
            {h.status === "paused" && (
              <span className="chip" style={{ background: "var(--warn-soft)", color: "var(--warn)", borderColor: "transparent" }}>متوقف</span>
            )}
          </div>
          <p className="mt-1 text-[11px]" style={{ color: "var(--fg-muted)" }}>
            {h.frequency === "daily" ? "هر روز" : `روزهای ${h.weekdays.map((w) => FA_WEEKDAYS[w]).join("، ")}`}
            {h.category ? ` · ${h.category}` : ""}
            {" · شروع: "}{faDateMed(h.startDate)}
          </p>
        </div>
        <div className="flex items-center gap-6 text-center">
          <div>
            <p className="text-base font-extrabold" style={{ color: "var(--accent)" }}>{faDigits(view.stats.current)}</p>
            <p className="text-[9px]" style={{ color: "var(--fg-faint)" }}>زنجیرهٔ فعلی</p>
          </div>
          <div>
            <p className="text-base font-extrabold">{faDigits(view.stats.longest)}</p>
            <p className="text-[9px]" style={{ color: "var(--fg-faint)" }}>رکورد</p>
          </div>
          <div>
            <p className="text-base font-extrabold">{view.stats.weeklyRate != null ? `${faDigits(view.stats.weeklyRate)}٪` : "—"}</p>
            <p className="text-[9px]" style={{ color: "var(--fg-faint)" }}>این هفته</p>
          </div>
          <div>
            <p className="text-base font-extrabold">{view.stats.monthRate != null ? `${faDigits(view.stats.monthRate)}٪` : "—"}</p>
            <p className="text-[9px]" style={{ color: "var(--fg-faint)" }}>این ماه</p>
          </div>
        </div>
      </div>

      {/* نوار هفته */}
      <div className="mt-3 grid grid-cols-7 gap-1.5">
        {weekDays.map((d) => {
          const o = occMap.get(d);
          const isSched = h.weekdays.length ? scheduled(h, d) : true;
          return (
            <div key={d} className="flex flex-col items-center gap-1">
              <span className="text-[9px]" style={{ color: "var(--fg-faint)" }}>{faDateShort(d).split("/")[2]}</span>
              <button
                disabled={!isSched || d > today}
                onClick={async () => {
                  const next = o?.status === "done" ? "partial" : o?.status === "partial" ? "missed" : o?.status === "missed" ? "skipped" : "done";
                  const r = await run(() => setOccurrence({ habitId: h.id, date: d, status: next }), { silent: true });
                  if (r?.error) toast.push("err", r.error);
                }}
                className="grid size-7 w-full max-w-7 place-items-center rounded-full border transition-all hover:scale-105 disabled:opacity-40"
                style={{
                  borderColor: "var(--border-strong)",
                  background: o ? STATUS_DOT[o.status] : "transparent",
                }}
                aria-label={`${faDateMed(d)} — ${o ? habitStatusLabel(o.status) : "ثبت نشده"}`}
                title={o ? habitStatusLabel(o.status) : "ثبت نشده"}
              >
                {o && (o.status === "done" || o.status === "partial") && <Check className="size-3.5" style={{ color: "white" }} />}
              </button>
            </div>
          );
        })}
      </div>

      <div className="mt-3 flex flex-wrap items-center gap-1 border-t pt-2.5" style={{ borderColor: "var(--border)" }}>
        <button className="btn btn-ghost !min-h-8 !px-2 !py-1 text-[11px]" onClick={onEdit}>
          <Pencil className="size-3.5" /> ویرایش
        </button>
        <button className="btn btn-ghost !min-h-8 !px-2 !py-1 text-[11px]"
          onClick={() => void run(() => toggleHabitPause(h.id))}>
          {h.status === "active" ? <><Pause className="size-3.5" /> توقف موقت</> : <><Play className="size-3.5" /> فعال کردن</>}
        </button>
        <button className="btn btn-ghost !min-h-8 !px-2 !py-1 text-[11px]" style={{ color: "var(--danger)" }} onClick={() => setDel(true)}>
          <Trash2 className="size-3.5" /> حذف
        </button>
        <div className="mr-auto flex items-center gap-1 text-[10px]" style={{ color: "var(--fg-faint)" }}>
          <span>وضعیت‌ها: </span>
          {HABIT_STATUS.map((s) => (
            <span key={s.value} className="flex items-center gap-1">
              <span className="size-2 rounded-full" style={{ background: STATUS_DOT[s.value] }} />
              {s.label}
            </span>
          ))}
        </div>
      </div>

      <Confirm
        open={del} onClose={() => setDel(false)}
        title="حذف عادت"
        message={`عادت «${h.name}» و سوابق روزانه‌اش حذف می‌شوند. مطمئنی؟`}
        danger
        onConfirm={async () => {
          const r = await deleteHabit(h.id);
          if (r.error) toast.push("err", r.error); else toast.push("ok", "عادت حذف شد.");
        }}
      />
    </div>
  );
}

function scheduled(h: HabitRow, iso: string): boolean {
  if (iso < h.startDate) return false;
  if (h.endDate && iso > h.endDate) return false;
  const wd = (new Date(iso + "T00:00:00Z").getUTCDay() + 1) % 7;
  return h.weekdays.includes(wd);
}

function HabitForm({ init, onDone, today }: { init?: HabitRow; onDone: () => void; today: string }) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const [name, setName] = useState(init?.name ?? "");
  const [description, setDescription] = useState(init?.description ?? "");
  const [category, setCategory] = useState(init?.category ?? "");
  const [frequency, setFrequency] = useState(init?.frequency ?? "daily");
  const [weekdays, setWeekdays] = useState<number[]>(init?.weekdays ?? [0, 1, 2, 3, 4, 5, 6]);
  const [minTarget, setMinTarget] = useState(String(init?.minTarget ?? 1));
  const [idealTarget, setIdealTarget] = useState(init?.idealTarget != null ? String(init.idealTarget) : "");
  const [unit, setUnit] = useState(init?.unit ?? "");
  const [startDate, setStartDate] = useState<string | null>(init?.startDate ?? today);
  const [endDate, setEndDate] = useState<string | null>(init?.endDate ?? null);

  const toggleWd = (w: number) =>
    setWeekdays((s) => (s.includes(w) ? s.filter((x) => x !== w) : [...s, w].sort()));

  return (
    <form
      className="space-y-4"
      onSubmit={async (e) => {
        e.preventDefault();
        setBusy(true);
        const r = await saveHabit({
          id: init?.id, name, description, category, frequency,
          weekdays: frequency === "custom" ? weekdays : undefined,
          minTarget: Number(minTarget) || 1,
          idealTarget: idealTarget ? Number(idealTarget) : null,
          unit, startDate, endDate,
        });
        setBusy(false);
        if (r.error) { toast.push("err", r.error); return; }
        toast.push("ok", r.success!);
        onDone();
      }}
    >
      <Field label="نام عادت">
        <input className="input" value={name} onChange={(e) => setName(e.target.value)} required autoFocus placeholder="مثلاً: مطالعهٔ روزانه" />
      </Field>
      <Field label="برنامهٔ هفتگی">
        <Segmented options={[{ value: "daily", label: "هر روز" }, { value: "custom", label: "روزهای خاص" }]} value={frequency} onChange={setFrequency} />
      </Field>
      {frequency === "custom" && (
        <Field label="کدام روزها؟">
          <div className="flex flex-wrap gap-1.5">
            {FA_WEEKDAYS.map((w, i) => (
              <button key={w} type="button"
                className="chip !px-3 !py-1.5 !text-[11px] transition-all"
                style={weekdays.includes(i) ? { background: "var(--accent)", color: "var(--accent-fg)", borderColor: "transparent" } : {}}
                onClick={() => toggleWd(i)}
                aria-pressed={weekdays.includes(i)}>
                {w}
              </button>
            ))}
          </div>
        </Field>
      )}
      <div className="grid grid-cols-3 gap-4">
        <Field label="هدف حداقلی">
          <input className="input" type="number" min={1} inputMode="numeric" value={minTarget} onChange={(e) => setMinTarget(e.target.value)} />
        </Field>
        <Field label="هدف ایده‌آل (اختیاری)">
          <input className="input" type="number" min={1} inputMode="numeric" value={idealTarget} onChange={(e) => setIdealTarget(e.target.value)} />
        </Field>
        <Field label="واحد" hint="دقیقه، صفحه، بار…">
          <input className="input" value={unit} onChange={(e) => setUnit(e.target.value)} placeholder="دقیقه" />
        </Field>
      </div>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Field label="تاریخ شروع"><JalaliDatePicker value={startDate} onChange={setStartDate} clearable={false} /></Field>
        <Field label="تاریخ پایان (اختیاری)"><JalaliDatePicker value={endDate} onChange={setEndDate} /></Field>
      </div>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Field label="دسته‌بندی">
          <input className="input" value={category} onChange={(e) => setCategory(e.target.value)} placeholder="مثلاً: سلامت" />
        </Field>
        <Field label="توضیح">
          <input className="input" value={description} onChange={(e) => setDescription(e.target.value)} />
        </Field>
      </div>
      <div className="flex justify-end gap-2">
        <button type="button" className="btn btn-ghost" onClick={onDone}>انصراف</button>
        <button type="submit" className="btn btn-primary" disabled={busy}>{busy ? <Spinner /> : "ذخیرهٔ عادت"}</button>
      </div>
    </form>
  );
}
