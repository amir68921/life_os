"use client";

import { useCallback, useEffect, useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { addInterruption, cancelFocus, finishFocus, pauseFocus, resumeFocus, saveFocusReview, startFocus, type FocusSessionDTO } from "@/app/actions/focus";
import { elapsedSeconds, remainingSeconds } from "@/lib/focus";
import { fa, formatClock, formatMinutes } from "@/lib/format";
import type { LinkOptions } from "@/lib/queries";
import { ActionForm, Field, RatingInput, Select } from "./forms";
import { usePrefs } from "./prefs";

type Interruption = { id: string; kind: string; reason: string };
const PENDING_KEY = "lifeos.focus.pendingClientId";

function beep() {
  try {
    const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ctx = new Ctx();
    [0, 0.35, 0.7].forEach((t) => {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.frequency.value = 660;
      g.gain.setValueAtTime(0.15, ctx.currentTime + t);
      g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + t + 0.3);
      o.connect(g).connect(ctx.destination);
      o.start(ctx.currentTime + t);
      o.stop(ctx.currentTime + t + 0.3);
    });
  } catch {}
}

export function FocusTimer({
  initial,
  initialInterruptions,
  serverNow,
  links,
  defaultTaskId,
}: {
  initial: FocusSessionDTO | null;
  initialInterruptions: Interruption[];
  serverNow: number;
  links: LinkOptions;
  defaultTaskId?: string;
}) {
  const prefs = usePrefs();
  const router = useRouter();
  const [session, setSession] = useState<FocusSessionDTO | null>(initial);
  const [ints, setInts] = useState<Interruption[]>(initialInterruptions);
  const [finished, setFinished] = useState<FocusSessionDTO | null>(null);
  const [now, setNow] = useState(() => Date.now());
  const [pending, start] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const [planned, setPlanned] = useState(prefs.focusMinutes);
  const [intText, setIntText] = useState("");
  const [intKind, setIntKind] = useState<"interruption" | "distraction">("distraction");
  const [breakLeft, setBreakLeft] = useState<number | null>(null);
  const [fullscreen, setFullscreen] = useState(false);
  const offset = useRef(serverNow - Date.now()); // clock skew between server and browser
  const autoFinishing = useRef(false);
  const container = useRef<HTMLDivElement>(null);

  const serverClock = () => Date.now() + offset.current;

  useEffect(() => {
    const iv = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(iv);
  }, []);

  const doFinish = useCallback(
    (auto: boolean) => {
      if (!session) return;
      start(async () => {
        const r = await finishFocus(session.id, auto);
        if (r.ok && r.data) {
          setFinished(r.data);
          setSession(null);
          setInts([]);
          if (r.data.breakMinutes > 0) setBreakLeft(r.data.breakMinutes * 60);
          router.refresh();
        } else if (!r.ok) setError(r.error);
        autoFinishing.current = false;
      });
    },
    [session, router],
  );

  // Auto-complete at the planned end (also covers recovery after refresh / closed tab).
  const remaining = session ? remainingSeconds(session, now + offset.current) : 0;
  useEffect(() => {
    if (session && session.status === "running" && remaining <= 0 && !autoFinishing.current) {
      autoFinishing.current = true;
      if (prefs.notifyFocusEnd) {
        beep();
        if (typeof Notification !== "undefined" && Notification.permission === "granted") {
          new Notification("LIFE OS", { body: "جلسهٔ تمرکز به پایان رسید." });
        }
      }
      doFinish(true);
    }
  }, [remaining, session, doFinish, prefs.notifyFocusEnd]);

  // Break countdown (client-only, not recorded as work)
  useEffect(() => {
    if (breakLeft === null) return;
    if (breakLeft <= 0) {
      if (prefs.notifyFocusEnd) beep();
      setBreakLeft(null);
      return;
    }
    const tmo = setTimeout(() => setBreakLeft((b) => (b === null ? null : b - 1)), 1000);
    return () => clearTimeout(tmo);
  }, [breakLeft, prefs.notifyFocusEnd]);

  useEffect(() => {
    const onFs = () => setFullscreen(!!document.fullscreenElement);
    document.addEventListener("fullscreenchange", onFs);
    return () => document.removeEventListener("fullscreenchange", onFs);
  }, []);

  const begin = (fd: FormData) => {
    setError(null);
    let clientId = localStorage.getItem(PENDING_KEY);
    if (!clientId) {
      clientId = crypto.randomUUID();
      localStorage.setItem(PENDING_KEY, clientId);
    }
    fd.set("clientId", clientId);
    if (prefs.notifyFocusEnd && typeof Notification !== "undefined" && Notification.permission === "default") {
      Notification.requestPermission().catch(() => {});
    }
    start(async () => {
      const r = await startFocus(fd);
      if (r.ok && r.data) {
        localStorage.removeItem(PENDING_KEY);
        offset.current = 0;
        setSession(r.data);
        setFinished(null);
        setBreakLeft(null);
        router.refresh();
      } else if (!r.ok) {
        setError(r.error);
        if (!/فعال/.test(r.error)) return;
        localStorage.removeItem(PENDING_KEY);
        router.refresh();
      }
    });
  };

  const act = (fn: () => Promise<{ ok: boolean; data?: FocusSessionDTO; error?: string }>) =>
    start(async () => {
      const r = await fn();
      if (r.ok && r.data) setSession(r.data);
      else if (!r.ok) setError(r.error ?? "خطا");
    });

  const toggleFs = () => {
    if (!document.fullscreenElement) container.current?.requestFullscreen?.().catch(() => setFullscreen((f) => !f));
    else document.exitFullscreen();
  };

  /* ---------------- Running / paused ---------------- */
  if (session) {
    const elapsed = elapsedSeconds(session, serverClock());
    const pct = Math.min(100, (elapsed / (session.plannedMinutes * 60)) * 100);
    const task = links.tasks.find((x) => x.id === session.taskId);
    return (
      <div ref={container} className={`card flex flex-col items-center text-center ${fullscreen ? "fixed inset-0 z-[60] justify-center rounded-none bg-zinc-50 dark:bg-zinc-950" : ""}`}>
        <div className="text-xs font-medium text-accent-700 dark:text-accent-300">{session.status === "paused" ? "متوقف" : "در حال تمرکز"}</div>
        {session.objective && <h2 className="mt-2 text-lg font-semibold">{session.objective}</h2>}
        {task && <p className="text-sm muted">کار: {task.title}</p>}
        <div className="relative my-6 flex h-56 w-56 items-center justify-center sm:h-64 sm:w-64">
          <svg viewBox="0 0 100 100" className="absolute inset-0 -rotate-90" aria-hidden>
            <circle cx="50" cy="50" r="45" fill="none" strokeWidth="5" className="stroke-zinc-200 dark:stroke-zinc-800" />
            <circle cx="50" cy="50" r="45" fill="none" strokeWidth="5" strokeLinecap="round" className="stroke-accent-500 transition-all" strokeDasharray={`${(pct / 100) * 282.7} 282.7`} />
          </svg>
          <div>
            <div suppressHydrationWarning className="text-5xl font-bold tabular-nums" role="timer" aria-live="off" aria-label="زمان باقی‌مانده">
              {formatClock(Math.max(0, remaining))}
            </div>
            <div suppressHydrationWarning className="mt-1 text-xs muted">باقی‌مانده · گذشته {formatClock(elapsed)}</div>
          </div>
        </div>
        <div className="flex flex-wrap justify-center gap-2">
          {session.status === "running" ? (
            <button type="button" className="btn btn-primary min-w-28" disabled={pending} onClick={() => act(() => pauseFocus(session.id))}>
              توقف موقت
            </button>
          ) : (
            <button type="button" className="btn btn-primary min-w-28" disabled={pending} onClick={() => act(() => resumeFocus(session.id))}>
              ادامه
            </button>
          )}
          <button type="button" className="btn" disabled={pending} onClick={() => doFinish(false)}>
            {remaining > 0 ? "پایان زودهنگام" : "پایان"}
          </button>
          <button
            type="button"
            className="btn btn-danger"
            disabled={pending}
            onClick={() => {
              if (!confirm("جلسه لغو شود؟ جلسهٔ لغوشده در آمار تمرکز حساب نمی‌شود.")) return;
              start(async () => {
                const r = await cancelFocus(session.id);
                if (r.ok) {
                  setSession(null);
                  router.refresh();
                } else setError(r.error);
              });
            }}
          >
            لغو
          </button>
          <button type="button" className="btn btn-ghost" onClick={toggleFs} aria-pressed={fullscreen}>
            {fullscreen ? "خروج از تمام‌صفحه" : "تمام‌صفحه"}
          </button>
        </div>
        <form
          className="mt-6 flex w-full max-w-md gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            const text = intText.trim();
            if (!text) return;
            start(async () => {
              const r = await addInterruption(session.id, intKind, text);
              if (r.ok) {
                setInts((x) => [...x, { id: crypto.randomUUID(), kind: intKind, reason: text }]);
                setIntText("");
              } else setError(r.error);
            });
          }}
        >
          <select value={intKind} onChange={(e) => setIntKind(e.target.value as "interruption" | "distraction")} className="input w-32 shrink-0" aria-label="نوع">
            <option value="distraction">حواس‌پرتی</option>
            <option value="interruption">وقفه</option>
          </select>
          <input value={intText} onChange={(e) => setIntText(e.target.value)} maxLength={200} className="input" placeholder="چه چیزی حواستان را پرت کرد؟" aria-label="علت" />
          <button type="submit" className="btn shrink-0" disabled={pending}>
            ثبت
          </button>
        </form>
        {ints.length > 0 && (
          <ul className="mt-3 flex flex-wrap justify-center gap-1.5">
            {ints.map((i) => (
              <li key={i.id} className="chip">
                {i.kind === "distraction" ? "حواس‌پرتی" : "وقفه"}: {i.reason}
              </li>
            ))}
          </ul>
        )}
        {error && <p role="alert" className="mt-3 text-sm text-red-600">{error}</p>}
        <p className="mt-4 text-xs muted">وضعیت جلسه روی سرور ذخیره می‌شود؛ با تازه‌سازی صفحه یا بستن مرورگر از بین نمی‌رود.</p>
      </div>
    );
  }

  /* ---------------- Post-session reflection ---------------- */
  if (finished) {
    const mins = Math.round((finished.elapsedSeconds ?? 0) / 60);
    return (
      <div className="card">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
          <div>
            <h2 className="section-title">جلسه ذخیره شد ✓</h2>
            <p className="text-sm muted">زمان اندازه‌گیری‌شده: {formatMinutes(mins)} {finished.finishedEarly ? "(پایان زودهنگام)" : ""}</p>
          </div>
          {breakLeft !== null && (
            <div className="rounded-xl bg-accent-50 px-3 py-2 text-sm text-accent-800 dark:bg-accent-900/30 dark:text-accent-100">
              استراحت: <span className="tabular-nums font-semibold">{formatClock(breakLeft)}</span>{" "}
              <button type="button" className="underline" onClick={() => setBreakLeft(null)}>رد کردن</button>
            </div>
          )}
        </div>
        <p className="mb-4 text-sm muted">پاسخ به این سؤال‌ها اختیاری است. زمان تایمر به‌طور خودکار «تمرکز واقعی» فرض نمی‌شود.</p>
        <ActionForm action={saveFocusReview} onSuccess={() => setFinished(null)} submitLabel="ثبت بازتاب" extraButtons={<button type="button" className="btn btn-ghost" onClick={() => setFinished(null)}>رد کردن</button>}>
          <input type="hidden" name="id" value={finished.id} />
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="به هدف جلسه رسیدید؟">
              <Select name="objectiveAchieved" options={[{ value: "yes", label: "بله" }, { value: "partly", label: "تا حدی" }, { value: "no", label: "خیر" }]} empty="—" />
            </Field>
            <Field label="چند دقیقه واقعاً متمرکز بودید؟" hint={`حداکثر ${fa(Math.ceil((finished.elapsedSeconds ?? 0) / 60))} دقیقه`}>
              <input name="focusedMinutes" type="number" min={0} max={Math.ceil((finished.elapsedSeconds ?? 0) / 60)} className="input" />
            </Field>
            <RatingInput name="focusRating" label="چقدر متمرکز بودید؟" />
            <RatingInput name="energyAfter" label="الان چقدر انرژی دارید؟" />
            <Field label="چه چیزی حواستان را پرت کرد؟" className="sm:col-span-2">
              <input name="interruptedBy" maxLength={300} className="input" />
            </Field>
            <Field label="قدم بعدی چیست؟" className="sm:col-span-2">
              <input name="nextStep" maxLength={500} className="input" />
            </Field>
          </div>
        </ActionForm>
      </div>
    );
  }

  /* ---------------- Setup ---------------- */
  return (
    <div className="card">
      {breakLeft !== null && (
        <div className="mb-4 rounded-xl bg-accent-50 px-3 py-2 text-sm dark:bg-accent-900/30">
          استراحت: <span className="tabular-nums font-semibold">{formatClock(breakLeft)}</span>
        </div>
      )}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          begin(new FormData(e.currentTarget));
        }}
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="هدف این جلسه" className="sm:col-span-2">
            <input name="objective" maxLength={500} className="input" placeholder="مثلاً نوشتن پیش‌نویس فصل اول" />
          </Field>
          <fieldset className="sm:col-span-2">
            <legend className="label">مدت جلسه (دقیقه)</legend>
            <div className="flex flex-wrap items-center gap-2">
              {[15, 25, 45, 50, 90].map((m) => (
                <button key={m} type="button" onClick={() => setPlanned(m)} aria-pressed={planned === m} className={`btn btn-sm ${planned === m ? "btn-primary" : ""}`}>
                  {fa(m)}
                </button>
              ))}
              <input name="plannedMinutes" type="number" min={1} max={480} value={planned} onChange={(e) => setPlanned(Number(e.target.value))} className="input w-24" aria-label="مدت دلخواه" required />
            </div>
          </fieldset>
          <Field label="استراحت پس از جلسه (دقیقه)">
            <input name="breakMinutes" type="number" min={0} max={120} defaultValue={prefs.breakMinutes} className="input" />
          </Field>
          <Field label="کار">
            <Select name="taskId" options={links.tasks.map((x) => ({ value: x.id, label: x.title }))} defaultValue={defaultTaskId} empty="بدون کار" />
          </Field>
          <Field label="پروژه">
            <Select name="projectId" options={links.projects.map((x) => ({ value: x.id, label: x.name }))} empty="بدون پروژه" />
          </Field>
          <Field label="هدف">
            <Select name="goalId" options={links.goals.map((x) => ({ value: x.id, label: x.title }))} empty="بدون هدف" />
          </Field>
          <RatingInput name="energyBefore" label="سطح انرژی فعلی" />
          <RatingInput name="focusBefore" label="آمادگی برای تمرکز" />
        </div>
        {error && <p role="alert" className="mt-4 text-sm text-red-600">{error}</p>}
        <button type="submit" className="btn btn-primary mt-5 w-full sm:w-auto" disabled={pending || !planned}>
          {pending ? "…" : `شروع جلسهٔ ${fa(planned || 0)} دقیقه‌ای`}
        </button>
      </form>
    </div>
  );
}
