import type { ReactNode } from "react";
import Link from "next/link";
import { fa } from "@/lib/format";

export function PageHeader({ title, subtitle, actions }: { title: string; subtitle?: ReactNode; actions?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-zinc-900 dark:text-zinc-50">{title}</h1>
        {subtitle && <p className="mt-1 text-sm muted">{subtitle}</p>}
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
    </div>
  );
}

export function Card({ children, className = "", title, action }: { children: ReactNode; className?: string; title?: ReactNode; action?: ReactNode }) {
  return (
    <section className={`card ${className}`}>
      {(title || action) && (
        <div className="mb-4 flex items-center justify-between gap-2">
          {title && <h2 className="section-title">{title}</h2>}
          {action}
        </div>
      )}
      {children}
    </section>
  );
}

export function Stat({ label, value, hint, href }: { label: string; value: ReactNode; hint?: ReactNode; href?: string }) {
  const body = (
    <>
      <div className="text-xs font-medium muted">{label}</div>
      <div className="mt-1.5 text-2xl font-bold tracking-tight">{value}</div>
      {hint && <div className="mt-1 text-xs muted">{hint}</div>}
    </>
  );
  return href ? (
    <Link href={href} className="card block transition-colors hover:border-accent-300 dark:hover:border-accent-700">
      {body}
    </Link>
  ) : (
    <div className="card">{body}</div>
  );
}

export function Progress({ value, label, size = "md" }: { value: number; label?: string; size?: "sm" | "md" }) {
  const v = Math.max(0, Math.min(100, Math.round(value)));
  return (
    <div
      role="progressbar"
      aria-valuenow={v}
      aria-valuemin={0}
      aria-valuemax={100}
      aria-label={label ?? "پیشرفت"}
      className={`w-full overflow-hidden rounded-full bg-zinc-100 dark:bg-zinc-800 ${size === "sm" ? "h-1.5" : "h-2.5"}`}
    >
      <div className="h-full rounded-full bg-accent-500 transition-all" style={{ width: `${v}%` }} />
    </div>
  );
}

const badgeTones: Record<string, string> = {
  neutral: "bg-zinc-100 text-zinc-700 dark:bg-zinc-800 dark:text-zinc-300",
  accent: "bg-accent-50 text-accent-700 dark:bg-accent-900/40 dark:text-accent-200",
  amber: "bg-amber-50 text-amber-800 dark:bg-amber-900/30 dark:text-amber-200",
  red: "bg-red-50 text-red-700 dark:bg-red-900/30 dark:text-red-300",
  blue: "bg-sky-50 text-sky-700 dark:bg-sky-900/30 dark:text-sky-200",
  green: "bg-emerald-50 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-200",
};

export function Badge({ children, tone = "neutral" }: { children: ReactNode; tone?: keyof typeof badgeTones | string }) {
  return <span className={`inline-flex items-center rounded-md px-2 py-0.5 text-xs font-medium ${badgeTones[tone] ?? badgeTones.neutral}`}>{children}</span>;
}

export const priorityTone: Record<string, string> = { low: "neutral", medium: "blue", high: "amber", critical: "red" };

export function EmptyState({ title, description, action, icon = "✦" }: { title: string; description?: string; action?: ReactNode; icon?: string }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-zinc-300 px-6 py-10 text-center dark:border-zinc-700">
      <div aria-hidden className="mb-3 text-2xl text-accent-500">
        {icon}
      </div>
      <p className="font-medium text-zinc-800 dark:text-zinc-200">{title}</p>
      {description && <p className="mt-1 max-w-sm text-sm muted">{description}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function Rating({ value, max = 5 }: { value: number | null | undefined; max?: number }) {
  if (!value) return <span className="muted">—</span>;
  return (
    <span aria-label={`${value} از ${max}`} className="tabular-nums">
      {fa(value)}/{fa(max)}
    </span>
  );
}

export function Tabs({ items, active }: { items: { href: string; label: string; key: string }[]; active: string }) {
  return (
    <nav className="mb-5 flex flex-wrap gap-1 rounded-xl border border-zinc-200 bg-white p-1 dark:border-zinc-800 dark:bg-zinc-900" aria-label="نما">
      {items.map((i) => (
        <Link key={i.key} href={i.href} className={`tab ${active === i.key ? "tab-active" : ""}`} aria-current={active === i.key ? "page" : undefined}>
          {i.label}
        </Link>
      ))}
    </nav>
  );
}
