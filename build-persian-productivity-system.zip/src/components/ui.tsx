"use client";

import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { X, CheckCircle2, AlertCircle, Inbox, Loader2 } from "lucide-react";

// ---------- Toast ----------

type Toast = { id: number; kind: "ok" | "err"; text: string };
const ToastCtx = createContext<{ push: (kind: "ok" | "err", text: string) => void }>({ push: () => {} });

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<Toast[]>([]);
  const idRef = useRef(1);
  const push = useCallback((kind: "ok" | "err", text: string) => {
    const id = idRef.current++;
    setItems((s) => [...s, { id, kind, text }]);
    setTimeout(() => setItems((s) => s.filter((t) => t.id !== id)), 4200);
  }, []);
  return (
    <ToastCtx.Provider value={{ push }}>
      {children}
      {typeof window !== "undefined" &&
        createPortal(
          <div className="fixed bottom-20 left-1/2 z-[100] flex w-full max-w-sm -translate-x-1/2 flex-col items-center gap-2 px-4 md:bottom-6" role="status" aria-live="polite">
            {items.map((t) => (
              <div
                key={t.id}
                className="animate-rise flex w-full items-center gap-2 rounded-xl border px-3.5 py-2.5 text-sm shadow-lg backdrop-blur-xl"
                style={{
                  background: "var(--card)",
                  borderColor: "var(--border)",
                  color: "var(--fg)",
                  boxShadow: "var(--shadow)",
                }}
              >
                {t.kind === "ok" ? (
                  <CheckCircle2 className="size-4 shrink-0" style={{ color: "var(--ok)" }} />
                ) : (
                  <AlertCircle className="size-4 shrink-0" style={{ color: "var(--danger)" }} />
                )}
                <span className="leading-6">{t.text}</span>
              </div>
            ))}
          </div>,
          document.body
        )}
    </ToastCtx.Provider>
  );
}

export function useToast() {
  return useContext(ToastCtx);
}

/** اجرای یک اکشن سروری و نمایش نتیجه‌اش به‌صورت توست */
export function useRun() {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const run = useCallback(
    async <R extends { error?: string; success?: string }>(fn: () => Promise<R>, opts?: { silent?: boolean }) => {
      setBusy(true);
      try {
        const r = await fn();
        if (!opts?.silent) {
          if (r?.error) toast.push("err", r.error);
          else if (r?.success) toast.push("ok", r.success);
        }
        return r;
      } catch {
        toast.push("err", "خطای غیرمنتظره رخ داد.");
        return undefined;
      } finally {
        setBusy(false);
      }
    },
    [toast]
  );
  return { run, busy };
}

// ---------- Primitives ----------

export function Card({ className = "", children, ...rest }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={`card p-5 ${className}`} {...rest}>
      {children}
    </div>
  );
}

export function SectionTitle({ title, subtitle, action }: { title: string; subtitle?: string; action?: React.ReactNode }) {
  return (
    <div className="mb-4 flex items-start justify-between gap-3">
      <div>
        <h2 className="text-sm font-bold" style={{ color: "var(--fg)" }}>{title}</h2>
        {subtitle && <p className="mt-0.5 text-xs" style={{ color: "var(--fg-muted)" }}>{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

export function Chip({ children, tone }: { children: React.ReactNode; tone?: "accent" | "danger" | "warn" | "ok" }) {
  const style: React.CSSProperties = {};
  if (tone === "accent") { style.background = "var(--accent-soft)"; style.color = "var(--accent)"; style.borderColor = "transparent"; }
  if (tone === "danger") { style.background = "var(--danger-soft)"; style.color = "var(--danger)"; style.borderColor = "transparent"; }
  if (tone === "warn") { style.background = "var(--warn-soft)"; style.color = "var(--warn)"; style.borderColor = "transparent"; }
  if (tone === "ok") { style.background = "var(--ok-soft)"; style.color = "var(--ok)"; style.borderColor = "transparent"; }
  return <span className="chip" style={style}>{children}</span>;
}

export function EmptyState({ title, hint, action }: { title: string; hint?: string; action?: React.ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 rounded-2xl border border-dashed px-6 py-10 text-center" style={{ borderColor: "var(--border-strong)" }}>
      <div className="grid size-11 place-items-center rounded-full" style={{ background: "var(--bg-soft)", color: "var(--fg-faint)" }}>
        <Inbox className="size-5" />
      </div>
      <p className="text-sm font-semibold" style={{ color: "var(--fg)" }}>{title}</p>
      {hint && <p className="max-w-xs text-xs leading-6" style={{ color: "var(--fg-muted)" }}>{hint}</p>}
      {action && <div className="mt-1">{action}</div>}
    </div>
  );
}

export function ProgressBar({ value, tone }: { value: number; tone?: "danger" | "warn" }) {
  const v = Math.max(0, Math.min(100, value));
  let bg = "var(--accent)";
  if (tone === "danger") bg = "var(--danger)";
  if (tone === "warn") bg = "var(--warn)";
  return (
    <div className="h-1.5 w-full overflow-hidden rounded-full" style={{ background: "var(--bg-soft)" }} role="progressbar" aria-valuenow={v} aria-valuemin={0} aria-valuemax={100}>
      <div className="h-full rounded-full transition-all duration-500" style={{ width: `${v}%`, background: bg }} />
    </div>
  );
}

export function Field({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  return (
    <div>
      <span className="label">{label}</span>
      {children}
      {hint && <p className="mt-1 text-[11px] leading-5" style={{ color: "var(--fg-faint)" }}>{hint}</p>}
    </div>
  );
}

export function RatingInput({ value, onChange, labels }: { value: number | null; onChange: (v: number) => void; labels?: string[] }) {
  return (
    <div className="flex items-center gap-1.5" role="radiogroup">
      {[1, 2, 3, 4, 5].map((n) => (
        <button
          key={n}
          type="button"
          role="radio"
          aria-checked={value === n}
          aria-label={labels?.[n - 1] ?? String(n)}
          title={labels?.[n - 1] ?? String(n)}
          onClick={() => onChange(n)}
          className="size-8 rounded-full border text-xs font-semibold transition-all hover:scale-105"
          style={{
            borderColor: value === n ? "transparent" : "var(--border-strong)",
            background: value === n ? "var(--accent)" : "var(--card-soft)",
            color: value === n ? "var(--accent-fg)" : "var(--fg-muted)",
          }}
        >
          {n === value ? n : n}
        </button>
      ))}
      {labels && value != null && (
        <span className="mr-1 text-[11px]" style={{ color: "var(--fg-muted)" }}>{labels[value - 1]}</span>
      )}
    </div>
  );
}

export function Spinner({ className = "size-4" }: { className?: string }) {
  return <Loader2 className={`animate-spin ${className}`} aria-hidden />;
}

// ---------- Modal ----------

export function Modal({
  open, onClose, title, children, wide,
}: {
  open: boolean; onClose: () => void; title: string; children: React.ReactNode; wide?: boolean;
}) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [open, onClose]);

  if (!open) return null;
  return createPortal(
    <div
      className="animate-fade fixed inset-0 z-[90] flex items-end justify-center p-0 sm:items-center sm:p-6"
      style={{ background: "rgba(0,0,0,0.45)", backdropFilter: "blur(4px)" }}
      onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}
      role="dialog"
      aria-modal="true"
      aria-label={title}
    >
      <div
        ref={ref}
        className="animate-scale max-h-[92dvh] w-full overflow-y-auto rounded-t-3xl border p-5 sm:rounded-2xl"
        style={{
          background: "var(--card)", borderColor: "var(--border)",
          maxWidth: wide ? "42rem" : "30rem", boxShadow: "var(--shadow)",
        }}
      >
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-sm font-bold">{title}</h3>
          <button onClick={onClose} className="btn-ghost btn !min-h-0 !p-1.5" aria-label="بستن">
            <X className="size-4" />
          </button>
        </div>
        {children}
      </div>
    </div>,
    document.body
  );
}

export function Confirm({
  open, onClose, onConfirm, title, message, danger,
}: {
  open: boolean; onClose: () => void; onConfirm: () => void | Promise<void>;
  title: string; message: string; danger?: boolean;
}) {
  const [busy, setBusy] = useState(false);
  return (
    <Modal open={open} onClose={onClose} title={title}>
      <p className="text-sm leading-7" style={{ color: "var(--fg-muted)" }}>{message}</p>
      <div className="mt-5 flex justify-end gap-2">
        <button className="btn btn-ghost" onClick={onClose}>انصراف</button>
        <button
          className={`btn ${danger ? "btn-danger" : "btn-primary"}`}
          disabled={busy}
          onClick={async () => { setBusy(true); await onConfirm(); setBusy(false); onClose(); }}
        >
          {busy ? <Spinner /> : "تأیید"}
        </button>
      </div>
    </Modal>
  );
}
