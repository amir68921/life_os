"use client";

import React, { useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import {
  Play, Pause, Square, XCircle, Maximize2, Minimize2, Zap, Trash2, Pencil, Flag, BellRing,
} from "lucide-react";
import { Modal, Field, RatingInput, Spinner, useRun, useToast, Confirm, EmptyState } from "@/components/ui";
import {
  startFocus, pauseFocus, resumeFocus, finishFocus, cancelFocus, interruptFocus,
  correctFocus, deleteFocus, type ActiveFocus,
} from "@/lib/actions-life";
import { faDigits, faDuration, faClock, faDateMed, fmtTimeInTz } from "@/lib/jalali";

export type RecentSession = {
  id: string; objective: string | null; taskTitle: string | null; goalTitle: string | null;
  plannedMinutes: number; elapsedSeconds: number | null; focusedMinutesSelf: number | null;
  focusRatingEnd: number | null; achievedObjective: boolean | null; interruptionsCount: number;
  interruptionsNote: string | null; nextSteps: string | null; distractions: string[];
  localDate: string; startedAt: string; endedAt: string | null;
};

const LS_KEY = "lifeos:focus";

export function FocusClient({
  active, tasks, goals, defaults, recent, tz,
}: {
  active: ActiveFocus | null;
  tasks: { id: string; title: string }[];
  goals: { id: string; title: string }[];
  defaults: { focus: number; breakMin: number };
  recent: RecentSession[];
  tz: string;
}) {
  return (
    <div className="space-y-5">
      {active ? (
        <Runner active={active} tz={tz} />
      ) : (
        <Setup tasks={tasks} goals={goals} defaults={defaults} />
      )}
      <History recent={recent} tz={tz} />
    </div>
  );
}

// ---------------- Setup ----------------

function Setup({ tasks, goals, defaults }: {
  tasks: { id: string; title: string }[];
  goals: { id: string; title: string }[];
  defaults: { focus: number; breakMin: number };
}) {
  const router = useRouter();
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const [taskId, setTaskId] = useState("");
  const [goalId, setGoalId] = useState("");
  const [objective, setObjective] = useState("");
  const [minutes, setMinutes] = useState(defaults.focus);
  const [energy, setEnergy] = useState<number | null>(null);
  const [focusR, setFocusR] = useState<number | null>(null);

  // انتخاب خودکار وظیفه از پارامتر آدرس
  useEffect(() => {
    const p = new URLSearchParams(window.location.search).get("task");
    if (p && tasks.some((t) => t.id === p)) setTaskId(p);
  }, [tasks]);

  const presets = [15, 25, 45, 60, 90];

  const start = async () => {
    setBusy(true);
    const r = await startFocus({ taskId: taskId || null, goalId: goalId || null, objective, plannedMinutes: minutes, energyStart: energy, focusRatingStart: focusR });
    setBusy(false);
    if (r.error) { toast.push("err", r.error); return; }
    toast.push("ok", r.success ?? "شروع شد");
    router.refresh();
  };

  return (
    <div className="card mx-auto max-w-xl p-6">
      <div className="mb-5 text-center">
        <div className="mx-auto mb-3 grid size-12 place-items-center rounded-2xl" style={{ background: "var(--accent-soft)", color: "var(--accent)" }}>
          <Play className="size-6" />
        </div>
        <h2 className="text-base font-extrabold">آمادهٔ تمرکز؟</h2>
        <p className="mt-1 text-xs" style={{ color: "var(--fg-muted)" }}>قبل از شروع مشخص کن روی چه چیزی و چقدر کار می‌کنی.</p>
      </div>
      <div className="space-y-4">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Field label="وظیفهٔ مرتبط (اختیاری)">
            <select className="input" value={taskId} onChange={(e) => setTaskId(e.target.value)}>
              <option value="">— بدون وظیفه —</option>
              {tasks.map((t) => <option key={t.id} value={t.id}>{t.title}</option>)}
            </select>
          </Field>
          <Field label="هدف مرتبط (اختیاری)">
            <select className="input" value={goalId} onChange={(e) => setGoalId(e.target.value)}>
              <option value="">— بدون هدف —</option>
              {goals.map((g) => <option key={g.id} value={g.id}>{g.title}</option>)}
            </select>
          </Field>
        </div>
        <Field label="هدف این جلسه" hint="یک خط: انتهای این جلسه دقیقاً چه چیزی تمام شده باشد؟">
          <input className="input" value={objective} onChange={(e) => setObjective(e.target.value)} placeholder="مثلاً: فصل ۳ کتاب خلاصه شود" />
        </Field>
        <Field label={`مدت جلسه: ${faDigits(minutes)} دقیقه`}>
          <div className="flex flex-wrap items-center gap-2">
            {presets.map((p) => (
              <button key={p} type="button"
                className="chip !px-3 !py-1.5 !text-xs transition-all hover:scale-105"
                style={minutes === p ? { background: "var(--accent)", color: "var(--accent-fg)", borderColor: "transparent" } : {}}
                onClick={() => setMinutes(p)}>
                {faDigits(p)}
              </button>
            ))}
            <input type="range" min={5} max={180} step={5} value={minutes}
              onChange={(e) => setMinutes(Number(e.target.value))}
              className="w-full accent-teal-700" aria-label="مدت جلسه به دقیقه" />
          </div>
        </Field>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Field label="انرژی فعلی">
            <RatingInput value={energy} onChange={setEnergy} labels={["خسته", "کم", "معمولی", "خوب", "پر انرژی"]} />
          </Field>
          <Field label="احساس تمرکز فعلی">
            <RatingInput value={focusR} onChange={setFocusR} labels={["پراکنده", "کم", "معمولی", "خوب", "کاملاً متمرکز"]} />
          </Field>
        </div>
        <button className="btn btn-primary h-12 w-full text-sm" onClick={() => void start()} disabled={busy}>
          {busy ? <Spinner /> : <><Play className="size-4" /> شروع جلسهٔ {faDigits(minutes)} دقیقه‌ای</>}
        </button>
      </div>
    </div>
  );
}

// ---------------- Runner ----------------

function Runner({ active, tz }: { active: ActiveFocus; tz: string }) {
  const router = useRouter();
  const toast = useToast();
  const { run } = useRun();
  const [now, setNow] = useState(() => Date.now());
  const [fs, setFs] = useState(false);
  const [interruptOpen, setInterruptOpen] = useState(false);
  const [interruptNote, setInterruptNote] = useState("");
  const [reportOpen, setReportOpen] = useState(false);
  const [cancelOpen, setCancelOpen] = useState(false);
  const wrapRef = useRef<HTMLDivElement>(null);

  const elapsed = useMemo(() => {
    const start = new Date(active.startedAt).getTime();
    let paused = active.pausedSeconds * 1000;
    if (active.status === "paused" && active.pauseStartedAt) {
      paused += now - new Date(active.pauseStartedAt).getTime();
    }
    return Math.max(0, Math.floor((now - start - paused) / 1000));
  }, [active, now]);

  useEffect(() => {
    if (active.status !== "active") return;
    const t = setInterval(() => setNow(Date.now()), 500);
    return () => clearInterval(t);
  }, [active.status]);

  // نسخهٔ پشتیبان محلی برای بازیابی بعد از رفرش
  useEffect(() => {
    try {
      localStorage.setItem(LS_KEY, JSON.stringify({ id: active.id, startedAt: active.startedAt, status: active.status }));
    } catch { /* noop */ }
    return () => { try { if (active.status === "completed" || active.status === "cancelled") localStorage.removeItem(LS_KEY); } catch { /* noop */ } };
  }, [active]);

  useEffect(() => () => { if (document.fullscreenElement) document.exitFullscreen().catch(() => {}); }, []);

  const planned = active.plannedMinutes * 60;
  const remaining = Math.max(0, planned - elapsed);
  const overtime = elapsed - planned;
  const frac = Math.min(1, elapsed / planned);
  const R = 118;
  const C = 2 * Math.PI * R;

  const toggleFs = async () => {
    try {
      if (!document.fullscreenElement && wrapRef.current) {
        await wrapRef.current.requestFullscreen();
        setFs(true);
      } else {
        await document.exitFullscreen();
        setFs(false);
      }
    } catch { /* مرورگر اجازه نداد */ }
  };

  const finish = async (report: Record<string, unknown> | null) => {
    const r = await finishFocus(active.id, report ?? {});
    if (r.error) { toast.push("err", r.error); return; }
    try { localStorage.removeItem(LS_KEY); } catch { /* noop */ }
    toast.push("ok", r.success!);
    setReportOpen(false);
    router.refresh();
  };

  const cancel = async () => {
    const r = await cancelFocus(active.id);
    if (!r.error) {
      try { localStorage.removeItem(LS_KEY); } catch { /* noop */ }
    }
    if (r.error) toast.push("err", r.error); else toast.push("ok", r.success!);
    router.refresh();
  };

  const mmss = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return faDigits(`${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`);
  };

  return (
    <div
      ref={wrapRef}
      className="card relative mx-auto flex max-w-xl flex-col items-center gap-5 overflow-hidden p-8"
      style={fs ? { background: "var(--bg)", borderRadius: 0, minHeight: "100dvh", justifyContent: "center" } : {}}
    >
      <div className="absolute left-3 top-3">
        <button className="btn btn-ghost !min-h-0 !p-2" onClick={() => void toggleFs()} aria-label={fs ? "خروج از تمام‌صفحه" : "تمام‌صفحه"}>
          {fs ? <Minimize2 className="size-4" /> : <Maximize2 className="size-4" />}
        </button>
      </div>

      <div className="text-center">
        <p className="text-[11px] font-semibold tracking-wide" style={{ color: "var(--accent)" }}>
          جلسهٔ تمرکز در حال اجراست
        </p>
        {active.objective && <p className="mt-1 max-w-xs text-sm font-bold leading-7">«{active.objective}»</p>}
        <p className="mt-1 text-[11px]" style={{ color: "var(--fg-muted)" }}>
          {active.taskTitle ? `وظیفه: ${active.taskTitle}` : active.goalTitle ? `هدف: ${active.goalTitle}` : "جلسهٔ آزاد"}
        </p>
      </div>

      {/* Ring */}
      <div className="relative" role="timer" aria-label={`زمان باقی‌مانده ${mmss(remaining)}`}>
        <svg width="260" height="260" viewBox="0 0 260 260">
          <circle cx="130" cy="130" r={R} fill="none" stroke="var(--bg-soft)" strokeWidth="10" />
          <circle
            cx="130" cy="130" r={R} fill="none"
            stroke={overtime > 0 ? "var(--warn)" : "var(--accent)"}
            strokeWidth="10" strokeLinecap="round"
            strokeDasharray={C} strokeDashoffset={C * (1 - frac)}
            transform="rotate(-90 130 130)"
            style={{ transition: "stroke-dashoffset 0.5s linear" }}
          />
          {active.status === "paused" && (
            <circle cx="130" cy="130" r={R - 14} fill="var(--warn-soft)" />
          )}
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-5xl font-extrabold tabular-nums" dir="ltr" style={{ fontVariantNumeric: "tabular-nums" }}>
            {mmss(overtime > 0 ? 0 : remaining)}
          </span>
          {overtime > 0 ? (
            <span className="mt-1 text-xs font-semibold" style={{ color: "var(--warn)" }}>
              {faDigits(Math.floor(overtime / 60))} دقیقه اضافه
            </span>
          ) : (
            <span className="mt-1 text-[11px]" style={{ color: "var(--fg-faint)" }}>
              گذشته: <span dir="ltr">{mmss(elapsed)}</span>
            </span>
          )}
          {active.status === "paused" && (
            <span className="live-dot mt-1 rounded-full px-2 py-0.5 text-[10px] font-bold" style={{ background: "var(--warn-soft)", color: "var(--warn)" }}>
              مکث
            </span>
          )}
        </div>
      </div>

      <div className="flex flex-wrap items-center justify-center gap-2">
        {active.status === "active" ? (
          <button className="btn !min-h-11 !px-5" onClick={() => void run(() => pauseFocus(active.id))}>
            <Pause className="size-4" /> مکث
          </button>
        ) : (
          <button className="btn btn-primary !min-h-11 !px-5" onClick={() => void run(() => resumeFocus(active.id))}>
            <Play className="size-4" /> ادامه
          </button>
        )}
        <button className="btn !min-h-11" onClick={() => { if (overtime <= 0 && elapsed < 120 && !window.confirm("کمتر از ۲ دقیقه گذشته؛ زودتر تمام شود؟")) return; setReportOpen(true); }}>
          <Square className="size-4" /> پایان جلسه
        </button>
        <button className="btn btn-ghost !min-h-11" onClick={() => setCancelOpen(true)}>
          <XCircle className="size-4" /> لغو
        </button>
      </div>

      <button className="btn btn-soft !min-h-9 !py-1.5 !text-xs" onClick={() => setInterruptOpen(true)}>
        <BellRing className="size-3.5" /> ثبت وقفه / حواس‌پرتی
      </button>

      <Modal open={interruptOpen} onClose={() => setInterruptOpen(false)} title="چه چیزی حواستان را پرت کرد؟">
        <div className="space-y-4">
          <Field label="شرح وقفه" hint="مثلاً: پیامک، اینستاگرام، صحبت هم‌اتاقی">
            <input className="input" value={interruptNote} onChange={(e) => setInterruptNote(e.target.value)} autoFocus />
          </Field>
          <div className="flex justify-end gap-2">
            <button className="btn btn-ghost" onClick={() => setInterruptOpen(false)}>انصراف</button>
            <button className="btn btn-primary"
              onClick={() => void run(() => interruptFocus(active.id, interruptNote)).then(() => { setInterruptNote(""); setInterruptOpen(false); })}>
              ثبت وقفه
            </button>
          </div>
        </div>
      </Modal>

      <ReportModal
        open={reportOpen}
        onClose={() => setReportOpen(false)}
        onFinish={finish}
        elapsedMinutes={Math.round(elapsed / 60)}
      />

      <Confirm
        open={cancelOpen} onClose={() => setCancelOpen(false)}
        title="لغو جلسه"
        message="جلسه به‌عنوان انجام‌نشده علامت می‌خورد و در آمار تمرکز حساب نمی‌شود. مطمئنی؟"
        danger
        onConfirm={cancel}
      />
    </div>
  );
}

// ---------------- Report ----------------

function ReportModal({ open, onClose, onFinish, elapsedMinutes }: {
  open: boolean; onClose: () => void;
  onFinish: (report: Record<string, unknown> | null) => Promise<void>;
  elapsedMinutes: number;
}) {
  const [achieved, setAchieved] = useState<boolean | null>(null);
  const [focusR, setFocusR] = useState<number | null>(null);
  const [selfMin, setSelfMin] = useState(elapsedMinutes);
  const [energy, setEnergy] = useState<number | null>(null);
  const [note, setNote] = useState("");
  const [next, setNext] = useState("");
  const [distr, setDistr] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => { if (open) setSelfMin(elapsedMinutes); }, [open, elapsedMinutes]);

  const distrList = distr.split(/[,،]/).map((s) => s.trim()).filter(Boolean);

  return (
    <Modal open={open} onClose={onClose} title="گزارش پایان جلسه" wide>
      <div className="space-y-4">
        <p className="rounded-xl px-3 py-2 text-xs leading-6" style={{ background: "var(--accent-soft)", color: "var(--accent)" }}>
          مدت واقعی جلسه: {faDuration(elapsedMinutes)} — این مقدار دقیق است و با گزارش خودت ترکیب نمی‌شود.
        </p>
        <Field label="به هدف این جلسه رسیدی؟">
          <div className="flex gap-2">
            {[{ v: true, l: "بله" }, { v: false, l: "نه کامل" }].map((o) => (
              <button key={String(o.v)} type="button"
                className="btn flex-1"
                style={achieved === o.v ? { background: "var(--accent)", color: "var(--accent-fg)", borderColor: "transparent" } : {}}
                onClick={() => setAchieved(o.v)}>
                {o.l}
              </button>
            ))}
          </div>
        </Field>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Field label="چقدر متمرکز بودی؟">
            <RatingInput value={focusR} onChange={setFocusR} labels={["اصلاً", "کم", "متوسط", "زیاد", "عمیق"]} />
          </Field>
          <Field label="انرژی فعلی">
            <RatingInput value={energy} onChange={setEnergy} labels={["خالی", "کم", "معمولی", "خوب", "عالی"]} />
          </Field>
        </div>
        <Field label={`چقدرش واقعاً متمرکز بود؟ ${faDigits(selfMin)} دقیقه`} hint="صادقانه باش؛ این عدد در آمارِ «تمرکزِ خودگزارشی» جدا حساب می‌شود.">
          <input type="range" min={0} max={Math.max(1, elapsedMinutes)} value={selfMin}
            onChange={(e) => setSelfMin(Number(e.target.value))} className="w-full accent-teal-700" aria-label="دقیقه‌های متمرکز به گزارش خودت" />
        </Field>
        <Field label="حواس‌پرتی‌ها (با ویرگول)">
          <input className="input" value={distr} onChange={(e) => setDistr(e.target.value)} placeholder="مثلاً: گوشی، فکرهای فرعی" />
        </Field>
        <Field label="وقفه‌ها و مزاحمت‌ها">
          <textarea className="input min-h-12" value={note} onChange={(e) => setNote(e.target.value)} />
        </Field>
        <Field label="قدم بعدی چیست؟">
          <input className="input" value={next} onChange={(e) => setNext(e.target.value)} placeholder="مثلاً: ادامهٔ فصل ۴ فردا صبح" />
        </Field>
        <div className="flex flex-wrap justify-between gap-2 pt-1">
          <button className="btn btn-ghost" disabled={busy} onClick={() => void onFinish(null)}>
            بدون گزارش، فقط ثبت کن
          </button>
          <button className="btn btn-primary" disabled={busy}
            onClick={async () => {
              setBusy(true);
              await onFinish({
                achievedObjective: achieved, focusRatingEnd: focusR, focusedMinutesSelf: selfMin,
                energyEnd: energy, interruptionsNote: note, nextSteps: next, distractions: distrList,
              });
              setBusy(false);
            }}>
            {busy ? <Spinner /> : "ثبت جلسه با گزارش"}
          </button>
        </div>
      </div>
    </Modal>
  );
}

// ---------------- History ----------------

function History({ recent, tz }: { recent: RecentSession[]; tz: string }) {
  const toast = useToast();
  const { run } = useRun();
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [edit, setEdit] = useState<RecentSession | null>(null);

  return (
    <div className="card p-5">
      <h2 className="mb-3 text-sm font-bold">جلسات اخیر</h2>
      {recent.length === 0 ? (
        <EmptyState title="هنوز جلسه‌ای ثبت نشده" hint="اولین جلسهٔ تمرکزت را شروع کن؛ آمار واقعی همین‌جا جمع می‌شود." />
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full min-w-[640px] text-xs">
            <thead>
              <tr style={{ color: "var(--fg-faint)" }}>
                {["روز", "موضوع", "مدت واقعی", "تمرکز خودگزارشی", "امتیاز", "وقفه", ""].map((h, i) => (
                  <th key={i} className="pb-2 text-start font-medium">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {recent.map((s) => (
                <tr key={s.id} className="border-t" style={{ borderColor: "var(--border)" }}>
                  <td className="py-2.5 pe-2">{faDateMed(s.localDate)}</td>
                  <td className="py-2.5 pe-2">
                    <p className="max-w-52 truncate font-medium">{s.objective || s.taskTitle || s.goalTitle || "جلسهٔ آزاد"}</p>
                    <p className="text-[10px]" style={{ color: "var(--fg-faint)" }} dir="ltr">
                      {fmtTimeInTz(new Date(s.startedAt), tz)} {s.endedAt ? `← ${fmtTimeInTz(new Date(s.endedAt), tz)}` : ""}
                    </p>
                  </td>
                  <td className="py-2.5 pe-2">{s.elapsedSeconds != null ? faDuration(Math.round(s.elapsedSeconds / 60)) : "—"}</td>
                  <td className="py-2.5 pe-2">{s.focusedMinutesSelf != null ? `${faDigits(s.focusedMinutesSelf)}د` : "—"}</td>
                  <td className="py-2.5 pe-2">{s.focusRatingEnd != null ? `${faDigits(s.focusRatingEnd)}/۵` : "—"}</td>
                  <td className="py-2.5 pe-2">{faDigits(s.interruptionsCount)}</td>
                  <td className="py-2.5">
                    <div className="flex gap-0.5">
                      <button className="btn btn-ghost !min-h-0 !p-1.5" onClick={() => setEdit(s)} aria-label="اصلاح رکورد"><Pencil className="size-3.5" /></button>
                      <button className="btn btn-ghost !min-h-0 !p-1.5" onClick={() => setDeleteId(s.id)} aria-label="حذف رکورد"><Trash2 className="size-3.5" /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <Confirm
        open={!!deleteId} onClose={() => setDeleteId(null)}
        title="حذف رکورد جلسه"
        message="این رکورد از آمارها و سوابق حذف می‌شود. مطمئنی؟"
        danger
        onConfirm={async () => {
          const r = await deleteFocus(deleteId!);
          if (r.error) toast.push("err", r.error); else toast.push("ok", "حذف شد.");
        }}
      />
      <CorrectModal session={edit} onClose={() => setEdit(null)} />
    </div>
  );
}

function CorrectModal({ session, onClose }: { session: RecentSession | null; onClose: () => void }) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const [selfMin, setSelfMin] = useState(session?.focusedMinutesSelf ?? 0);
  const [note, setNote] = useState(session?.interruptionsNote ?? "");
  const [next, setNext] = useState(session?.nextSteps ?? "");
  const [distr, setDistr] = useState((session?.distractions ?? []).join("، "));

  useEffect(() => {
    setSelfMin(session?.focusedMinutesSelf ?? 0);
    setNote(session?.interruptionsNote ?? "");
    setNext(session?.nextSteps ?? "");
    setDistr((session?.distractions ?? []).join("، "));
  }, [session]);

  if (!session) return null;
  const maxSelf = Math.max(1, Math.round((session.elapsedSeconds ?? 0) / 60));
  return (
    <Modal open onClose={onClose} title="اصلاح رکورد جلسه" wide>
      <div className="space-y-4">
        <Field label={`تمرکز خودگزارشی: ${faDigits(selfMin)} دقیقه (حداکثر ${faDigits(maxSelf)})`}>
          <input type="range" min={0} max={maxSelf} value={selfMin} onChange={(e) => setSelfMin(Number(e.target.value))}
            className="w-full accent-teal-700" aria-label="تمرکز خودگزارشی" />
        </Field>
        <Field label="حواس‌پرتی‌ها (با ویرگول)">
          <input className="input" value={distr} onChange={(e) => setDistr(e.target.value)} />
        </Field>
        <Field label="وقفه‌ها">
          <textarea className="input min-h-12" value={note} onChange={(e) => setNote(e.target.value)} />
        </Field>
        <Field label="قدم بعدی">
          <input className="input" value={next} onChange={(e) => setNext(e.target.value)} />
        </Field>
        <div className="flex justify-end gap-2">
          <button className="btn btn-ghost" onClick={onClose}>انصراف</button>
          <button className="btn btn-primary" disabled={busy}
            onClick={async () => {
              setBusy(true);
              const r = await correctFocus(session.id, {
                focusedMinutesSelf: selfMin, interruptionsNote: note, nextSteps: next,
                distractions: distr.split(/[,،]/).map((s) => s.trim()).filter(Boolean),
              });
              setBusy(false);
              if (r.error) toast.push("err", r.error);
              else { toast.push("ok", r.success!); onClose(); }
            }}>
            {busy ? <Spinner /> : "ذخیرهٔ اصلاحات"}
          </button>
        </div>
      </div>
    </Modal>
  );
}
