import React from "react";
import { faDigits, faDateShort } from "@/lib/jalali";

// ---------- Bar chart (RTL-friendly via flex) ----------

export function BarChart({
  data, height = 140, unit = "", highlightLast = true,
}: {
  data: { date: string; value: number }[];
  height?: number;
  unit?: string;
  highlightLast?: boolean;
}) {
  const max = Math.max(1, ...data.map((d) => d.value));
  const sparseLabel = data.length > 14 ? 3 : data.length > 7 ? 2 : 1;
  return (
    <div>
      <div className="flex items-end gap-1" style={{ height }}>
        {data.map((d, i) => (
          <div key={d.date} className="group relative flex h-full min-w-0 flex-1 flex-col items-center justify-end">
            <div
              className="w-full rounded-t-md transition-all group-hover:opacity-80"
              style={{
                height: `${Math.max(d.value > 0 ? 4 : 0, (d.value / max) * 100)}%`,
                background: highlightLast && i === data.length - 1 ? "var(--accent)" : "var(--border-strong)",
                opacity: d.value === 0 ? 0.25 : 1,
              }}
              role="img"
              aria-label={`${faDateShort(d.date)}: ${faDigits(d.value)} ${unit}`}
            />
            <div className="pointer-events-none absolute -top-8 z-10 hidden whitespace-nowrap rounded-lg border px-2 py-1 text-[10px] group-hover:block"
              style={{ background: "var(--card)", borderColor: "var(--border)", color: "var(--fg)", boxShadow: "var(--shadow)" }}>
              {faDigits(d.value)} {unit}
            </div>
          </div>
        ))}
      </div>
      <div className="mt-1.5 flex gap-1">
        {data.map((d, i) => (
          <span key={d.date} className="min-w-0 flex-1 truncate text-center text-[9px]" style={{ color: "var(--fg-faint)" }}>
            {i % sparseLabel === 0 ? faDateShort(d.date).replace(/^\d+\//, "") : ""}
          </span>
        ))}
      </div>
    </div>
  );
}

// ---------- Line chart (SVG; time flows right → left) ----------

export function LineChart({
  data, height = 140, unit = "", target,
}: {
  data: { date: string; value: number | null }[];
  height?: number;
  unit?: string;
  target?: number;
}) {
  const W = 600, H = 160, P = 12;
  const vals = data.map((d) => d.value).filter((v): v is number => v != null);
  if (!vals.length) {
    return <p className="py-8 text-center text-xs" style={{ color: "var(--fg-faint)" }}>داده‌ای برای نمایش نیست.</p>;
  }
  const max = Math.max(...vals, target ?? 0);
  const min = Math.min(...vals);
  const span = Math.max(1, max - min);
  const x = (i: number) => W - P - (i / Math.max(1, data.length - 1)) * (W - 2 * P);
  const y = (v: number) => H - P - ((v - min) / span) * (H - 2 * P);

  let path = "";
  let started = false;
  const pts: { cx: number; cy: number; i: number }[] = [];
  data.forEach((d, i) => {
    if (d.value == null) { started = false; return; }
    const cx = x(i), cy = y(d.value);
    path += started ? ` L ${cx} ${cy}` : ` M ${cx} ${cy}`;
    started = true;
    pts.push({ cx, cy, i });
  });

  const ty = target != null && target >= min && target <= max ? y(target) : target != null && target > max ? P : H - P;

  return (
    <div style={{ height }}>
      <svg viewBox={`0 0 ${W} ${H}`} className="h-full w-full" role="img" aria-label="نمودار خطی">
        {target != null && (
          <>
            <line x1={P} x2={W - P} y1={ty} y2={ty} stroke="var(--warn)" strokeWidth="1" strokeDasharray="5 4" />
            <text x={P} y={ty - 5} fontSize="9" fill="var(--warn)">{`هدف: ${faDigits(target)} ${unit}`}</text>
          </>
        )}
        <path d={path} fill="none" stroke="var(--accent)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
        {pts.map((p) => (
          <g key={p.i}>
            <circle cx={p.cx} cy={p.cy} r="9" fill="transparent">
              <title>{`${faDateShort(data[p.i].date)} — ${faDigits(data[p.i].value!)} ${unit}`}</title>
            </circle>
            <circle cx={p.cx} cy={p.cy} r="2.5" fill="var(--accent)" />
          </g>
        ))}
      </svg>
    </div>
  );
}

// ---------- Donut ----------

const DONUT_COLORS = ["#0f766e", "#2dd4bf", "#f59e0b", "#8b5cf6", "#f43f5e", "#0ea5e9", "#84cc16", "#f97316", "#a8a29e"];

export function Donut({
  data, size = 150, centerLabel,
}: {
  data: { name: string; value: number }[];
  size?: number;
  centerLabel?: string;
}) {
  const total = data.reduce((a, b) => a + b.value, 0);
  const R = 44, C = 2 * Math.PI * R;
  let acc = 0;
  if (!total) {
    return <p className="py-6 text-center text-xs" style={{ color: "var(--fg-faint)" }}>داده‌ای برای نمایش نیست.</p>;
  }
  return (
    <div className="flex flex-wrap items-center justify-center gap-4">
      <svg width={size} height={size} viewBox="0 0 100 100" role="img" aria-label={centerLabel ?? "نمودار دایره‌ای"}>
        <circle cx="50" cy="50" r={R} fill="none" stroke="var(--bg-soft)" strokeWidth="11" />
        {data.map((d, i) => {
          const frac = d.value / total;
          const dash = `${frac * C} ${C}`;
          const offset = -acc * C;
          acc += frac;
          return (
            <circle
              key={d.name}
              cx="50" cy="50" r={R} fill="none"
              stroke={DONUT_COLORS[i % DONUT_COLORS.length]}
              strokeWidth="11" strokeDasharray={dash} strokeDashoffset={offset}
              transform="rotate(-90 50 50)" strokeLinecap="butt"
            >
              <title>{`${d.name}: ${faDigits(Math.round(frac * 100))}٪`}</title>
            </circle>
          );
        })}
        {centerLabel && (
          <text x="50" y="54" textAnchor="middle" fontSize="13" fontWeight="700" fill="var(--fg)">{centerLabel}</text>
        )}
      </svg>
      <ul className="space-y-1.5 text-xs">
        {data.slice(0, 7).map((d, i) => (
          <li key={d.name} className="flex items-center gap-2">
            <span className="size-2.5 rounded-full" style={{ background: DONUT_COLORS[i % DONUT_COLORS.length] }} />
            <span style={{ color: "var(--fg)" }}>{d.name}</span>
            <span style={{ color: "var(--fg-faint)" }}>{faDigits(Math.round((d.value / total) * 100))}٪</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

// ---------- Grouped bars (planned vs done per week) ----------

export function CompareBars({
  data, aLabel, bLabel,
}: {
  data: { label: string; a: number; b: number }[];
  aLabel: string;
  bLabel: string;
}) {
  const max = Math.max(1, ...data.flatMap((d) => [d.a, d.b]));
  return (
    <div>
      <div className="mb-3 flex items-center gap-4 text-[11px]" style={{ color: "var(--fg-muted)" }}>
        <span className="flex items-center gap-1.5"><span className="h-2 w-3 rounded-sm" style={{ background: "var(--border-strong)" }} />{aLabel}</span>
        <span className="flex items-center gap-1.5"><span className="h-2 w-3 rounded-sm" style={{ background: "var(--accent)" }} />{bLabel}</span>
      </div>
      <div className="space-y-3">
        {data.map((d) => (
          <div key={d.label}>
            <div className="mb-1 flex items-center justify-between text-[11px]" style={{ color: "var(--fg-muted)" }}>
              <span>{d.label}</span>
              <span>{faDigits(d.b)} / {faDigits(d.a)}</span>
            </div>
            <div className="relative h-2.5 w-full overflow-hidden rounded-full" style={{ background: "var(--bg-soft)" }}>
              <div className="absolute inset-y-0 right-0 rounded-full" style={{ width: `${(d.a / max) * 100}%`, background: "var(--border-strong)" }} />
              <div className="absolute inset-y-0 right-0 rounded-full" style={{ width: `${(d.b / max) * 100}%`, background: "var(--accent)" }} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
