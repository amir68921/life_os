"use client";

import { Bar, BarChart, CartesianGrid, Cell, Legend, Line, LineChart, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { fa } from "@/lib/format";

const COLORS = ["#2d847d", "#6366f1", "#f59e0b", "#ef4444", "#0ea5e9", "#a855f7", "#10b981", "#64748b", "#ec4899"];

type Datum = Record<string, string | number | null>;
type Series = { key: string; name: string; color?: string };

const axisStyle = { fontSize: 11, fill: "currentColor" };
const tooltipStyle = {
  contentStyle: { borderRadius: 12, border: "1px solid rgb(228 228 231)", fontSize: 12, direction: "rtl" as const, textAlign: "right" as const },
  labelStyle: { fontWeight: 600 },
};

function Empty() {
  return <div className="flex h-56 items-center justify-center text-sm muted">داده‌ای برای این بازه ثبت نشده است.</div>;
}

/** Bars, RTL: x-axis reversed so time flows right → left like Persian text. Null values = no data (gap). */
export function BarSeries({ data, xKey, series, unit = "", height = 240, stacked = false }: { data: Datum[]; xKey: string; series: Series[]; unit?: string; height?: number; stacked?: boolean }) {
  if (!data.length || data.every((d) => series.every((s) => d[s.key] === null || d[s.key] === 0))) return <Empty />;
  return (
    <div className="text-zinc-500 dark:text-zinc-400" style={{ height }} dir="ltr">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 8, right: 4, left: 4, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="currentColor" strokeOpacity={0.15} />
          <XAxis dataKey={xKey} reversed tick={axisStyle} tickLine={false} axisLine={false} interval="preserveStartEnd" />
          <YAxis orientation="right" tick={axisStyle} tickLine={false} axisLine={false} width={36} tickFormatter={(v) => fa(v)} />
          <Tooltip {...tooltipStyle} formatter={(v, n) => [v === null || v === undefined ? "بدون داده" : `${fa(Math.round(Number(v) * 10) / 10)} ${unit}`, n]} />
          {series.length > 1 && <Legend wrapperStyle={{ fontSize: 12, direction: "rtl" }} />}
          {series.map((s, i) => (
            <Bar key={s.key} dataKey={s.key} name={s.name} fill={s.color ?? COLORS[i % COLORS.length]} radius={[4, 4, 0, 0]} stackId={stacked ? "a" : undefined} maxBarSize={36} />
          ))}
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export function LineSeries({ data, xKey, series, unit = "", height = 240, domain }: { data: Datum[]; xKey: string; series: Series[]; unit?: string; height?: number; domain?: [number, number] }) {
  if (!data.length || data.every((d) => series.every((s) => d[s.key] === null))) return <Empty />;
  return (
    <div className="text-zinc-500 dark:text-zinc-400" style={{ height }} dir="ltr">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ top: 8, right: 4, left: 4, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="currentColor" strokeOpacity={0.15} />
          <XAxis dataKey={xKey} reversed tick={axisStyle} tickLine={false} axisLine={false} interval="preserveStartEnd" />
          <YAxis orientation="right" tick={axisStyle} tickLine={false} axisLine={false} width={36} domain={domain} tickFormatter={(v) => fa(Math.round(v * 10) / 10)} />
          <Tooltip {...tooltipStyle} formatter={(v, n) => [v === null || v === undefined ? "بدون داده" : `${fa(Math.round(Number(v) * 10) / 10)} ${unit}`, n]} />
          {series.length > 1 && <Legend wrapperStyle={{ fontSize: 12, direction: "rtl" }} />}
          {series.map((s, i) => (
            <Line key={s.key} type="monotone" dataKey={s.key} name={s.name} stroke={s.color ?? COLORS[i % COLORS.length]} strokeWidth={2} dot={{ r: 3 }} connectNulls={false} />
          ))}
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

export function PieSeries({ data, unit = "", height = 260 }: { data: { name: string; value: number }[]; unit?: string; height?: number }) {
  const total = data.reduce((a, d) => a + d.value, 0);
  if (!data.length || total === 0) return <Empty />;
  return (
    <div className="grid items-center gap-4 sm:grid-cols-2">
      <div style={{ height }} dir="ltr">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie data={data} dataKey="value" nameKey="name" innerRadius="55%" outerRadius="85%" paddingAngle={2}>
              {data.map((_, i) => (
                <Cell key={i} fill={COLORS[i % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip {...tooltipStyle} formatter={(v, n) => [`${fa(Math.round(Number(v)))} ${unit}`, n]} />
          </PieChart>
        </ResponsiveContainer>
      </div>
      <ul className="space-y-1.5 text-sm">
        {data.map((d, i) => (
          <li key={d.name} className="flex items-center justify-between gap-2">
            <span className="flex items-center gap-2">
              <span className="h-3 w-3 rounded-sm" style={{ background: COLORS[i % COLORS.length] }} aria-hidden />
              {d.name}
            </span>
            <span className="tabular-nums muted">
              {fa(Math.round(d.value))} {unit} ({fa(Math.round((d.value / total) * 100))}٪)
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}
