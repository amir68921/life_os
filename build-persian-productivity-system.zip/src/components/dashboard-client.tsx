"use client";

import React, { useState } from "react";
import Link from "next/link";
import { Plus, Timer, NotebookPen, Check, Play, ListTodo } from "lucide-react";
import { Modal, useRun } from "@/components/ui";
import { TaskForm } from "@/components/task-form";
import { setTaskStatus } from "@/lib/actions-core";
import { priorityLabel } from "@/lib/utils";

export function QuickActions({ goals }: { goals: { id: string; title: string }[] }) {
  const [taskOpen, setTaskOpen] = useState(false);
  return (
    <>
      <div className="grid grid-cols-3 gap-2">
        <button className="btn btn-primary h-auto flex-col gap-1.5 !py-3" onClick={() => setTaskOpen(true)}>
          <Plus className="size-5" />
          <span className="text-[11px]">وظیفهٔ جدید</span>
        </button>
        <Link href="/focus" className="btn btn-soft h-auto flex-col gap-1.5 !py-3">
          <Timer className="size-5" />
          <span className="text-[11px]">شروع تمرکز</span>
        </Link>
        <Link href="/reviews/daily" className="btn h-auto flex-col gap-1.5 !py-3">
          <NotebookPen className="size-5" />
          <span className="text-[11px]">مرور روزانه</span>
        </Link>
      </div>
      <Modal open={taskOpen} onClose={() => setTaskOpen(false)} title="وظیفهٔ جدید">
        <TaskForm goals={goals} onDone={() => setTaskOpen(false)} />
      </Modal>
    </>
  );
}

function priorityTone(p: string): "danger" | "warn" | undefined {
  return p === "high" ? "danger" : p === "medium" ? "warn" : undefined;
}

export function TodayTaskRow({
  task, showDone = true,
}: {
  task: { id: string; title: string; status: string; priority: string; plannedStart: string | null; plannedEnd: string | null; estimatedMinutes: number | null; category: string | null };
  showDone?: boolean;
}) {
  const { run, busy } = useRun();
  const done = task.status === "done";
  return (
    <div className="flex items-center gap-3 rounded-xl px-2 py-2 transition-colors" style={{ background: "transparent" }}>
      <button
        disabled={busy}
        onClick={() => void run(() => setTaskStatus(task.id, done ? "pending" : "done"))}
        className="grid size-6 shrink-0 place-items-center rounded-full border transition-all hover:scale-105"
        style={{
          borderColor: done ? "transparent" : "var(--border-strong)",
          background: done ? "var(--ok)" : "transparent",
          color: "white",
        }}
        aria-label={done ? "برگرداندن به حالت انجام‌نشده" : "علامت انجام شد"}
        aria-pressed={done}
      >
        {done && <Check className="size-3.5" />}
      </button>
      <Link href="/tasks" className="min-w-0 flex-1 truncate text-[13px] font-medium" style={{
        color: done ? "var(--fg-faint)" : "var(--fg)",
        textDecoration: done ? "line-through" : "none",
      }}>
        {task.title}
      </Link>
      <span className="hidden items-center gap-1.5 sm:flex">
        {task.plannedStart && (
          <span className="chip" dir="ltr">{task.plannedStart}{task.plannedEnd ? `–${task.plannedEnd}` : ""}</span>
        )}
        {!task.plannedStart && task.estimatedMinutes != null && (
          <span className="chip">{task.estimatedMinutes}د</span>
        )}
        {task.category && <span className="chip">{task.category}</span>}
        {showDone && task.priority !== "low" && (
          <span className="chip" style={
            task.priority === "high"
              ? { background: "var(--danger-soft)", color: "var(--danger)", borderColor: "transparent" }
              : { background: "var(--warn-soft)", color: "var(--warn)", borderColor: "transparent" }
          }>
            {priorityLabel(task.priority)}
          </span>
        )}
      </span>
    </div>
  );
}

export function TopTaskActions({ id }: { id: string }) {
  const { run, busy } = useRun();
  return (
    <div className="flex flex-wrap gap-2">
      <button className="btn btn-primary" disabled={busy} onClick={() => void run(() => setTaskStatus(id, "done"))}>
        <Check className="size-4" /> انجام شد
      </button>
      <Link href={`/focus?task=${id}`} className="btn btn-soft">
        <Play className="size-4" /> تمرکز روی همین
      </Link>
      <Link href="/tasks" className="btn btn-ghost">
        <ListTodo className="size-4" /> همهٔ وظایف
      </Link>
    </div>
  );
}
