"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { updateSuggestion } from "@/app/actions/reviews";
import type { Suggestion } from "@/db/schema";

export function SuggestionCard({ weekStart, s }: { weekStart: string; s: Suggestion }) {
  const [editing, setEditing] = useState(false);
  const [text, setText] = useState(s.text);
  const [pending, start] = useTransition();
  const router = useRouter();
  const save = (status: Suggestion["status"], newText = s.text) =>
    start(async () => {
      const r = await updateSuggestion(weekStart, { ...s, text: newText, status });
      if (!r.ok) alert(r.error);
      setEditing(false);
      router.refresh();
    });
  if (s.status === "dismissed") return null;
  return (
    <li className={`rounded-xl border p-3 ${s.status === "accepted" ? "border-accent-300 bg-accent-50/50 dark:border-accent-800 dark:bg-accent-900/20" : "border-zinc-200 dark:border-zinc-800"}`}>
      {editing ? (
        <div className="space-y-2">
          <label className="sr-only" htmlFor={`sg-${s.id}`}>متن پیشنهاد</label>
          <textarea id={`sg-${s.id}`} value={text} onChange={(e) => setText(e.target.value)} rows={2} maxLength={500} className="input" />
          <div className="flex gap-2">
            <button type="button" className="btn btn-primary btn-sm" disabled={pending} onClick={() => save("accepted", text)}>ذخیره و پذیرش</button>
            <button type="button" className="btn btn-ghost btn-sm" onClick={() => setEditing(false)}>انصراف</button>
          </div>
        </div>
      ) : (
        <>
          <p className="text-sm">{s.status === "accepted" && <span className="text-accent-700 dark:text-accent-300">✓ </span>}{s.text}</p>
          <p className="mt-1 text-xs muted">شواهد: {s.basis}</p>
          <div className="mt-2 flex flex-wrap gap-1.5">
            {s.status !== "accepted" && <button type="button" className="btn btn-sm" disabled={pending} onClick={() => save("accepted")}>می‌پذیرم</button>}
            <button type="button" className="btn btn-sm" disabled={pending} onClick={() => setEditing(true)}>ویرایش</button>
            <button type="button" className="btn btn-ghost btn-sm" disabled={pending} onClick={() => save("dismissed")}>رد کردن</button>
          </div>
        </>
      )}
    </li>
  );
}
