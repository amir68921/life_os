"use client";

import Link from "next/link";
import type { ReactNode } from "react";
import { addDays } from "@/lib/time";
import { DateInput } from "./forms";
import { usePrefs } from "./prefs";

/** Date-range filter that submits ISO dates via GET (works with the Jalali picker). */
export function DateRangeFilter({ from, to, basePath, extra }: { from: string; to: string; basePath: string; extra?: ReactNode }) {
  const { today } = usePrefs();
  const presets = [
    { label: "۷ روز", from: addDays(today, -6) },
    { label: "۳۰ روز", from: addDays(today, -29) },
    { label: "۹۰ روز", from: addDays(today, -89) },
  ];
  return (
    <form action={basePath} className="card grid items-end gap-3 sm:grid-cols-2 lg:grid-cols-5">
      <DateInput name="from" label="از تاریخ" defaultValue={from} required allowClear={false} />
      <DateInput name="to" label="تا تاریخ" defaultValue={to} required allowClear={false} />
      {extra}
      <div className="flex flex-wrap gap-1.5 lg:col-span-5">
        <button type="submit" className="btn btn-primary btn-sm">اعمال</button>
        {presets.map((p) => (
          <Link key={p.label} href={`${basePath}?from=${p.from}&to=${today}`} className="btn btn-sm">
            {p.label} اخیر
          </Link>
        ))}
      </div>
    </form>
  );
}
