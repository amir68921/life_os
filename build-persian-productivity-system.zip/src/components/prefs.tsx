"use client";

import { createContext, useContext, type ReactNode } from "react";
import type { DateMode } from "@/lib/format";

export type ClientPrefs = {
  tz: string;
  mode: DateMode;
  weekStart: number;
  today: string;
  focusMinutes: number;
  breakMinutes: number;
  notifyFocusEnd: boolean;
};

const Ctx = createContext<ClientPrefs>({
  tz: "Asia/Tehran",
  mode: "jalali",
  weekStart: 6,
  today: "1970-01-01",
  focusMinutes: 25,
  breakMinutes: 5,
  notifyFocusEnd: true,
});

export function PrefsProvider({ value, children }: { value: ClientPrefs; children: ReactNode }) {
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export const usePrefs = () => useContext(Ctx);
