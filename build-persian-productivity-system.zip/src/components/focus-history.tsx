"use client";

import { useState } from "react";
import { deleteFocusSession, saveFocusReview, type FocusSessionDTO } from "@/app/actions/focus";
import { fa, formatDateTime, formatMinutes } from "@/lib/format";
import { label, t } from "@/lib/i18n";
import type { LinkOptions } from "@/lib/queries";
import { ActionButton, ActionForm, Field, RatingInput, Select } from "./forms";
import { Modal } from "./modal";
import { usePrefs } from "./prefs";

export function FocusSessionRow({ s, links, interruptions }: { s: FocusSessionDTO; links: LinkOptions; interruptions: string[] }) {
  const { tz, mode } = usePrefs();
  const [open, setOpen] = useState(false);
  const mins = Math.round((s.elapsedSeconds ?? 0) / 60);
  return (
    <li className="flex flex-col gap-1 py-3 sm:flex-row sm:items-center sm:justify-between">
      <div className="min-w-0">
        <div className="text-sm font-medium">
          {s.objective || "جلسهٔ تمرکز"} {s.status === "cancelled" && <span className="chip">لغوشده</span>}
        </div>
        <div className="text-xs muted">
          {formatDateTime(s.startedAt, tz, mode)} · برنامه {fa(s.plannedMinutes)} دقیقه · اندازه‌گیری‌شده {formatMinutes(mins)}
          {s.focusedMinutes !== null ? ` · متمرکز (خوداظهاری) ${formatMinutes(s.focusedMinutes)}` : ""}
          {s.focusRating ? ` · تمرکز ${fa(s.focusRating)}/۵` : ""}
          {s.objectiveAchieved ? ` · هدف: ${label(t.achieved, s.objectiveAchieved)}` : ""}
        </div>
        {interruptions.length > 0 && <div className="mt-0.5 text-xs muted">وقفه‌ها: {interruptions.join("، ")}</div>}
        {s.nextStep && <div className="mt-0.5 text-xs muted">قدم بعدی: {s.nextStep}</div>}
      </div>
      <button type="button" className="btn btn-ghost btn-sm self-start" onClick={() => setOpen(true)}>
        بازبینی / اصلاح
      </button>
      <Modal open={open} onClose={() => setOpen(false)} title="بازبینی جلسهٔ تمرکز" wide>
        <ActionForm action={saveFocusReview} onSuccess={() => setOpen(false)}>
          <input type="hidden" name="id" value={s.id} />
          <input type="hidden" name="linksEdited" value="1" />
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="هدف جلسه" className="sm:col-span-2">
              <input name="objective" defaultValue={s.objective ?? ""} maxLength={500} className="input" />
            </Field>
            {s.status === "completed" && (
              <Field label="مدت واقعی (دقیقه)" hint="اگر تایمر را فراموش کردید متوقف کنید، اینجا اصلاح کنید">
                <input name="elapsedMinutes" type="number" min={0} max={1440} defaultValue={mins} className="input" />
              </Field>
            )}
            <Field label="دقایق واقعاً متمرکز (خوداظهاری)">
              <input name="focusedMinutes" type="number" min={0} max={1440} defaultValue={s.focusedMinutes ?? ""} className="input" />
            </Field>
            <Field label="به هدف رسیدید؟">
              <Select name="objectiveAchieved" options={[{ value: "yes", label: "بله" }, { value: "partly", label: "تا حدی" }, { value: "no", label: "خیر" }]} defaultValue={s.objectiveAchieved} empty="—" />
            </Field>
            <Field label="کار">
              <Select name="taskId" options={links.tasks.map((x) => ({ value: x.id, label: x.title }))} defaultValue={s.taskId} empty="بدون کار" />
            </Field>
            <Field label="پروژه">
              <Select name="projectId" options={links.projects.map((x) => ({ value: x.id, label: x.name }))} defaultValue={s.projectId} empty="بدون پروژه" />
            </Field>
            <Field label="هدف">
              <Select name="goalId" options={links.goals.map((x) => ({ value: x.id, label: x.title }))} defaultValue={s.goalId} empty="بدون هدف" />
            </Field>
            <RatingInput name="focusRating" label="میزان تمرکز" defaultValue={s.focusRating} />
            <RatingInput name="energyAfter" label="انرژی پس از جلسه" defaultValue={s.energyAfter} />
            <Field label="قدم بعدی" className="sm:col-span-2">
              <input name="nextStep" defaultValue={s.nextStep ?? ""} maxLength={500} className="input" />
            </Field>
            <Field label="بازتاب" className="sm:col-span-2">
              <textarea name="reflection" defaultValue={s.reflection ?? ""} rows={2} className="input" />
            </Field>
          </div>
        </ActionForm>
        <div className="mt-4 border-t border-zinc-200 pt-4 dark:border-zinc-800">
          <ActionButton run={() => deleteFocusSession(s.id)} confirm="این جلسه و فعالیت ثبت‌شدهٔ مرتبط با آن حذف شود؟" className="btn btn-danger btn-sm" onDone={() => setOpen(false)}>
            حذف جلسه
          </ActionButton>
        </div>
      </Modal>
    </li>
  );
}
