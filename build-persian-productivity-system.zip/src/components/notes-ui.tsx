"use client";

import { Fragment, useState, type ReactNode } from "react";
import { useRouter } from "next/navigation";
import { deleteNote, saveNote } from "@/app/actions/notes";
import { options, t } from "@/lib/i18n";
import type { LinkOptions } from "@/lib/queries";
import { ActionButton, ActionForm, Field, Select } from "./forms";

/** Minimal, safe Markdown renderer (no HTML injection): headings, lists, bold, italic, code, links. */
function inline(text: string, key: string): ReactNode[] {
  const out: ReactNode[] = [];
  const re = /(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`|\[[^\]]+\]\((https?:\/\/[^)\s]+)\))/g;
  let last = 0;
  let m: RegExpExecArray | null;
  let i = 0;
  while ((m = re.exec(text))) {
    if (m.index > last) out.push(text.slice(last, m.index));
    const tok = m[0];
    const k = `${key}-${i++}`;
    if (tok.startsWith("**")) out.push(<strong key={k}>{tok.slice(2, -2)}</strong>);
    else if (tok.startsWith("`")) out.push(<code key={k} className="rounded bg-zinc-100 px-1 text-[0.9em] dark:bg-zinc-800">{tok.slice(1, -1)}</code>);
    else if (tok.startsWith("[")) {
      const label = tok.slice(1, tok.indexOf("]"));
      out.push(<a key={k} href={m[2]} target="_blank" rel="noopener noreferrer nofollow" className="text-accent-700 underline dark:text-accent-300">{label}</a>);
    } else out.push(<em key={k}>{tok.slice(1, -1)}</em>);
    last = m.index + tok.length;
  }
  if (last < text.length) out.push(text.slice(last));
  return out;
}

export function Markdown({ source }: { source: string }) {
  const lines = source.split("\n");
  const blocks: ReactNode[] = [];
  let list: string[] = [];
  const flush = (k: string) => {
    if (list.length) {
      blocks.push(<ul key={"ul" + k} className="my-2 list-inside list-disc space-y-0.5">{list.map((l, i) => <li key={i}>{inline(l, k + i)}</li>)}</ul>);
      list = [];
    }
  };
  lines.forEach((line, idx) => {
    const k = String(idx);
    if (/^\s*[-*]\s+/.test(line)) {
      list.push(line.replace(/^\s*[-*]\s+/, ""));
      return;
    }
    flush(k);
    if (/^###\s/.test(line)) blocks.push(<h4 key={k} className="mt-3 font-semibold">{inline(line.slice(4), k)}</h4>);
    else if (/^##\s/.test(line)) blocks.push(<h3 key={k} className="mt-4 text-lg font-semibold">{inline(line.slice(3), k)}</h3>);
    else if (/^#\s/.test(line)) blocks.push(<h2 key={k} className="mt-4 text-xl font-bold">{inline(line.slice(2), k)}</h2>);
    else if (/^>\s?/.test(line)) blocks.push(<blockquote key={k} className="my-2 border-r-4 border-zinc-300 pr-3 muted dark:border-zinc-700">{inline(line.replace(/^>\s?/, ""), k)}</blockquote>);
    else if (line.trim() === "") blocks.push(<Fragment key={k}><div className="h-2" /></Fragment>);
    else blocks.push(<p key={k} className="leading-7">{inline(line, k)}</p>);
  });
  flush("end");
  return <div className="text-sm">{blocks}</div>;
}

export type NoteRow = {
  id: string;
  title: string;
  content: string;
  kind: string;
  tags: string[];
  projectId: string | null;
  goalId: string | null;
  taskId: string | null;
};

export function NoteEditor({ note, links }: { note?: NoteRow; links: LinkOptions }) {
  const [preview, setPreview] = useState(false);
  const [content, setContent] = useState(note?.content ?? "");
  const router = useRouter();
  return (
    <ActionForm
      key={note?.id ?? "new"}
      action={saveNote}
      onSuccess={(r) => {
        if (!note && r.ok && r.id) router.push(`/notes?id=${r.id}`);
      }}
      extraButtons={
        note ? (
          <ActionButton run={() => deleteNote(note.id)} confirm="این یادداشت حذف شود؟" className="btn btn-danger" onDone={() => router.push("/notes")}>
            حذف
          </ActionButton>
        ) : undefined
      }
    >
      {note && <input type="hidden" name="id" value={note.id} />}
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="عنوان *" className="sm:col-span-2">
          <input name="title" required maxLength={200} defaultValue={note?.title} className="input" />
        </Field>
        <Field label="نوع">
          <Select name="kind" options={options(t.noteKind)} defaultValue={note?.kind ?? "note"} />
        </Field>
        <Field label="برچسب‌ها" hint="با ویرگول جدا کنید">
          <input name="tags" defaultValue={(note?.tags ?? []).join("، ")} className="input" />
        </Field>
        <div className="sm:col-span-2">
          <div className="mb-1.5 flex items-center justify-between">
            <span className="label mb-0">متن (Markdown)</span>
            <button type="button" className="btn btn-ghost btn-sm" onClick={() => setPreview((p) => !p)} aria-pressed={preview}>
              {preview ? "ویرایش" : "پیش‌نمایش"}
            </button>
          </div>
          <textarea name="content" rows={14} value={content} onChange={(e) => setContent(e.target.value)} className={`input font-[inherit] leading-7 ${preview ? "hidden" : ""}`} aria-label="متن یادداشت" placeholder={"# عنوان\n- مورد اول\n**پررنگ** و *مورب*"} />
          {preview && <div className="min-h-40 rounded-xl border border-zinc-200 p-3 dark:border-zinc-800"><Markdown source={content || "—"} /></div>}
        </div>
        <Field label="پروژه">
          <Select name="projectId" options={links.projects.map((x) => ({ value: x.id, label: x.name }))} defaultValue={note?.projectId} empty="—" />
        </Field>
        <Field label="هدف">
          <Select name="goalId" options={links.goals.map((x) => ({ value: x.id, label: x.title }))} defaultValue={note?.goalId} empty="—" />
        </Field>
        <Field label="کار">
          <Select name="taskId" options={links.tasks.map((x) => ({ value: x.id, label: x.title }))} defaultValue={note?.taskId} empty="—" />
        </Field>
      </div>
    </ActionForm>
  );
}
