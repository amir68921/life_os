"use client";

import { useEffect, useId, useRef, useState, useTransition, type ReactNode } from "react";
import { useRouter } from "next/navigation";
import type { ActionResult } from "@/lib/server-utils";
import { fa, formatDateLong, formatDateShort } from "@/lib/format";
import { isoToJalali, jalaliMonthLength, jalaliToIso, JALALI_MONTHS, GREGORIAN_MONTHS_FA, WEEKDAYS_FA, WEEKDAYS_FA_SHORT } from "@/lib/jalali";
import { addDays, weekdayOf } from "@/lib/time";
import { usePrefs } from "./prefs";

/**
 * Form wrapper for server actions: pending state, inline validation errors,
 * and an explicit "save anyway" confirmation step when the server reports
 * conflicts (overlapping blocks / activities).
 */
export function ActionForm({
  action,
  children,
  submitLabel = "ذخیره",
  onSuccess,
  className = "",
  reset = false,
  extraButtons,
}: {
  action: (fd: FormData) => Promise<ActionResult>;
  children: ReactNode;
  submitLabel?: string;
  onSuccess?: (r: ActionResult) => void;
  className?: string;
  reset?: boolean;
  extraButtons?: ReactNode;
}) {
  const ref = useRef<HTMLFormElement>(null);
  const [pending, start] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const [conflicts, setConflicts] = useState<{ title: string; detail: string }[] | null>(null);
  const router = useRouter();

  const submit = (force: boolean) => {
    const form = ref.current;
    if (!form) return;
    const fd = new FormData(form);
    if (force) fd.set("force", "1");
    start(async () => {
      const r = await action(fd);
      if (r.ok) {
        setError(null);
        setConflicts(null);
        if (reset) form.reset();
        router.refresh();
        onSuccess?.(r);
      } else {
        setError(r.error);
        setConflicts(r.needsConfirm ? (r.conflicts ?? []) : null);
      }
    });
  };

  return (
    <form
      ref={ref}
      className={className}
      onSubmit={(e) => {
        e.preventDefault();
        submit(false);
      }}
      noValidate={false}
    >
      {children}
      {error && (
        <div role="alert" className="mt-4 rounded-xl border border-red-200 bg-red-50 px-3 py-2.5 text-sm text-red-800 dark:border-red-900 dark:bg-red-950/50 dark:text-red-200">
          {error}
          {conflicts && conflicts.length > 0 && (
            <ul className="mt-2 list-inside list-disc space-y-0.5 text-xs">
              {conflicts.map((c, i) => (
                <li key={i}>
                  {c.title} — {c.detail}
                </li>
              ))}
            </ul>
          )}
          {conflicts && (
            <button type="button" className="btn btn-sm mt-3" onClick={() => submit(true)} disabled={pending}>
              با وجود هم‌پوشانی ذخیره شود
            </button>
          )}
        </div>
      )}
      <div className="mt-5 flex flex-wrap items-center gap-2">
        <button type="submit" className="btn btn-primary" disabled={pending}>
          {pending ? "در حال ذخیره…" : submitLabel}
        </button>
        {extraButtons}
      </div>
    </form>
  );
}

export function Field({ label, children, hint, className = "" }: { label: string; children: ReactNode; hint?: string; className?: string }) {
  // Note: callers pass inputs with matching id via <Input id> or wrap; a <label> wrapper keeps association simple.
  return (
    <label className={`block ${className}`}>
      <span className="label">{label}</span>
      {children}
      {hint && <span className="hint block">{hint}</span>}
    </label>
  );
}

export function Select({
  name,
  options,
  defaultValue,
  empty,
  required,
  onChange,
  ariaLabel,
}: {
  name: string;
  options: { value: string; label: string }[];
  defaultValue?: string | null;
  empty?: string;
  required?: boolean;
  onChange?: (v: string) => void;
  ariaLabel?: string;
}) {
  return (
    <select
      name={name}
      defaultValue={defaultValue ?? ""}
      required={required}
      className="input"
      aria-label={ariaLabel}
      onChange={onChange ? (e) => onChange(e.target.value) : undefined}
    >
      {empty !== undefined && <option value="">{empty}</option>}
      {options.map((o) => (
        <option key={o.value} value={o.value}>
          {o.label}
        </option>
      ))}
    </select>
  );
}

export function WeekdayPicker({ name, defaultValue = [], legend }: { name: string; defaultValue?: number[]; legend: string }) {
  const { weekStart } = usePrefs();
  const order = Array.from({ length: 7 }, (_, i) => (weekStart + i) % 7);
  return (
    <fieldset>
      <legend className="label">{legend}</legend>
      <div className="flex flex-wrap gap-1.5">
        {order.map((d) => (
          <label key={d} className="cursor-pointer">
            <input type="checkbox" name={name} value={d} defaultChecked={defaultValue.includes(d)} className="peer sr-only" />
            <span className="inline-flex h-10 min-w-10 items-center justify-center rounded-xl border border-zinc-300 px-2 text-sm peer-checked:border-accent-600 peer-checked:bg-accent-600 peer-checked:text-white peer-focus-visible:ring-2 peer-focus-visible:ring-accent-500 dark:border-zinc-700">
              {WEEKDAYS_FA[d]}
            </span>
          </label>
        ))}
      </div>
    </fieldset>
  );
}

/**
 * Date input that displays & navigates in the user's calendar (Jalali by
 * default) while submitting an ISO (Gregorian) YYYY-MM-DD value.
 */
export function DateInput({
  name,
  defaultValue,
  required,
  label,
  onChange,
  allowClear = true,
}: {
  name: string;
  defaultValue?: string | null;
  required?: boolean;
  label: string;
  onChange?: (v: string) => void;
  allowClear?: boolean;
}) {
  const { mode, today, weekStart } = usePrefs();
  const [value, setValue] = useState<string>(defaultValue ?? "");
  const [open, setOpen] = useState(false);
  const [view, setView] = useState<string>(defaultValue || today);
  const id = useId();
  const wrap = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const close = (e: MouseEvent) => {
      if (wrap.current && !wrap.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", close);
    return () => document.removeEventListener("mousedown", close);
  }, [open]);

  const choose = (v: string) => {
    setValue(v);
    setOpen(false);
    onChange?.(v);
  };

  // Build month grid for the view month
  let title = "";
  let first = "";
  let length = 30;
  let prevMonth = "";
  let nextMonth = "";
  if (mode === "jalali") {
    const { jy, jm } = isoToJalali(view);
    title = `${JALALI_MONTHS[jm - 1]} ${fa(jy)}`;
    first = jalaliToIso(jy, jm, 1);
    length = jalaliMonthLength(jy, jm);
    prevMonth = jm === 1 ? jalaliToIso(jy - 1, 12, 1) : jalaliToIso(jy, jm - 1, 1);
    nextMonth = jm === 12 ? jalaliToIso(jy + 1, 1, 1) : jalaliToIso(jy, jm + 1, 1);
  } else {
    const [y, m] = view.split("-").map(Number);
    title = `${GREGORIAN_MONTHS_FA[m - 1]} ${fa(y)}`;
    first = `${y}-${String(m).padStart(2, "0")}-01`;
    length = new Date(Date.UTC(y, m, 0)).getUTCDate();
    prevMonth = m === 1 ? `${y - 1}-12-01` : `${y}-${String(m - 1).padStart(2, "0")}-01`;
    nextMonth = m === 12 ? `${y + 1}-01-01` : `${y}-${String(m + 1).padStart(2, "0")}-01`;
  }
  const lead = (weekdayOf(first) - weekStart + 7) % 7;
  const cells: (string | null)[] = [...Array(lead).fill(null), ...Array.from({ length }, (_, i) => addDays(first, i))];
  const order = Array.from({ length: 7 }, (_, i) => (weekStart + i) % 7);
  const dayNum = (iso: string) => (mode === "jalali" ? isoToJalali(iso).jd : Number(iso.slice(8)));

  return (
    <div ref={wrap} className="relative">
      <span className="label" id={id + "-l"}>
        {label}
        {required && <span className="text-red-600"> *</span>}
      </span>
      <input type="hidden" name={name} value={value} />
      <div className="flex gap-1.5">
        <button
          type="button"
          className="input text-start"
          aria-haspopup="dialog"
          aria-expanded={open}
          aria-labelledby={id + "-l"}
          onClick={() => {
            setView(value || today);
            setOpen((o) => !o);
          }}
        >
          {value ? formatDateLong(value, mode, true) : <span className="text-zinc-400">انتخاب تاریخ</span>}
        </button>
        {allowClear && value && !required && (
          <button type="button" className="icon-btn shrink-0" aria-label="پاک کردن تاریخ" onClick={() => choose("")}>
            ✕
          </button>
        )}
      </div>
      {required && <input tabIndex={-1} aria-hidden className="pointer-events-none absolute h-0 w-0 opacity-0" value={value} required onChange={() => {}} />}
      {open && (
        <div role="dialog" aria-label="انتخاب تاریخ" className="absolute z-50 mt-1 w-72 rounded-2xl border border-zinc-200 bg-white p-3 shadow-xl dark:border-zinc-700 dark:bg-zinc-900">
          <div className="mb-2 flex items-center justify-between">
            <button type="button" className="icon-btn" aria-label="ماه قبل" onClick={() => setView(prevMonth)}>
              ›
            </button>
            <span className="text-sm font-semibold">{title}</span>
            <button type="button" className="icon-btn" aria-label="ماه بعد" onClick={() => setView(nextMonth)}>
              ‹
            </button>
          </div>
          <div className="grid grid-cols-7 gap-0.5 text-center text-xs muted">
            {order.map((d) => (
              <div key={d} className="py-1" aria-hidden>
                {WEEKDAYS_FA_SHORT[d]}
              </div>
            ))}
          </div>
          <div className="grid grid-cols-7 gap-0.5">
            {cells.map((c, i) =>
              c ? (
                <button
                  key={c}
                  type="button"
                  onClick={() => choose(c)}
                  aria-label={formatDateLong(c, mode, true)}
                  aria-pressed={c === value}
                  className={`h-9 rounded-lg text-sm tabular-nums hover:bg-zinc-100 dark:hover:bg-zinc-800 ${c === value ? "bg-accent-600 text-white hover:bg-accent-600" : ""} ${c === today && c !== value ? "ring-1 ring-accent-500" : ""}`}
                >
                  {fa(dayNum(c))}
                </button>
              ) : (
                <span key={"e" + i} />
              ),
            )}
          </div>
          <div className="mt-2 flex justify-between text-xs">
            <button type="button" className="btn btn-ghost btn-sm" onClick={() => choose(today)}>
              امروز
            </button>
            <button type="button" className="btn btn-ghost btn-sm" onClick={() => choose(addDays(today, 1))}>
              فردا
            </button>
            <span className="self-center muted">{value ? formatDateShort(value, mode === "jalali" ? "gregorian" : "jalali") : ""}</span>
          </div>
        </div>
      )}
    </div>
  );
}

/** Button that runs a server action, optionally after confirmation. */
export function ActionButton({
  run,
  children,
  confirm,
  className = "btn btn-sm",
  ariaLabel,
  onDone,
}: {
  run: () => Promise<ActionResult>;
  children: ReactNode;
  confirm?: string;
  className?: string;
  ariaLabel?: string;
  onDone?: () => void;
}) {
  const [pending, start] = useTransition();
  const router = useRouter();
  return (
    <button
      type="button"
      className={className}
      aria-label={ariaLabel}
      disabled={pending}
      onClick={() => {
        if (confirm && !window.confirm(confirm)) return;
        start(async () => {
          const r = await run();
          if (!r.ok) window.alert(r.error);
          else {
            router.refresh();
            onDone?.();
          }
        });
      }}
    >
      {pending ? "…" : children}
    </button>
  );
}

export function RatingInput({ name, label, defaultValue }: { name: string; label: string; defaultValue?: number | null }) {
  return (
    <fieldset>
      <legend className="label">{label}</legend>
      <div className="flex gap-1.5">
        {[1, 2, 3, 4, 5].map((n) => (
          <label key={n} className="cursor-pointer">
            <input type="radio" name={name} value={n} defaultChecked={defaultValue === n} className="peer sr-only" />
            <span className="inline-flex h-10 w-10 items-center justify-center rounded-xl border border-zinc-300 text-sm peer-checked:border-accent-600 peer-checked:bg-accent-600 peer-checked:text-white peer-focus-visible:ring-2 peer-focus-visible:ring-accent-500 dark:border-zinc-700">
              {fa(n)}
            </span>
          </label>
        ))}
      </div>
    </fieldset>
  );
}
