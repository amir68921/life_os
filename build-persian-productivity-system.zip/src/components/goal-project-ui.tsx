"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { addMilestone, archiveGoal, deleteGoal, deleteMilestone, saveGoal, setGoalProgress, toggleMilestone } from "@/app/actions/goals";
import { deleteProject, saveProject } from "@/app/actions/projects";
import type { goals, projects } from "@/db/schema";
import { fa, formatDateShort } from "@/lib/format";
import { options, t } from "@/lib/i18n";
import { ActionButton, ActionForm, DateInput, Field, Select } from "./forms";
import { Modal } from "./modal";
import { usePrefs } from "./prefs";

type Goal = typeof goals.$inferSelect;
type Project = typeof projects.$inferSelect;

export function GoalForm({ goal, parents, onDone, defaultParent }: { goal?: Goal; parents: { id: string; title: string }[]; onDone?: () => void; defaultParent?: string }) {
  return (
    <ActionForm action={saveGoal} onSuccess={onDone}>
      {goal && <input type="hidden" name="id" value={goal.id} />}
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="عنوان *" className="sm:col-span-2">
          <input name="title" required maxLength={200} defaultValue={goal?.title} className="input" autoFocus />
        </Field>
        <Field label="افق زمانی">
          <Select name="horizon" options={options(t.horizon)} defaultValue={goal?.horizon ?? "medium"} />
        </Field>
        <Field label="دسته‌بندی">
          <input name="category" maxLength={60} defaultValue={goal?.category ?? ""} className="input" placeholder="مثلاً شغلی، سلامت، یادگیری" />
        </Field>
        <DateInput name="startDate" label="تاریخ شروع" defaultValue={goal?.startDate ?? null} />
        <DateInput name="targetDate" label="تاریخ هدف" defaultValue={goal?.targetDate ?? null} />
        <Field label="اولویت">
          <Select name="priority" options={options(t.priority)} defaultValue={goal?.priority ?? "medium"} />
        </Field>
        <Field label="وضعیت">
          <Select name="status" options={options(t.goalStatus)} defaultValue={goal?.status ?? "active"} />
        </Field>
        <Field label="پیشرفت (٪)">
          <input name="progress" type="number" min={0} max={100} defaultValue={goal?.progress ?? 0} className="input" />
        </Field>
        <Field label="هدف والد" hint="برای ساختار سلسله‌مراتبی">
          <Select name="parentId" options={parents.filter((p) => p.id !== goal?.id).map((p) => ({ value: p.id, label: p.title }))} defaultValue={goal?.parentId ?? defaultParent ?? ""} empty="بدون والد" />
        </Field>
        <Field label="توضیحات" className="sm:col-span-2">
          <textarea name="description" rows={2} defaultValue={goal?.description ?? ""} className="input" />
        </Field>
        <Field label="معیار موفقیت" className="sm:col-span-2" hint="چه زمانی این هدف محقق‌شده محسوب می‌شود؟">
          <textarea name="successCriteria" rows={2} defaultValue={goal?.successCriteria ?? ""} className="input" />
        </Field>
        <Field label="یادداشت" className="sm:col-span-2">
          <textarea name="notes" rows={2} defaultValue={goal?.notes ?? ""} className="input" />
        </Field>
      </div>
    </ActionForm>
  );
}

export function NewGoalButton({ parents, defaultParent, label = "هدف جدید", className = "btn btn-primary" }: { parents: { id: string; title: string }[]; defaultParent?: string; label?: string; className?: string }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button type="button" className={className} onClick={() => setOpen(true)}>
        + {label}
      </button>
      <Modal open={open} onClose={() => setOpen(false)} title={label} wide>
        <GoalForm parents={parents} defaultParent={defaultParent} onDone={() => setOpen(false)} />
      </Modal>
    </>
  );
}

export function GoalAdmin({ goal, parents }: { goal: Goal; parents: { id: string; title: string }[] }) {
  const [open, setOpen] = useState(false);
  const router = useRouter();
  return (
    <div className="flex flex-wrap gap-2">
      <button type="button" className="btn btn-sm" onClick={() => setOpen(true)}>
        ویرایش
      </button>
      <ActionButton run={() => archiveGoal(goal.id, goal.status !== "archived")}>{goal.status === "archived" ? "خروج از بایگانی" : "بایگانی"}</ActionButton>
      <ActionButton
        run={() => deleteGoal(goal.id)}
        className="btn btn-danger btn-sm"
        confirm="هدف، نقاط عطف و سابقهٔ پیشرفت آن حذف می‌شود. کارها، جلسات تمرکز، فعالیت‌ها و یادداشت‌های مرتبط حفظ می‌شوند و فقط پیوندشان برداشته می‌شود. ادامه می‌دهید؟"
        onDone={() => router.push("/goals")}
      >
        حذف
      </ActionButton>
      <Modal open={open} onClose={() => setOpen(false)} title="ویرایش هدف" wide>
        <GoalForm goal={goal} parents={parents} onDone={() => setOpen(false)} />
      </Modal>
    </div>
  );
}

export function ProgressSetter({ id, value, suggested }: { id: string; value: number; suggested?: number | null }) {
  const [v, setV] = useState(value);
  const [pending, start] = useTransition();
  const router = useRouter();
  const save = (p: number) =>
    start(async () => {
      const r = await setGoalProgress(id, p);
      if (!r.ok) alert(r.error);
      router.refresh();
    });
  return (
    <div>
      <label className="label" htmlFor={`prog-${id}`}>
        پیشرفت: {fa(v)}٪
      </label>
      <div className="flex items-center gap-3">
        <input id={`prog-${id}`} type="range" min={0} max={100} step={5} value={v} onChange={(e) => setV(Number(e.target.value))} className="w-full accent-[var(--color-accent-600)]" />
        <button type="button" className="btn btn-sm" disabled={pending || v === value} onClick={() => save(v)}>
          ثبت
        </button>
      </div>
      {suggested !== null && suggested !== undefined && suggested !== value && (
        <p className="hint">
          بر اساس نقاط عطف و کارهای انجام‌شده، پیشرفت تخمینی {fa(suggested)}٪ است.{" "}
          <button type="button" className="underline" onClick={() => { setV(suggested); save(suggested); }}>
            اعمال
          </button>
        </p>
      )}
    </div>
  );
}

export function Milestones({ items, goalId, projectId }: { items: { id: string; title: string; dueDate: string | null; completedAt: Date | null }[]; goalId?: string; projectId?: string }) {
  const { mode, today } = usePrefs();
  const [pending, start] = useTransition();
  const router = useRouter();
  return (
    <div>
      {items.length === 0 && <p className="mb-3 text-sm muted">هنوز نقطهٔ عطفی تعریف نشده است.</p>}
      <ul className="mb-3 space-y-1">
        {items.map((m) => (
          <li key={m.id} className="flex items-center gap-3 rounded-lg px-1 py-1.5">
            <input
              type="checkbox"
              checked={!!m.completedAt}
              disabled={pending}
              aria-label={`تکمیل ${m.title}`}
              onChange={() => start(async () => { await toggleMilestone(m.id); router.refresh(); })}
              className="h-5 w-5 accent-[var(--color-accent-600)]"
            />
            <span className={`flex-1 text-sm ${m.completedAt ? "text-zinc-400 line-through" : ""}`}>{m.title}</span>
            {m.dueDate && <span className={`text-xs ${!m.completedAt && m.dueDate < today ? "text-red-600" : "muted"}`}>{formatDateShort(m.dueDate, mode)}</span>}
            <ActionButton run={() => deleteMilestone(m.id)} className="icon-btn" ariaLabel={`حذف ${m.title}`} confirm="این نقطهٔ عطف حذف شود؟">
              ✕
            </ActionButton>
          </li>
        ))}
      </ul>
      <ActionForm action={addMilestone} reset submitLabel="افزودن نقطهٔ عطف">
        {goalId && <input type="hidden" name="goalId" value={goalId} />}
        {projectId && <input type="hidden" name="projectId" value={projectId} />}
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="عنوان نقطهٔ عطف">
            <input name="title" required maxLength={200} className="input" />
          </Field>
          <DateInput name="dueDate" label="سررسید" />
        </div>
      </ActionForm>
    </div>
  );
}

export function ProjectForm({ project, goalOptions, linkedGoalIds = [], onDone }: { project?: Project; goalOptions: { id: string; title: string }[]; linkedGoalIds?: string[]; onDone?: () => void }) {
  return (
    <ActionForm action={saveProject} onSuccess={onDone}>
      {project && <input type="hidden" name="id" value={project.id} />}
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="نام پروژه *" className="sm:col-span-2">
          <input name="name" required maxLength={200} defaultValue={project?.name} className="input" autoFocus />
        </Field>
        <Field label="هدف پروژه (Objective)" className="sm:col-span-2">
          <input name="objective" maxLength={2000} defaultValue={project?.objective ?? ""} className="input" />
        </Field>
        <DateInput name="startDate" label="تاریخ شروع" defaultValue={project?.startDate ?? null} />
        <DateInput name="targetDate" label="تاریخ هدف" defaultValue={project?.targetDate ?? null} />
        <Field label="اولویت">
          <Select name="priority" options={options(t.priority)} defaultValue={project?.priority ?? "medium"} />
        </Field>
        <Field label="وضعیت">
          <Select name="status" options={options(t.projectStatus)} defaultValue={project?.status ?? "planned"} />
        </Field>
        <Field label="پیشرفت (٪)">
          <input name="progress" type="number" min={0} max={100} defaultValue={project?.progress ?? 0} className="input" />
        </Field>
        {goalOptions.length > 0 && (
          <fieldset className="sm:col-span-2">
            <legend className="label">اهداف مرتبط</legend>
            <div className="flex flex-wrap gap-2">
              {goalOptions.map((g) => (
                <label key={g.id} className="chip cursor-pointer py-1.5">
                  <input type="checkbox" name="goalIds" value={g.id} defaultChecked={linkedGoalIds.includes(g.id)} className="accent-[var(--color-accent-600)]" />
                  {g.title}
                </label>
              ))}
            </div>
          </fieldset>
        )}
        <Field label="توضیحات" className="sm:col-span-2">
          <textarea name="description" rows={2} defaultValue={project?.description ?? ""} className="input" />
        </Field>
        <Field label="یادداشت" className="sm:col-span-2">
          <textarea name="notes" rows={2} defaultValue={project?.notes ?? ""} className="input" />
        </Field>
      </div>
    </ActionForm>
  );
}

export function NewProjectButton({ goalOptions }: { goalOptions: { id: string; title: string }[] }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button type="button" className="btn btn-primary" onClick={() => setOpen(true)}>
        + پروژهٔ جدید
      </button>
      <Modal open={open} onClose={() => setOpen(false)} title="پروژهٔ جدید" wide>
        <ProjectForm goalOptions={goalOptions} onDone={() => setOpen(false)} />
      </Modal>
    </>
  );
}

export function ProjectAdmin({ project, goalOptions, linkedGoalIds }: { project: Project; goalOptions: { id: string; title: string }[]; linkedGoalIds: string[] }) {
  const [open, setOpen] = useState(false);
  const router = useRouter();
  return (
    <div className="flex flex-wrap gap-2">
      <button type="button" className="btn btn-sm" onClick={() => setOpen(true)}>
        ویرایش
      </button>
      <ActionButton
        run={() => deleteProject(project.id)}
        className="btn btn-danger btn-sm"
        confirm="پروژه و نقاط عطف آن حذف می‌شود. کارها، جلسات و فعالیت‌های مرتبط حفظ می‌شوند. ادامه می‌دهید؟"
        onDone={() => router.push("/projects")}
      >
        حذف
      </ActionButton>
      <Modal open={open} onClose={() => setOpen(false)} title="ویرایش پروژه" wide>
        <ProjectForm project={project} goalOptions={goalOptions} linkedGoalIds={linkedGoalIds} onDone={() => setOpen(false)} />
      </Modal>
    </div>
  );
}
