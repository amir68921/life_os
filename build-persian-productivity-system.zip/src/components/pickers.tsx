"use client";

import React, { useEffect, useMemo, useRef, useState } from "react";
import { Calendar, ChevronLeft, ChevronRight, X } from "lucide-react";
import {
  FA_MONTHS, FA_WEEKDAYS_SHORT, faDigits, faDateMed, jalaliMonthGrid, jalaliOfIso,
  isoOfJalali, todayIso,
} from "@/lib/jalali";

export function JalaliDatePicker({
  value, onChange, placeholder = "انتخاب تاریخ", clearable = true, compact = false,
}: {
  value: string | null;
  onChange: (iso: string | null) => void;
  placeholder?: string;
  clearable?: boolean;
  compact?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const initial = value ? jalaliOfIso(value) : jalaliOfIso(todayIso("Asia/Tehran"));
  const [view, setView] = useState({ jy: initial.jy, jm: initial.jm });
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onDoc = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, [open]);

  useEffect(() => {
    if (value) {
      const j = jalaliOfIso(value);
      setView({ jy: j.jy, jm: j.jm });
    }
  }, [value]);

  const grid = useMemo(() => jalaliMonthGrid(view.jy, view.jm), [view]);
  const todayJ = jalaliOfIso(todayIso("Asia/Tehran"));

  const nav = (dir: 1 | -1) => {
    setView((v) => {
      let jm = v.jm + dir, jy = v.jy;
      if (jm > 12) { jm = 1; jy++; }
      if (jm < 1) { jm = 12; jy--; }
      return { jy, jm };
    });
  };

  return (
    <div className="relative" ref={ref}>
      <button
        type="button"
        className={`input flex items-center justify-between gap-2 text-start ${compact ? "!min-h-9 !py-1 !text-xs" : ""}`}
        onClick={() => setOpen((o) => !o)}
        aria-haspopup="dialog"
        aria-expanded={open}
      >
        <span className="flex min-w-0 items-center gap-2">
          <Calendar className="size-4 shrink-0" style={{ color: "var(--fg-faint)" }} />
          <span className="truncate" style={{ color: value ? "var(--fg)" : "var(--fg-faint)" }}>
            {value ? faDateMed(value) : placeholder}
          </span>
        </span>
        {clearable && value && (
          <span
            role="button"
            aria-label="پاک کردن تاریخ"
            className="rounded-full p-0.5 hover:opacity-70"
            onClick={(e) => { e.stopPropagation(); onChange(null); }}
          >
            <X className="size-3.5" style={{ color: "var(--fg-faint)" }} />
          </span>
        )}
      </button>

      {open && (
        <div
          className="animate-scale absolute z-50 mt-2 w-72 rounded-2xl border p-3"
          role="dialog"
          aria-label="تقویم جلالی"
          style={{ background: "var(--card)", borderColor: "var(--border)", boxShadow: "var(--shadow)" }}
        >
          <div className="mb-2 flex items-center justify-between">
            <button type="button" className="btn btn-ghost !min-h-0 !p-1.5" onClick={() => nav(1)} aria-label="ماه بعد">
              <ChevronRight className="size-4" />
            </button>
            <span className="text-sm font-bold">
              {FA_MONTHS[view.jm - 1]} {faDigits(view.jy)}
            </span>
            <button type="button" className="btn btn-ghost !min-h-0 !p-1.5" onClick={() => nav(-1)} aria-label="ماه قبل">
              <ChevronLeft className="size-4" />
            </button>
          </div>
          <div className="grid grid-cols-7 gap-0.5 text-center">
            {FA_WEEKDAYS_SHORT.map((w, i) => (
              <span key={i} className="py-1 text-[10px] font-medium" style={{ color: "var(--fg-faint)" }}>{w}</span>
            ))}
            {grid.flat().map((iso, i) => {
              if (!iso) return <span key={i} />;
              const j = jalaliOfIso(iso);
              const isToday = j.jy === todayJ.jy && j.jm === todayJ.jm && j.jd === todayJ.jd;
              const selected = iso === value;
              return (
                <button
                  key={i}
                  type="button"
                  onClick={() => { onChange(iso); setOpen(false); }}
                  className="aspect-square rounded-lg text-xs transition-colors"
                  style={{
                    background: selected ? "var(--accent)" : "transparent",
                    color: selected ? "var(--accent-fg)" : isToday ? "var(--accent)" : "var(--fg)",
                    fontWeight: selected || isToday ? 700 : 400,
                  }}
                  aria-pressed={selected}
                >
                  {faDigits(j.jd)}
                </button>
              );
            })}
          </div>
          <button
            type="button"
            className="btn btn-soft mt-2 w-full !min-h-8 !py-1 !text-xs"
            onClick={() => { onChange(todayIso("Asia/Tehran")); setOpen(false); }}
          >
            امروز
          </button>
        </div>
      )}
    </div>
  );
}

export function TimeField({
  value, onChange, placeholder,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
}) {
  return (
    <input
      type="time"
      dir="ltr"
      className="input text-center"
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      aria-label={placeholder ?? "ساعت"}
    />
  );
}

export function Segmented<T extends string>({
  options, value, onChange, size = "md",
}: {
  options: { value: T; label: string }[];
  value: T;
  onChange: (v: T) => void;
  size?: "sm" | "md";
}) {
  return (
    <div
      className="inline-flex flex-wrap items-center gap-1 rounded-xl border p-1"
      style={{ borderColor: "var(--border)", background: "var(--card-soft)" }}
      role="tablist"
    >
      {options.map((o) => (
        <button
          key={o.value}
          type="button"
          role="tab"
          aria-selected={value === o.value}
          onClick={() => onChange(o.value)}
          className={`rounded-lg font-medium transition-all ${size === "sm" ? "px-2.5 py-1 text-[11px]" : "px-3 py-1.5 text-xs"}`}
          style={{
            background: value === o.value ? "var(--card)" : "transparent",
            color: value === o.value ? "var(--fg)" : "var(--fg-muted)",
            boxShadow: value === o.value ? "var(--shadow)" : "none",
            border: value === o.value ? "1px solid var(--border)" : "1px solid transparent",
          }}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}
