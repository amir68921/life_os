"use client";

import Link from "next/link";
import { useActionState, useEffect, useState } from "react";
import { loginAction, registerAction } from "@/app/actions/auth";

export function AuthForm({ mode }: { mode: "login" | "register" }) {
  const [state, action, pending] = useActionState(mode === "login" ? loginAction : registerAction, undefined);
  const [tz, setTz] = useState("Asia/Tehran");
  useEffect(() => {
    try {
      setTz(Intl.DateTimeFormat().resolvedOptions().timeZone || "Asia/Tehran");
    } catch {}
  }, []);
  return (
    <div className="flex min-h-screen items-center justify-center px-4 py-10">
      <div className="w-full max-w-sm">
        <div className="mb-8 text-center">
          <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-2xl bg-accent-600 text-lg font-bold text-white">L</div>
          <h1 className="text-2xl font-bold">LIFE OS</h1>
          <p className="mt-1 text-sm muted">سیستم شخصی مدیریت زندگی و بهره‌وری</p>
        </div>
        <form action={action} className="card space-y-4">
          <h2 className="text-lg font-semibold">{mode === "login" ? "ورود به حساب" : "ساخت حساب جدید"}</h2>
          {mode === "register" && (
            <label className="block">
              <span className="label">نام</span>
              <input name="name" required maxLength={80} autoComplete="name" className="input" />
            </label>
          )}
          <label className="block">
            <span className="label">ایمیل</span>
            <input name="email" type="email" required autoComplete="email" className="input" />
          </label>
          <label className="block">
            <span className="label">رمز عبور</span>
            <input
              name="password"
              type="password"
              required
              minLength={mode === "register" ? 8 : 1}
              autoComplete={mode === "login" ? "current-password" : "new-password"}
              className="input"
            />
            {mode === "register" && <span className="hint block">حداقل ۸ نویسه</span>}
          </label>
          <input type="hidden" name="timezone" value={tz} />
          {state?.error && (
            <p role="alert" className="rounded-xl bg-red-50 px-3 py-2 text-sm text-red-800 dark:bg-red-950/50 dark:text-red-200">
              {state.error}
            </p>
          )}
          <button type="submit" className="btn btn-primary w-full" disabled={pending}>
            {pending ? "لطفاً صبر کنید…" : mode === "login" ? "ورود" : "ساخت حساب"}
          </button>
          <p className="text-center text-sm muted">
            {mode === "login" ? (
              <>
                حساب ندارید؟{" "}
                <Link href="/register" className="font-medium text-accent-700 underline-offset-4 hover:underline dark:text-accent-300">
                  ثبت‌نام
                </Link>
              </>
            ) : (
              <>
                حساب دارید؟{" "}
                <Link href="/login" className="font-medium text-accent-700 underline-offset-4 hover:underline dark:text-accent-300">
                  ورود
                </Link>
              </>
            )}
          </p>
        </form>
        <p className="mt-4 text-center text-xs muted">داده‌های شما فقط برای حساب خودتان قابل دسترسی است.</p>
      </div>
    </div>
  );
}
