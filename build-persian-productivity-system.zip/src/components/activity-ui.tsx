"use client";

import { useState } from "react";
import { deleteActivity, saveActivity, trimActivity } from "@/app/actions/activities";
import { formatMinutes, formatTime } from "@/lib/format";
import { label, options, t } from "@/lib/i18n";
import type { LinkOptions } from "@/lib/queries";
import { localDate, localTime } from "@/lib/time";
import { ActionButton, ActionForm, DateInput, Field, Select } from "./forms";
import { Modal } from "./modal";
import { usePrefs } from "./prefs";

export type ActivityRow = {
  id: string;
  title: string;
  category: string;
  startAt: Date;
  endAt: Date;
  taskId: string | null;
  projectId: string | null;
  goalId: string | null;
  notes: string | null;
  source: string;
};

function ActivityForm({ a, links, onDone, date }: { a?: ActivityRow; links: LinkOptions; onDone: () => void; date?: string }) {
  const { tz, today } = usePrefs();
  return (
    <ActionForm action={saveActivity} onSuccess={onDone}>
      {a && <input type="hidden" name="id" value={a.id} />}
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="عنوان *" className="sm:col-span-2">
          <input name="title" required maxLength={200} defaultValue={a?.title} className="input" autoFocus />
        </Field>
        <Field label="دسته‌بندی">
          <Select name="category" options={options(t.activityCategory)} defaultValue={a?.category ?? "work"} />
        </Field>
        <DateInput name="date" label="تاریخ شروع" required allowClear={false} defaultValue={a ? localDate(a.startAt, tz) : (date ?? today)} />
        <Field label="ساعت شروع *">
          <input name="start" type="time" required defaultValue={a ? localTime(a.startAt, tz) : ""} className="input" />
        </Field>
        <Field label="ساعت پایان" hint="اگر کمتر از شروع باشد، روز بعد حساب می‌شود">
          <input name="end" type="time" defaultValue={a ? localTime(a.endAt, tz) : ""} className="input" />
        </Field>
        <Field label="یا مدت (دقیقه)">
          <input name="duration" type="number" min={1} max={1440} className="input" />
        </Field>
        <Field label="کار مرتبط">
          <Select name="taskId" options={links.tasks.map((x) => ({ value: x.id, label: x.title }))} defaultValue={a?.taskId} empty="—" />
        </Field>
        <Field label="پروژهٔ مرتبط">
          <Select name="projectId" options={links.projects.map((x) => ({ value: x.id, label: x.name }))} defaultValue={a?.projectId} empty="—" />
        </Field>
        <Field label="هدف مرتبط">
          <Select name="goalId" options={links.goals.map((x) => ({ value: x.id, label: x.title }))} defaultValue={a?.goalId} empty="—" />
        </Field>
        <Field label="یادداشت" className="sm:col-span-2">
          <textarea name="notes" rows={2} defaultValue={a?.notes ?? ""} className="input" />
        </Field>
      </div>
    </ActionForm>
  );
}

export function NewActivityButton({ links, defaultOpen = false, date }: { links: LinkOptions; defaultOpen?: boolean; date?: string }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <>
      <button type="button" className="btn btn-primary" onClick={() => setOpen(true)}>
        + ثبت فعالیت
      </button>
      <Modal open={open} onClose={() => setOpen(false)} title="ثبت فعالیت" wide>
        <ActivityForm links={links} onDone={() => setOpen(false)} date={date} />
      </Modal>
    </>
  );
}

export function ActivityItem({ a, links, overlapWith }: { a: ActivityRow; links: LinkOptions; overlapWith: ActivityRow[] }) {
  const { tz } = usePrefs();
  const [open, setOpen] = useState(false);
  const mins = (a.endAt.getTime() - a.startAt.getTime()) / 60000;
  return (
    <li className="py-3">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-sm font-medium">{a.title}</span>
            <span className="chip">{label(t.activityCategory, a.category)}</span>
            {a.source !== "manual" && <span className="chip">{label(t.activitySource, a.source)}</span>}
          </div>
          <div className="text-xs tabular-nums muted">
            {formatTime(a.startAt, tz)}–{formatTime(a.endAt, tz)} · {formatMinutes(mins)}
          </div>
          {a.notes && <div className="text-xs muted">{a.notes}</div>}
        </div>
        <button type="button" className="btn btn-ghost btn-sm" onClick={() => setOpen(true)}>
          ویرایش
        </button>
      </div>
      {overlapWith.length > 0 && (
        <div className="mt-2 rounded-xl bg-amber-50 px-3 py-2 text-xs text-amber-900 dark:bg-amber-900/30 dark:text-amber-100">
          ⚠ هم‌پوشانی با: {overlapWith.map((o) => `«${o.title}» (${formatTime(o.startAt, tz)}–${formatTime(o.endAt, tz)})`).join("، ")}
          <div className="mt-1.5 flex flex-wrap gap-1.5">
            {overlapWith
              .filter((o) => o.startAt > a.startAt && o.startAt < a.endAt)
              .map((o) => (
                <ActionButton key={o.id} run={() => trimActivity(a.id, o.startAt.toISOString())} className="btn btn-sm">
                  پایان این فعالیت هنگام شروع «{o.title}»
                </ActionButton>
              ))}
            <span className="self-center">یا یکی را ویرایش/حذف کنید. هم‌پوشانی می‌تواند عمدی هم باشد.</span>
          </div>
        </div>
      )}
      <Modal open={open} onClose={() => setOpen(false)} title="ویرایش فعالیت" wide>
        <ActivityForm a={a} links={links} onDone={() => setOpen(false)} />
        <div className="mt-4 border-t border-zinc-200 pt-4 dark:border-zinc-800">
          <ActionButton run={() => deleteActivity(a.id)} confirm="این فعالیت حذف شود؟" className="btn btn-danger btn-sm" onDone={() => setOpen(false)}>
            حذف
          </ActionButton>
        </div>
      </Modal>
    </li>
  );
}
