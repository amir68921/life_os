"use client";

import React, { useMemo, useState } from "react";
import {
  Plus, Pencil, Trash2, Archive, Play, Pause, Flag, ChevronDown, ChevronUp, Check, Target,
} from "lucide-react";
import { Modal, Confirm, EmptyState, Field, ProgressBar, Spinner, useRun, useToast, Chip } from "@/components/ui";
import { JalaliDatePicker, Segmented } from "@/components/pickers";
import {
  createGoal, updateGoal, setGoalStatus, setGoalProgress, deleteGoal,
  addMilestone, toggleMilestone, deleteMilestone,
} from "@/lib/actions-core";
import {
  PRIORITIES, priorityLabel, TIMEFRAMES, timeframeLabel, GOAL_STATUSES, goalStatusLabel, GOAL_CATEGORIES,
} from "@/lib/utils";
import { faDigits, faDateMed, faRelativeDay } from "@/lib/jalali";

export type GoalRow = {
  id: string; parentId: string | null; title: string; description: string | null;
  category: string | null; timeframe: string; priority: string; status: string;
  startDate: string | null; targetDate: string | null; successCriteria: string | null;
  progress: number; notes: string | null; taskCount: number;
};

export type MilestoneRow = { id: string; goalId: string; title: string; dueDate: string | null; done: boolean };

const STATUS_TONE: Record<string, "accent" | "warn" | "ok" | undefined> = {
  active: "accent", paused: "warn", completed: "ok",
};

export function GoalsClient({
  goals, milestonesByGoal, today,
}: {
  goals: GoalRow[];
  milestonesByGoal: Record<string, MilestoneRow[]>;
  today: string;
}) {
  const toast = useToast();
  const { run } = useRun();
  const [statusF, setStatusF] = useState("all");
  const [prioF, setPrioF] = useState("all");
  const [timeF, setTimeF] = useState("all");
  const [editing, setEditing] = useState<GoalRow | null>(null);
  const [creating, setCreating] = useState(false);
  const [deleting, setDeleting] = useState<GoalRow | null>(null);
  const [detail, setDetail] = useState<GoalRow | null>(null);

  const filtered = useMemo(() => goals.filter((g) => {
    if (statusF !== "all" && g.status !== statusF) return false;
    if (prioF !== "all" && g.priority !== prioF) return false;
    if (timeF !== "all" && g.timeframe !== timeF) return false;
    return true;
  }), [goals, statusF, prioF, timeF]);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <button className="btn btn-primary" onClick={() => setCreating(true)}>
          <Plus className="size-4" /> هدف جدید
        </button>
        <Segmented options={[{ value: "all", label: "همهٔ وضعیت‌ها" }, ...GOAL_STATUSES.map((s) => ({ value: s.value, label: s.label }))]} value={statusF} onChange={setStatusF} size="sm" />
        <Segmented options={[{ value: "all", label: "همهٔ اولویت‌ها" }, ...PRIORITIES.map((p) => ({ value: p.value, label: p.label }))]} value={prioF} onChange={setPrioF} size="sm" />
        <Segmented options={[{ value: "all", label: "همهٔ بازه‌ها" }, ...TIMEFRAMES.map((t) => ({ value: t.value, label: t.label }))]} value={timeF} onChange={setTimeF} size="sm" />
      </div>

      {filtered.length === 0 ? (
        <EmptyState
          title="هدفی اینجا نیست"
          hint="هدف‌ها به وظایف روزانه سمت‌وسو می‌دهند. یک هدف کوتاه‌مدت یا بلندمدت بساز و سنگ‌نماهایش را مشخص کن."
          action={<button className="btn btn-primary" onClick={() => setCreating(true)}><Plus className="size-4" /> ساخت هدف</button>}
        />
      ) : (
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
          {filtered.map((g) => {
            const ms = milestonesByGoal[g.id] ?? [];
            const doneMs = ms.filter((m) => m.done).length;
            const overdue = g.targetDate && g.targetDate < today && g.status === "active";
            return (
              <div key={g.id} className="card flex flex-col gap-3 p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <button className="truncate text-sm font-bold hover:underline underline-offset-4" onClick={() => setDetail(g)}>
                      {g.title}
                    </button>
                    <div className="mt-1.5 flex flex-wrap gap-1.5">
                      <Chip tone={STATUS_TONE[g.status]}>{goalStatusLabel(g.status)}</Chip>
                      <Chip>{timeframeLabel(g.timeframe)}</Chip>
                      <Chip tone={g.priority === "high" ? "danger" : g.priority === "medium" ? "warn" : undefined}>{priorityLabel(g.priority)}</Chip>
                      {g.category && <Chip>{g.category}</Chip>}
                      {g.parentId && <Chip>زیرمجموعهٔ هدف دیگر</Chip>}
                    </div>
                  </div>
                  <span className="shrink-0 text-lg font-extrabold" style={{ color: "var(--accent)" }}>{faDigits(g.progress)}٪</span>
                </div>

                <ProgressBar value={g.progress} />

                <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px]" style={{ color: "var(--fg-muted)" }}>
                  {g.targetDate && (
                    <span style={overdue ? { color: "var(--danger)", fontWeight: 600 } : {}}>
                      سررسید: {faDateMed(g.targetDate)} ({faRelativeDay(g.targetDate, today)})
                    </span>
                  )}
                  {ms.length > 0 && <span>سنگ‌نماها: {faDigits(doneMs)}/{faDigits(ms.length)}</span>}
                  {g.taskCount > 0 && <span>وظایف پیوندخورده: {faDigits(g.taskCount)}</span>}
                </div>

                <div className="mt-auto flex flex-wrap items-center gap-1 border-t pt-2" style={{ borderColor: "var(--border)" }}>
                  <button className="btn btn-ghost !min-h-8 !px-2 !py-1 text-[11px]" onClick={() => setDetail(g)}>
                    <Flag className="size-3.5" /> جزئیات و سنگ‌نماها
                  </button>
                  <button className="btn btn-ghost !min-h-8 !px-2 !py-1 text-[11px]" onClick={() => setEditing(g)}>
                    <Pencil className="size-3.5" /> ویرایش
                  </button>
                  {g.status === "active" && (
                    <button className="btn btn-ghost !min-h-8 !px-2 !py-1 text-[11px]"
                      onClick={() => void run(() => setGoalStatus(g.id, "paused"))}>
                      <Pause className="size-3.5" /> توقف
                    </button>
                  )}
                  {g.status === "paused" && (
                    <button className="btn btn-ghost !min-h-8 !px-2 !py-1 text-[11px]"
                      onClick={() => void run(() => setGoalStatus(g.id, "active"))}>
                      <Play className="size-3.5" /> ادامه
                    </button>
                  )}
                  {g.status !== "archived" ? (
                    <button className="btn btn-ghost !min-h-8 !px-2 !py-1 text-[11px]"
                      onClick={() => void run(() => setGoalStatus(g.id, "archived"))}>
                      <Archive className="size-3.5" /> بایگانی
                    </button>
                  ) : (
                    <button className="btn btn-ghost !min-h-8 !px-2 !py-1 text-[11px]"
                      onClick={() => void run(() => setGoalStatus(g.id, "active"))}>
                      <Play className="size-3.5" /> بازگردانی
                    </button>
                  )}
                  <button className="btn btn-ghost !min-h-8 !px-2 !py-1 text-[11px]" style={{ color: "var(--danger)" }}
                    onClick={() => setDeleting(g)}>
                    <Trash2 className="size-3.5" /> حذف
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <Modal open={creating} onClose={() => setCreating(false)} title="هدف جدید" wide>
        <GoalForm goals={goals} onDone={() => setCreating(false)} />
      </Modal>
      <Modal open={!!editing} onClose={() => setEditing(null)} title="ویرایش هدف" wide>
        {editing && <GoalForm goals={goals.filter((x) => x.id !== editing.id)} init={editing} onDone={() => setEditing(null)} />}
      </Modal>

      <GoalDetail
        goal={detail}
        milestones={detail ? (milestonesByGoal[detail.id] ?? []) : []}
        onClose={() => setDetail(null)}
      />

      <Confirm
        open={!!deleting}
        onClose={() => setDeleting(null)}
        title="حذف هدف"
        message={`هدف «${deleting?.title}» حذف می‌شود. وظایف و جلسات تمرکزِ پیوندخورده حفظ می‌مانند و فقط اتصالشان بریده می‌شود.`}
        danger
        onConfirm={async () => {
          const r = await deleteGoal(deleting!.id);
          if (r.error) toast.push("err", r.error); else toast.push("ok", "هدف حذف شد.");
        }}
      />
    </div>
  );
}

function GoalForm({ init, goals, onDone }: { init?: GoalRow; goals: GoalRow[]; onDone: () => void }) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const [title, setTitle] = useState(init?.title ?? "");
  const [description, setDescription] = useState(init?.description ?? "");
  const [category, setCategory] = useState(init?.category ?? "");
  const [timeframe, setTimeframe] = useState(init?.timeframe ?? "medium");
  const [priority, setPriority] = useState(init?.priority ?? "medium");
  const [status, setStatus] = useState(init?.status ?? "active");
  const [startDate, setStartDate] = useState<string | null>(init?.startDate ?? null);
  const [targetDate, setTargetDate] = useState<string | null>(init?.targetDate ?? null);
  const [successCriteria, setSuccessCriteria] = useState(init?.successCriteria ?? "");
  const [progress, setProgress] = useState(init?.progress ?? 0);
  const [notes, setNotes] = useState(init?.notes ?? "");
  const [parentId, setParentId] = useState(init?.parentId ?? "");

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    const payload = { title, description, category, timeframe, priority, status, startDate, targetDate, successCriteria, progress, notes, parentId: parentId || null };
    const r = init ? await updateGoal(init.id, payload) : await createGoal(payload);
    setBusy(false);
    if (r.error) { toast.push("err", r.error); return; }
    toast.push("ok", r.success ?? "ذخیره شد.");
    onDone();
  };

  return (
    <form className="space-y-4" onSubmit={submit}>
      <Field label="عنوان هدف">
        <input className="input" value={title} onChange={(e) => setTitle(e.target.value)} required autoFocus placeholder="مثلاً: یادگیری زبان انگلیسی تا سطح B2" />
      </Field>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Field label="بازهٔ زمانی">
          <Segmented options={[...TIMEFRAMES]} value={timeframe} onChange={setTimeframe} size="sm" />
        </Field>
        <Field label="اولویت">
          <Segmented options={[...PRIORITIES]} value={priority} onChange={setPriority} size="sm" />
        </Field>
        <Field label="وضعیت">
          <select className="input" value={status} onChange={(e) => setStatus(e.target.value)}>
            {GOAL_STATUSES.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
          </select>
        </Field>
      </div>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Field label="تاریخ شروع"><JalaliDatePicker value={startDate} onChange={setStartDate} /></Field>
        <Field label="تاریخ هدف (سررسید)"><JalaliDatePicker value={targetDate} onChange={setTargetDate} /></Field>
      </div>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <Field label="دسته‌بندی">
          <input className="input" list="goal-cats" value={category} onChange={(e) => setCategory(e.target.value)} placeholder="انتخاب یا تایپ کنید" />
          <datalist id="goal-cats">{GOAL_CATEGORIES.map((c) => <option key={c} value={c} />)}</datalist>
        </Field>
        <Field label="هدف والد (اختیاری)" hint="برای ساخت سلسله‌مراتب هدف‌ها">
          <select className="input" value={parentId} onChange={(e) => setParentId(e.target.value)}>
            <option value="">— ندارد —</option>
            {goals.map((g) => <option key={g.id} value={g.id}>{g.title}</option>)}
          </select>
        </Field>
      </div>
      <Field label="معیار موفقیت" hint="چطور می‌فهمی بهش رسیدی؟ مثلاً: «قبولی در آزمون آزمایشی با نمرهٔ ۸۰٪»">
        <input className="input" value={successCriteria} onChange={(e) => setSuccessCriteria(e.target.value)} />
      </Field>
      <Field label={`میزان پیشرفت: ${faDigits(progress)}٪`}>
        <input type="range" min={0} max={100} step={5} value={progress}
          onChange={(e) => setProgress(Number(e.target.value))}
          className="w-full accent-teal-700" aria-label="میزان پیشرفت" />
      </Field>
      <Field label="توضیحات">
        <textarea className="input min-h-16" value={description} onChange={(e) => setDescription(e.target.value)} />
      </Field>
      <Field label="یادداشت">
        <textarea className="input min-h-12" value={notes} onChange={(e) => setNotes(e.target.value)} />
      </Field>
      <div className="flex justify-end gap-2">
        <button type="button" className="btn btn-ghost" onClick={onDone}>انصراف</button>
        <button type="submit" className="btn btn-primary" disabled={busy}>{busy ? <Spinner /> : "ذخیره"}</button>
      </div>
    </form>
  );
}

function GoalDetail({ goal, milestones, onClose }: { goal: GoalRow | null; milestones: MilestoneRow[]; onClose: () => void }) {
  const toast = useToast();
  const { run } = useRun();
  const [newMs, setNewMs] = useState("");
  const [newMsDate, setNewMsDate] = useState<string | null>(null);
  const [prog, setProg] = useState(goal?.progress ?? 0);
  const [expanded, setExpanded] = useState(true);

  React.useEffect(() => { setProg(goal?.progress ?? 0); }, [goal?.id, goal?.progress]);

  if (!goal) return null;
  return (
    <Modal open onClose={onClose} title={goal.title} wide>
      <div className="space-y-5">
        {goal.successCriteria && (
          <div className="rounded-xl px-3 py-2.5 text-xs leading-6" style={{ background: "var(--accent-soft)", color: "var(--accent)" }}>
            <strong>معیار موفقیت:</strong> {goal.successCriteria}
          </div>
        )}
        {goal.description && <p className="text-sm leading-7" style={{ color: "var(--fg-muted)" }}>{goal.description}</p>}

        <div>
          <Field label={`پیشرفت: ${faDigits(prog)}٪`}>
            <div className="flex items-center gap-3">
              <input type="range" min={0} max={100} step={5} value={prog} onChange={(e) => setProg(Number(e.target.value))}
                className="w-full accent-teal-700" aria-label="پیشرفت" />
              <button className="btn btn-soft !min-h-8 !py-1 !text-xs"
                onClick={() => void run(() => setGoalProgress(goal.id, prog))}>
                ثبت
              </button>
            </div>
          </Field>
          <ProgressBar value={prog} />
        </div>

        <div>
          <button className="mb-2 flex items-center gap-1.5 text-xs font-bold" onClick={() => setExpanded((v) => !v)}>
            سنگ‌نماها ({faDigits(milestones.length)})
            {expanded ? <ChevronUp className="size-3.5" /> : <ChevronDown className="size-3.5" />}
          </button>
          {expanded && (
            <div className="space-y-1.5">
              {milestones.length === 0 && (
                <p className="text-xs" style={{ color: "var(--fg-muted)" }}>هنوز سنگ‌نمایی ندارد؛ هدف را به گام‌های کوچک بشکن.</p>
              )}
              {milestones.map((m) => (
                <div key={m.id} className="flex items-center gap-2 rounded-xl border px-3 py-2" style={{ borderColor: "var(--border)" }}>
                  <button
                    className="grid size-5 shrink-0 place-items-center rounded-full border transition-all"
                    style={{ borderColor: m.done ? "transparent" : "var(--border-strong)", background: m.done ? "var(--ok)" : "transparent", color: "white" }}
                    onClick={() => void run(() => toggleMilestone(m.id, goal.id), { silent: true })}
                    aria-label={m.done ? "برگرداندن" : "انجام شد"} aria-pressed={m.done}>
                    {m.done && <Check className="size-3" />}
                  </button>
                  <span className="flex-1 text-xs font-medium" style={{ textDecoration: m.done ? "line-through" : "none", color: m.done ? "var(--fg-faint)" : "var(--fg)" }}>
                    {m.title}
                  </span>
                  {m.dueDate && <span className="text-[10px]" style={{ color: "var(--fg-faint)" }}>{faDateMed(m.dueDate)}</span>}
                  <button className="p-1" onClick={() => void run(() => deleteMilestone(m.id, goal.id), { silent: true })} aria-label="حذف سنگ‌نما">
                    <Trash2 className="size-3.5" style={{ color: "var(--fg-faint)" }} />
                  </button>
                </div>
              ))}
              <form
                className="flex flex-wrap items-center gap-2 pt-1"
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!newMs.trim()) return;
                  void run(async () => {
                    const r = await addMilestone(goal.id, newMs, newMsDate);
                    if (!r.error) { setNewMs(""); setNewMsDate(null); }
                    return r;
                  });
                }}
              >
                <input className="input min-w-40 flex-1 !min-h-9 !py-1 !text-xs" placeholder="عنوان سنگ‌نمای جدید…"
                  value={newMs} onChange={(e) => setNewMs(e.target.value)} />
                <div className="w-44"><JalaliDatePicker value={newMsDate} onChange={setNewMsDate} placeholder="سررسید (اختیاری)" compact /></div>
                <button className="btn btn-soft !min-h-9 !py-1 !text-xs" type="submit"><Plus className="size-3.5" /> افزودن</button>
              </form>
            </div>
          )}
        </div>
      </div>
    </Modal>
  );
}
