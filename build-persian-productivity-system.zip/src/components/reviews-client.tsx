"use client";

import React, { useState } from "react";
import { useRouter } from "next/navigation";
import { Save, X, Lightbulb, ChevronRight, ChevronLeft } from "lucide-react";
import { Field, RatingInput, Spinner, useToast, useRun } from "@/components/ui";
import { JalaliDatePicker } from "@/components/pickers";
import { saveDailyReview, saveWeeklyReview, dismissSuggestion } from "@/lib/actions-life";
import { faDigits, faDateMed, faDateLong, addDaysIso, faDuration } from "@/lib/jalali";

// ---------------- Daily ----------------

export type DailyReviewInit = {
  date: string; accomplishment: string; goalProgress: string; distractions: string;
  wentWell: string; improve: string; tomorrowPriority: string; energy: number | null;
} | null;

export function DailyReviewForm({ init, today }: { init: DailyReviewInit; today: string }) {
  const toast = useToast();
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [date, setDate] = useState(init?.date ?? today);
  const [f, setF] = useState({
    accomplishment: init?.accomplishment ?? "",
    goalProgress: init?.goalProgress ?? "",
    distractions: init?.distractions ?? "",
    wentWell: init?.wentWell ?? "",
    improve: init?.improve ?? "",
    tomorrowPriority: init?.tomorrowPriority ?? "",
  });
  const [energy, setEnergy] = useState<number | null>(init?.energy ?? null);

  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLTextAreaElement | HTMLInputElement>) =>
    setF((s) => ({ ...s, [k]: e.target.value }));

  const loadDate = (d: string | null) => {
    if (!d) return;
    setDate(d);
    router.push(`/reviews/daily?d=${d}`);
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    const r = await saveDailyReview({ date, ...f, energy });
    setBusy(false);
    if (r.error) { toast.push("err", r.error); return; }
    toast.push("ok", r.success!);
    router.refresh();
  };

  return (
    <form onSubmit={submit} className="space-y-4">
      <div className="flex flex-wrap items-center gap-3">
        <div className="w-52">
          <JalaliDatePicker value={date} onChange={loadDate} clearable={false} />
        </div>
        <button type="button" className="btn btn-ghost !min-h-0 !p-1.5" onClick={() => loadDate(addDaysIso(date, -1))} aria-label="روز قبل"><ChevronRight className="size-4" /></button>
        <button type="button" className="btn btn-ghost !min-h-0 !p-1.5" onClick={() => loadDate(addDaysIso(date, 1))} aria-label="روز بعد" disabled={date >= today}><ChevronLeft className="size-4" /></button>
        {date !== today && (
          <button type="button" className="btn btn-soft !min-h-8 !py-1 !text-xs" onClick={() => loadDate(today)}>برگرد به امروز</button>
        )}
        <span className="text-xs font-medium" style={{ color: "var(--fg-muted)" }}>{faDateLong(date)}</span>
        {init && <span className="chip" style={{ background: "var(--ok-soft)", color: "var(--ok)", borderColor: "transparent" }}>ثبت شده</span>}
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <div className="card space-y-4 p-5">
          <Field label="مهم‌ترین دستاورد امروز چه بود؟">
            <textarea className="input min-h-16" value={f.accomplishment} onChange={set("accomplishment")} placeholder="حتی یک کار کوچک" />
          </Field>
          <Field label="به کدام هدف نزدیک‌تر شدی؟">
            <textarea className="input min-h-16" value={f.goalProgress} onChange={set("goalProgress")} />
          </Field>
          <Field label="چه چیزهایی حواستانت را پرت کرد؟">
            <textarea className="input min-h-16" value={f.distractions} onChange={set("distractions")} />
          </Field>
        </div>
        <div className="card space-y-4 p-5">
          <Field label="چه چیزی خوب پیش رفت؟">
            <textarea className="input min-h-16" value={f.wentWell} onChange={set("wentWell")} />
          </Field>
          <Field label="چه چیزی را می‌شود بهتر کرد؟">
            <textarea className="input min-h-16" value={f.improve} onChange={set("improve")} />
          </Field>
          <Field label="مهم‌ترین کار فردا چیست؟">
            <input className="input" value={f.tomorrowPriority} onChange={set("tomorrowPriority")} />
          </Field>
          <Field label="انرژی‌ات امروز چطور بود؟">
            <RatingInput value={energy} onChange={setEnergy} labels={["تحلیل رفته", "کم", "معمولی", "خوب", "فوق‌العاده"]} />
          </Field>
        </div>
      </div>

      <div className="flex justify-end">
        <button type="submit" className="btn btn-primary" disabled={busy}>
          {busy ? <Spinner /> : <><Save className="size-4" /> ذخیرهٔ مرور {faDateMed(date)}</>}
        </button>
      </div>
    </form>
  );
}

// ---------------- Weekly ----------------

export function WeeklyReflectionForm({ weekStart, initial }: { weekStart: string; initial: string }) {
  const toast = useToast();
  const [reflection, setReflection] = useState(initial);
  const [busy, setBusy] = useState(false);
  React.useEffect(() => setReflection(initial), [weekStart, initial]);
  return (
    <div className="card p-5">
      <h3 className="mb-2 text-sm font-bold">جمع‌بندی خودت از این هفته</h3>
      <p className="mb-3 text-xs leading-6" style={{ color: "var(--fg-muted)" }}>
        آمار بالا از داده‌های واقعی‌ات ساخته شده؛ اینجا جای نوشتنِ برداشتِ خودت است.
      </p>
      <textarea
        className="input min-h-28"
        value={reflection}
        onChange={(e) => setReflection(e.target.value)}
        placeholder="این هفته چه آموختی؟ چه الگویی دیدی؟ هفتهٔ بعد چه چیزی را متفاوت می‌کنی؟"
        aria-label="جمع‌بندی هفته"
      />
      <div className="mt-3 flex justify-end">
        <button className="btn btn-primary" disabled={busy}
          onClick={async () => {
            setBusy(true);
            const r = await saveWeeklyReview({ weekStart, reflection });
            setBusy(false);
            if (r.error) toast.push("err", r.error); else toast.push("ok", r.success!);
          }}>
          {busy ? <Spinner /> : <><Save className="size-4" /> ذخیره</>}
        </button>
      </div>
    </div>
  );
}

export function SuggestionList({ suggestions, weekStart, dismissed }: {
  suggestions: { key: string; text: string }[];
  weekStart: string;
  dismissed: string[];
}) {
  const { run } = useRun();
  const visible = suggestions.filter((s) => !dismissed.includes(s.key));
  if (!visible.length) return null;
  return (
    <div className="card p-5">
      <h3 className="mb-1 text-sm font-bold">پیشنهادهای شفاف</h3>
      <p className="mb-3 text-[11px] leading-6" style={{ color: "var(--fg-muted)" }}>
        این‌ها بر اساس داده‌های همین هفته ساخته شده‌اند — قضاوت نیستند؛ می‌توانی هرکدام را کنار بگذاری.
      </p>
      <ul className="space-y-2">
        {visible.map((s) => (
          <li key={s.key} className="flex items-start gap-3 rounded-xl border px-3 py-2.5" style={{ borderColor: "var(--border)", background: "var(--card-soft)" }}>
            <Lightbulb className="mt-0.5 size-4 shrink-0" style={{ color: "var(--warn)" }} />
            <p className="flex-1 text-xs leading-6">{s.text}</p>
            <button
              className="btn btn-ghost !min-h-0 !p-1"
              aria-label="کنار گذاشتن پیشنهاد"
              title="کنار گذاشتن"
              onClick={() => void run(() => dismissSuggestion(weekStart, s.key), { silent: true })}
            >
              <X className="size-3.5" />
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
