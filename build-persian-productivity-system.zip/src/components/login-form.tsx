"use client";

import React, { useActionState, useState } from "react";
import { loginAction, registerAction } from "@/lib/actions-auth";
import { Spinner } from "@/components/ui";
import { LifeBuoy } from "lucide-react";

export function LoginForm() {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [loginState, loginFn, loginPending] = useActionState(loginAction, {});
  const [regState, regFn, regPending] = useActionState(registerAction, {});

  return (
    <div className="w-full max-w-sm">
      <div className="mb-8 flex flex-col items-center text-center">
        <div className="mb-3 grid size-14 place-items-center rounded-2xl" style={{ background: "var(--accent)", color: "var(--accent-fg)", boxShadow: "var(--shadow)" }}>
          <LifeBuoy className="size-7" />
        </div>
        <h1 className="text-xl font-extrabold tracking-tight">LIFE OS</h1>
        <p className="mt-1 text-xs" style={{ color: "var(--fg-muted)" }}>سیستم مدیریت زندگی و بهره‌وری شخصی</p>
      </div>

      <div className="card p-6">
        <div className="mb-5 grid grid-cols-2 gap-1 rounded-xl border p-1" style={{ borderColor: "var(--border)", background: "var(--card-soft)" }}>
          {(["login", "register"] as const).map((m) => (
            <button
              key={m}
              type="button"
              onClick={() => setMode(m)}
              className="rounded-lg py-2 text-xs font-semibold transition-all"
              style={{
                background: mode === m ? "var(--card)" : "transparent",
                color: mode === m ? "var(--fg)" : "var(--fg-muted)",
                boxShadow: mode === m ? "var(--shadow)" : "none",
              }}
            >
              {m === "login" ? "ورود" : "ساخت حساب"}
            </button>
          ))}
        </div>

        {mode === "login" ? (
          <form action={loginFn} className="space-y-4">
            <div>
              <label htmlFor="l-user" className="label">نام کاربری</label>
              <input id="l-user" name="username" className="input" autoComplete="username" required dir="auto" />
            </div>
            <div>
              <label htmlFor="l-pass" className="label">رمز عبور</label>
              <input id="l-pass" name="password" type="password" className="input" autoComplete="current-password" required dir="ltr" />
            </div>
            {loginState.error && (
              <p className="rounded-xl px-3 py-2 text-xs font-medium" style={{ background: "var(--danger-soft)", color: "var(--danger)" }} role="alert">
                {loginState.error}
              </p>
            )}
            <button className="btn btn-primary w-full" disabled={loginPending}>
              {loginPending ? <Spinner /> : "ورود به LIFE OS"}
            </button>
          </form>
        ) : (
          <form action={regFn} className="space-y-4">
            <div>
              <label htmlFor="r-name" className="label">نام نمایشی (اختیاری)</label>
              <input id="r-name" name="displayName" className="input" autoComplete="nickname" />
            </div>
            <div>
              <label htmlFor="r-user" className="label">نام کاربری</label>
              <input id="r-user" name="username" className="input" autoComplete="username" required minLength={3} dir="auto" />
            </div>
            <div>
              <label htmlFor="r-pass" className="label">رمز عبور</label>
              <input id="r-pass" name="password" type="password" className="input" autoComplete="new-password" required minLength={8} dir="ltr" />
              <p className="mt-1 text-[11px]" style={{ color: "var(--fg-faint)" }}>دست‌کم ۸ نویسه؛ رمز شما به‌صورت امن (هش‌شده) نگهداری می‌شود.</p>
            </div>
            {regState.error && (
              <p className="rounded-xl px-3 py-2 text-xs font-medium" style={{ background: "var(--danger-soft)", color: "var(--danger)" }} role="alert">
                {regState.error}
              </p>
            )}
            <button className="btn btn-primary w-full" disabled={regPending}>
              {regPending ? <Spinner /> : "ساخت حساب و شروع"}
            </button>
          </form>
        )}
      </div>

      <p className="mt-6 text-center text-[11px] leading-6" style={{ color: "var(--fg-faint)" }}>
        داده‌های شما فقط برای خودتان است و روی همین سرور نگهداری می‌شود.
        <br />
        هیچ سرویس بیرونی‌ای در کار نیست.
      </p>
    </div>
  );
}
