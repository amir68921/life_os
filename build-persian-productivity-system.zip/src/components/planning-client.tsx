"use client";

import React, { useMemo, useState } from "react";
import { Plus, ChevronRight, ChevronLeft, Pencil, Coffee, Clock3, Zap } from "lucide-react";
import { Modal, useRun, useToast, Confirm } from "@/components/ui";
import { TaskForm } from "@/components/task-form";
import { deleteTask, setTaskStatus } from "@/lib/actions-core";
import {
  faDigits, faDateMed, faWeekdayName, addDaysIso, faRelativeDay, faDuration, faDateShort,
} from "@/lib/jalali";

type PlanTask = {
  id: string; title: string; dueDate: string | null; plannedStart: string | null; plannedEnd: string | null;
  estimatedMinutes: number | null; priority: string; status: string; category: string | null;
  description: string | null; actualMinutes: number | null; energy: string | null; tags: string | null;
  recurrence: string; goalId: string | null; notes: string | null; completedDate: string | null;
};

type FocusBlock = { id: string; localDate: string; startedClock: string; minutes: number; objective: string | null };

const toMin = (t: string) => { const [h, m] = t.split(":").map(Number); return h * 60 + m; };

export function PlanningClient({
  tasks, focus, goals, today, weekDays, tz,
}: {
  tasks: PlanTask[];
  focus: FocusBlock[];
  goals: { id: string; title: string }[];
  today: string;
  weekDays: string[];
  tz: string;
}) {
  const [anchor, setAnchor] = useState(today);
  const [selectedDay, setSelectedDay] = useState(today);
  const [createDay, setCreateDay] = useState<string | null>(null);
  const [createPreset, setCreatePreset] = useState<string | undefined>(undefined);
  const [editTask, setEditTask] = useState<PlanTask | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const toast = useToast();

  const week = useMemo(() => {
    const idx = weekDays.indexOf(anchor);
    const base = idx >= 0 ? weekDays[0] : anchor;
    return Array.from({ length: 7 }, (_, i) => addDaysIso(base, i));
  }, [anchor, weekDays]);

  const dayTasks = useMemo(
    () => tasks.filter((t) => t.dueDate === selectedDay && t.status !== "cancelled")
      .sort((a, b) => (a.plannedStart ?? "99").localeCompare(b.plannedStart ?? "99")),
    [tasks, selectedDay]
  );
  const dayFocus = useMemo(() => focus.filter((f) => f.localDate === selectedDay), [focus, selectedDay]);

  const plannedMinutes = dayTasks
    .filter((t) => t.plannedStart && t.plannedEnd)
    .reduce((a, t) => a + Math.max(0, toMin(t.plannedEnd!) - toMin(t.plannedStart!)), 0);
  const actualFocusMin = dayFocus.reduce((a, f) => a + f.minutes, 0);
  const overlaps = findOverlaps(dayTasks);

  return (
    <div className="space-y-4">
      {/* ناوبری هفته */}
      <div className="flex flex-wrap items-center gap-2">
        <button className="btn btn-ghost !min-h-0 !p-1.5" onClick={() => setAnchor(addDaysIso(week[0], -7))} aria-label="هفتهٔ قبل"><ChevronRight className="size-4" /></button>
        <button className="btn btn-soft !min-h-8 !py-1 !text-xs" onClick={() => { setAnchor(today); setSelectedDay(today); }}>این هفته</button>
        <button className="btn btn-ghost !min-h-0 !p-1.5" onClick={() => setAnchor(addDaysIso(week[0], 7))} aria-label="هفتهٔ بعد"><ChevronLeft className="size-4" /></button>
        <span className="text-xs" style={{ color: "var(--fg-muted)" }}>{faDateMed(week[0])} تا {faDateMed(week[6])}</span>
      </div>

      {/* روزهای هفته */}
      <div className="grid grid-cols-7 gap-1.5 sm:gap-2" role="tablist" aria-label="روزهای هفته">
        {week.map((d) => {
          const count = tasks.filter((t) => t.dueDate === d && t.status !== "cancelled").length;
          const active = d === selectedDay;
          const isToday = d === today;
          return (
            <button
              key={d}
              role="tab"
              aria-selected={active}
              onClick={() => setSelectedDay(d)}
              className="card !rounded-xl px-1 py-2 text-center transition-all hover:-translate-y-0.5"
              style={active ? { borderColor: "var(--accent)", background: "var(--accent-soft)" } : {}}
            >
              <p className="text-[9px] font-medium sm:text-[10px]" style={{ color: active ? "var(--accent)" : "var(--fg-muted)" }}>
                {faWeekdayName(d)}
              </p>
              <p className="mt-0.5 text-sm font-extrabold" style={{ color: isToday ? "var(--accent)" : "var(--fg)" }}>
                {faDigits(faDateShort(d).split("/")[2])}
              </p>
              <p className="mt-0.5 text-[9px]" style={{ color: "var(--fg-faint)" }}>
                {count ? `${faDigits(count)} کار` : "—"}
              </p>
            </button>
          );
        })}
      </div>

      {/* روز انتخاب‌شده */}
      <div className="card p-5">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
          <div>
            <h2 className="text-sm font-bold">{faDateMed(selectedDay)} · {faWeekdayName(selectedDay)}</h2>
            <p className="mt-0.5 text-xs" style={{ color: "var(--fg-muted)" }}>{faRelativeDay(selectedDay, today)}</p>
          </div>
          <div className="flex gap-2">
            <button className="btn btn-primary !min-h-9 !py-1.5 !text-xs" onClick={() => { setCreateDay(selectedDay); setCreatePreset(undefined); }}>
              <Plus className="size-3.5" /> کار / تعهد شخصی
            </button>
            <button className="btn btn-soft !min-h-9 !py-1.5 !text-xs" onClick={() => { setCreateDay(selectedDay); setCreatePreset("استراحت"); }}>
              <Coffee className="size-3.5" /> استراحت
            </button>
          </div>
        </div>

        <div className="mb-4 grid grid-cols-2 gap-3 sm:grid-cols-3">
          <div className="rounded-xl border px-3 py-2" style={{ borderColor: "var(--border)" }}>
            <p className="text-[10px]" style={{ color: "var(--fg-muted)" }}>زمان برنامه‌ریزی‌شده</p>
            <p className="mt-0.5 text-sm font-extrabold"><Clock3 className="ml-1 inline size-3.5" style={{ color: "var(--fg-faint)" }} />{faDuration(plannedMinutes)}</p>
          </div>
          <div className="rounded-xl border px-3 py-2" style={{ borderColor: "var(--border)" }}>
            <p className="text-[10px]" style={{ color: "var(--fg-muted)" }}>تمرکز واقعی ثبت‌شده</p>
            <p className="mt-0.5 text-sm font-extrabold" style={{ color: "var(--accent)" }}>
              <Zap className="ml-1 inline size-3.5" />{faDuration(actualFocusMin)}
            </p>
          </div>
          <div className="rounded-xl border px-3 py-2" style={{ borderColor: "var(--border)" }}>
            <p className="text-[10px]" style={{ color: "var(--fg-muted)" }}>وضعیت</p>
            <p className="mt-0.5 text-sm font-extrabold">
              {faDigits(dayTasks.filter((t) => t.status === "done").length)} / {faDigits(dayTasks.length)} انجام‌شده
            </p>
          </div>
        </div>

        {overlaps.length > 0 && (
          <p className="mb-3 rounded-xl px-3 py-2 text-[11px] font-medium" style={{ background: "var(--warn-soft)", color: "var(--warn)" }} role="alert">
            هم‌پوشانی زمانی: {overlaps.join("، ")} — پیشنهاد می‌کنیم ساعت‌ها را اصلاح کنی.
          </p>
        )}

        {dayTasks.length === 0 && dayFocus.length === 0 ? (
          <p className="rounded-xl border border-dashed px-4 py-8 text-center text-xs leading-7" style={{ borderColor: "var(--border-strong)", color: "var(--fg-muted)" }}>
            این روز آزاد است. لازم نیست هر دقیقه را برنامه‌ریزی کنی؛ فقط چیزهای مهمی را که می‌خواهی انجام شوند بنویس.
          </p>
        ) : (
          <div className="space-y-1.5">
            {dayTasks.map((t) => <PlanRow key={t.id} task={t} onEdit={() => setEditTask(t)} onDelete={() => setDeleteId(t.id)} />)}
            {dayFocus.map((f) => (
              <div key={f.id} className="flex items-center gap-3 rounded-xl border border-dashed px-3 py-2.5" style={{ borderColor: "var(--accent)" }}>
                <Zap className="size-4 shrink-0" style={{ color: "var(--accent)" }} />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-xs font-medium">{f.objective ?? "جلسهٔ تمرکز"}</p>
                  <p className="text-[10px]" style={{ color: "var(--fg-muted)" }}>واقعی — ثبت‌شده با تایمر</p>
                </div>
                <span className="chip" dir="ltr">{f.startedClock}</span>
                <span className="chip" style={{ background: "var(--accent-soft)", color: "var(--accent)", borderColor: "transparent" }}>{faDuration(f.minutes)}</span>
              </div>
            ))}
          </div>
        )}

        <p className="mt-4 text-[10px]" style={{ color: "var(--fg-faint)" }}>
          خط‌ی پر از رنگ = برنامه‌ریزی‌شده · خط‌چین = واقعیِ ثبت‌شده با تایمر تمرکز
        </p>
      </div>

      <Modal open={!!createDay} onClose={() => setCreateDay(null)} title={`برای ${createDay ? faDateMed(createDay) : ""}`} wide>
        {createDay && (
          <TaskForm goals={goals} defaultDate={createDay} defaultCategory={createPreset} onDone={() => setCreateDay(null)} />
        )}
      </Modal>
      <Modal open={!!editTask} onClose={() => setEditTask(null)} title="ویرایش و زمان‌بندی" wide>
        {editTask && <TaskForm goals={goals} init={editTask} onDone={() => setEditTask(null)} />}
      </Modal>
      <Confirm
        open={!!deleteId} onClose={() => setDeleteId(null)} title="حذف وظیفه"
        message="این وظیفه برای همیشه حذف می‌شود." danger
        onConfirm={async () => {
          const r = await deleteTask(deleteId!);
          if (r.error) toast.push("err", r.error); else toast.push("ok", "حذف شد.");
        }}
      />
    </div>
  );
}

function findOverlaps(dayTasks: PlanTask[]): string[] {
  const timed = dayTasks.filter((t) => t.plannedStart && t.plannedEnd && t.status !== "done");
  const msgs: string[] = [];
  for (let i = 0; i < timed.length; i++) {
    for (let j = i + 1; j < timed.length; j++) {
      const a = timed[i], b = timed[j];
      if (toMin(a.plannedStart!) < toMin(b.plannedEnd!) && toMin(b.plannedStart!) < toMin(a.plannedEnd!)) {
        msgs.push(`«${a.title}» با «${b.title}»`);
      }
    }
  }
  return msgs;
}

function PlanRow({ task, onEdit, onDelete }: { task: PlanTask; onEdit: () => void; onDelete: () => void }) {
  const { run } = useRun();
  const done = task.status === "done";
  return (
    <div className="flex items-center gap-3 rounded-xl border px-3 py-2.5" style={{ borderColor: "var(--border)", background: "var(--card-soft)" }}>
      <button
        className="grid size-5 shrink-0 place-items-center rounded-full border"
        style={{ borderColor: done ? "transparent" : "var(--border-strong)", background: done ? "var(--ok)" : "transparent", color: "white" }}
        onClick={() => void run(() => setTaskStatus(task.id, done ? "pending" : "done"), { silent: true })}
        aria-label="تغییر وضعیت انجام" aria-pressed={done}
      >
        {done && <span className="text-[10px]">✓</span>}
      </button>
      <div className="min-w-0 flex-1">
        <p className="truncate text-xs font-medium" style={{ textDecoration: done ? "line-through" : "none", color: done ? "var(--fg-faint)" : "var(--fg)" }}>
          {task.title}
        </p>
        <p className="text-[10px]" style={{ color: "var(--fg-muted)" }}>
          برنامه‌ریزی‌شده{task.category ? ` · ${task.category}` : ""}
        </p>
      </div>
      {task.plannedStart && task.plannedEnd ? (
        <span className="chip" dir="ltr">{task.plannedStart}–{task.plannedEnd}</span>
      ) : (
        <button className="chip transition-all hover:opacity-70" onClick={onEdit}>
          <Clock3 className="size-3" /> ساعت بده
        </button>
      )}
      {task.estimatedMinutes != null && <span className="chip hidden sm:inline-flex">{faDuration(task.estimatedMinutes)}</span>}
      <button className="btn btn-ghost !min-h-0 !p-1.5" onClick={onEdit} aria-label="ویرایش"><Pencil className="size-3.5" /></button>
    </div>
  );
}
