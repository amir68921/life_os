"use client";

import React, { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard, CalendarDays, ListTodo, Target, Timer, Moon, Repeat2,
  BarChart3, NotebookPen, CalendarCheck2, Settings, LogOut, Menu, X,
  Sun, MoonStar, Monitor, FolderKanban, Footprints, StickyNote, LifeBuoy,
} from "lucide-react";
import { logoutAction } from "@/lib/actions-auth";
import { ToastProvider } from "@/components/ui";

const NAV = [
  { href: "/", label: "داشبورد", icon: LayoutDashboard, exact: true },
  { href: "/planning", label: "برنامه‌ریزی روزانه", icon: CalendarDays },
  { href: "/tasks", label: "وظایف", icon: ListTodo },
  { href: "/goals", label: "اهداف", icon: Target },
  { href: "/focus", label: "تایمر تمرکز", icon: Timer },
  { href: "/sleep", label: "خواب", icon: Moon },
  { href: "/habits", label: "عادت‌ها", icon: Repeat2 },
  { href: "/reviews/daily", label: "مرور روزانه", icon: NotebookPen },
  { href: "/reviews/weekly", label: "مرور هفتگی", icon: CalendarCheck2 },
  { href: "/analytics", label: "تحلیل‌ها", icon: BarChart3 },
];

const SOON = [
  { href: "/soon", label: "پروژه‌ها", icon: FolderKanban },
  { href: "/soon", label: "گزارش فعالیت‌ها", icon: Footprints },
  { href: "/soon", label: "یادداشت‌ها", icon: StickyNote },
];

const MOBILE = [NAV[0], NAV[1], NAV[2], NAV[4], NAV[6]];

function ThemeToggle() {
  const [theme, setTheme] = useState<"light" | "dark" | "system">("system");
  useEffect(() => {
    const t = (localStorage.getItem("lifeos-theme") as "light" | "dark" | "system") ?? "system";
    setTheme(t);
  }, []);
  const cycle = () => {
    const next = theme === "system" ? "light" : theme === "light" ? "dark" : "system";
    setTheme(next);
    localStorage.setItem("lifeos-theme", next);
    const dark = next === "dark" || (next === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);
    document.documentElement.classList.toggle("dark", dark);
    document.cookie = `lifeos-theme=${next};path=/;max-age=31536000`;
  };
  const Icon = theme === "dark" ? MoonStar : theme === "light" ? Sun : Monitor;
  return (
    <button onClick={cycle} className="btn btn-ghost !min-h-0 !p-2" aria-label="تغییر پوسته" title={`پوسته: ${theme === "system" ? "خودکار" : theme === "light" ? "روشن" : "تیره"}`}>
      <Icon className="size-4" />
    </button>
  );
}

function NavList({ onNavigate }: { onNavigate?: () => void }) {
  const path = usePathname();
  return (
    <nav className="flex flex-col gap-0.5 px-3" aria-label="بخش‌های اصلی">
      {NAV.map((item) => {
        const active = item.exact ? path === item.href : path.startsWith(item.href);
        return (
          <Link
            key={item.href}
            href={item.href}
            onClick={onNavigate}
            className="flex items-center gap-3 rounded-xl px-3 py-2 text-[13px] font-medium transition-colors"
            style={{
              background: active ? "var(--accent-soft)" : "transparent",
              color: active ? "var(--accent)" : "var(--fg-muted)",
            }}
            aria-current={active ? "page" : undefined}
          >
            <item.icon className="size-[18px] shrink-0" />
            {item.label}
          </Link>
        );
      })}
      <p className="mt-4 mb-1 px-3 text-[10px] font-semibold" style={{ color: "var(--fg-faint)" }}>فاز ۲ — به‌زودی</p>
      {SOON.map((item) => (
        <Link
          key={item.label}
          href={item.href}
          onClick={onNavigate}
          className="flex items-center gap-3 rounded-xl px-3 py-2 text-[13px] font-medium transition-colors"
          style={{ color: "var(--fg-faint)" }}
        >
          <item.icon className="size-[18px] shrink-0" />
          {item.label}
        </Link>
      ))}
    </nav>
  );
}

export function Shell({ children, userName }: { children: React.ReactNode; userName: string }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const path = usePathname();
  useEffect(() => { setMenuOpen(false); }, [path]);

  return (
    <ToastProvider>
      {/* Sidebar (desktop) */}
      <aside
        className="fixed inset-y-0 right-0 z-40 hidden w-60 flex-col border-l lg:flex"
        style={{ background: "var(--card)", borderColor: "var(--border)" }}
      >
        <div className="flex items-center gap-2.5 px-6 pt-6 pb-5">
          <div className="grid size-9 place-items-center rounded-xl" style={{ background: "var(--accent)", color: "var(--accent-fg)" }}>
            <LifeBuoy className="size-5" />
          </div>
          <div>
            <p className="text-sm font-extrabold tracking-tight">LIFE OS</p>
            <p className="text-[10px]" style={{ color: "var(--fg-faint)" }}>سیستم مدیریت زندگی</p>
          </div>
        </div>
        <div className="flex-1 overflow-y-auto pb-3">
          <NavList />
        </div>
        <div className="border-t px-4 py-3" style={{ borderColor: "var(--border)" }}>
          <div className="flex items-center justify-between gap-2">
            <div className="flex min-w-0 items-center gap-2">
              <div className="grid size-8 shrink-0 place-items-center rounded-full text-xs font-bold" style={{ background: "var(--bg-soft)", color: "var(--fg-muted)" }}>
                {userName.slice(0, 1)}
              </div>
              <span className="truncate text-xs font-medium" style={{ color: "var(--fg-muted)" }}>{userName}</span>
            </div>
            <div className="flex items-center">
              <ThemeToggle />
              <Link href="/settings" className="btn btn-ghost !min-h-0 !p-2" aria-label="تنظیمات">
                <Settings className="size-4" />
              </Link>
              <form action={logoutAction}>
                <button className="btn btn-ghost !min-h-0 !p-2" aria-label="خروج از حساب" title="خروج">
                  <LogOut className="size-4" />
                </button>
              </form>
            </div>
          </div>
        </div>
      </aside>

      {/* Top bar (mobile) */}
      <header
        className="fixed inset-x-0 top-0 z-40 flex items-center justify-between border-b px-4 py-3 lg:hidden"
        style={{ background: "color-mix(in srgb, var(--bg) 85%, transparent)", backdropFilter: "blur(12px)", borderColor: "var(--border)" }}
      >
        <div className="flex items-center gap-2">
          <div className="grid size-8 place-items-center rounded-lg" style={{ background: "var(--accent)", color: "var(--accent-fg)" }}>
            <LifeBuoy className="size-4" />
          </div>
          <p className="text-sm font-extrabold">LIFE OS</p>
        </div>
        <div className="flex items-center gap-1">
          <ThemeToggle />
          <button className="btn btn-ghost !min-h-0 !p-2" onClick={() => setMenuOpen(true)} aria-label="باز کردن منو">
            <Menu className="size-5" />
          </button>
        </div>
      </header>

      {/* Mobile drawer */}
      {menuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden" role="dialog" aria-modal="true" aria-label="منوی اصلی">
          <div className="animate-fade absolute inset-0 bg-black/40" onClick={() => setMenuOpen(false)} />
          <div
            className="animate-scale absolute inset-y-0 right-0 flex w-64 flex-col pt-4"
            style={{ background: "var(--card)", borderColor: "var(--border)" }}
          >
            <div className="mb-2 flex items-center justify-between px-4">
              <span className="text-sm font-bold">منو</span>
              <div className="flex items-center gap-1">
                <Link href="/settings" className="btn btn-ghost !min-h-0 !p-2" aria-label="تنظیمات">
                  <Settings className="size-4" />
                </Link>
                <form action={logoutAction}>
                  <button className="btn btn-ghost !min-h-0 !p-2" aria-label="خروج">
                    <LogOut className="size-4" />
                  </button>
                </form>
                <button className="btn btn-ghost !min-h-0 !p-2" onClick={() => setMenuOpen(false)} aria-label="بستن منو">
                  <X className="size-4" />
                </button>
              </div>
            </div>
            <div className="flex-1 overflow-y-auto pb-6">
              <NavList onNavigate={() => setMenuOpen(false)} />
            </div>
          </div>
        </div>
      )}

      {/* Bottom nav (mobile) */}
      <nav
        className="fixed inset-x-0 bottom-0 z-40 flex items-stretch justify-around border-t px-1 lg:hidden"
        style={{ background: "color-mix(in srgb, var(--card) 92%, transparent)", backdropFilter: "blur(12px)", borderColor: "var(--border)", paddingBottom: "max(4px, env(safe-area-inset-bottom))" }}
        aria-label="پیمایش سریع"
      >
        {MOBILE.map((item) => {
          const active = item.exact ? path === item.href : path.startsWith(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              className="flex flex-1 flex-col items-center gap-1 py-2"
              style={{ color: active ? "var(--accent)" : "var(--fg-faint)" }}
              aria-current={active ? "page" : undefined}
            >
              <item.icon className="size-5" />
              <span className="text-[9px] font-medium">{item.label}</span>
            </Link>
          );
        })}
      </nav>

      {/* Content */}
      <main className="min-h-dvh pb-24 pt-16 lg:pb-10 lg:pt-0 lg:ps-60">
        <div className="mx-auto w-full max-w-6xl px-4 py-5 sm:px-6 lg:py-8">
          {children}
        </div>
      </main>
    </ToastProvider>
  );
}
