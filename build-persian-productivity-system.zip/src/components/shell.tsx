"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState, useTransition, type ReactNode } from "react";
import { t } from "@/lib/i18n";
import { logoutAction } from "@/app/actions/auth";
import { setThemeAction } from "@/app/actions/settings";

const NAV: { href: string; key: keyof typeof t.nav; icon: string }[] = [
  { href: "/", key: "dashboard", icon: "◧" },
  { href: "/planner", key: "planner", icon: "▤" },
  { href: "/tasks", key: "tasks", icon: "☑" },
  { href: "/goals", key: "goals", icon: "◎" },
  { href: "/projects", key: "projects", icon: "▦" },
  { href: "/focus", key: "focus", icon: "◷" },
  { href: "/sleep", key: "sleep", icon: "☾" },
  { href: "/habits", key: "habits", icon: "↻" },
  { href: "/activity", key: "activity", icon: "≣" },
  { href: "/notes", key: "notes", icon: "✎" },
  { href: "/analytics", key: "analytics", icon: "▥" },
  { href: "/review", key: "review", icon: "✓" },
  { href: "/weekly", key: "weekly", icon: "⧉" },
  { href: "/settings", key: "settings", icon: "⚙" },
];

const MOBILE_MAIN = ["/", "/tasks", "/focus", "/habits"];

function isActive(path: string, href: string) {
  return href === "/" ? path === "/" : path === href || path.startsWith(href + "/");
}

export function AppShell({ children, userName, theme }: { children: ReactNode; userName: string; theme: string }) {
  const path = usePathname();
  const [more, setMore] = useState(false);
  const [pending, start] = useTransition();
  const router = useRouter();

  const toggleTheme = () => {
    const isDark = document.documentElement.classList.contains("dark");
    const next = isDark ? "light" : "dark";
    document.documentElement.classList.toggle("dark", !isDark);
    start(async () => {
      await setThemeAction(next);
      router.refresh();
    });
  };

  return (
    <div className="min-h-screen lg:flex">
      <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:top-2 focus:right-2 focus:z-50 focus:rounded-lg focus:bg-white focus:px-3 focus:py-2 dark:focus:bg-zinc-900">
        پرش به محتوا
      </a>
      {/* Desktop sidebar */}
      <aside className="sticky top-0 hidden h-screen w-64 shrink-0 flex-col border-l border-zinc-200 bg-white/80 px-3 py-5 backdrop-blur dark:border-zinc-800 dark:bg-zinc-950/80 lg:flex">
        <Link href="/" className="mb-6 flex items-center gap-2 px-3">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-accent-600 text-sm font-bold text-white">L</span>
          <span className="text-lg font-bold tracking-tight">LIFE OS</span>
        </Link>
        <nav aria-label="ناوبری اصلی" className="flex-1 space-y-0.5 overflow-y-auto">
          {NAV.map((n) => {
            const active = isActive(path, n.href);
            return (
              <Link
                key={n.href}
                href={n.href}
                aria-current={active ? "page" : undefined}
                className={`flex min-h-10 items-center gap-3 rounded-xl px-3 text-sm transition-colors ${active ? "bg-accent-50 font-semibold text-accent-800 dark:bg-accent-900/40 dark:text-accent-100" : "text-zinc-600 hover:bg-zinc-100 dark:text-zinc-400 dark:hover:bg-zinc-900"}`}
              >
                <span aria-hidden className="w-5 text-center">
                  {n.icon}
                </span>
                {t.nav[n.key]}
              </Link>
            );
          })}
        </nav>
        <div className="mt-4 border-t border-zinc-200 pt-4 dark:border-zinc-800">
          <div className="mb-2 truncate px-3 text-sm font-medium">{userName}</div>
          <div className="flex items-center gap-1 px-1">
            <button type="button" onClick={toggleTheme} className="icon-btn" aria-label="تغییر حالت روشن/تیره" disabled={pending}>
              ◐
            </button>
            <form action={logoutAction}>
              <button type="submit" className="btn btn-ghost btn-sm">
                خروج
              </button>
            </form>
          </div>
        </div>
      </aside>

      {/* Mobile top bar */}
      <header className="sticky top-0 z-30 flex items-center justify-between border-b border-zinc-200 bg-white/90 px-4 py-2.5 backdrop-blur dark:border-zinc-800 dark:bg-zinc-950/90 lg:hidden">
        <Link href="/" className="flex items-center gap-2">
          <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-accent-600 text-xs font-bold text-white">L</span>
          <span className="font-bold">LIFE OS</span>
        </Link>
        <button type="button" onClick={toggleTheme} className="icon-btn" aria-label="تغییر حالت روشن/تیره">
          ◐
        </button>
      </header>

      <main id="main" className="mx-auto w-full max-w-6xl flex-1 px-4 pb-28 pt-5 sm:px-6 lg:px-10 lg:pb-12 lg:pt-8">
        {children}
      </main>

      {/* Mobile bottom navigation */}
      <nav aria-label="ناوبری موبایل" className="fixed inset-x-0 bottom-0 z-40 border-t border-zinc-200 bg-white/95 pb-[env(safe-area-inset-bottom)] backdrop-blur dark:border-zinc-800 dark:bg-zinc-950/95 lg:hidden">
        <div className="grid grid-cols-5">
          {NAV.filter((n) => MOBILE_MAIN.includes(n.href)).map((n) => {
            const active = isActive(path, n.href);
            return (
              <Link key={n.href} href={n.href} aria-current={active ? "page" : undefined} className={`flex min-h-14 flex-col items-center justify-center gap-0.5 text-[11px] ${active ? "text-accent-700 dark:text-accent-300" : "text-zinc-500"}`}>
                <span aria-hidden className="text-lg leading-none">
                  {n.icon}
                </span>
                {t.nav[n.key]}
              </Link>
            );
          })}
          <button type="button" onClick={() => setMore(true)} className="flex min-h-14 flex-col items-center justify-center gap-0.5 text-[11px] text-zinc-500" aria-expanded={more}>
            <span aria-hidden className="text-lg leading-none">
              ☰
            </span>
            بیشتر
          </button>
        </div>
      </nav>

      {more && (
        <div className="fixed inset-0 z-50 lg:hidden" role="dialog" aria-modal="true" aria-label="همهٔ بخش‌ها">
          <button type="button" className="absolute inset-0 bg-black/40" aria-label="بستن" onClick={() => setMore(false)} />
          <div className="absolute inset-x-0 bottom-0 max-h-[80vh] overflow-y-auto rounded-t-3xl bg-white p-4 pb-8 dark:bg-zinc-900">
            <div className="mx-auto mb-4 h-1 w-10 rounded-full bg-zinc-300 dark:bg-zinc-700" />
            <div className="grid grid-cols-3 gap-2">
              {NAV.map((n) => (
                <Link
                  key={n.href}
                  href={n.href}
                  onClick={() => setMore(false)}
                  className={`flex min-h-20 flex-col items-center justify-center gap-1 rounded-2xl border text-xs ${isActive(path, n.href) ? "border-accent-500 bg-accent-50 dark:bg-accent-900/30" : "border-zinc-200 dark:border-zinc-800"}`}
                >
                  <span aria-hidden className="text-xl">
                    {n.icon}
                  </span>
                  {t.nav[n.key]}
                </Link>
              ))}
            </div>
            <form action={logoutAction} className="mt-4">
              <button type="submit" className="btn w-full">
                خروج از حساب ({userName})
              </button>
            </form>
          </div>
        </div>
      )}
      <span hidden>{theme}</span>
    </div>
  );
}
