"use client";

import React, { useMemo, useState } from "react";
import { Save, Download, KeyRound, UserX, LogOut } from "lucide-react";
import { Field, Spinner, useToast, Modal, Card, SectionTitle } from "@/components/ui";
import { Segmented, TimeField } from "@/components/pickers";
import { updateSettings, updateProfile, changePassword, exportData, deleteAccount } from "@/lib/actions-life";
import { logoutAction } from "@/lib/actions-auth";
import { faDigits } from "@/lib/jalali";

const COMMON_TZ = ["Asia/Tehran", "Asia/Dubai", "Europe/Berlin", "Europe/London", "America/New_York", "America/Los_Angeles", "Asia/Tokyo", "Australia/Sydney"];

export function SettingsClient({
  settings, username, displayName,
}: {
  settings: {
    theme: string; timezone: string; weekStart: number;
    defaultFocusMinutes: number; defaultBreakMinutes: number;
    targetBedTime: string; targetWakeTime: string; targetSleepMinutes: number;
  };
  username: string;
  displayName: string;
}) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const [theme, setTheme] = useState(settings.theme);
  const [timezone, setTimezone] = useState(settings.timezone);
  const [weekStart, setWeekStart] = useState(String(settings.weekStart));
  const [defFocus, setDefFocus] = useState(String(settings.defaultFocusMinutes));
  const [defBreak, setDefBreak] = useState(String(settings.defaultBreakMinutes));
  const [bed, setBed] = useState(settings.targetBedTime);
  const [wake, setWake] = useState(settings.targetWakeTime);
  const [sleepMin, setSleepMin] = useState(String(settings.targetSleepMinutes));
  const [name, setName] = useState(displayName);

  const timezones = useMemo(() => {
    let list = COMMON_TZ;
    try {
      const all = Intl.supportedValuesOf("timeZone");
      list = [...new Set([...COMMON_TZ, ...all])];
    } catch { /* مرورگر قدیمی */ }
    return list;
  }, []);

  const applyTheme = (v: string) => {
    setTheme(v);
    localStorage.setItem("lifeos-theme", v);
    const dark = v === "dark" || (v === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);
    document.documentElement.classList.toggle("dark", dark);
  };

  return (
    <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
      {/* نمایش و محلی‌سازی */}
      <Card>
        <SectionTitle title="ظاهر و منطقه" subtitle="پوسته، زبان و تقویم" />
        <div className="space-y-4">
          <Field label="پوسته" hint="زبان رابط «فارسی» و تقویم «جلالی» است؛ افزودن زبان‌های دیگر در نقشهٔ راه است.">
            <Segmented
              options={[{ value: "light", label: "روشن" }, { value: "dark", label: "تیره" }, { value: "system", label: "خودکار" }]}
              value={theme}
              onChange={applyTheme}
            />
          </Field>
          <Field label="منطقهٔ زمانی" hint="برای ساعت خواب، تمرکز و تاریخ امروز استفاده می‌شود">
            <select className="input" dir="ltr" value={timezone} onChange={(e) => setTimezone(e.target.value)}>
              {timezones.map((z) => <option key={z} value={z}>{z}</option>)}
            </select>
          </Field>
          <Field label="شروع هفته">
            <Segmented
              options={[{ value: "0", label: "شنبه" }, { value: "6", label: "جمعه" }]}
              value={weekStart}
              onChange={setWeekStart}
            />
          </Field>
        </div>
      </Card>

      {/* پیش‌فرض‌های تمرکز و خواب */}
      <Card>
        <SectionTitle title="پیش‌فرض‌های تمرکز و خواب" />
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Field label="مدت پیش‌فرض جلسه (دقیقه)">
              <input className="input" type="number" min={5} max={480} value={defFocus} onChange={(e) => setDefFocus(e.target.value)} inputMode="numeric" />
            </Field>
            <Field label="استراحت پیش‌فرض (دقیقه)">
              <input className="input" type="number" min={0} max={120} value={defBreak} onChange={(e) => setDefBreak(e.target.value)} inputMode="numeric" />
            </Field>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Field label="ساعت خواب هدف"><TimeField value={bed} onChange={setBed} /></Field>
            <Field label="ساعت بیداری هدف"><TimeField value={wake} onChange={setWake} /></Field>
          </div>
          <Field label={`مدت خواب هدف: ${faDigits(sleepMin)} دقیقه`}>
            <input type="range" min={240} max={720} step={15} value={sleepMin}
              onChange={(e) => setSleepMin(e.target.value)} className="w-full accent-teal-700" aria-label="مدت خواب هدف" />
          </Field>
          <button
            className="btn btn-primary w-full"
            disabled={busy}
            onClick={async () => {
              setBusy(true);
              const r = await updateSettings({
                theme, timezone, weekStart: Number(weekStart),
                defaultFocusMinutes: Number(defFocus), defaultBreakMinutes: Number(defBreak),
                targetBedTime: bed, targetWakeTime: wake, targetSleepMinutes: Number(sleepMin),
              });
              setBusy(false);
              if (r.error) toast.push("err", r.error); else toast.push("ok", r.success!);
            }}
          >
            {busy ? <Spinner /> : <><Save className="size-4" /> ذخیرهٔ تنظیمات</>}
          </button>
        </div>
      </Card>

      {/* حساب کاربری */}
      <Card>
        <SectionTitle title="حساب کاربری" subtitle={`نام کاربری: ${username}`} />
        <div className="space-y-4">
          <Field label="نام نمایشی">
            <div className="flex gap-2">
              <input className="input" value={name} onChange={(e) => setName(e.target.value)} />
              <button className="btn btn-soft shrink-0" onClick={async () => {
                const r = await updateProfile({ displayName: name });
                if (r.error) toast.push("err", r.error); else toast.push("ok", r.success!);
              }}>ذخیره</button>
            </div>
          </Field>
          <ChangePassword />
          <form action={logoutAction}>
            <button className="btn w-full"><LogOut className="size-4" /> خروج از حساب</button>
          </form>
        </div>
      </Card>

      {/* داده‌ها */}
      <Card>
        <SectionTitle title="داده‌هایت" subtitle="مالکیت داده با توست" />
        <div className="space-y-3">
          <ExportButton />
          <div className="rounded-xl border p-3" style={{ borderColor: "var(--danger)" }}>
            <p className="text-xs font-bold" style={{ color: "var(--danger)" }}>منطقهٔ خطر</p>
            <p className="mt-1 mb-2 text-[11px] leading-6" style={{ color: "var(--fg-muted)" }}>
              حذف حساب، همهٔ وظایف، اهداف، جلسات، خواب‌ها و عادت‌ها را برای همیشه پاک می‌کند. اول خروجی بگیر.
            </p>
            <DeleteAccountButton />
          </div>
        </div>
      </Card>
    </div>
  );
}

function ExportButton() {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  return (
    <button
      className="btn w-full"
      disabled={busy}
      onClick={async () => {
        setBusy(true);
        const r = await exportData();
        setBusy(false);
        if (r.error || !r.json) { toast.push("err", r.error ?? "خطا در خروجی گرفتن"); return; }
        const blob = new Blob([r.json], { type: "application/json;charset=utf-8" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `lifeos-export-${new Date().toISOString().slice(0, 10)}.json`;
        a.click();
        URL.revokeObjectURL(url);
        toast.push("ok", "فایل خروجی دانلود شد.");
      }}
    >
      {busy ? <Spinner /> : <><Download className="size-4" /> دانلود خروجی کامل (JSON)</>}
    </button>
  );
}

function ChangePassword() {
  const toast = useToast();
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [cur, setCur] = useState("");
  const [nxt, setNxt] = useState("");
  return (
    <>
      <button className="btn w-full" onClick={() => setOpen(true)}><KeyRound className="size-4" /> تغییر رمز عبور</button>
      <Modal open={open} onClose={() => setOpen(false)} title="تغییر رمز عبور">
        <div className="space-y-4">
          <Field label="رمز فعلی">
            <input type="password" className="input" dir="ltr" value={cur} onChange={(e) => setCur(e.target.value)} autoComplete="current-password" />
          </Field>
          <Field label="رمز جدید (حداقل ۸ نویسه)">
            <input type="password" className="input" dir="ltr" value={nxt} onChange={(e) => setNxt(e.target.value)} autoComplete="new-password" />
          </Field>
          <div className="flex justify-end gap-2">
            <button className="btn btn-ghost" onClick={() => setOpen(false)}>انصراف</button>
            <button className="btn btn-primary" disabled={busy}
              onClick={async () => {
                setBusy(true);
                const r = await changePassword({ current: cur, next: nxt });
                setBusy(false);
                if (r.error) { toast.push("err", r.error); return; }
                toast.push("ok", r.success!);
                setCur(""); setNxt(""); setOpen(false);
              }}>
              {busy ? <Spinner /> : "تغییر رمز"}
            </button>
          </div>
        </div>
      </Modal>
    </>
  );
}

function DeleteAccountButton() {
  const toast = useToast();
  const [open, setOpen] = useState(false);
  const [pw, setPw] = useState("");
  const [busy, setBusy] = useState(false);
  return (
    <>
      <button className="btn btn-danger" onClick={() => setOpen(true)}><UserX className="size-4" /> حذف حساب کاربری</button>
      <Modal open={open} onClose={() => setOpen(false)} title="حذف حساب کاربری">
        <div className="space-y-4">
          <p className="text-sm leading-7" style={{ color: "var(--fg-muted)" }}>
            این کار قابل برگشت نیست. برای تأیید، رمز عبورت را وارد کن.
          </p>
          <Field label="رمز عبور">
            <input type="password" className="input" dir="ltr" value={pw} onChange={(e) => setPw(e.target.value)} autoComplete="current-password" />
          </Field>
          <div className="flex justify-end gap-2">
            <button className="btn btn-ghost" onClick={() => setOpen(false)}>انصراف</button>
            <button className="btn btn-danger" disabled={busy}
              onClick={async () => {
                setBusy(true);
                const r = await deleteAccount({ password: pw });
                setBusy(false);
                if (r?.error) toast.push("err", r.error);
              }}>
              {busy ? <Spinner /> : "حذف دائمی حساب"}
            </button>
          </div>
        </div>
      </Modal>
    </>
  );
}
