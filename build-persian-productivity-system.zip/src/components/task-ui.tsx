"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import type { tasks } from "@/db/schema";
import { deleteTaskAction, quickAddTask, rescheduleTaskAction, saveTask, setTaskStatusAction, toggleMitAction } from "@/app/actions/tasks";
import { fa, formatDateShort, formatMinutes } from "@/lib/format";
import { label, options, t } from "@/lib/i18n";
import { describeRecurrence } from "@/lib/recurrence";
import { addDays } from "@/lib/time";
import { ActionForm, DateInput, Field, Select, WeekdayPicker } from "./forms";
import { Modal } from "./modal";
import { usePrefs } from "./prefs";
import type { LinkOptions } from "@/lib/queries";

type Task = typeof tasks.$inferSelect;

export function TaskForm({
  task,
  links,
  defaults,
  onDone,
}: {
  task?: Partial<Task> | null;
  links: LinkOptions;
  defaults?: { dueDate?: string; goalId?: string; projectId?: string };
  onDone?: () => void;
}) {
  const [freq, setFreq] = useState<string>(task?.recurrence?.freq ?? "");
  return (
    <ActionForm action={saveTask} onSuccess={onDone}>
      {task?.id && <input type="hidden" name="id" value={task.id} />}
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="عنوان *" className="sm:col-span-2">
          <input name="title" required maxLength={200} defaultValue={task?.title ?? ""} className="input" autoFocus />
        </Field>
        <DateInput name="dueDate" label="تاریخ سررسید" defaultValue={task?.dueDate ?? defaults?.dueDate ?? null} />
        <Field label="زمان شروع برنامه‌ریزی‌شده">
          <input name="plannedStart" type="time" defaultValue={task?.plannedStart ?? ""} className="input" />
        </Field>
        <Field label="زمان تخمینی (دقیقه)">
          <input name="estimatedMinutes" type="number" min={1} max={1440} defaultValue={task?.estimatedMinutes ?? ""} className="input" />
        </Field>
        <Field label="زمان واقعی (دقیقه)" hint="خالی بگذارید تا از جلسات تمرکز محاسبه شود">
          <input name="actualMinutes" type="number" min={0} max={10000} defaultValue={task?.actualMinutes ?? ""} className="input" />
        </Field>
        <Field label="اولویت">
          <Select name="priority" options={options(t.priority)} defaultValue={task?.priority ?? "medium"} />
        </Field>
        <Field label="وضعیت">
          <Select name="status" options={options(t.taskStatus)} defaultValue={task?.status ?? "todo"} />
        </Field>
        <Field label="دسته‌بندی">
          <input name="category" maxLength={60} defaultValue={task?.category ?? ""} className="input" placeholder="مثلاً کار، درس، خانه" />
        </Field>
        <Field label="انرژی لازم">
          <Select name="energy" options={options(t.energy)} defaultValue={task?.energy ?? ""} empty="مشخص نشده" />
        </Field>
        <Field label="هدف مرتبط">
          <Select name="goalId" options={links.goals.map((g) => ({ value: g.id, label: g.title }))} defaultValue={task?.goalId ?? defaults?.goalId ?? ""} empty="بدون هدف" />
        </Field>
        <Field label="پروژهٔ مرتبط">
          <Select name="projectId" options={links.projects.map((p) => ({ value: p.id, label: p.name }))} defaultValue={task?.projectId ?? defaults?.projectId ?? ""} empty="بدون پروژه" />
        </Field>
        <Field label="برچسب‌ها" hint="با ویرگول جدا کنید" className="sm:col-span-2">
          <input name="tags" defaultValue={(task?.tags ?? []).join("، ")} className="input" />
        </Field>
        <Field label="توضیحات" className="sm:col-span-2">
          <textarea name="description" rows={2} defaultValue={task?.description ?? ""} className="input" />
        </Field>
        <div className="space-y-3 rounded-xl border border-zinc-200 p-3 dark:border-zinc-800 sm:col-span-2">
          <Field label="تکرار">
            <Select
              name="recurFreq"
              options={[
                { value: "daily", label: "روزانه" },
                { value: "weekly", label: "هفتگی" },
                { value: "monthly", label: "ماهانه" },
              ]}
              defaultValue={freq}
              empty="بدون تکرار"
              onChange={setFreq}
            />
          </Field>
          {freq && (
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="هر چند بار" hint="مثلاً ۲ = یک در میان">
                <input name="recurInterval" type="number" min={1} max={52} defaultValue={task?.recurrence?.interval ?? 1} className="input" />
              </Field>
              <DateInput name="recurUntil" label="پایان تکرار (اختیاری)" defaultValue={task?.recurrence?.until ?? null} />
              {freq === "weekly" && (
                <div className="sm:col-span-2">
                  <WeekdayPicker name="recurWeekdays" legend="روزهای هفته" defaultValue={task?.recurrence?.weekdays ?? []} />
                </div>
              )}
              <p className="hint sm:col-span-2">با تکمیل هر نوبت، نوبت بعدی به‌صورت یک کار جدید ساخته می‌شود و سابقهٔ نوبت‌های قبلی دست نمی‌خورد.</p>
            </div>
          )}
        </div>
        <label className="flex items-center gap-2 text-sm sm:col-span-2">
          <input type="checkbox" name="isMit" defaultChecked={task?.isMit ?? false} className="h-4 w-4 accent-[var(--color-accent-600)]" />
          مهم‌ترین کار آن روز
        </label>
        <Field label="یادداشت" className="sm:col-span-2">
          <textarea name="notes" rows={2} defaultValue={task?.notes ?? ""} className="input" />
        </Field>
      </div>
    </ActionForm>
  );
}

export function NewTaskButton({ links, defaults, label: text = "کار جدید", className = "btn btn-primary" }: { links: LinkOptions; defaults?: { dueDate?: string; goalId?: string; projectId?: string }; label?: string; className?: string }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button type="button" className={className} onClick={() => setOpen(true)}>
        + {text}
      </button>
      <Modal open={open} onClose={() => setOpen(false)} title="کار جدید" wide>
        <TaskForm links={links} defaults={defaults} onDone={() => setOpen(false)} />
      </Modal>
    </>
  );
}

export function TaskRow({ task, links, focusMinutes, showDate = true }: { task: Task; links: LinkOptions; focusMinutes?: number; showDate?: boolean }) {
  const { mode, today } = usePrefs();
  const [edit, setEdit] = useState(false);
  const [resched, setResched] = useState(false);
  const [pending, start] = useTransition();
  const router = useRouter();
  const done = task.status === "done";
  const overdue = !done && task.status !== "cancelled" && task.dueDate && task.dueDate < today;
  const actual = task.actualMinutes ?? (focusMinutes ? Math.round(focusMinutes) : null);

  const run = (fn: () => Promise<{ ok: boolean; error?: string }>) =>
    start(async () => {
      const r = await fn();
      if (!r.ok) alert(r.error);
      router.refresh();
    });

  return (
    <li className="group flex items-start gap-3 rounded-xl px-2 py-2.5 hover:bg-zinc-50 dark:hover:bg-zinc-800/40">
      <input
        type="checkbox"
        checked={done}
        disabled={pending || task.status === "cancelled"}
        onChange={() => run(() => setTaskStatusAction(task.id, done ? "todo" : "done"))}
        aria-label={done ? `بازگرداندن «${task.title}» به انجام‌نشده` : `علامت‌گذاری «${task.title}» به‌عنوان انجام‌شده`}
        className="mt-0.5 h-5 w-5 shrink-0 cursor-pointer rounded accent-[var(--color-accent-600)]"
      />
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-1.5">
          {task.isMit && <span title="مهم‌ترین کار" className="text-amber-500" aria-label="مهم‌ترین کار">★</span>}
          <span className={`text-sm font-medium ${done ? "text-zinc-400 line-through" : ""} ${task.status === "cancelled" ? "text-zinc-400 line-through" : ""}`}>{task.title}</span>
          {task.priority !== "medium" && (
            <span className={`text-[11px] ${task.priority === "critical" ? "text-red-600" : task.priority === "high" ? "text-amber-600" : "text-zinc-400"}`}>{label(t.priority, task.priority)}</span>
          )}
          {task.status === "in_progress" && <span className="chip">در حال انجام</span>}
          {task.recurrence && <span className="chip" title={describeRecurrence(task.recurrence)}>↻ {describeRecurrence(task.recurrence)}</span>}
        </div>
        <div className="mt-0.5 flex flex-wrap gap-x-3 gap-y-0.5 text-xs muted">
          {showDate && task.dueDate && <span className={overdue ? "font-medium text-red-600 dark:text-red-400" : ""}>{overdue ? "عقب‌افتاده · " : ""}{formatDateShort(task.dueDate, mode)}</span>}
          {task.plannedStart && <span>ساعت {fa(task.plannedStart)}</span>}
          {(task.estimatedMinutes || actual) && (
            <span>
              تخمین {formatMinutes(task.estimatedMinutes)} {actual ? `· واقعی ${formatMinutes(actual)}` : ""}
            </span>
          )}
          {task.postponeCount > 0 && <span>{fa(task.postponeCount)} بار جابه‌جا شده</span>}
          {task.tags.length > 0 && <span>#{task.tags.join(" #")}</span>}
        </div>
      </div>
      <div className="flex shrink-0 items-center gap-0.5 opacity-100 sm:opacity-60 sm:group-hover:opacity-100 sm:group-focus-within:opacity-100">
        <button type="button" className="icon-btn" aria-label="مهم‌ترین کار روز" title="مهم‌ترین کار روز" onClick={() => run(() => toggleMitAction(task.id))}>
          {task.isMit ? "★" : "☆"}
        </button>
        <button type="button" className="icon-btn" aria-label="زمان‌بندی مجدد" title="زمان‌بندی مجدد" onClick={() => setResched(true)}>
          ⇆
        </button>
        <button type="button" className="icon-btn" aria-label="ویرایش" onClick={() => setEdit(true)}>
          ✎
        </button>
      </div>
      <Modal open={edit} onClose={() => setEdit(false)} title="ویرایش کار" wide>
        <TaskForm task={task} links={links} onDone={() => setEdit(false)} />
        <div className="mt-4 border-t border-zinc-200 pt-4 dark:border-zinc-800">
          <button
            type="button"
            className="btn btn-danger btn-sm"
            onClick={() => {
              if (!confirm(t.common.confirmDelete)) return;
              run(() => deleteTaskAction(task.id));
              setEdit(false);
            }}
          >
            حذف کار
          </button>
        </div>
      </Modal>
      <Modal open={resched} onClose={() => setResched(false)} title="زمان‌بندی مجدد">
        <p className="mb-3 text-sm muted">تاریخ جدید را انتخاب کنید. هیچ کاری بدون تأیید شما جابه‌جا نمی‌شود.</p>
        <div className="mb-3 flex flex-wrap gap-2">
          {[
            { l: "امروز", d: today },
            { l: "فردا", d: addDays(today, 1) },
            { l: "هفتهٔ بعد", d: addDays(today, 7) },
          ].map((o) => (
            <button
              key={o.l}
              type="button"
              className="btn btn-sm"
              onClick={() => {
                run(() => rescheduleTaskAction(task.id, o.d));
                setResched(false);
              }}
            >
              {o.l}
            </button>
          ))}
          <button
            type="button"
            className="btn btn-sm"
            onClick={() => {
              run(() => rescheduleTaskAction(task.id, null));
              setResched(false);
            }}
          >
            بدون تاریخ
          </button>
        </div>
        <DateInput
          name="_resched"
          label="یا تاریخ دلخواه"
          defaultValue={task.dueDate}
          onChange={(v) => {
            if (v) {
              run(() => rescheduleTaskAction(task.id, v));
              setResched(false);
            }
          }}
        />
      </Modal>
    </li>
  );
}

export function QuickTaskForm({ dueDate, placeholder = "افزودن سریع کار و Enter…" }: { dueDate?: string; placeholder?: string }) {
  const [pending, start] = useTransition();
  const [value, setValue] = useState("");
  const router = useRouter();
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        if (!value.trim()) return;
        const fd = new FormData();
        fd.set("title", value);
        if (dueDate) fd.set("dueDate", dueDate);
        start(async () => {
          const r = await quickAddTask(fd);
          if (!r.ok) alert(r.error);
          else setValue("");
          router.refresh();
        });
      }}
      className="flex gap-2"
    >
      <label className="sr-only" htmlFor="quick-task">
        افزودن سریع کار
      </label>
      <input id="quick-task" value={value} onChange={(e) => setValue(e.target.value)} placeholder={placeholder} maxLength={200} className="input" />
      <button type="submit" className="btn btn-primary shrink-0" disabled={pending || !value.trim()}>
        افزودن
      </button>
    </form>
  );
}
