"use client";

import React, { useState } from "react";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { Modal, Confirm, Field, RatingInput, Spinner, useToast } from "@/components/ui";
import { JalaliDatePicker, TimeField } from "@/components/pickers";
import { saveSleep, deleteSleep } from "@/lib/actions-life";
import { isoOfJalali, jalaliOfIso, todayIso, addDaysIso } from "@/lib/jalali";

export type SleepRow = {
  id: string; wakeDate: string;
  bedTime: string; wakeTime: string; durationMinutes: number | null;
  quality: number | null; morningEnergy: number | null; awakenings: number | null; notes: string | null;
};

function toLocalIsoAndTime(isoUtc: string, tz: string): { iso: string; time: string } {
  const d = new Date(isoUtc);
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", hourCycle: "h23",
  }).formatToParts(d);
  const get = (t: string) => parts.find((p) => p.type === t)?.value ?? "";
  return {
    iso: `${get("year")}-${get("month")}-${get("day")}`,
    time: `${get("hour") === "24" ? "00" : get("hour")}:${get("minute")}`,
  };
}

export function SleepFormButton({ edit, tz, targets }: {
  edit?: SleepRow; tz: string;
  targets: { bed: string; wake: string };
}) {
  const toast = useToast();
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);

  const today = todayIso(tz);
  const parsed = edit ? {
    bed: toLocalIsoAndTime(edit.bedTime, tz),
    wake: toLocalIsoAndTime(edit.wakeTime, tz),
  } : null;

  const [bedDate, setBedDate] = useState<string | null>(parsed?.bed.iso ?? addDaysIso(today, -1));
  const [bedTime, setBedTime] = useState(parsed?.bed.time ?? targets.bed);
  const [wakeDate, setWakeDate] = useState<string | null>(parsed?.wake.iso ?? today);
  const [wakeTime, setWakeTime] = useState(parsed?.wake.time ?? targets.wake);
  const [latency, setLatency] = useState("");
  const [quality, setQuality] = useState<number | null>(edit?.quality ?? null);
  const [energy, setEnergy] = useState<number | null>(edit?.morningEnergy ?? null);
  const [awakenings, setAwakenings] = useState(edit?.awakenings != null ? String(edit.awakenings) : "");
  const [notes, setNotes] = useState(edit?.notes ?? "");
  const [error, setError] = useState<string | null>(null);

  return (
    <>
      {edit ? (
        <button className="btn btn-ghost !min-h-0 !p-1.5" onClick={() => setOpen(true)} aria-label="ویرایش رکورد خواب">
          <Pencil className="size-3.5" />
        </button>
      ) : (
        <button className="btn btn-primary" onClick={() => setOpen(true)}>
          <Plus className="size-4" /> ثبت خواب
        </button>
      )}
      <Modal open={open} onClose={() => setOpen(false)} title={edit ? "ویرایش رکورد خواب" : "ثبت خواب دیشب"} wide>
        <form
          className="space-y-4"
          onSubmit={async (e) => {
            e.preventDefault();
            setBusy(true);
            setError(null);
            const r = await saveSleep({
              id: edit?.id, bedDate, bedTime, wakeDate, wakeTime,
              fallAsleepMinutes: latency ? Number(latency) : null,
              quality, morningEnergy: energy, awakenings: awakenings ? Number(awakenings) : null,
              notes,
            });
            setBusy(false);
            if (r.error) { setError(r.error); return; }
            toast.push("ok", r.success!);
            setOpen(false);
          }}
        >
          <p className="rounded-xl px-3 py-2 text-[11px] leading-6" style={{ background: "var(--bg-soft)", color: "var(--fg-muted)" }}>
            این داده‌ها تخمینِ دستیِ خودتان است و هدف آگاهی شخصی است، نه اندازه‌گیری پزشکی. اگر خوابتان از نیمه‌شب رد می‌شود فقط تاریخ و ساعت‌ها را درست وارد کنید؛ سیستم خودش حساب می‌کند.
          </p>
          <div className="grid grid-cols-2 gap-4">
            <Field label="تاریخ خوابیدن">
              <JalaliDatePicker value={bedDate} onChange={setBedDate} clearable={false} />
            </Field>
            <Field label="ساعت خوابیدن">
              <TimeField value={bedTime} onChange={setBedTime} />
            </Field>
            <Field label="تاریخ بیدار شدن">
              <JalaliDatePicker value={wakeDate} onChange={setWakeDate} clearable={false} />
            </Field>
            <Field label="ساعت بیدار شدن">
              <TimeField value={wakeTime} onChange={setWakeTime} />
            </Field>
          </div>
          <Field label="چقدر طول کشید به خواب بروید؟ (دقیقه)" hint="با این مقدار، مدت خواب واقعی دقیق‌تر تخمین زده می‌شود">
            <input className="input" type="number" min={0} max={300} inputMode="numeric" value={latency} onChange={(e) => setLatency(e.target.value)} placeholder="مثلاً ۱۵" />
          </Field>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <Field label="کیفیت خواب">
              <RatingInput value={quality} onChange={setQuality} labels={["بد", "ضعیف", "معمولی", "خوب", "عالی"]} />
            </Field>
            <Field label="انرژی صبحگاهی">
              <RatingInput value={energy} onChange={setEnergy} labels={["کسل", "کم", "معمولی", "خوب", "سرحال"]} />
            </Field>
            <Field label="تعداد بیدار شدن در شب (اختیاری)">
              <input className="input" type="number" min={0} max={50} inputMode="numeric" value={awakenings} onChange={(e) => setAwakenings(e.target.value)} />
            </Field>
          </div>
          <Field label="یادداشت">
            <textarea className="input min-h-12" value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="مثلاً: دیر خوابیدم چون سریال دیدم" />
          </Field>
          {error && (
            <p className="rounded-xl px-3 py-2 text-xs font-medium" style={{ background: "var(--danger-soft)", color: "var(--danger)" }} role="alert">{error}</p>
          )}
          <div className="flex justify-end gap-2">
            <button type="button" className="btn btn-ghost" onClick={() => setOpen(false)}>انصراف</button>
            <button type="submit" className="btn btn-primary" disabled={busy}>{busy ? <Spinner /> : "ثبت خواب"}</button>
          </div>
        </form>
      </Modal>
    </>
  );
}

export function SleepDeleteButton({ id }: { id: string }) {
  const toast = useToast();
  const [open, setOpen] = useState(false);
  return (
    <>
      <button className="btn btn-ghost !min-h-0 !p-1.5" onClick={() => setOpen(true)} aria-label="حذف رکورد خواب">
        <Trash2 className="size-3.5" />
      </button>
      <Confirm
        open={open} onClose={() => setOpen(false)}
        title="حذف رکورد خواب"
        message="این رکورد حذف می‌شود و از میانگین‌ها کم می‌شود. مطمئنی؟"
        danger
        onConfirm={async () => {
          const r = await deleteSleep(id);
          if (r.error) toast.push("err", r.error); else toast.push("ok", "حذف شد.");
        }}
      />
    </>
  );
}
