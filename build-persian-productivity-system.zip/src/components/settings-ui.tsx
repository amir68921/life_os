"use client";

import { useActionState } from "react";
import { changePasswordAction, deleteAccountAction } from "@/app/actions/auth";
import { saveSettings } from "@/app/actions/settings";
import type { Prefs } from "@/lib/auth";
import { WEEKDAYS_FA } from "@/lib/jalali";
import { COMMON_TIMEZONES } from "@/lib/time";
import { ActionForm, Field, Select } from "./forms";

const WIDGETS = [
  { value: "tasks", label: "کارهای امروز" },
  { value: "focus", label: "تمرکز" },
  { value: "sleep", label: "خواب" },
  { value: "habits", label: "عادت‌ها" },
  { value: "goals", label: "اهداف" },
  { value: "deadlines", label: "سررسیدها" },
];

export function SettingsForm({ prefs, name }: { prefs: Prefs; name: string }) {
  const tzs = COMMON_TIMEZONES.includes(prefs.timezone) ? COMMON_TIMEZONES : [prefs.timezone, ...COMMON_TIMEZONES];
  return (
    <ActionForm action={saveSettings} submitLabel="ذخیرهٔ تنظیمات">
      <div className="space-y-6">
        <section className="grid gap-4 sm:grid-cols-2">
          <h3 className="section-title sm:col-span-2">عمومی</h3>
          <Field label="نام نمایشی"><input name="name" defaultValue={name} maxLength={80} className="input" /></Field>
          <Field label="زبان" hint="انگلیسی در نسخه‌های بعدی اضافه می‌شود">
            <Select name="language" options={[{ value: "fa", label: "فارسی" }]} defaultValue={prefs.language} />
          </Field>
          <Field label="پوسته">
            <Select name="theme" options={[{ value: "system", label: "مطابق سیستم" }, { value: "light", label: "روشن" }, { value: "dark", label: "تیره" }]} defaultValue={prefs.theme} />
          </Field>
          <Field label="منطقهٔ زمانی" hint="روزها، آمار و ثبت‌ها بر اساس این منطقه محاسبه می‌شوند">
            <input name="timezone" list="tz-list" defaultValue={prefs.timezone} className="input" dir="ltr" />
            <datalist id="tz-list">{tzs.map((z) => <option key={z} value={z} />)}</datalist>
          </Field>
          <Field label="تقویم و قالب تاریخ">
            <Select name="dateFormat" options={[{ value: "jalali", label: "شمسی (جلالی)" }, { value: "gregorian", label: "میلادی" }]} defaultValue={prefs.dateFormat} />
          </Field>
          <Field label="شروع هفته">
            <Select name="weekStart" options={[6, 0, 1].map((d) => ({ value: String(d), label: WEEKDAYS_FA[d] }))} defaultValue={String(prefs.weekStart)} />
          </Field>
        </section>
        <section className="grid gap-4 sm:grid-cols-2">
          <h3 className="section-title sm:col-span-2">تمرکز</h3>
          <Field label="مدت پیش‌فرض جلسه (دقیقه)"><input name="focusMinutes" type="number" min={1} max={480} defaultValue={prefs.focusMinutes} className="input" /></Field>
          <Field label="مدت پیش‌فرض استراحت (دقیقه)"><input name="breakMinutes" type="number" min={0} max={120} defaultValue={prefs.breakMinutes} className="input" /></Field>
        </section>
        <section className="grid gap-4 sm:grid-cols-3">
          <h3 className="section-title sm:col-span-3">اهداف خواب</h3>
          <Field label="زمان هدف خواب"><input name="sleepTargetBed" type="time" defaultValue={prefs.sleepTargetBed} className="input" /></Field>
          <Field label="زمان هدف بیداری"><input name="sleepTargetWake" type="time" defaultValue={prefs.sleepTargetWake} className="input" /></Field>
          <Field label="مدت هدف خواب (دقیقه)"><input name="sleepTargetMinutes" type="number" min={180} max={900} defaultValue={prefs.sleepTargetMinutes} className="input" /></Field>
        </section>
        <fieldset className="space-y-2">
          <legend className="section-title mb-2">اعلان‌ها</legend>
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="notifyFocusEnd" defaultChecked={prefs.notifications.focusEnd} className="h-4 w-4 accent-[var(--color-accent-600)]" /> صدا و اعلان مرورگر در پایان جلسهٔ تمرکز و استراحت</label>
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="notifyDailyReview" defaultChecked={prefs.notifications.dailyReview} className="h-4 w-4 accent-[var(--color-accent-600)]" /> یادآوری مرور روزانه <span className="chip">هنوز در دسترس نیست</span></label>
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" name="notifyHabitReminder" defaultChecked={prefs.notifications.habitReminder} className="h-4 w-4 accent-[var(--color-accent-600)]" /> یادآوری عادت‌ها <span className="chip">هنوز در دسترس نیست</span></label>
          <p className="hint">یادآوری‌های زمان‌بندی‌شده به سرویس اعلان پس‌زمینه نیاز دارند و در این نسخه ارسال نمی‌شوند؛ ترجیح شما ذخیره می‌شود.</p>
        </fieldset>
        <fieldset>
          <legend className="section-title mb-2">ویجت‌های داشبورد</legend>
          <div className="flex flex-wrap gap-2">
            {WIDGETS.map((w) => (
              <label key={w.value} className="chip cursor-pointer py-1.5">
                <input type="checkbox" name="widgets" value={w.value} defaultChecked={prefs.dashboardWidgets.includes(w.value)} className="accent-[var(--color-accent-600)]" />
                {w.label}
              </label>
            ))}
          </div>
        </fieldset>
      </div>
    </ActionForm>
  );
}

export function PasswordForm() {
  const [state, action, pending] = useActionState(changePasswordAction, undefined);
  return (
    <form action={action} className="grid gap-3 sm:grid-cols-3 sm:items-end">
      <Field label="رمز فعلی"><input name="current" type="password" required autoComplete="current-password" className="input" /></Field>
      <Field label="رمز جدید"><input name="next" type="password" required minLength={8} autoComplete="new-password" className="input" /></Field>
      <button className="btn" disabled={pending}>تغییر رمز</button>
      {state?.error && <p role="alert" className="text-sm text-red-600 sm:col-span-3">{state.error}</p>}
      {state?.ok && <p role="status" className="text-sm text-accent-700 sm:col-span-3">رمز عبور تغییر کرد.</p>}
    </form>
  );
}

export function DeleteAccountForm() {
  const [state, action, pending] = useActionState(deleteAccountAction, undefined);
  return (
    <form action={action} className="grid gap-3 sm:grid-cols-3 sm:items-end">
      <Field label="رمز عبور"><input name="password" type="password" required autoComplete="current-password" className="input" /></Field>
      <Field label="برای تأیید بنویسید: حذف"><input name="confirm" required className="input" /></Field>
      <button className="btn btn-danger" disabled={pending}>حذف دائمی حساب و همهٔ داده‌ها</button>
      {state?.error && <p role="alert" className="text-sm text-red-600 sm:col-span-3">{state.error}</p>}
    </form>
  );
}
