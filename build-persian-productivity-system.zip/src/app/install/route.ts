// One-line Ubuntu installer:  wget -qO- https://<this-host>/install | bash
// Downloads the full project snapshot (public/lifeos.tar.gz) and runs scripts/setup-ubuntu.sh.
export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const host = request.headers.get("x-forwarded-host") ?? request.headers.get("host") ?? url.host;
  const proto = (request.headers.get("x-forwarded-proto") ?? url.protocol.replace(":", "")).split(",")[0].trim();
  const base = `${proto}://${host}`.replace(/[^A-Za-z0-9:/._-]/g, "");

  const script = `#!/usr/bin/env bash
# LIFE OS - one-line installer for Ubuntu
set -euo pipefail
ARCHIVE_URL="${base}/lifeos.tar.gz"
DEST="\${LIFEOS_DIR:-$HOME/lifeos}"

if [ "$(id -u)" -eq 0 ]; then
  echo "Run this as your normal user, without sudo." >&2; exit 1
fi

echo "==> Downloading LIFE OS from $ARCHIVE_URL"
TMP="$(mktemp -d)"
if command -v wget >/dev/null 2>&1; then
  wget -q --show-progress -O "$TMP/lifeos.tar.gz" "$ARCHIVE_URL"
elif command -v curl >/dev/null 2>&1; then
  curl -fL --progress-bar -o "$TMP/lifeos.tar.gz" "$ARCHIVE_URL"
else
  echo "Neither wget nor curl is installed. Run: sudo apt install -y wget" >&2; exit 1
fi

echo "==> Extracting to $DEST"
mkdir -p "$DEST"
# Keeps existing .env, node_modules and backups when updating
tar -xzf "$TMP/lifeos.tar.gz" -C "$DEST"
rm -rf "$TMP"
chmod +x "$DEST"/scripts/*.sh

MODE="--service"
if [ -d "$DEST/.next" ] && [ -f /etc/systemd/system/lifeos.service ]; then MODE="--app-only"; fi

echo "==> Running installer ($MODE)"
cd "$DEST"
if { : < /dev/tty; } 2>/dev/null; then
  exec ./scripts/setup-ubuntu.sh $MODE < /dev/tty
else
  exec ./scripts/setup-ubuntu.sh $MODE
fi
`;
  return new Response(script, {
    headers: { "Content-Type": "text/x-shellscript; charset=utf-8", "Cache-Control": "no-store" },
  });
}
