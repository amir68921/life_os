import { eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import {
  activities,
  dailyReviews,
  focusSessions,
  goalProgressLog,
  goals,
  habitOccurrences,
  habitPauses,
  habits,
  interruptions,
  milestones,
  notes,
  preferences,
  projectGoals,
  projects,
  sleepRecords,
  tasks,
  timeBlocks,
  users,
  weeklyReviews,
} from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

/** Full JSON export of the authenticated user's data (password hash & sessions excluded). */
export async function GET() {
  const user = await getCurrentUser();
  if (!user) return Response.json({ error: "unauthorized" }, { status: 401 });
  const uid = user.id;
  const [account, prefs, g, gl, p, m, tk, tb, fs, it, sl, h, ho, act, n, dr, wr] = await Promise.all([
    db.select({ id: users.id, email: users.email, name: users.name, createdAt: users.createdAt }).from(users).where(eq(users.id, uid)),
    db.select().from(preferences).where(eq(preferences.userId, uid)),
    db.select().from(goals).where(eq(goals.userId, uid)),
    db.select().from(goalProgressLog).where(eq(goalProgressLog.userId, uid)),
    db.select().from(projects).where(eq(projects.userId, uid)),
    db.select().from(milestones).where(eq(milestones.userId, uid)),
    db.select().from(tasks).where(eq(tasks.userId, uid)),
    db.select().from(timeBlocks).where(eq(timeBlocks.userId, uid)),
    db.select().from(focusSessions).where(eq(focusSessions.userId, uid)),
    db.select().from(interruptions).where(eq(interruptions.userId, uid)),
    db.select().from(sleepRecords).where(eq(sleepRecords.userId, uid)),
    db.select().from(habits).where(eq(habits.userId, uid)),
    db.select().from(habitOccurrences).where(eq(habitOccurrences.userId, uid)),
    db.select().from(activities).where(eq(activities.userId, uid)),
    db.select().from(notes).where(eq(notes.userId, uid)),
    db.select().from(dailyReviews).where(eq(dailyReviews.userId, uid)),
    db.select().from(weeklyReviews).where(eq(weeklyReviews.userId, uid)),
  ]);
  const habitIds = h.map((x) => x.id);
  const projectIds = p.map((x) => x.id);
  const [hp, pg] = await Promise.all([
    habitIds.length ? db.select().from(habitPauses).where(inArray(habitPauses.habitId, habitIds)) : Promise.resolve([]),
    projectIds.length ? db.select().from(projectGoals).where(inArray(projectGoals.projectId, projectIds)) : Promise.resolve([]),
  ]);
  const body = {
    format: "lifeos-export",
    version: 1,
    exportedAt: new Date().toISOString(),
    account: account[0],
    preferences: prefs[0],
    goals: g,
    goalProgressLog: gl,
    projects: p,
    projectGoals: pg,
    milestones: m,
    tasks: tk,
    timeBlocks: tb,
    focusSessions: fs,
    interruptions: it,
    sleepRecords: sl,
    habits: h,
    habitPauses: hp,
    habitOccurrences: ho,
    activities: act,
    notes: n,
    dailyReviews: dr,
    weeklyReviews: wr,
  };
  return new Response(JSON.stringify(body, null, 2), {
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Content-Disposition": `attachment; filename="lifeos-export-${new Date().toISOString().slice(0, 10)}.json"`,
      "Cache-Control": "no-store",
    },
  });
}
