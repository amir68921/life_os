"use server";

import { revalidatePath } from "next/cache";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { preferences, users } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { fail, reader, ValidationError, type ActionResult } from "@/lib/server-utils";
import { isValidTimeZone } from "@/lib/time";

const WIDGETS = ["tasks", "focus", "sleep", "habits", "goals", "deadlines"];

export async function saveSettings(formData: FormData): Promise<ActionResult> {
  try {
    const user = await requireUser();
    const r = reader(formData);
    const timezone = r.str("timezone", "منطقهٔ زمانی", 64);
    if (!isValidTimeZone(timezone)) throw new ValidationError("منطقهٔ زمانی معتبر نیست.");
    const values = {
      language: r.oneOf("language", ["fa"] as const, "fa"),
      theme: r.oneOf("theme", ["light", "dark", "system"] as const, "system"),
      timezone,
      dateFormat: r.oneOf("dateFormat", ["jalali", "gregorian"] as const, "jalali"),
      weekStart: r.int("weekStart", "شروع هفته", 0, 6),
      focusMinutes: r.int("focusMinutes", "مدت پیش‌فرض تمرکز", 1, 480),
      breakMinutes: r.int("breakMinutes", "مدت پیش‌فرض استراحت", 0, 120),
      sleepTargetBed: r.time("sleepTargetBed", "زمان هدف خواب"),
      sleepTargetWake: r.time("sleepTargetWake", "زمان هدف بیداری"),
      sleepTargetMinutes: r.int("sleepTargetMinutes", "مدت هدف خواب", 180, 900),
      notifications: {
        focusEnd: r.bool("notifyFocusEnd"),
        dailyReview: r.bool("notifyDailyReview"),
        habitReminder: r.bool("notifyHabitReminder"),
      },
      dashboardWidgets: formData
        .getAll("widgets")
        .map(String)
        .filter((w) => WIDGETS.includes(w)),
      updatedAt: new Date(),
    };
    await db
      .insert(preferences)
      .values({ ...values, userId: user.id })
      .onConflictDoUpdate({ target: preferences.userId, set: values });
    const name = r.optStr("name", 80);
    if (name) await db.update(users).set({ name }).where(eq(users.id, user.id));
    revalidatePath("/", "layout");
    return { ok: true };
  } catch (e) {
    return fail(e);
  }
}

export async function setThemeAction(theme: string): Promise<ActionResult> {
  try {
    const user = await requireUser();
    if (!["light", "dark", "system"].includes(theme)) return { ok: false, error: "نامعتبر" };
    await db.update(preferences).set({ theme, updatedAt: new Date() }).where(eq(preferences.userId, user.id));
    revalidatePath("/", "layout");
    return { ok: true };
  } catch (e) {
    return fail(e);
  }
}
