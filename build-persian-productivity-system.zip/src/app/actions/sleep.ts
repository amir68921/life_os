"use server";

import { revalidatePath } from "next/cache";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { sleepRecords } from "@/db/schema";
import { requireContext } from "@/lib/auth";
import { fail, reader, ValidationError, type ActionResult } from "@/lib/server-utils";
import { estimateSleepMinutes } from "@/lib/sleep";
import { addDays, hhmmToMinutes, zonedToUtc } from "@/lib/time";

const revalidate = () => ["/", "/sleep", "/analytics", "/weekly"].forEach((p) => revalidatePath(p));

/**
 * The user enters the wake-up date plus clock times. If the bedtime clock is
 * later than the wake clock (e.g. 23:30 → 07:00) the bedtime is placed on the
 * previous day, so nights crossing midnight are handled automatically.
 */
export async function saveSleep(formData: FormData): Promise<ActionResult> {
  try {
    const { user, tz } = await requireContext();
    const r = reader(formData);
    const id = r.uuid("id");
    const wakeDate = r.date("wakeDate", "تاریخ بیداری");
    const bedStr = r.time("bedTime", "زمان رفتن به رختخواب");
    const wakeStr = r.time("wakeTime", "زمان بیداری");
    const asleepStr = r.optTime("sleepStart", "زمان به خواب رفتن");
    const wakeMin = hhmmToMinutes(wakeStr);
    const placeDate = (clock: string) => (hhmmToMinutes(clock) >= wakeMin ? addDays(wakeDate, -1) : wakeDate);
    const bedTime = zonedToUtc(placeDate(bedStr), bedStr, tz);
    const wakeTime = zonedToUtc(wakeDate, wakeStr, tz);
    let sleepStart = asleepStr ? zonedToUtc(placeDate(asleepStr), asleepStr, tz) : null;
    if (sleepStart && sleepStart < bedTime) sleepStart = bedTime;
    if (wakeTime.getTime() - bedTime.getTime() > 20 * 3600000) throw new ValidationError("مدت خواب بیش از ۲۰ ساعت است؛ زمان‌ها را بررسی کنید.");
    const override = r.optInt("durationMinutes", "مدت خواب", 0, 1200);
    const values = {
      wakeDate,
      bedTime,
      sleepStart,
      wakeTime,
      durationMinutes: override ?? estimateSleepMinutes(bedTime, sleepStart, wakeTime),
      quality: r.optInt("quality", "کیفیت خواب", 1, 5),
      morningEnergy: r.optInt("morningEnergy", "انرژی صبح", 1, 5),
      awakenings: r.optInt("awakenings", "دفعات بیداری", 0, 50),
      notes: r.optStr("notes", 2000),
      updatedAt: new Date(),
    };
    if (id) {
      const res = await db
        .update(sleepRecords)
        .set(values)
        .where(and(eq(sleepRecords.id, id), eq(sleepRecords.userId, user.id)))
        .returning({ id: sleepRecords.id });
      if (!res.length) return { ok: false, error: "رکورد پیدا نشد." };
    } else {
      const [exists] = await db
        .select({ id: sleepRecords.id })
        .from(sleepRecords)
        .where(and(eq(sleepRecords.userId, user.id), eq(sleepRecords.wakeDate, wakeDate)))
        .limit(1);
      if (exists) return { ok: false, error: "برای این تاریخ قبلاً خواب ثبت شده است؛ همان رکورد را ویرایش کنید." };
      await db.insert(sleepRecords).values({ ...values, userId: user.id, source: "manual" });
    }
    revalidate();
    return { ok: true };
  } catch (e) {
    return fail(e);
  }
}

export async function deleteSleep(id: string): Promise<ActionResult> {
  try {
    const { user } = await requireContext();
    await db.delete(sleepRecords).where(and(eq(sleepRecords.id, id), eq(sleepRecords.userId, user.id)));
    revalidate();
    return { ok: true };
  } catch (e) {
    return fail(e);
  }
}
