"use server";

import { revalidatePath } from "next/cache";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { goalProgressLog, goals, milestones } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { fail, ownedLinks, reader, ValidationError, type ActionResult } from "@/lib/server-utils";

const revalidate = () => ["/", "/goals", "/projects", "/analytics", "/weekly"].forEach((p) => revalidatePath(p, "layout"));

export async function saveGoal(formData: FormData): Promise<ActionResult> {
  try {
    const user = await requireUser();
    const r = reader(formData);
    const id = r.uuid("id");
    let parentId = (await ownedLinks(user.id, { goalId: r.uuid("parentId") })).goalId;
    if (id && parentId === id) parentId = null;
    const values = {
      title: r.str("title", "عنوان", 200),
      description: r.optStr("description", 5000),
      category: r.optStr("category", 60),
      horizon: r.oneOf("horizon", ["long", "medium", "short"] as const, "medium"),
      startDate: r.optDate("startDate", "تاریخ شروع"),
      targetDate: r.optDate("targetDate", "تاریخ هدف"),
      priority: r.oneOf("priority", ["low", "medium", "high", "critical"] as const, "medium"),
      status: r.oneOf("status", ["active", "paused", "completed", "archived", "abandoned"] as const, "active"),
      successCriteria: r.optStr("successCriteria", 3000),
      progress: r.optInt("progress", "پیشرفت", 0, 100) ?? 0,
      notes: r.optStr("notes", 10000),
      parentId,
    };
    if (values.startDate && values.targetDate && values.targetDate < values.startDate)
      throw new ValidationError("تاریخ هدف نمی‌تواند قبل از تاریخ شروع باشد.");
    const savedId = await db.transaction(async (tx) => {
      if (id) {
        const [prev] = await tx.select().from(goals).where(and(eq(goals.id, id), eq(goals.userId, user.id))).limit(1);
        if (!prev) throw new ValidationError("هدف پیدا نشد.");
        await tx
          .update(goals)
          .set({ ...values, archivedAt: values.status === "archived" ? (prev.archivedAt ?? new Date()) : null, updatedAt: new Date() })
          .where(and(eq(goals.id, id), eq(goals.userId, user.id)));
        if (prev.progress !== values.progress)
          await tx.insert(goalProgressLog).values({ userId: user.id, goalId: id, progress: values.progress });
        return id;
      }
      const [g] = await tx.insert(goals).values({ ...values, userId: user.id }).returning({ id: goals.id });
      await tx.insert(goalProgressLog).values({ userId: user.id, goalId: g.id, progress: values.progress });
      return g.id;
    });
    revalidate();
    return { ok: true, id: savedId };
  } catch (e) {
    return fail(e);
  }
}

export async function setGoalProgress(id: string, progress: number): Promise<ActionResult> {
  try {
    const user = await requireUser();
    const p = Math.max(0, Math.min(100, Math.round(progress)));
    await db.transaction(async (tx) => {
      const r = await tx
        .update(goals)
        .set({ progress: p, updatedAt: new Date() })
        .where(and(eq(goals.id, id), eq(goals.userId, user.id)))
        .returning({ id: goals.id });
      if (!r.length) throw new ValidationError("هدف پیدا نشد.");
      await tx.insert(goalProgressLog).values({ userId: user.id, goalId: id, progress: p });
    });
    revalidate();
    return { ok: true };
  } catch (e) {
    return fail(e);
  }
}

export async function archiveGoal(id: string, archive: boolean): Promise<ActionResult> {
  try {
    const user = await requireUser();
    await db
      .update(goals)
      .set({ status: archive ? "archived" : "active", archivedAt: archive ? new Date() : null, updatedAt: new Date() })
      .where(and(eq(goals.id, id), eq(goals.userId, user.id)));
    revalidate();
    return { ok: true };
  } catch (e) {
    return fail(e);
  }
}

/**
 * Deleting a goal removes its milestones and progress log, but linked tasks,
 * focus sessions, activities and notes are preserved (their goal link is set
 * to null by the FK), and child goals are detached rather than deleted.
 */
export async function deleteGoal(id: string): Promise<ActionResult> {
  try {
    const user = await requireUser();
    await db.transaction(async (tx) => {
      await tx.update(goals).set({ parentId: null }).where(and(eq(goals.userId, user.id), eq(goals.parentId, id)));
      await tx.delete(goals).where(and(eq(goals.id, id), eq(goals.userId, user.id)));
    });
    revalidate();
    return { ok: true };
  } catch (e) {
    return fail(e);
  }
}

export async function addMilestone(formData: FormData): Promise<ActionResult> {
  try {
    const user = await requireUser();
    const r = reader(formData);
    const links = await ownedLinks(user.id, { goalId: r.uuid("goalId"), projectId: r.uuid("projectId") });
    if (!links.goalId && !links.projectId) throw new ValidationError("نقطهٔ عطف باید به یک هدف یا پروژه متصل باشد.");
    await db.insert(milestones).values({
      userId: user.id,
      goalId: links.goalId,
      projectId: links.projectId,
      title: r.str("title", "عنوان نقطهٔ عطف", 200),
      dueDate: r.optDate("dueDate", "سررسید"),
    });
    revalidate();
    return { ok: true };
  } catch (e) {
    return fail(e);
  }
}

export async function toggleMilestone(id: string): Promise<ActionResult> {
  try {
    const user = await requireUser();
    const [m] = await db.select().from(milestones).where(and(eq(milestones.id, id), eq(milestones.userId, user.id))).limit(1);
    if (!m) return { ok: false, error: "پیدا نشد." };
    await db.update(milestones).set({ completedAt: m.completedAt ? null : new Date() }).where(eq(milestones.id, id));
    revalidate();
    return { ok: true };
  } catch (e) {
    return fail(e);
  }
}

export async function deleteMilestone(id: string): Promise<ActionResult> {
  try {
    const user = await requireUser();
    await db.delete(milestones).where(and(eq(milestones.id, id), eq(milestones.userId, user.id)));
    revalidate();
    return { ok: true };
  } catch (e) {
    return fail(e);
  }
}
