"use server";

import { revalidatePath } from "next/cache";
import { and, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { activities, focusSessions, interruptions } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { clampFocused, elapsedSeconds, resumedPausedSeconds } from "@/lib/focus";
import { fail, ownedLinks, reader, ValidationError, type ActionResult } from "@/lib/server-utils";

const revalidate = () => ["/", "/focus", "/analytics", "/activity", "/weekly"].forEach((p) => revalidatePath(p));

export type FocusSessionDTO = typeof focusSessions.$inferSelect;

async function getOwned(userId: string, id: string) {
  const [s] = await db.select().from(focusSessions).where(and(eq(focusSessions.id, id), eq(focusSessions.userId, userId))).limit(1);
  return s ?? null;
}

export async function startFocus(formData: FormData): Promise<ActionResult<FocusSessionDTO>> {
  try {
    const user = await requireUser();
    const r = reader(formData);
    const clientId = r.uuid("clientId");
    if (!clientId) throw new ValidationError("شناسهٔ جلسه نامعتبر است.");
    // Idempotency: if this clientId was already used, return the existing session.
    const [dup] = await db
      .select()
      .from(focusSessions)
      .where(and(eq(focusSessions.userId, user.id), eq(focusSessions.clientId, clientId)))
      .limit(1);
    if (dup) return { ok: true, id: dup.id, data: dup };
    const [active] = await db
      .select()
      .from(focusSessions)
      .where(and(eq(focusSessions.userId, user.id), inArray(focusSessions.status, ["running", "paused"])))
      .limit(1);
    if (active) return { ok: false, error: "یک جلسهٔ تمرکز فعال دارید. ابتدا آن را تمام یا لغو کنید." };
    const links = await ownedLinks(user.id, { taskId: r.uuid("taskId"), projectId: r.uuid("projectId"), goalId: r.uuid("goalId") });
    const [s] = await db
      .insert(focusSessions)
      .values({
        userId: user.id,
        clientId,
        taskId: links.taskId,
        projectId: links.projectId,
        goalId: links.goalId,
        objective: r.optStr("objective", 500),
        plannedMinutes: r.int("plannedMinutes", "مدت جلسه", 1, 480),
        breakMinutes: r.optInt("breakMinutes", "مدت استراحت", 0, 120) ?? 0,
        energyBefore: r.optInt("energyBefore", "انرژی", 1, 5),
        focusBefore: r.optInt("focusBefore", "آمادگی تمرکز", 1, 5),
        startedAt: new Date(),
        status: "running",
      })
      .returning();
    revalidate();
    return { ok: true, id: s.id, data: s };
  } catch (e) {
    return fail(e) as ActionResult<FocusSessionDTO>;
  }
}

export async function pauseFocus(id: string): Promise<ActionResult<FocusSessionDTO>> {
  try {
    const user = await requireUser();
    const s = await getOwned(user.id, id);
    if (!s) return { ok: false, error: "جلسه پیدا نشد." };
    if (s.status !== "running") return { ok: true, data: s };
    const [u] = await db.update(focusSessions).set({ status: "paused", pausedAt: new Date(), updatedAt: new Date() }).where(eq(focusSessions.id, id)).returning();
    return { ok: true, data: u };
  } catch (e) {
    return fail(e) as ActionResult<FocusSessionDTO>;
  }
}

export async function resumeFocus(id: string): Promise<ActionResult<FocusSessionDTO>> {
  try {
    const user = await requireUser();
    const s = await getOwned(user.id, id);
    if (!s) return { ok: false, error: "جلسه پیدا نشد." };
    if (s.status !== "paused") return { ok: true, data: s };
    const [u] = await db
      .update(focusSessions)
      .set({ status: "running", pausedSeconds: resumedPausedSeconds(s), pausedAt: null, updatedAt: new Date() })
      .where(eq(focusSessions.id, id))
      .returning();
    return { ok: true, data: u };
  } catch (e) {
    return fail(e) as ActionResult<FocusSessionDTO>;
  }
}

/**
 * Completes a session. Elapsed time is measured on the server from stored
 * timestamps (pauses excluded). A matching activity-log entry is created in the
 * same transaction; the unique index on focus_session_id prevents duplicates.
 * Calling finish twice is safe (idempotent).
 */
export async function finishFocus(id: string, auto = false): Promise<ActionResult<FocusSessionDTO>> {
  try {
    const user = await requireUser();
    const result = await db.transaction(async (tx) => {
      const [s] = await tx
        .select()
        .from(focusSessions)
        .where(and(eq(focusSessions.id, id), eq(focusSessions.userId, user.id)))
        .for("update")
        .limit(1);
      if (!s) throw new ValidationError("جلسه پیدا نشد.");
      if (s.status === "completed" || s.status === "cancelled") return s;
      const now = new Date();
      const measured = elapsedSeconds(s, now.getTime());
      // Auto-finish (timer reached zero, possibly detected after a refresh) never
      // counts time beyond the planned duration.
      const elapsed = auto ? Math.min(measured, s.plannedMinutes * 60) : measured;
      const endedAt = auto
        ? new Date(s.startedAt.getTime() + (s.pausedSeconds + elapsed) * 1000)
        : s.status === "paused" && s.pausedAt
          ? s.pausedAt
          : now;
      const [u] = await tx
        .update(focusSessions)
        .set({
          status: "completed",
          endedAt,
          elapsedSeconds: elapsed,
          pausedSeconds: s.status === "paused" ? s.pausedSeconds : s.pausedSeconds,
          pausedAt: null,
          finishedEarly: elapsed < s.plannedMinutes * 60 - 30,
          updatedAt: now,
        })
        .where(eq(focusSessions.id, id))
        .returning();
      if (elapsed >= 60) {
        await tx
          .insert(activities)
          .values({
            userId: user.id,
            title: s.objective || "جلسهٔ تمرکز",
            category: "work",
            startAt: s.startedAt,
            endAt: endedAt > s.startedAt ? endedAt : new Date(s.startedAt.getTime() + 60000),
            taskId: s.taskId,
            projectId: s.projectId,
            goalId: s.goalId,
            focusSessionId: s.id,
            source: "focus",
            notes: s.pausedSeconds > 0 ? "شامل زمان توقف" : null,
          })
          .onConflictDoNothing();
      }
      return u;
    });
    revalidate();
    return { ok: true, data: result };
  } catch (e) {
    return fail(e) as ActionResult<FocusSessionDTO>;
  }
}

export async function cancelFocus(id: string): Promise<ActionResult> {
  try {
    const user = await requireUser();
    const s = await getOwned(user.id, id);
    if (!s) return { ok: false, error: "جلسه پیدا نشد." };
    if (s.status === "completed") return { ok: false, error: "جلسهٔ تکمیل‌شده را نمی‌توان لغو کرد؛ می‌توانید آن را حذف کنید." };
    await db
      .update(focusSessions)
      .set({ status: "cancelled", endedAt: new Date(), elapsedSeconds: elapsedSeconds(s), pausedAt: null, updatedAt: new Date() })
      .where(eq(focusSessions.id, id));
    revalidate();
    return { ok: true };
  } catch (e) {
    return fail(e);
  }
}

export async function addInterruption(sessionId: string, kind: "interruption" | "distraction", reason: string): Promise<ActionResult> {
  try {
    const user = await requireUser();
    const s = await getOwned(user.id, sessionId);
    if (!s) return { ok: false, error: "جلسه پیدا نشد." };
    const text = reason.trim().slice(0, 200);
    if (!text) return { ok: false, error: "علت را بنویسید." };
    await db.insert(interruptions).values({ userId: user.id, sessionId, kind: kind === "distraction" ? "distraction" : "interruption", reason: text });
    revalidatePath("/focus");
    return { ok: true };
  } catch (e) {
    return fail(e);
  }
}

/** Post-session reflection and later corrections. */
export async function saveFocusReview(formData: FormData): Promise<ActionResult> {
  try {
    const user = await requireUser();
    const r = reader(formData);
    const id = r.uuid("id");
    if (!id) throw new ValidationError("جلسه نامعتبر است.");
    const s = await getOwned(user.id, id);
    if (!s) return { ok: false, error: "جلسه پیدا نشد." };
    let elapsed = s.elapsedSeconds ?? 0;
    const correctedMinutes = r.optInt("elapsedMinutes", "مدت واقعی", 0, 1440);
    if (correctedMinutes !== null && s.status === "completed") elapsed = correctedMinutes * 60;
    const links = await ownedLinks(user.id, { taskId: r.uuid("taskId"), projectId: r.uuid("projectId"), goalId: r.uuid("goalId") });
    await db.transaction(async (tx) => {
      await tx
        .update(focusSessions)
        .set({
          objectiveAchieved: r.optOneOf("objectiveAchieved", ["yes", "partly", "no"] as const),
          focusRating: r.optInt("focusRating", "میزان تمرکز", 1, 5),
          focusedMinutes: clampFocused(r.optInt("focusedMinutes", "زمان واقعاً متمرکز", 0, 1440), elapsed),
          energyAfter: r.optInt("energyAfter", "انرژی", 1, 5),
          nextStep: r.optStr("nextStep", 500),
          reflection: r.optStr("reflection", 2000),
          elapsedSeconds: s.status === "completed" ? elapsed : s.elapsedSeconds,
          ...(r.has("objective") ? { objective: r.optStr("objective", 500) } : {}),
          ...(r.has("linksEdited") ? { taskId: links.taskId, projectId: links.projectId, goalId: links.goalId } : {}),
          updatedAt: new Date(),
        })
        .where(eq(focusSessions.id, id));
      const interruptionText = r.optStr("interruptedBy", 300);
      if (interruptionText) await tx.insert(interruptions).values({ userId: user.id, sessionId: id, kind: "interruption", reason: interruptionText });
      if (correctedMinutes !== null && s.status === "completed" && elapsed >= 60) {
        await tx
          .update(activities)
          .set({ endAt: new Date(s.startedAt.getTime() + elapsed * 1000 + s.pausedSeconds * 1000) })
          .where(and(eq(activities.focusSessionId, id), eq(activities.userId, user.id)));
      }
    });
    revalidate();
    return { ok: true };
  } catch (e) {
    return fail(e);
  }
}

export async function deleteFocusSession(id: string): Promise<ActionResult> {
  try {
    const user = await requireUser();
    await db.transaction(async (tx) => {
      await tx.delete(activities).where(and(eq(activities.focusSessionId, id), eq(activities.userId, user.id)));
      await tx.delete(focusSessions).where(and(eq(focusSessions.id, id), eq(focusSessions.userId, user.id)));
    });
    revalidate();
    return { ok: true };
  } catch (e) {
    return fail(e);
  }
}
