"use server";

import { redirect } from "next/navigation";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { preferences, users } from "@/db/schema";
import { createSession, destroySession, requireUser } from "@/lib/auth";
import { hashPassword, verifyPassword } from "@/lib/password";
import { isValidTimeZone } from "@/lib/time";

type AuthState = { error?: string } | undefined;

// Simple in-memory throttle against brute force (per email, per process).
const attempts = new Map<string, { count: number; until: number }>();
function throttled(key: string) {
  const a = attempts.get(key);
  return !!a && a.count >= 5 && a.until > Date.now();
}
function recordFailure(key: string) {
  const a = attempts.get(key);
  const count = a && a.until > Date.now() ? a.count + 1 : 1;
  attempts.set(key, { count, until: Date.now() + 10 * 60 * 1000 });
}

const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export async function registerAction(_: AuthState, formData: FormData): Promise<AuthState> {
  const name = String(formData.get("name") ?? "").trim();
  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  const password = String(formData.get("password") ?? "");
  const tz = String(formData.get("timezone") ?? "");
  if (!name || name.length > 80) return { error: "نام را وارد کنید (حداکثر ۸۰ نویسه)." };
  if (!emailRe.test(email) || email.length > 200) return { error: "ایمیل معتبر نیست." };
  if (password.length < 8 || password.length > 200) return { error: "رمز عبور باید حداقل ۸ نویسه باشد." };
  const existing = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
  if (existing.length) return { error: "با این ایمیل قبلاً حساب ساخته شده است." };
  const passwordHash = await hashPassword(password);
  const userId = await db.transaction(async (tx) => {
    const [u] = await tx.insert(users).values({ name, email, passwordHash }).returning({ id: users.id });
    await tx.insert(preferences).values({ userId: u.id, timezone: isValidTimeZone(tz) ? tz : "Asia/Tehran" });
    return u.id;
  });
  await createSession(userId);
  redirect("/");
}

export async function loginAction(_: AuthState, formData: FormData): Promise<AuthState> {
  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  const password = String(formData.get("password") ?? "");
  if (throttled(email)) return { error: "تلاش‌های ناموفق زیاد بود. چند دقیقه بعد دوباره امتحان کنید." };
  const [u] = await db.select().from(users).where(eq(users.email, email)).limit(1);
  const ok = u ? await verifyPassword(password, u.passwordHash) : false;
  if (!u || !ok) {
    recordFailure(email);
    return { error: "ایمیل یا رمز عبور نادرست است." };
  }
  attempts.delete(email);
  await createSession(u.id);
  redirect("/");
}

export async function logoutAction() {
  await destroySession();
  redirect("/login");
}

export async function deleteAccountAction(_: AuthState, formData: FormData): Promise<AuthState> {
  const user = await requireUser();
  const password = String(formData.get("password") ?? "");
  const confirm = String(formData.get("confirm") ?? "");
  if (confirm !== "حذف") return { error: "برای تأیید، کلمهٔ «حذف» را تایپ کنید." };
  const [u] = await db.select().from(users).where(eq(users.id, user.id)).limit(1);
  if (!u || !(await verifyPassword(password, u.passwordHash))) return { error: "رمز عبور نادرست است." };
  // All user-owned rows cascade from users.
  await db.delete(users).where(eq(users.id, user.id));
  await destroySession();
  redirect("/register");
}

type PwState = { error?: string; ok?: boolean } | undefined;
export async function changePasswordAction(_: PwState, formData: FormData): Promise<PwState> {
  const user = await requireUser();
  const current = String(formData.get("current") ?? "");
  const next = String(formData.get("next") ?? "");
  if (next.length < 8) return { error: "رمز جدید باید حداقل ۸ نویسه باشد." };
  const [u] = await db.select().from(users).where(eq(users.id, user.id)).limit(1);
  if (!u || !(await verifyPassword(current, u.passwordHash))) return { error: "رمز فعلی نادرست است." };
  await db.update(users).set({ passwordHash: await hashPassword(next) }).where(eq(users.id, user.id));
  return { ok: true };
}
