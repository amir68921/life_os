"use server";

import { revalidatePath } from "next/cache";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { tasks, type Recurrence } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import * as dal from "@/lib/dal/tasks";
import { fail, ownedLinks, reader, ValidationError, type ActionResult } from "@/lib/server-utils";

const PRIORITIES = ["low", "medium", "high", "critical"] as const;
const STATUSES = ["todo", "in_progress", "done", "cancelled"] as const;
const ENERGY = ["low", "medium", "high"] as const;

function revalidate() {
  for (const p of ["/", "/tasks", "/planner", "/goals", "/projects", "/weekly", "/analytics"]) revalidatePath(p);
}

async function parseTask(userId: string, formData: FormData) {
  const r = reader(formData);
  const freq = r.optOneOf("recurFreq", ["daily", "weekly", "monthly"] as const);
  let recurrence: Recurrence | null = null;
  const dueDate = r.optDate("dueDate", "تاریخ سررسید");
  if (freq) {
    if (!dueDate) throw new ValidationError("برای کار تکرارشونده، تاریخ سررسید لازم است.");
    recurrence = {
      freq,
      interval: r.optInt("recurInterval", "فاصلهٔ تکرار", 1, 52) ?? 1,
      weekdays: freq === "weekly" ? r.ints("recurWeekdays") : undefined,
      until: r.optDate("recurUntil", "پایان تکرار"),
    };
  }
  const links = await ownedLinks(userId, {
    goalId: r.uuid("goalId"),
    projectId: r.uuid("projectId"),
    milestoneId: r.uuid("milestoneId"),
  });
  return {
    title: r.str("title", "عنوان", 200),
    description: r.optStr("description", 5000),
    dueDate,
    plannedStart: r.optTime("plannedStart", "زمان شروع"),
    estimatedMinutes: r.optInt("estimatedMinutes", "زمان تخمینی", 1, 1440),
    actualMinutes: r.optInt("actualMinutes", "زمان واقعی", 0, 10000),
    priority: r.oneOf("priority", PRIORITIES, "medium"),
    status: r.oneOf("status", STATUSES, "todo"),
    category: r.optStr("category", 60),
    energy: r.optOneOf("energy", ENERGY),
    tags: r.tags("tags"),
    notes: r.optStr("notes", 5000),
    isMit: r.bool("isMit"),
    recurrence,
    goalId: links.goalId,
    projectId: links.projectId,
    milestoneId: links.milestoneId,
  };
}

export async function saveTask(formData: FormData): Promise<ActionResult> {
  try {
    const user = await requireUser();
    const id = reader(formData).uuid("id");
    const values = await parseTask(user.id, formData);
    const { status, ...rest } = values;
    if (id) {
      const row = await dal.updateTask(user.id, id, rest);
      if (!row) return { ok: false, error: "کار پیدا نشد." };
      if (row.status !== status) await dal.setTaskStatus(user.id, id, status);
      revalidate();
      return { ok: true, id };
    }
    const row = await dal.createTask(user.id, { ...rest, status: status === "done" ? "todo" : status });
    if (status === "done") await dal.completeTask(user.id, row.id);
    revalidate();
    return { ok: true, id: row.id };
  } catch (e) {
    return fail(e);
  }
}

export async function quickAddTask(formData: FormData): Promise<ActionResult> {
  try {
    const user = await requireUser();
    const r = reader(formData);
    const row = await dal.createTask(user.id, {
      title: r.str("title", "عنوان", 200),
      dueDate: r.optDate("dueDate", "تاریخ"),
      priority: r.oneOf("priority", PRIORITIES, "medium"),
    });
    revalidate();
    return { ok: true, id: row.id };
  } catch (e) {
    return fail(e);
  }
}

export async function setTaskStatusAction(id: string, status: (typeof STATUSES)[number]): Promise<ActionResult> {
  try {
    const user = await requireUser();
    if (!STATUSES.includes(status)) return { ok: false, error: "وضعیت نامعتبر است." };
    const row = await dal.setTaskStatus(user.id, id, status);
    if (!row) return { ok: false, error: "کار پیدا نشد." };
    revalidate();
    return { ok: true, id };
  } catch (e) {
    return fail(e);
  }
}

export async function rescheduleTaskAction(id: string, dueDate: string | null, plannedStart?: string | null): Promise<ActionResult> {
  try {
    const user = await requireUser();
    if (dueDate !== null && !/^\d{4}-\d{2}-\d{2}$/.test(dueDate)) return { ok: false, error: "تاریخ نامعتبر است." };
    const row = await dal.rescheduleTask(user.id, id, dueDate, plannedStart);
    if (!row) return { ok: false, error: "کار پیدا نشد." };
    revalidate();
    return { ok: true, id };
  } catch (e) {
    return fail(e);
  }
}

export async function toggleMitAction(id: string): Promise<ActionResult> {
  try {
    const user = await requireUser();
    const t = await dal.getTask(user.id, id);
    if (!t) return { ok: false, error: "کار پیدا نشد." };
    await db.transaction(async (tx) => {
      if (!t.isMit && t.dueDate) {
        await tx.update(tasks).set({ isMit: false }).where(and(eq(tasks.userId, user.id), eq(tasks.dueDate, t.dueDate)));
      }
      await tx.update(tasks).set({ isMit: !t.isMit }).where(and(eq(tasks.id, id), eq(tasks.userId, user.id)));
    });
    revalidate();
    return { ok: true, id };
  } catch (e) {
    return fail(e);
  }
}

export async function deleteTaskAction(id: string): Promise<ActionResult> {
  try {
    const user = await requireUser();
    const ok = await dal.deleteTask(user.id, id);
    revalidate();
    return ok ? { ok: true } : { ok: false, error: "کار پیدا نشد." };
  } catch (e) {
    return fail(e);
  }
}
