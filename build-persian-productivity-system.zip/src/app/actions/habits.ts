"use server";

import { revalidatePath } from "next/cache";
import { and, eq, isNull } from "drizzle-orm";
import { db } from "@/db";
import { habitOccurrences, habitPauses, habits } from "@/db/schema";
import { requireContext } from "@/lib/auth";
import { fail, reader, ValidationError, type ActionResult } from "@/lib/server-utils";
import { addDays, isIsoDate, todayIn } from "@/lib/time";

const revalidate = () => ["/", "/habits", "/analytics", "/weekly"].forEach((p) => revalidatePath(p));

export async function saveHabit(formData: FormData): Promise<ActionResult> {
  try {
    const { user, tz } = await requireContext();
    const r = reader(formData);
    const id = r.uuid("id");
    const frequency = r.oneOf("frequency", ["daily", "custom", "weekly"] as const, "daily");
    const weekdays = frequency === "custom" ? r.ints("weekdays") : null;
    if (frequency === "custom" && (!weekdays || weekdays.length === 0)) throw new ValidationError("حداقل یک روز هفته را انتخاب کنید.");
    const values = {
      name: r.str("name", "نام عادت", 120),
      description: r.optStr("description", 2000),
      category: r.optStr("category", 60),
      frequency,
      weekdays,
      timesPerWeek: frequency === "weekly" ? r.int("timesPerWeek", "تعداد در هفته", 1, 7) : null,
      minTarget: r.optNum("minTarget", "حداقل هدف"),
      idealTarget: r.optNum("idealTarget", "هدف ایده‌آل"),
      unit: r.optStr("unit", 30),
      startDate: r.optDate("startDate", "تاریخ شروع") ?? todayIn(tz),
      endDate: r.optDate("endDate", "تاریخ پایان"),
    };
    if (values.endDate && values.endDate < values.startDate) throw new ValidationError("تاریخ پایان باید بعد از شروع باشد.");
    if (id) {
      const res = await db.update(habits).set(values).where(and(eq(habits.id, id), eq(habits.userId, user.id))).returning({ id: habits.id });
      if (!res.length) return { ok: false, error: "عادت پیدا نشد." };
    } else {
      await db.insert(habits).values({ ...values, userId: user.id });
    }
    revalidate();
    return { ok: true };
  } catch (e) {
    return fail(e);
  }
}

/** Pause/resume. Paused periods are stored so they are excluded from rates and streaks. */
export async function toggleHabitPause(id: string): Promise<ActionResult> {
  try {
    const { user, tz } = await requireContext();
    const today = todayIn(tz);
    await db.transaction(async (tx) => {
      const [h] = await tx.select().from(habits).where(and(eq(habits.id, id), eq(habits.userId, user.id))).limit(1);
      if (!h) throw new ValidationError("عادت پیدا نشد.");
      if (h.status === "active") {
        await tx.update(habits).set({ status: "paused" }).where(eq(habits.id, id));
        await tx.insert(habitPauses).values({ habitId: id, startDate: today });
      } else {
        await tx.update(habits).set({ status: "active" }).where(eq(habits.id, id));
        await tx
          .update(habitPauses)
          .set({ endDate: addDays(today, -1) })
          .where(and(eq(habitPauses.habitId, id), isNull(habitPauses.endDate)));
      }
    });
    revalidate();
    return { ok: true };
  } catch (e) {
    return fail(e);
  }
}

export async function logHabit(habitId: string, date: string, status: string | null, value?: number | null): Promise<ActionResult> {
  try {
    const { user, tz } = await requireContext();
    if (!isIsoDate(date)) return { ok: false, error: "تاریخ نامعتبر است." };
    if (date > todayIn(tz)) return { ok: false, error: "ثبت برای روزهای آینده ممکن نیست." };
    const [h] = await db.select({ id: habits.id }).from(habits).where(and(eq(habits.id, habitId), eq(habits.userId, user.id))).limit(1);
    if (!h) return { ok: false, error: "عادت پیدا نشد." };
    if (status === null) {
      await db.delete(habitOccurrences).where(and(eq(habitOccurrences.habitId, habitId), eq(habitOccurrences.date, date)));
    } else {
      if (!["completed", "partial", "missed", "skipped"].includes(status)) return { ok: false, error: "وضعیت نامعتبر است." };
      await db
        .insert(habitOccurrences)
        .values({ userId: user.id, habitId, date, status, value: value ?? null })
        .onConflictDoUpdate({ target: [habitOccurrences.habitId, habitOccurrences.date], set: { status, value: value ?? null } });
    }
    revalidate();
    return { ok: true };
  } catch (e) {
    return fail(e);
  }
}

export async function deleteHabit(id: string): Promise<ActionResult> {
  try {
    const { user } = await requireContext();
    await db.delete(habits).where(and(eq(habits.id, id), eq(habits.userId, user.id)));
    revalidate();
    return { ok: true };
  } catch (e) {
    return fail(e);
  }
}
