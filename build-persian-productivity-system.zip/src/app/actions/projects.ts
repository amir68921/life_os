"use server";

import { revalidatePath } from "next/cache";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { projectGoals, projects } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { fail, ownedGoalIds, reader, ValidationError, type ActionResult } from "@/lib/server-utils";

const revalidate = () => ["/", "/projects", "/goals", "/analytics"].forEach((p) => revalidatePath(p, "layout"));

export async function saveProject(formData: FormData): Promise<ActionResult> {
  try {
    const user = await requireUser();
    const r = reader(formData);
    const id = r.uuid("id");
    const goalIds = await ownedGoalIds(
      user.id,
      formData.getAll("goalIds").map(String).filter((s) => /^[0-9a-f-]{36}$/i.test(s)),
    );
    const values = {
      name: r.str("name", "نام پروژه", 200),
      description: r.optStr("description", 5000),
      objective: r.optStr("objective", 2000),
      startDate: r.optDate("startDate", "تاریخ شروع"),
      targetDate: r.optDate("targetDate", "تاریخ هدف"),
      priority: r.oneOf("priority", ["low", "medium", "high", "critical"] as const, "medium"),
      status: r.oneOf("status", ["planned", "active", "on_hold", "completed", "archived"] as const, "planned"),
      progress: r.optInt("progress", "پیشرفت", 0, 100) ?? 0,
      notes: r.optStr("notes", 10000),
    };
    if (values.startDate && values.targetDate && values.targetDate < values.startDate)
      throw new ValidationError("تاریخ هدف نمی‌تواند قبل از تاریخ شروع باشد.");
    const savedId = await db.transaction(async (tx) => {
      let pid = id;
      if (pid) {
        const r2 = await tx
          .update(projects)
          .set({ ...values, updatedAt: new Date() })
          .where(and(eq(projects.id, pid), eq(projects.userId, user.id)))
          .returning({ id: projects.id });
        if (!r2.length) throw new ValidationError("پروژه پیدا نشد.");
        await tx.delete(projectGoals).where(eq(projectGoals.projectId, pid));
      } else {
        const [p] = await tx.insert(projects).values({ ...values, userId: user.id }).returning({ id: projects.id });
        pid = p.id;
      }
      if (goalIds.length) await tx.insert(projectGoals).values(goalIds.map((goalId) => ({ projectId: pid!, goalId })));
      return pid!;
    });
    revalidate();
    return { ok: true, id: savedId };
  } catch (e) {
    return fail(e);
  }
}

/** Tasks, sessions, activities and notes linked to the project are preserved (link set to null). */
export async function deleteProject(id: string): Promise<ActionResult> {
  try {
    const user = await requireUser();
    await db.delete(projects).where(and(eq(projects.id, id), eq(projects.userId, user.id)));
    revalidate();
    return { ok: true };
  } catch (e) {
    return fail(e);
  }
}
