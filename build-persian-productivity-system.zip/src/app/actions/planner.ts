"use server";

import { revalidatePath } from "next/cache";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { timeBlocks } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { fa } from "@/lib/format";
import { blockConflicts } from "@/lib/overlap";
import { fail, ownedLinks, reader, ValidationError, type ActionResult } from "@/lib/server-utils";
import { hhmmToMinutes, minutesToHHMM } from "@/lib/time";

const revalidate = () => ["/", "/planner"].forEach((p) => revalidatePath(p));

/**
 * Saves a time block. If it overlaps existing blocks, nothing is saved and the
 * conflicts are returned; the client asks the user and can resubmit with force=1.
 */
export async function saveBlock(formData: FormData): Promise<ActionResult> {
  try {
    const user = await requireUser();
    const r = reader(formData);
    const id = r.uuid("id");
    const start = hhmmToMinutes(r.time("start", "ساعت شروع"));
    const endStr = r.time("end", "ساعت پایان");
    const end = endStr === "00:00" ? 1440 : hhmmToMinutes(endStr);
    if (end <= start) throw new ValidationError("ساعت پایان باید بعد از ساعت شروع باشد (بلوک‌های عبوری از نیمه‌شب را در دو بخش ثبت کنید).");
    const repeat = r.bool("repeat") ? r.ints("repeatWeekdays") : [];
    if (r.bool("repeat") && repeat.length === 0) throw new ValidationError("برای تکرار، حداقل یک روز هفته را انتخاب کنید.");
    const links = await ownedLinks(user.id, { taskId: r.uuid("taskId") });
    const values = {
      title: r.str("title", "عنوان", 200),
      kind: r.oneOf("kind", ["task", "focus", "break", "personal", "other"] as const, "task"),
      date: r.date("date", "تاریخ"),
      startMinute: start,
      endMinute: end,
      repeatWeekdays: repeat.length ? repeat : null,
      repeatUntil: repeat.length ? r.optDate("repeatUntil", "پایان تکرار") : null,
      taskId: links.taskId,
      notes: r.optStr("notes", 2000),
    };
    if (!r.bool("force")) {
      const existing = await db.select().from(timeBlocks).where(eq(timeBlocks.userId, user.id));
      const conflicts = blockConflicts({ id: id ?? "new", ...values }, existing);
      if (conflicts.length) {
        return {
          ok: false,
          needsConfirm: true,
          error: "این بلوک با برنامه‌های موجود هم‌پوشانی دارد.",
          conflicts: conflicts.map((c) => ({
            title: c.block.title,
            detail: fa(`${minutesToHHMM(c.block.startMinute)}–${minutesToHHMM(c.block.endMinute)}`) + ` (${c.date})`,
          })),
        };
      }
    }
    if (id) {
      const res = await db
        .update(timeBlocks)
        .set(values)
        .where(and(eq(timeBlocks.id, id), eq(timeBlocks.userId, user.id)))
        .returning({ id: timeBlocks.id });
      if (!res.length) return { ok: false, error: "بلوک پیدا نشد." };
    } else {
      await db.insert(timeBlocks).values({ ...values, userId: user.id });
    }
    revalidate();
    return { ok: true };
  } catch (e) {
    return fail(e);
  }
}

export async function deleteBlock(id: string): Promise<ActionResult> {
  try {
    const user = await requireUser();
    await db.delete(timeBlocks).where(and(eq(timeBlocks.id, id), eq(timeBlocks.userId, user.id)));
    revalidate();
    return { ok: true };
  } catch (e) {
    return fail(e);
  }
}
