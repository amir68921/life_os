"use server";

import { revalidatePath } from "next/cache";
import { and, eq, gt, lt, ne } from "drizzle-orm";
import { db } from "@/db";
import { activities } from "@/db/schema";
import { requireContext } from "@/lib/auth";
import { formatTime } from "@/lib/format";
import { fail, ownedLinks, reader, ValidationError, type ActionResult } from "@/lib/server-utils";
import { addDays, hhmmToMinutes, zonedToUtc } from "@/lib/time";

const CATEGORIES = ["work", "learning", "personal_projects", "health", "sleep", "social", "entertainment", "chores", "other"] as const;
const revalidate = () => ["/", "/activity", "/analytics", "/planner", "/projects"].forEach((p) => revalidatePath(p, "layout"));

export async function saveActivity(formData: FormData): Promise<ActionResult> {
  try {
    const { user, tz } = await requireContext();
    const r = reader(formData);
    const id = r.uuid("id");
    const date = r.date("date", "تاریخ");
    const startStr = r.time("start", "ساعت شروع");
    const startAt = zonedToUtc(date, startStr, tz);
    const endStr = r.optTime("end", "ساعت پایان");
    const duration = r.optInt("duration", "مدت (دقیقه)", 1, 1440);
    let endAt: Date;
    if (endStr) {
      // end clock earlier than start → activity crosses midnight
      const endDate = hhmmToMinutes(endStr) <= hhmmToMinutes(startStr) ? addDays(date, 1) : date;
      endAt = zonedToUtc(endDate, endStr, tz);
    } else if (duration) {
      endAt = new Date(startAt.getTime() + duration * 60000);
    } else throw new ValidationError("ساعت پایان یا مدت را وارد کنید.");
    if (endAt.getTime() - startAt.getTime() > 24 * 3600000) throw new ValidationError("مدت فعالیت نمی‌تواند بیش از ۲۴ ساعت باشد.");
    const links = await ownedLinks(user.id, { taskId: r.uuid("taskId"), projectId: r.uuid("projectId"), goalId: r.uuid("goalId") });
    const values = {
      title: r.str("title", "عنوان", 200),
      category: r.oneOf("category", CATEGORIES, "other"),
      startAt,
      endAt,
      notes: r.optStr("notes", 2000),
      ...links,
    };
    delete (values as { milestoneId?: unknown }).milestoneId;
    if (!r.bool("force")) {
      const overlapping = await db
        .select()
        .from(activities)
        .where(and(eq(activities.userId, user.id), lt(activities.startAt, endAt), gt(activities.endAt, startAt), id ? ne(activities.id, id) : undefined));
      if (overlapping.length) {
        const exact = overlapping.find((o) => o.title === values.title && o.startAt.getTime() === startAt.getTime());
        if (exact) return { ok: false, error: "فعالیتی با همین عنوان و زمان شروع قبلاً ثبت شده است (تکراری)." };
        return {
          ok: false,
          needsConfirm: true,
          error: "این فعالیت با فعالیت‌های ثبت‌شده هم‌پوشانی دارد.",
          conflicts: overlapping.map((o) => ({ title: o.title, detail: `${formatTime(o.startAt, tz)}–${formatTime(o.endAt, tz)}` })),
        };
      }
    }
    if (id) {
      const res = await db
        .update(activities)
        .set(values)
        .where(and(eq(activities.id, id), eq(activities.userId, user.id)))
        .returning({ id: activities.id });
      if (!res.length) return { ok: false, error: "فعالیت پیدا نشد." };
    } else {
      await db.insert(activities).values({ ...values, userId: user.id, source: "manual" });
    }
    revalidate();
    return { ok: true };
  } catch (e) {
    return fail(e);
  }
}

export async function deleteActivity(id: string): Promise<ActionResult> {
  try {
    const { user } = await requireContext();
    await db.delete(activities).where(and(eq(activities.id, id), eq(activities.userId, user.id)));
    revalidate();
    return { ok: true };
  } catch (e) {
    return fail(e);
  }
}

/** Resolve an overlap by trimming one activity to end when the other starts. */
export async function trimActivity(id: string, newEndIso: string): Promise<ActionResult> {
  try {
    const { user } = await requireContext();
    const end = new Date(newEndIso);
    if (Number.isNaN(end.getTime())) return { ok: false, error: "زمان نامعتبر است." };
    const [a] = await db.select().from(activities).where(and(eq(activities.id, id), eq(activities.userId, user.id))).limit(1);
    if (!a) return { ok: false, error: "فعالیت پیدا نشد." };
    if (end <= a.startAt) return { ok: false, error: "با این برش، مدت فعالیت صفر می‌شود؛ به‌جای آن حذفش کنید." };
    await db.update(activities).set({ endAt: end }).where(eq(activities.id, id));
    revalidate();
    return { ok: true };
  } catch (e) {
    return fail(e);
  }
}
