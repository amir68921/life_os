"use server";

import { revalidatePath } from "next/cache";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { notes } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { fail, ownedLinks, reader, type ActionResult } from "@/lib/server-utils";

export async function saveNote(formData: FormData): Promise<ActionResult> {
  try {
    const user = await requireUser();
    const r = reader(formData);
    const id = r.uuid("id");
    const links = await ownedLinks(user.id, { taskId: r.uuid("taskId"), projectId: r.uuid("projectId"), goalId: r.uuid("goalId") });
    const values = {
      title: r.str("title", "عنوان", 200),
      content: r.optStr("content", 100000) ?? "",
      kind: r.oneOf("kind", ["note", "lesson", "reflection", "idea"] as const, "note"),
      tags: r.tags("tags"),
      taskId: links.taskId,
      projectId: links.projectId,
      goalId: links.goalId,
    };
    let savedId = id;
    if (id) {
      const res = await db
        .update(notes)
        .set({ ...values, updatedAt: new Date() })
        .where(and(eq(notes.id, id), eq(notes.userId, user.id)))
        .returning({ id: notes.id });
      if (!res.length) return { ok: false, error: "یادداشت پیدا نشد." };
    } else {
      const [n] = await db.insert(notes).values({ ...values, userId: user.id }).returning({ id: notes.id });
      savedId = n.id;
    }
    revalidatePath("/notes");
    return { ok: true, id: savedId ?? undefined };
  } catch (e) {
    return fail(e);
  }
}

export async function deleteNote(id: string): Promise<ActionResult> {
  try {
    const user = await requireUser();
    await db.delete(notes).where(and(eq(notes.id, id), eq(notes.userId, user.id)));
    revalidatePath("/notes");
    return { ok: true };
  } catch (e) {
    return fail(e);
  }
}
