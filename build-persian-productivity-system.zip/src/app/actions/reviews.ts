"use server";

import { revalidatePath } from "next/cache";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { dailyReviews, weeklyReviews, type Suggestion } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { fail, reader, type ActionResult } from "@/lib/server-utils";
import { isIsoDate } from "@/lib/time";

export async function saveDailyReview(formData: FormData): Promise<ActionResult> {
  try {
    const user = await requireUser();
    const r = reader(formData);
    const values = {
      date: r.date("date", "تاریخ"),
      accomplishment: r.optStr("accomplishment", 2000),
      goalProgress: r.optStr("goalProgress", 2000),
      distractions: r.optStr("distractions", 2000),
      wentWell: r.optStr("wentWell", 2000),
      improve: r.optStr("improve", 2000),
      tomorrowPriority: r.optStr("tomorrowPriority", 500),
      energy: r.optInt("energy", "انرژی", 1, 5),
    };
    await db
      .insert(dailyReviews)
      .values({ ...values, userId: user.id })
      .onConflictDoUpdate({ target: [dailyReviews.userId, dailyReviews.date], set: { ...values, updatedAt: new Date() } });
    revalidatePath("/review");
    revalidatePath("/");
    return { ok: true };
  } catch (e) {
    return fail(e);
  }
}

export async function deleteDailyReview(id: string): Promise<ActionResult> {
  try {
    const user = await requireUser();
    await db.delete(dailyReviews).where(and(eq(dailyReviews.id, id), eq(dailyReviews.userId, user.id)));
    revalidatePath("/review");
    return { ok: true };
  } catch (e) {
    return fail(e);
  }
}

export async function saveWeeklyReview(formData: FormData): Promise<ActionResult> {
  try {
    const user = await requireUser();
    const r = reader(formData);
    const values = {
      weekStart: r.date("weekStart", "هفته"),
      wins: r.optStr("wins", 3000),
      challenges: r.optStr("challenges", 3000),
      reflection: r.optStr("reflection", 5000),
      nextWeekFocus: r.optStr("nextWeekFocus", 2000),
    };
    await db
      .insert(weeklyReviews)
      .values({ ...values, userId: user.id })
      .onConflictDoUpdate({ target: [weeklyReviews.userId, weeklyReviews.weekStart], set: { ...values, updatedAt: new Date() } });
    revalidatePath("/weekly");
    return { ok: true };
  } catch (e) {
    return fail(e);
  }
}

/** Accept / edit / dismiss a data-backed suggestion. Stored per week. */
export async function updateSuggestion(weekStart: string, suggestion: Suggestion): Promise<ActionResult> {
  try {
    const user = await requireUser();
    if (!isIsoDate(weekStart)) return { ok: false, error: "هفته نامعتبر است." };
    if (!["pending", "accepted", "dismissed"].includes(suggestion.status)) return { ok: false, error: "وضعیت نامعتبر است." };
    const clean: Suggestion = {
      id: String(suggestion.id).slice(0, 50),
      text: String(suggestion.text).slice(0, 500),
      basis: String(suggestion.basis).slice(0, 500),
      status: suggestion.status,
    };
    await db.transaction(async (tx) => {
      const [existing] = await tx
        .select()
        .from(weeklyReviews)
        .where(and(eq(weeklyReviews.userId, user.id), eq(weeklyReviews.weekStart, weekStart)))
        .limit(1);
      const list = (existing?.suggestions ?? []).filter((s) => s.id !== clean.id);
      list.push(clean);
      if (existing) await tx.update(weeklyReviews).set({ suggestions: list, updatedAt: new Date() }).where(eq(weeklyReviews.id, existing.id));
      else await tx.insert(weeklyReviews).values({ userId: user.id, weekStart, suggestions: list });
    });
    revalidatePath("/weekly");
    return { ok: true };
  } catch (e) {
    return fail(e);
  }
}
