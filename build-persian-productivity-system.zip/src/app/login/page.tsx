import { redirect } from "next/navigation";
import { getUser } from "@/lib/auth";
import { LoginForm } from "@/components/login-form";

export const dynamic = "force-dynamic";

export default async function LoginPage() {
  const user = await getUser();
  if (user) redirect("/");
  return (
    <div className="flex min-h-dvh items-center justify-center px-4 py-10">
      <LoginForm />
    </div>
  );
}
