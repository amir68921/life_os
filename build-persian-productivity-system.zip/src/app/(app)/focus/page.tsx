import { and, desc, eq, gte, inArray, lt } from "drizzle-orm";
import { db } from "@/db";
import { focusSessions, interruptions } from "@/db/schema";
import { requireContext } from "@/lib/auth";
import { fa, formatMinutes } from "@/lib/format";
import { getLinkOptions } from "@/lib/queries";
import { addDays, dayBoundsUtc, rangeBoundsUtc, startOfWeek, todayIn } from "@/lib/time";
import { Card, EmptyState, PageHeader, Stat } from "@/components/ui";
import { FocusTimer } from "@/components/focus-timer";
import { FocusSessionRow } from "@/components/focus-history";

type SP = Promise<Record<string, string | undefined>>;

export default async function FocusPage({ searchParams }: { searchParams: SP }) {
  const sp = await searchParams;
  const { user, prefs, tz } = await requireContext();
  const today = todayIn(tz);
  const day = dayBoundsUtc(today, tz);
  const weekStart = startOfWeek(today, prefs.weekStart);
  const week = rangeBoundsUtc(weekStart, addDays(weekStart, 6), tz);

  const [active, recent, weekSessions, links] = await Promise.all([
    db.select().from(focusSessions).where(and(eq(focusSessions.userId, user.id), inArray(focusSessions.status, ["running", "paused"]))).limit(1),
    db.select().from(focusSessions).where(and(eq(focusSessions.userId, user.id), inArray(focusSessions.status, ["completed", "cancelled"]))).orderBy(desc(focusSessions.startedAt)).limit(25),
    db.select().from(focusSessions).where(and(eq(focusSessions.userId, user.id), eq(focusSessions.status, "completed"), gte(focusSessions.startedAt, week.start), lt(focusSessions.startedAt, week.end))),
    getLinkOptions(user.id),
  ]);
  const sessionIds = [...recent.map((r) => r.id), ...active.map((a) => a.id)];
  const ints = sessionIds.length ? await db.select().from(interruptions).where(and(eq(interruptions.userId, user.id), inArray(interruptions.sessionId, sessionIds))) : [];

  const todays = weekSessions.filter((s) => s.startedAt >= day.start && s.startedAt < day.end);
  const sum = (xs: typeof weekSessions) => xs.reduce((a, s) => a + (s.elapsedSeconds ?? 0), 0) / 60;
  const reported = weekSessions.filter((s) => s.focusedMinutes !== null);
  const defaultTask = sp.task && links.tasks.some((x) => x.id === sp.task) ? sp.task : undefined;

  return (
    <div className="space-y-6">
      <PageHeader title="تایمر تمرکز" subtitle="زمان اندازه‌گیری‌شدهٔ تایمر جدا از زمان واقعاً متمرکزی که خودتان گزارش می‌دهید ذخیره می‌شود." />
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="امروز" value={todays.length ? formatMinutes(sum(todays)) : "—"} hint={`${fa(todays.length)} جلسه`} />
        <Stat label="این هفته" value={weekSessions.length ? formatMinutes(sum(weekSessions)) : "—"} hint={`${fa(weekSessions.length)} جلسه`} />
        <Stat
          label="متمرکز (خوداظهاری) این هفته"
          value={reported.length ? formatMinutes(reported.reduce((a, s) => a + (s.focusedMinutes ?? 0), 0)) : "—"}
          hint={reported.length ? `از ${fa(reported.length)} جلسهٔ دارای گزارش` : "هنوز گزارشی ثبت نشده"}
        />
        <Stat label="میانگین طول جلسه" value={weekSessions.length ? formatMinutes(sum(weekSessions) / weekSessions.length) : "—"} hint="این هفته" />
      </div>
      <FocusTimer
        initial={active[0] ?? null}
        initialInterruptions={ints.filter((i) => i.sessionId === active[0]?.id).map((i) => ({ id: i.id, kind: i.kind, reason: i.reason }))}
        serverNow={Date.now()}
        links={links}
        defaultTaskId={defaultTask}
      />
      <Card title="جلسات اخیر">
        {recent.length === 0 ? (
          <EmptyState title="هنوز جلسه‌ای ثبت نشده" description="اولین جلسهٔ تمرکز خود را از بالا شروع کنید." icon="◷" />
        ) : (
          <ul className="divide-y divide-zinc-100 dark:divide-zinc-800">
            {recent.map((s) => (
              <FocusSessionRow key={s.id} s={s} links={links} interruptions={ints.filter((i) => i.sessionId === s.id).map((i) => i.reason)} />
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}
