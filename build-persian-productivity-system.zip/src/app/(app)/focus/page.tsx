import { and, desc, eq, or } from "drizzle-orm";
import { db } from "@/db";
import { tasks, goals, focusSessions } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { getActiveFocus } from "@/lib/actions-life";
import { FocusClient, type RecentSession } from "@/components/focus-client";
import { Timer } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function FocusPage() {
  const user = await requireUser();

  const todayTasks = db.select({ id: tasks.id, title: tasks.title, dueDate: tasks.dueDate, status: tasks.status })
    .from(tasks).where(and(eq(tasks.userId, user.id), or(eq(tasks.status, "pending"), eq(tasks.status, "in_progress"))))
    .orderBy(desc(tasks.updatedAt)).limit(50);

  const goalRows = db.select({ id: goals.id, title: goals.title }).from(goals)
    .where(and(eq(goals.userId, user.id), eq(goals.status, "active"))).limit(50);

  const [active, tks, gls, recentRows] = await Promise.all([
    getActiveFocus(),
    todayTasks,
    goalRows,
    db.select({
      id: focusSessions.id, objective: focusSessions.objective, plannedMinutes: focusSessions.plannedMinutes,
      elapsedSeconds: focusSessions.elapsedSeconds, focusedMinutesSelf: focusSessions.focusedMinutesSelf,
      focusRatingEnd: focusSessions.focusRatingEnd, achievedObjective: focusSessions.achievedObjective,
      interruptionsCount: focusSessions.interruptionsCount, interruptionsNote: focusSessions.interruptionsNote,
      nextSteps: focusSessions.nextSteps, distractions: focusSessions.distractions,
      localDate: focusSessions.localDate, startedAt: focusSessions.startedAt, endedAt: focusSessions.endedAt,
      taskTitle: tasks.title, goalTitle: goals.title,
    })
      .from(focusSessions)
      .leftJoin(tasks, eq(tasks.id, focusSessions.taskId))
      .leftJoin(goals, eq(goals.id, focusSessions.goalId))
      .where(and(eq(focusSessions.userId, user.id), eq(focusSessions.status, "completed")))
      .orderBy(desc(focusSessions.startedAt)).limit(15),
  ]);

  const recent: RecentSession[] = recentRows.map((r) => ({
    ...r,
    startedAt: r.startedAt.toISOString(),
    endedAt: r.endedAt ? r.endedAt.toISOString() : null,
  }));

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2.5">
        <Timer className="size-5" style={{ color: "var(--accent)" }} />
        <div>
          <h1 className="text-lg font-extrabold tracking-tight">تایمر تمرکز</h1>
          <p className="text-xs" style={{ color: "var(--fg-muted)" }}>جلسهٔ فعالت پس از رفرش یا بستن مرورگر حفظ می‌شود</p>
        </div>
      </div>
      <FocusClient
        active={active}
        tasks={tks.map((t) => ({ id: t.id, title: t.title }))}
        goals={gls}
        defaults={{ focus: user.settings.defaultFocusMinutes, breakMin: user.settings.defaultBreakMinutes }}
        recent={recent}
        tz={user.settings.timezone}
      />
    </div>
  );
}
