import type { ReactNode } from "react";
import { AppShell } from "@/components/shell";
import { PrefsProvider } from "@/components/prefs";
import { requireContext } from "@/lib/auth";
import { todayIn } from "@/lib/time";

export const dynamic = "force-dynamic";

export default async function AppLayout({ children }: { children: ReactNode }) {
  const { user, prefs } = await requireContext();
  return (
    <PrefsProvider
      value={{
        tz: prefs.timezone,
        mode: prefs.dateFormat === "gregorian" ? "gregorian" : "jalali",
        weekStart: prefs.weekStart,
        today: todayIn(prefs.timezone),
        focusMinutes: prefs.focusMinutes,
        breakMinutes: prefs.breakMinutes,
        notifyFocusEnd: prefs.notifications.focusEnd,
      }}
    >
      <AppShell userName={user.name} theme={prefs.theme}>
        {children}
      </AppShell>
    </PrefsProvider>
  );
}
