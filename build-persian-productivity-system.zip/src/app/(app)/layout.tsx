import { requireUser } from "@/lib/auth";
import { Shell } from "@/components/shell";

export default function AppLayout({ children }: { children: React.ReactNode }) {
  return <GuardedShell>{children}</GuardedShell>;
}

async function GuardedShell({ children }: { children: React.ReactNode }) {
  const user = await requireUser();
  return <Shell userName={user.displayName || user.username}>{children}</Shell>;
}
