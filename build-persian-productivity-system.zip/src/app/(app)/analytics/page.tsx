import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { getAnalytics } from "@/lib/queries";
import { Card, SectionTitle, EmptyState, ProgressBar } from "@/components/ui";
import { BarChart, LineChart, Donut, CompareBars } from "@/components/charts";
import { faDigits, faDuration, faDateMed } from "@/lib/jalali";
import { BarChart3 } from "lucide-react";

export const dynamic = "force-dynamic";

const RANGES = [
  { value: 7, label: "۷ روز" },
  { value: 14, label: "۱۴ روز" },
  { value: 30, label: "۳۰ روز" },
];

export default async function AnalyticsPage({
  searchParams,
}: {
  searchParams: Promise<{ days?: string }>;
}) {
  const user = await requireUser();
  const { days: dp } = await searchParams;
  const days = RANGES.some((r) => String(r.value) === dp) ? Number(dp) : 14;
  const a = await getAnalytics(user, days);

  const empty = a.focusCount === 0 && a.sleepCount === 0 && a.habitReports.length === 0 && a.weeks.every((w) => !w.planned && !w.done);

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <BarChart3 className="size-5" style={{ color: "var(--accent)" }} />
          <div>
            <h1 className="text-lg font-extrabold tracking-tight">تحلیل‌ها</h1>
            <p className="text-xs" style={{ color: "var(--fg-muted)" }}>
              {faDateMed(a.start)} تا {faDateMed(a.today)} — همه از داده‌های واقعیِ ثبت‌شدهٔ خودت
            </p>
          </div>
        </div>
        <div className="flex gap-1.5">
          {RANGES.map((r) => (
            <Link key={r.value} href={`/analytics?days=${r.value}`}
              className="chip !px-3 !py-1.5 !text-xs transition-all hover:scale-105"
              style={r.value === days ? { background: "var(--accent)", color: "var(--accent-fg)", borderColor: "transparent" } : {}}>
              {r.label}
            </Link>
          ))}
        </div>
      </div>

      {empty ? (
        <EmptyState
          title="هنوز داده‌ای برای تحلیل نیست"
          hint="چند روز وظیفه ثبت کن، تمرکز کن و خوابت را بنویس؛ نمودارها پروز می‌کنند — بدون هیچ دادهٔ ساختگی."
        />
      ) : (
        <>
          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            <Card>
              <SectionTitle
                title="تمرکز روزانه"
                subtitle={`مجموع: ${faDuration(a.totalFocusMin)} در ${faDigits(a.focusCount)} جلسه · روزهای خالی = بدون جلسه`}
              />
              <BarChart data={a.focusSeries} unit="دقیقه" />
            </Card>
            <Card>
              <SectionTitle
                title="مدت خواب"
                subtitle={a.avgSleep != null ? `میانگین: ${faDuration(a.avgSleep)}` : "رکوردی ثبت نشده"}
              />
              {a.sleepSeries.length >= 2 ? (
                <LineChart data={a.sleepSeries} unit="دقیقه" target={user.settings.targetSleepMinutes} />
              ) : (
                <p className="py-8 text-center text-xs" style={{ color: "var(--fg-faint)" }}>
                  {a.sleepSeries.length === 1 ? "فقط یک شب ثبت شده؛ یک شب دیگر هم ثبت کن." : "رکوردی در این بازه نیست."}
                </p>
              )}
            </Card>
          </div>

          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            <Card>
              <SectionTitle title="برنامه‌ریزی در برابر انجام (هفتگی)" subtitle="تعداد وظایف" />
              {a.weeks.length ? (
                <CompareBars
                  aLabel="برنامه‌ریزی‌شده"
                  bLabel="انجام‌شده"
                  data={a.weeks.slice(-5).map((w) => ({ label: faDateMed(w.start), a: w.planned, b: w.done }))}
                />
              ) : (
                <p className="py-6 text-center text-xs" style={{ color: "var(--fg-faint)" }}>داده‌ای نیست.</p>
              )}
            </Card>
            <Card>
              <SectionTitle
                title="تخصیص زمان بر اساس دسته"
                subtitle="زمان واقعیِ وظایف انجام‌شده؛ در نبود آن، برآورد"
              />
              <Donut data={a.categoryShare} centerLabel={faDuration(a.categoryShare.reduce((x, y) => x + y.value, 0))} />
            </Card>
          </div>

          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            <Card>
              <SectionTitle title="برآورد در برابر واقعیت" subtitle="وظایفی که هر دو عدد را دارند" />
              {a.estVsActual.length === 0 ? (
                <p className="py-6 text-center text-xs leading-6" style={{ color: "var(--fg-muted)" }}>
                  وقتی وظیفه‌ای را تمام می‌کنی، «مدت واقعی» را هم بنویس تا دقت برآوردت اینجا دیده شود.
                </p>
              ) : (
                <div className="space-y-2.5">
                  {a.estVsActual.slice(0, 8).map((t, i) => {
                    const ratio = t.est > 0 ? Math.round((t.act / t.est) * 100) : 0;
                    return (
                      <div key={i}>
                        <div className="mb-1 flex items-center justify-between text-[11px]" style={{ color: "var(--fg-muted)" }}>
                          <span className="truncate font-medium" style={{ color: "var(--fg)" }}>{t.title}</span>
                          <span className="shrink-0">
                            برآورد {faDuration(t.est)} · واقعی {faDuration(t.act)}
                            <strong style={{ color: ratio > 120 ? "var(--danger)" : ratio > 95 ? "var(--warn)" : "var(--ok)" }}> ({faDigits(ratio)}٪)</strong>
                          </span>
                        </div>
                        <div className="relative h-2 overflow-hidden rounded-full" style={{ background: "var(--bg-soft)" }}>
                          <div className="absolute inset-y-0 right-0 rounded-full" style={{ width: `${Math.min(100, (t.est / Math.max(t.est, t.act)) * 100)}%`, background: "var(--border-strong)" }} />
                          <div className="absolute inset-y-0 right-0 rounded-full opacity-80" style={{ width: `${Math.min(100, (t.act / Math.max(t.est, t.act)) * 100)}%`, background: ratio > 120 ? "var(--danger)" : "var(--accent)" }} />
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </Card>

            <Card>
              <SectionTitle title="نرخ انجام عادت‌ها" subtitle={`در ${faDigits(days)} روز گذشته — روزهای بدون برنامه در مخرج نیستند`} />
              {a.habitReports.length === 0 ? (
                <p className="py-6 text-center text-xs" style={{ color: "var(--fg-muted)" }}>عادتی ساخته نشده.</p>
              ) : (
                <div className="space-y-3">
                  {a.habitReports.map(({ habit, stats }) => (
                    <div key={habit.id}>
                      <div className="mb-1 flex items-center justify-between text-xs">
                        <span className="font-medium">{habit.name}{habit.status === "paused" ? " (متوقف)" : ""}</span>
                        <span style={{ color: "var(--fg-faint)" }}>
                          {stats.monthRate != null ? `${faDigits(stats.monthRate)}٪` : "—"} · زنجیره: {faDigits(stats.current)}
                        </span>
                      </div>
                      <ProgressBar value={stats.monthRate ?? 0} />
                    </div>
                  ))}
                </div>
              )}
            </Card>
          </div>

          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            <Card>
              <SectionTitle title="تمرکز واقعی در برابر خودگزارشی" subtitle="شفافیتِ آمار — هیچ‌کدام جای دیگری را نمی‌گیرند" />
              <div className="flex items-center justify-around py-4 text-center">
                <div>
                  <p className="text-2xl font-extrabold">{faDuration(a.totalFocusMin)}</p>
                  <p className="mt-1 text-[10px]" style={{ color: "var(--fg-muted)" }}>مدت واقعیِ تایمر</p>
                </div>
                <div className="h-10 w-px" style={{ background: "var(--border)" }} />
                <div>
                  <p className="text-2xl font-extrabold" style={{ color: "var(--accent)" }}>{faDuration(a.selfFocusedMin)}</p>
                  <p className="mt-1 text-[10px]" style={{ color: "var(--fg-muted)" }}>جمع گزارشِ «چقدرش متمرکز بودم»</p>
                </div>
              </div>
              {a.interruptionsTotal > 0 && (
                <p className="text-center text-[11px]" style={{ color: "var(--fg-muted)" }}>
                  مجموع وقفه‌های ثبت‌شده: {faDigits(a.interruptionsTotal)}
                </p>
              )}
            </Card>
            <Card>
              <SectionTitle title="حواس‌پرتی‌های پرتکرار" subtitle="از گزارش‌های پایان جلسه" />
              {a.topDistractions.length === 0 ? (
                <p className="py-6 text-center text-xs" style={{ color: "var(--fg-muted)" }}>
                  چیزی ثبت نشده؛ موقع پایان جلسه می‌توانی حواس‌پرتی‌ها را بنویسی.
                </p>
              ) : (
                <div className="flex flex-wrap gap-2">
                  {a.topDistractions.map(([name, count]) => (
                    <span key={name} className="chip !px-3 !py-1.5 !text-xs">{name} × {faDigits(count)}</span>
                  ))}
                </div>
              )}
              <p className="mt-4 border-t pt-3 text-[10px] leading-6" style={{ borderColor: "var(--border)", color: "var(--fg-faint)" }}>
                عمداً «نمرهٔ کلی بهره‌وری» نداریم: عددهای ترکیبیِ بی‌توضیح گمراه‌کننده‌اند. هر متریک بالا دقیقاً از جدول مشخص خودش حساب می‌شود.
              </p>
            </Card>
          </div>
        </>
      )}
    </div>
  );
}
