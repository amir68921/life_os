import { and, asc, eq, gte, inArray, isNotNull, lt, lte, ne } from "drizzle-orm";
import { db } from "@/db";
import { activities, focusSessions, goalProgressLog, goals, habitOccurrences, habitPauses, habits, projects, sleepRecords, tasks } from "@/db/schema";
import { requireContext } from "@/lib/auth";
import { fa, formatDayMonth, formatMinutes, formatPercent } from "@/lib/format";
import { computeHabitStats, type HabitStatus } from "@/lib/habits";
import { label, t } from "@/lib/i18n";
import { isoToJalali, JALALI_MONTHS } from "@/lib/jalali";
import { computeSleepStats } from "@/lib/sleep";
import { addDays, dateRange, diffDays, isIsoDate, localDate, rangeBoundsUtc, splitByLocalDay, startOfWeek, todayIn } from "@/lib/time";
import { Card, PageHeader, Stat } from "@/components/ui";
import { BarSeries, LineSeries, PieSeries } from "@/components/charts";
import { DateRangeFilter } from "@/components/range-filter";

type SP = Promise<Record<string, string | undefined>>;

export default async function AnalyticsPage({ searchParams }: { searchParams: SP }) {
  const sp = await searchParams;
  const { user, prefs, tz, mode } = await requireContext();
  const today = todayIn(tz);
  let to = isIsoDate(sp.to) ? sp.to : today;
  let from = isIsoDate(sp.from) ? sp.from : addDays(to, -29);
  if (from > to) [from, to] = [to, from];
  if (diffDays(to, from) > 366) from = addDays(to, -366);
  const { start, end } = rangeBoundsUtc(from, to, tz);
  const days = dateRange(from, to);

  const [sessions, acts, rangeTasks, doneTasks, sleep, habitRows, occ, pauses, gLog, goalRows, projectRows] = await Promise.all([
    db.select().from(focusSessions).where(and(eq(focusSessions.userId, user.id), eq(focusSessions.status, "completed"), gte(focusSessions.startedAt, start), lt(focusSessions.startedAt, end))),
    db.select().from(activities).where(and(eq(activities.userId, user.id), lt(activities.startAt, end), gte(activities.endAt, start))),
    db.select({ dueDate: tasks.dueDate, status: tasks.status }).from(tasks).where(and(eq(tasks.userId, user.id), gte(tasks.dueDate, from), lte(tasks.dueDate, to), ne(tasks.status, "cancelled"))),
    db.select().from(tasks).where(and(eq(tasks.userId, user.id), eq(tasks.status, "done"), isNotNull(tasks.estimatedMinutes), gte(tasks.completedAt, start), lt(tasks.completedAt, end))).orderBy(asc(tasks.completedAt)),
    db.select().from(sleepRecords).where(and(eq(sleepRecords.userId, user.id), gte(sleepRecords.wakeDate, from), lte(sleepRecords.wakeDate, to))),
    db.select().from(habits).where(eq(habits.userId, user.id)),
    db.select().from(habitOccurrences).where(and(eq(habitOccurrences.userId, user.id), gte(habitOccurrences.date, from), lte(habitOccurrences.date, to))),
    db.select({ habitId: habitPauses.habitId, startDate: habitPauses.startDate, endDate: habitPauses.endDate }).from(habitPauses).innerJoin(habits, eq(habits.id, habitPauses.habitId)).where(eq(habits.userId, user.id)),
    db.select().from(goalProgressLog).where(and(eq(goalProgressLog.userId, user.id), lt(goalProgressLog.recordedAt, end))).orderBy(asc(goalProgressLog.recordedAt)),
    db.select({ id: goals.id, title: goals.title }).from(goals).where(and(eq(goals.userId, user.id), inArray(goals.status, ["active", "completed", "paused"]))),
    db.select({ id: projects.id, name: projects.name }).from(projects).where(eq(projects.userId, user.id)),
  ]);

  // Focus per local day (sessions crossing midnight are split across days)
  const focusByDay = new Map<string, number>();
  for (const s of sessions) {
    const ended = new Date(s.startedAt.getTime() + ((s.elapsedSeconds ?? 0) + s.pausedSeconds) * 1000);
    const segs = splitByLocalDay(s.startedAt, ended, tz);
    const wall = segs.reduce((a, x) => a + x.minutes, 0) || 1;
    for (const seg of segs) focusByDay.set(seg.date, (focusByDay.get(seg.date) ?? 0) + ((s.elapsedSeconds ?? 0) / 60) * (seg.minutes / wall));
  }
  const totalFocus = sessions.reduce((a, s) => a + (s.elapsedSeconds ?? 0), 0) / 60;
  const reported = sessions.filter((s) => s.focusedMinutes !== null);
  const dailyFocus = days.map((d) => ({ day: formatDayMonth(d, mode), minutes: Math.round(focusByDay.get(d) ?? 0) }));

  const weekMap = new Map<string, number>();
  days.forEach((d) => {
    const w = startOfWeek(d, prefs.weekStart);
    weekMap.set(w, (weekMap.get(w) ?? 0) + (focusByDay.get(d) ?? 0));
  });
  const weeklyFocus = [...weekMap.entries()].map(([w, m]) => ({ week: formatDayMonth(w, mode), hours: Math.round((m / 60) * 10) / 10 }));

  const monthKey = (d: string) => {
    if (mode === "jalali") {
      const j = isoToJalali(d);
      return { key: `${j.jy}-${j.jm}`, label: `${JALALI_MONTHS[j.jm - 1]} ${fa(j.jy % 100)}` };
    }
    return { key: d.slice(0, 7), label: fa(d.slice(0, 7).replace("-", "/")) };
  };
  const monthMap = new Map<string, { label: string; m: number }>();
  days.forEach((d) => {
    const k = monthKey(d);
    const cur = monthMap.get(k.key) ?? { label: k.label, m: 0 };
    cur.m += focusByDay.get(d) ?? 0;
    monthMap.set(k.key, cur);
  });
  const monthlyFocus = [...monthMap.values()].map((x) => ({ month: x.label, hours: Math.round((x.m / 60) * 10) / 10 }));

  // Planned vs completed tasks per day
  const tasksPerDay = days.map((d) => {
    const ts = rangeTasks.filter((x) => x.dueDate === d);
    return { day: formatDayMonth(d, mode), planned: ts.length, done: ts.filter((x) => x.status === "done").length };
  });

  // Estimated vs actual
  const focusByTask = new Map<string, number>();
  const allTaskSessions = doneTasks.length
    ? await db.select({ taskId: focusSessions.taskId, sec: focusSessions.elapsedSeconds }).from(focusSessions).where(and(eq(focusSessions.userId, user.id), eq(focusSessions.status, "completed"), inArray(focusSessions.taskId, doneTasks.map((x) => x.id))))
    : [];
  allTaskSessions.forEach((s) => s.taskId && focusByTask.set(s.taskId, (focusByTask.get(s.taskId) ?? 0) + (s.sec ?? 0) / 60));
  const estActual = doneTasks
    .map((x) => ({ name: x.title.length > 18 ? x.title.slice(0, 18) + "…" : x.title, estimated: x.estimatedMinutes!, actual: x.actualMinutes ?? (focusByTask.has(x.id) ? Math.round(focusByTask.get(x.id)!) : null) }))
    .filter((x) => x.actual !== null)
    .slice(-15);
  const ratio = estActual.length ? estActual.reduce((a, x) => a + (x.actual ?? 0), 0) / estActual.reduce((a, x) => a + x.estimated, 0) : null;

  // Sleep
  const sleepStats = computeSleepStats(sleep, tz, { bed: prefs.sleepTargetBed, wake: prefs.sleepTargetWake, minutes: prefs.sleepTargetMinutes });
  const sleepByDay = new Map(sleep.map((s) => [s.wakeDate, s.durationMinutes]));
  const sleepChart = days.map((d) => ({ day: formatDayMonth(d, mode), hours: sleepByDay.has(d) ? Math.round((sleepByDay.get(d)! / 60) * 10) / 10 : null }));

  // Habits
  const effectiveTo = to < today ? to : today;
  const habitRates = habitRows
    .filter((h) => h.startDate <= effectiveTo)
    .map((h) => {
      const map = new Map<string, HabitStatus>(occ.filter((o) => o.habitId === h.id).map((o) => [o.date, o.status as HabitStatus]));
      const s = computeHabitStats(h, map, pauses.filter((p) => p.habitId === h.id), from, effectiveTo, prefs.weekStart);
      return { name: h.name, rate: s.completionRate === null ? null : Math.round(s.completionRate) };
    });

  // Time allocation by category & project
  const cat = new Map<string, number>();
  const proj = new Map<string, number>();
  for (const a of acts) {
    const mins = splitByLocalDay(a.startAt, a.endAt, tz).filter((s) => s.date >= from && s.date <= to).reduce((m, s) => m + s.minutes, 0);
    cat.set(a.category, (cat.get(a.category) ?? 0) + mins);
    if (a.projectId) proj.set(a.projectId, (proj.get(a.projectId) ?? 0) + mins);
  }
  const catData = [...cat.entries()].map(([k, v]) => ({ name: label(t.activityCategory, k), value: Math.round(v) })).sort((a, b) => b.value - a.value);
  const projData = [...proj.entries()].map(([k, v]) => ({ name: projectRows.find((p) => p.id === k)?.name ?? "—", value: Math.round(v) })).sort((a, b) => b.value - a.value);

  // Goal progress over time (last known value per day; null before first record)
  const topGoals = goalRows.filter((g) => gLog.some((l) => l.goalId === g.id)).slice(0, 5);
  const goalChart = days.map((d) => {
    const row: Record<string, string | number | null> = { day: formatDayMonth(d, mode) };
    for (const g of topGoals) {
      const last = gLog.filter((l) => l.goalId === g.id && localDate(l.recordedAt, tz) <= d).pop();
      row[g.id] = last ? last.progress : null;
    }
    return row;
  });

  return (
    <div className="space-y-6">
      <PageHeader title="تحلیل‌ها" subtitle="همهٔ نمودارها مستقیماً از رکوردهای ذخیره‌شده محاسبه می‌شوند. روزهای بدون ثبت به‌عنوان «بدون داده» نمایش داده می‌شوند." />
      <DateRangeFilter from={from} to={to} basePath="/analytics" />
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="مجموع تمرکز (تایمر)" value={sessions.length ? formatMinutes(totalFocus) : "—"} hint={`${fa(sessions.length)} جلسه`} />
        <Stat label="تمرکز خوداظهاری" value={reported.length ? formatMinutes(reported.reduce((a, s) => a + (s.focusedMinutes ?? 0), 0)) : "—"} hint={reported.length ? `از ${fa(reported.length)} جلسهٔ دارای گزارش (${formatMinutes(reported.reduce((a, s) => a + (s.elapsedSeconds ?? 0), 0) / 60)} تایمر)` : "گزارشی ثبت نشده"} />
        <Stat label="میانگین خواب" value={formatMinutes(sleepStats.avgDuration)} hint={`${fa(sleepStats.count)} شب ثبت‌شده`} />
        <Stat label="نسبت زمان واقعی به تخمین" value={ratio === null ? "—" : `${fa(ratio.toFixed(2))}×`} hint={estActual.length ? `${fa(estActual.length)} کار دارای هر دو مقدار` : "دادهٔ کافی نیست"} />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card title="تمرکز روزانه (دقیقه)" className="lg:col-span-2"><BarSeries data={dailyFocus} xKey="day" unit="دقیقه" series={[{ key: "minutes", name: "تمرکز" }]} /></Card>
        <Card title="تمرکز هفتگی (ساعت)"><BarSeries data={weeklyFocus} xKey="week" unit="ساعت" series={[{ key: "hours", name: "تمرکز" }]} /></Card>
        <Card title="روند ماهانهٔ تمرکز (ساعت)"><BarSeries data={monthlyFocus} xKey="month" unit="ساعت" series={[{ key: "hours", name: "تمرکز" }]} /></Card>
        <Card title="کارهای برنامه‌ریزی‌شده در برابر انجام‌شده" className="lg:col-span-2"><BarSeries data={tasksPerDay} xKey="day" series={[{ key: "planned", name: "برنامه‌ریزی‌شده", color: "#a1a1aa" }, { key: "done", name: "انجام‌شده" }]} /></Card>
        <Card title="زمان تخمینی در برابر واقعی (دقیقه)" className="lg:col-span-2">
          <BarSeries data={estActual} xKey="name" unit="دقیقه" series={[{ key: "estimated", name: "تخمین", color: "#a1a1aa" }, { key: "actual", name: "واقعی" }]} />
          <p className="hint">زمان واقعی = مقدار واردشده روی کار، یا در نبود آن مجموع جلسات تمرکز مرتبط. کارهای بدون زمان واقعی نمایش داده نمی‌شوند.</p>
        </Card>
        <Card title="مدت خواب (ساعت)">
          <LineSeries data={sleepChart} xKey="day" unit="ساعت" series={[{ key: "hours", name: "خواب" }]} />
          <p className="hint">ثبات زمان خواب: {sleepStats.bedtimeStdDev === null ? "—" : `±${formatMinutes(sleepStats.bedtimeStdDev)}`} · ثبات بیداری: {sleepStats.wakeStdDev === null ? "—" : `±${formatMinutes(sleepStats.wakeStdDev)}`} · رسیدن به هدف مدت: {formatPercent(sleepStats.targetDurationHitRate)}</p>
        </Card>
        <Card title="نرخ تکمیل عادت‌ها (٪)"><BarSeries data={habitRates} xKey="name" unit="٪" series={[{ key: "rate", name: "نرخ تکمیل" }]} /></Card>
        <Card title="تخصیص زمان بر اساس دسته"><PieSeries data={catData} unit="دقیقه" /></Card>
        <Card title="تخصیص زمان به پروژه‌ها"><PieSeries data={projData} unit="دقیقه" /></Card>
        <Card title="پیشرفت اهداف در طول زمان (٪)" className="lg:col-span-2">
          <LineSeries data={goalChart} xKey="day" unit="٪" domain={[0, 100]} series={topGoals.map((g) => ({ key: g.id, name: g.title }))} />
        </Card>
      </div>

      <Card title="روش محاسبه">
        <ul className="list-inside list-disc space-y-1 text-sm muted">
          <li>«تمرکز (تایمر)» زمان اندازه‌گیری‌شدهٔ جلسات تکمیل‌شده بدون احتساب توقف‌هاست؛ جلسات لغوشده حساب نمی‌شوند. «خوداظهاری» فقط از جلساتی است که پس از پایان گزارش داده‌اید.</li>
          <li>جلسات و فعالیت‌هایی که از نیمه‌شب عبور می‌کنند به نسبت زمان بین دو روز تقسیم می‌شوند (بر اساس منطقهٔ زمانی شما: {tz}).</li>
          <li>نرخ عادت‌ها فقط روزهای برنامه‌ریزی‌شده را در نظر می‌گیرد؛ دوره‌های توقف و رد عمدی خنثی هستند.</li>
          <li>هیچ «امتیاز بهره‌وری» ترکیبی استفاده نمی‌شود؛ هر شاخص جداگانه و شفاف نمایش داده می‌شود.</li>
        </ul>
      </Card>
    </div>
  );
}
