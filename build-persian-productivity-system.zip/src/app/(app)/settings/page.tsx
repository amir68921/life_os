import { requireUser } from "@/lib/auth";
import { SettingsClient } from "@/components/settings-client";
import { Settings as SettingsIcon } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function SettingsPage() {
  const user = await requireUser();
  const s = user.settings;
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2.5">
        <SettingsIcon className="size-5" style={{ color: "var(--accent)" }} />
        <div>
          <h1 className="text-lg font-extrabold tracking-tight">تنظیمات</h1>
          <p className="text-xs" style={{ color: "var(--fg-muted)" }}>پوسته، منطقهٔ زمانی، اهداف خواب، خروجی و حساب</p>
        </div>
      </div>
      <SettingsClient
        settings={{
          theme: s.theme, timezone: s.timezone, weekStart: s.weekStart,
          defaultFocusMinutes: s.defaultFocusMinutes, defaultBreakMinutes: s.defaultBreakMinutes,
          targetBedTime: s.targetBedTime, targetWakeTime: s.targetWakeTime, targetSleepMinutes: s.targetSleepMinutes,
        }}
        username={user.username}
        displayName={user.displayName ?? ""}
      />
    </div>
  );
}
