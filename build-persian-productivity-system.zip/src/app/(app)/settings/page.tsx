import { requireContext } from "@/lib/auth";
import { aiStatus } from "@/lib/ai";
import { Badge, Card, PageHeader } from "@/components/ui";
import { DeleteAccountForm, PasswordForm, SettingsForm } from "@/components/settings-ui";

export default async function SettingsPage() {
  const { user, prefs } = await requireContext();
  const ai = aiStatus();
  return (
    <div className="space-y-6">
      <PageHeader title="تنظیمات" subtitle={`حساب: ${user.email}`} />
      <Card>
        <SettingsForm prefs={prefs} name={user.name} />
      </Card>
      <Card title="داده‌های شما">
        <p className="mb-3 text-sm muted">یک نسخهٔ کامل JSON از همهٔ داده‌هایتان دریافت کنید (بدون رمز عبور).</p>
        <div className="flex flex-wrap items-center gap-2">
          <a href="/api/export" className="btn" download>
            دریافت خروجی کامل (JSON)
          </a>
          <button type="button" className="btn" disabled aria-disabled>
            ورود داده
          </button>
          <Badge>ورود داده هنوز در دسترس نیست</Badge>
        </div>
      </Card>
      <Card title="دستیار هوش مصنوعی">
        <p className="text-sm muted">
          {ai.configured
            ? "یک ارائه‌دهندهٔ هوش مصنوعی در سرور پیکربندی شده است. قابلیت‌های دستیار در نسخه‌های بعدی فعال می‌شوند و همیشه فقط پیشنهاد می‌دهند."
            : "هوش مصنوعی پیکربندی نشده است و همهٔ بخش‌های برنامه بدون آن کار می‌کنند. زیرساخت آن آماده است (به README مراجعه کنید)."}
        </p>
        <div className="mt-2"><Badge tone={ai.configured ? "accent" : "neutral"}>{ai.configured ? "پیکربندی‌شده" : "غیرفعال"}</Badge></div>
      </Card>
      <Card title="تغییر رمز عبور">
        <PasswordForm />
      </Card>
      <Card title="حذف حساب" className="border-red-200 dark:border-red-900">
        <p className="mb-3 text-sm muted">همهٔ داده‌ها برای همیشه حذف می‌شوند. پیشنهاد می‌شود ابتدا خروجی بگیرید.</p>
        <DeleteAccountForm />
      </Card>
    </div>
  );
}
