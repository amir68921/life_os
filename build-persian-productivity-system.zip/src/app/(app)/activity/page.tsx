import { and, asc, eq, gte, lt, type SQL } from "drizzle-orm";
import { db } from "@/db";
import { activities } from "@/db/schema";
import { requireContext } from "@/lib/auth";
import { formatDateLong, formatMinutes } from "@/lib/format";
import { label, options, t } from "@/lib/i18n";
import { overlaps } from "@/lib/overlap";
import { getLinkOptions } from "@/lib/queries";
import { addDays, isIsoDate, localDate, rangeBoundsUtc, todayIn } from "@/lib/time";
import { Card, EmptyState, PageHeader } from "@/components/ui";
import { ActivityItem, NewActivityButton } from "@/components/activity-ui";
import { DateRangeFilter } from "@/components/range-filter";

type SP = Promise<Record<string, string | undefined>>;

export default async function ActivityPage({ searchParams }: { searchParams: SP }) {
  const sp = await searchParams;
  const { user, tz, mode } = await requireContext();
  const today = todayIn(tz);
  const to = isIsoDate(sp.to) ? sp.to : isIsoDate(sp.date) ? sp.date : today;
  const from = isIsoDate(sp.from) ? sp.from : isIsoDate(sp.date) ? sp.date : addDays(to, -6);
  const { start, end } = rangeBoundsUtc(from, to, tz);
  const conds: SQL[] = [eq(activities.userId, user.id), lt(activities.startAt, end), gte(activities.endAt, start)];
  if (sp.category) conds.push(eq(activities.category, sp.category));
  if (sp.source) conds.push(eq(activities.source, sp.source));
  const [rows, links] = await Promise.all([db.select().from(activities).where(and(...conds)).orderBy(asc(activities.startAt)), getLinkOptions(user.id)]);

  const byDay = new Map<string, typeof rows>();
  for (const r of rows) {
    const d = localDate(r.startAt, tz);
    byDay.set(d, [...(byDay.get(d) ?? []), r]);
  }
  const days = [...byDay.keys()].sort().reverse();
  const totals = new Map<string, number>();
  rows.forEach((r) => totals.set(r.category, (totals.get(r.category) ?? 0) + (r.endAt.getTime() - r.startAt.getTime()) / 60000));
  const overlapsFor = (r: (typeof rows)[number]) =>
    rows.filter((o) => o.id !== r.id && overlaps({ start: r.startAt.getTime(), end: r.endAt.getTime() }, { start: o.startAt.getTime(), end: o.endAt.getTime() }));

  return (
    <div className="space-y-5">
      <PageHeader
        title="گزارش فعالیت"
        subtitle="ثبت دستی زمان و فعالیت‌هایی که از تایمر تمرکز می‌آیند. زمان ثبت‌نشده «هدررفته» فرض نمی‌شود. این برنامه فعالیت سایر اپلیکیشن‌ها را پایش نمی‌کند."
        actions={<NewActivityButton links={links} defaultOpen={sp.new === "1"} date={isIsoDate(sp.date) ? sp.date : undefined} />}
      />
      <DateRangeFilter from={from} to={to} basePath="/activity" extra={
        <>
          <select name="category" defaultValue={sp.category ?? ""} className="input" aria-label="دسته‌بندی">
            <option value="">همهٔ دسته‌ها</option>
            {options(t.activityCategory).map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
          </select>
          <select name="source" defaultValue={sp.source ?? ""} className="input" aria-label="منبع">
            <option value="">همهٔ منابع</option>
            {options(t.activitySource).map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
          </select>
        </>
      } />
      {totals.size > 0 && (
        <Card title="جمع بازه بر اساس دسته">
          <div className="flex flex-wrap gap-2">
            {[...totals.entries()].sort((a, b) => b[1] - a[1]).map(([c, m]) => (
              <span key={c} className="chip py-1">{label(t.activityCategory, c)}: {formatMinutes(m)}</span>
            ))}
          </div>
        </Card>
      )}
      {rows.length === 0 ? (
        <EmptyState title="فعالیتی در این بازه ثبت نشده" description="فعالیت‌ها را دستی ثبت کنید؛ جلسات تمرکز تکمیل‌شده هم خودکار اضافه می‌شوند." icon="≣" />
      ) : (
        days.map((d) => (
          <Card key={d} title={formatDateLong(d, mode, true)}>
            <ul className="divide-y divide-zinc-100 dark:divide-zinc-800">
              {byDay.get(d)!.map((r) => <ActivityItem key={r.id} a={r} links={links} overlapWith={overlapsFor(r)} />)}
            </ul>
          </Card>
        ))
      )}
    </div>
  );
}
