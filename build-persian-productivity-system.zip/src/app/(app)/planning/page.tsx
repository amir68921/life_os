import { and, eq, gte, lte, asc } from "drizzle-orm";
import { db } from "@/db";
import { tasks, goals, focusSessions } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { PlanningClient } from "@/components/planning-client";
import { todayIso, addDaysIso, weekDaysIso, fmtTimeInTz } from "@/lib/jalali";
import { CalendarDays } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function PlanningPage() {
  const user = await requireUser();
  const tz = user.settings.timezone;
  const today = todayIso(tz);
  const weekDays = weekDaysIso(today, user.settings.weekStart);
  const from = addDaysIso(weekDays[0], -7);
  const to = addDaysIso(weekDays[6], 14);

  const [taskRows, goalRows, focusRows] = await Promise.all([
    db.select().from(tasks).where(and(eq(tasks.userId, user.id), gte(tasks.dueDate, from), lte(tasks.dueDate, to))),
    db.select({ id: goals.id, title: goals.title }).from(goals).where(eq(goals.userId, user.id)).orderBy(asc(goals.title)),
    db.select().from(focusSessions).where(and(
      eq(focusSessions.userId, user.id), eq(focusSessions.status, "completed"),
      gte(focusSessions.localDate, from), lte(focusSessions.localDate, to))),
  ]);

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2.5">
        <CalendarDays className="size-5" style={{ color: "var(--accent)" }} />
        <div>
          <h1 className="text-lg font-extrabold tracking-tight">برنامه‌ریزی روزانه و هفتگی</h1>
          <p className="text-xs" style={{ color: "var(--fg-muted)" }}>
            کارهایت را روی روزها بچین، ساعت بده، و با تمرکزِ واقعیِ ثبت‌شده مقایسه کن.
          </p>
        </div>
      </div>
      <PlanningClient
        tasks={taskRows}
        focus={focusRows.map((f) => ({
          id: f.id, localDate: f.localDate,
          startedClock: fmtTimeInTz(f.startedAt, tz),
          minutes: Math.round((f.elapsedSeconds ?? 0) / 60),
          objective: f.objective,
        }))}
        goals={goalRows}
        today={today}
        weekDays={weekDays}
        tz={tz}
      />
    </div>
  );
}
