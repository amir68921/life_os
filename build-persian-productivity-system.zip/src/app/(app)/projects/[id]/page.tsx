import Link from "next/link";
import { notFound } from "next/navigation";
import { and, asc, desc, eq, ne, sql } from "drizzle-orm";
import { db } from "@/db";
import { activities, goals, milestones, notes, projectGoals, projects, tasks } from "@/db/schema";
import { requireContext } from "@/lib/auth";
import { fa, formatDateShort, formatMinutes } from "@/lib/format";
import { label, t } from "@/lib/i18n";
import { getLinkOptions } from "@/lib/queries";
import { Badge, Card, PageHeader, Progress, priorityTone } from "@/components/ui";
import { Milestones, ProjectAdmin } from "@/components/goal-project-ui";
import { NewTaskButton, TaskRow } from "@/components/task-ui";

export default async function ProjectDetail({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!/^[0-9a-f-]{36}$/i.test(id)) notFound();
  const { user, mode } = await requireContext();
  const [project] = await db.select().from(projects).where(and(eq(projects.id, id), eq(projects.userId, user.id))).limit(1);
  if (!project) notFound();
  const [ms, projectTasks, linked, goalOptions, time, byCategory, projectNotes, links] = await Promise.all([
    db.select().from(milestones).where(and(eq(milestones.projectId, id), eq(milestones.userId, user.id))).orderBy(sql`${milestones.dueDate} asc nulls last`),
    db.select().from(tasks).where(and(eq(tasks.projectId, id), eq(tasks.userId, user.id))).orderBy(sql`${tasks.dueDate} asc nulls last`),
    db.select({ id: goals.id, title: goals.title }).from(projectGoals).innerJoin(goals, eq(goals.id, projectGoals.goalId)).where(and(eq(projectGoals.projectId, id), eq(goals.userId, user.id))),
    db.select({ id: goals.id, title: goals.title }).from(goals).where(and(eq(goals.userId, user.id), ne(goals.status, "archived"))).orderBy(asc(goals.title)),
    db.select({ min: sql<number>`coalesce(sum(extract(epoch from (${activities.endAt} - ${activities.startAt})) / 60), 0)::float` }).from(activities).where(and(eq(activities.projectId, id), eq(activities.userId, user.id))),
    db.select({ source: activities.source, min: sql<number>`sum(extract(epoch from (${activities.endAt} - ${activities.startAt})) / 60)::float` }).from(activities).where(and(eq(activities.projectId, id), eq(activities.userId, user.id))).groupBy(activities.source),
    db.select({ id: notes.id, title: notes.title }).from(notes).where(and(eq(notes.projectId, id), eq(notes.userId, user.id))).orderBy(desc(notes.updatedAt)).limit(10),
    getLinkOptions(user.id),
  ]);
  const open = projectTasks.filter((x) => x.status !== "cancelled");
  const done = open.filter((x) => x.status === "done").length;
  const est = open.reduce((a, x) => a + (x.estimatedMinutes ?? 0), 0);

  return (
    <div className="space-y-6">
      <Link href="/projects" className="text-sm muted hover:underline">→ بازگشت به پروژه‌ها</Link>
      <PageHeader
        title={project.name}
        subtitle={
          <span className="flex flex-wrap gap-1.5">
            <Badge tone="accent">{label(t.projectStatus, project.status)}</Badge>
            <Badge tone={priorityTone[project.priority]}>اولویت {label(t.priority, project.priority)}</Badge>
          </span>
        }
        actions={<ProjectAdmin project={project} goalOptions={goalOptions} linkedGoalIds={linked.map((g) => g.id)} />}
      />
      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <Card>
            <div className="flex items-center gap-3">
              <Progress value={project.progress} label="پیشرفت پروژه" />
              <span className="text-lg font-bold">{fa(project.progress)}٪</span>
            </div>
            {open.length > 0 && <p className="hint">پیشرفت بر اساس کارها: {fa(Math.round((done / open.length) * 100))}٪ ({fa(done)} از {fa(open.length)})</p>}
            <dl className="mt-5 grid gap-4 text-sm sm:grid-cols-4">
              <div><dt className="text-xs muted">شروع</dt><dd>{formatDateShort(project.startDate, mode)}</dd></div>
              <div><dt className="text-xs muted">هدف</dt><dd>{formatDateShort(project.targetDate, mode)}</dd></div>
              <div><dt className="text-xs muted">زمان واقعی صرف‌شده</dt><dd>{formatMinutes(time[0]?.min ?? 0)}</dd></div>
              <div><dt className="text-xs muted">مجموع تخمین کارها</dt><dd>{formatMinutes(est)}</dd></div>
            </dl>
            {byCategory.length > 0 && (
              <p className="hint mt-2">
                {byCategory.map((b) => `${label(t.activitySource, b.source)}: ${formatMinutes(b.min)}`).join(" · ")}
              </p>
            )}
            {project.objective && <p className="mt-4 text-sm"><span className="font-medium">هدف پروژه: </span>{project.objective}</p>}
            {project.description && <p className="mt-2 whitespace-pre-wrap text-sm muted">{project.description}</p>}
            {project.notes && <p className="mt-2 whitespace-pre-wrap text-sm muted">{project.notes}</p>}
          </Card>
          <Card title="کارهای پروژه" action={<NewTaskButton links={links} defaults={{ projectId: project.id }} className="btn btn-sm" label="کار" />}>
            {projectTasks.length === 0 ? (
              <p className="text-sm muted">هنوز کاری به این پروژه اضافه نشده است.</p>
            ) : (
              <ul className="divide-y divide-zinc-100 dark:divide-zinc-800">
                {projectTasks.map((task) => (
                  <TaskRow key={task.id} task={task} links={links} />
                ))}
              </ul>
            )}
          </Card>
        </div>
        <div className="space-y-6">
          <Card title="نقاط عطف">
            <Milestones items={ms} projectId={project.id} />
          </Card>
          <Card title="اهداف مرتبط">
            {linked.length === 0 ? (
              <p className="text-sm muted">به هیچ هدفی متصل نیست (از «ویرایش» اضافه کنید).</p>
            ) : (
              <ul className="space-y-1.5 text-sm">
                {linked.map((g) => (
                  <li key={g.id}><Link href={`/goals/${g.id}`} className="hover:underline">◎ {g.title}</Link></li>
                ))}
              </ul>
            )}
          </Card>
          <Card title="یادداشت‌ها">
            {projectNotes.length === 0 ? (
              <p className="text-sm muted">یادداشتی پیوند نشده است.</p>
            ) : (
              <ul className="space-y-1.5 text-sm">
                {projectNotes.map((n) => (
                  <li key={n.id}><Link href={`/notes?id=${n.id}`} className="hover:underline">{n.title}</Link></li>
                ))}
              </ul>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}
