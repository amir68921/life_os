import Link from "next/link";
import { and, asc, eq, ne, sql } from "drizzle-orm";
import { db } from "@/db";
import { activities, goals, projects, tasks } from "@/db/schema";
import { requireContext } from "@/lib/auth";
import { fa, formatDateShort, formatMinutes } from "@/lib/format";
import { label, options, t } from "@/lib/i18n";
import { Badge, EmptyState, PageHeader, Progress, priorityTone } from "@/components/ui";
import { NewProjectButton } from "@/components/goal-project-ui";

type SP = Promise<Record<string, string | undefined>>;

export default async function ProjectsPage({ searchParams }: { searchParams: SP }) {
  const sp = await searchParams;
  const { user, mode } = await requireContext();
  const status = sp.status ?? "open";
  const where =
    status === "open"
      ? and(eq(projects.userId, user.id), sql`${projects.status} in ('planned','active','on_hold')`)
      : status === "all"
        ? eq(projects.userId, user.id)
        : and(eq(projects.userId, user.id), eq(projects.status, status));
  const [rows, goalOptions, taskCounts, time] = await Promise.all([
    db.select().from(projects).where(where).orderBy(sql`${projects.targetDate} asc nulls last`),
    db.select({ id: goals.id, title: goals.title }).from(goals).where(and(eq(goals.userId, user.id), ne(goals.status, "archived"))).orderBy(asc(goals.title)),
    db
      .select({ projectId: tasks.projectId, total: sql<number>`count(*) filter (where ${tasks.status} <> 'cancelled')::int`, done: sql<number>`count(*) filter (where ${tasks.status} = 'done')::int` })
      .from(tasks)
      .where(and(eq(tasks.userId, user.id), sql`${tasks.projectId} is not null`))
      .groupBy(tasks.projectId),
    db
      .select({ projectId: activities.projectId, min: sql<number>`sum(extract(epoch from (${activities.endAt} - ${activities.startAt})) / 60)::float` })
      .from(activities)
      .where(and(eq(activities.userId, user.id), sql`${activities.projectId} is not null`))
      .groupBy(activities.projectId),
  ]);
  const tc = new Map(taskCounts.map((x) => [x.projectId, x]));
  const tm = new Map(time.map((x) => [x.projectId, x.min]));

  return (
    <div>
      <PageHeader title="پروژه‌ها" subtitle="پیشرفت، کارها، نقاط عطف و زمان واقعی صرف‌شده برای هر پروژه." actions={<NewProjectButton goalOptions={goalOptions} />} />
      <nav className="mb-5 flex flex-wrap gap-1" aria-label="فیلتر وضعیت">
        {[{ value: "open", label: "در جریان" }, ...options(t.projectStatus), { value: "all", label: "همه" }].map((o) => (
          <Link key={o.value} href={`/projects?status=${o.value}`} className={`tab ${status === o.value ? "tab-active" : ""}`}>
            {o.label}
          </Link>
        ))}
      </nav>
      {rows.length === 0 ? (
        <EmptyState title="پروژه‌ای پیدا نشد" description="پروژه‌ها مجموعه‌ای از کارها و نقاط عطف با یک هدف مشخص هستند." action={<NewProjectButton goalOptions={goalOptions} />} icon="▦" />
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {rows.map((p) => {
            const c = tc.get(p.id);
            return (
              <Link key={p.id} href={`/projects/${p.id}`} className="card block transition-colors hover:border-accent-300 dark:hover:border-accent-700">
                <div className="flex items-start justify-between gap-2">
                  <h2 className="font-semibold">{p.name}</h2>
                  <Badge tone={p.status === "active" ? "accent" : "neutral"}>{label(t.projectStatus, p.status)}</Badge>
                </div>
                {p.objective && <p className="mt-1 line-clamp-2 text-sm muted">{p.objective}</p>}
                <div className="mt-4 flex items-center gap-3">
                  <Progress value={p.progress} label={`پیشرفت ${p.name}`} />
                  <span className="w-10 shrink-0 text-sm font-semibold">{fa(p.progress)}٪</span>
                </div>
                <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-xs muted">
                  <Badge tone={priorityTone[p.priority]}>{label(t.priority, p.priority)}</Badge>
                  {c && <span>کارها: {fa(c.done)}/{fa(c.total)}</span>}
                  <span>زمان صرف‌شده: {formatMinutes(tm.get(p.id) ?? 0)}</span>
                  {p.targetDate && <span>هدف: {formatDateShort(p.targetDate, mode)}</span>}
                </div>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
