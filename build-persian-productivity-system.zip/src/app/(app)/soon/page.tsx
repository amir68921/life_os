import { Card } from "@/components/ui";
import { FolderKanban, Footprints, StickyNote, Rocket } from "lucide-react";

export const dynamic = "force-dynamic";

const ITEMS = [
  {
    icon: FolderKanban, title: "پروژه‌ها",
    desc: "مدیریت پروژه با سنگ‌نما، وظایف مرتبط، زمان صرف‌شده و پیشرفت — در فاز ۲.",
  },
  {
    icon: Footprints, title: "گزارش فعالیت‌ها",
    desc: "ثبت و مرور اینکه روزت دقیقاً صرف چه شد، با تشخیص هم‌پوشانی و اتصال به وظایف — در فاز ۲.",
  },
  {
    icon: StickyNote, title: "یادداشت‌ها",
    desc: "دانش شخصی: جستجو، برچسب، اتصال به هدف و پروژه، بدون وابستگی به سرویس بیرونی — در فاز ۲.",
  },
];

export default function SoonPage() {
  return (
    <div className="space-y-5">
      <div className="flex items-center gap-2.5">
        <Rocket className="size-5" style={{ color: "var(--accent)" }} />
        <div>
          <h1 className="text-lg font-extrabold tracking-tight">در دست ساخت — فاز ۲</h1>
          <p className="text-xs" style={{ color: "var(--fg-muted)" }}>
            این بخش‌ها هنوز ساخته نشده‌اند؛ به‌جای دکمهٔ نمایشی، صادقانه اعلامشان می‌کنیم.
          </p>
        </div>
      </div>
      <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
        {ITEMS.map((it) => (
          <Card key={it.title} className="!p-5">
            <div className="mb-3 grid size-10 place-items-center rounded-xl" style={{ background: "var(--bg-soft)", color: "var(--fg-faint)" }}>
              <it.icon className="size-5" />
            </div>
            <p className="text-sm font-bold">{it.title}</p>
            <p className="mt-1.5 text-xs leading-6" style={{ color: "var(--fg-muted)" }}>{it.desc}</p>
            <span className="chip mt-3" style={{ background: "var(--bg-soft)", color: "var(--fg-faint)", borderColor: "transparent" }}>
              فاز ۲ — به‌زودی
            </span>
          </Card>
        ))}
      </div>
      <p className="text-xs leading-6" style={{ color: "var(--fg-faint)" }}>
        اولویت تیم (تو!) فعلاً پایداری و دقت هستهٔ فعلی است: وظایف، اهداف، تمرکز، خواب، عادت‌ها و مرورها.
      </p>
    </div>
  );
}
