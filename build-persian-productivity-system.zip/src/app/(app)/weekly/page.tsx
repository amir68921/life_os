import Link from "next/link";
import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { weeklyReviews, type Suggestion } from "@/db/schema";
import { requireContext } from "@/lib/auth";
import { saveWeeklyReview } from "@/app/actions/reviews";
import { fa, formatDayMonth, formatMinutes, formatPercent } from "@/lib/format";
import { generateSuggestions } from "@/lib/suggestions";
import { addDays, isIsoDate, startOfWeek, todayIn } from "@/lib/time";
import { weeklyReport } from "@/lib/weekly";
import { Card, PageHeader, Stat } from "@/components/ui";
import { ActionForm, Field } from "@/components/forms";
import { SuggestionCard } from "@/components/suggestions-ui";

type SP = Promise<Record<string, string | undefined>>;

export default async function WeeklyPage({ searchParams }: { searchParams: SP }) {
  const sp = await searchParams;
  const { user, prefs, tz, mode } = await requireContext();
  const today = todayIn(tz);
  const weekStart = startOfWeek(isIsoDate(sp.week) ? sp.week : today, prefs.weekStart);
  const weekEnd = addDays(weekStart, 6);
  const [report, saved, past] = await Promise.all([
    weeklyReport(user.id, prefs, weekStart, today),
    db.select().from(weeklyReviews).where(and(eq(weeklyReviews.userId, user.id), eq(weeklyReviews.weekStart, weekStart))).limit(1),
    db.select({ weekStart: weeklyReviews.weekStart }).from(weeklyReviews).where(eq(weeklyReviews.userId, user.id)).orderBy(desc(weeklyReviews.weekStart)).limit(12),
  ]);
  const m = report.metrics;
  const review = saved[0];
  const savedSuggestions = new Map((review?.suggestions ?? []).map((s) => [s.id, s]));
  const generated = generateSuggestions(m);
  const suggestions: Suggestion[] = [
    ...generated.map((g) => savedSuggestions.get(g.id) ?? { ...g, status: "pending" as const }),
    ...(review?.suggestions ?? []).filter((s) => !generated.some((g) => g.id === s.id) && s.status === "accepted"),
  ];

  return (
    <div className="space-y-6">
      <PageHeader
        title="مرور هفتگی"
        subtitle={`${formatDayMonth(weekStart, mode)} تا ${formatDayMonth(weekEnd, mode)} — گزارش بر اساس داده‌های واقعاً ثبت‌شده`}
        actions={
          <div className="flex gap-1">
            <Link href={`/weekly?week=${addDays(weekStart, -7)}`} className="btn btn-sm">هفتهٔ قبل</Link>
            <Link href="/weekly" className="btn btn-sm">این هفته</Link>
            {weekEnd < today && <Link href={`/weekly?week=${addDays(weekStart, 7)}`} className="btn btn-sm">هفتهٔ بعد</Link>}
          </div>
        }
      />
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="کارهای انجام‌شده / برنامه‌ریزی‌شده" value={m.tasksPlanned ? `${fa(m.tasksCompleted)}/${fa(m.tasksPlanned)}` : "—"} hint={m.tasksPlanned ? formatPercent((m.tasksCompleted / m.tasksPlanned) * 100) : "کاری با سررسید این هفته نبود"} />
        <Stat label="زمان تمرکز (تایمر)" value={m.focusSessions ? formatMinutes(m.focusMinutes) : "—"} hint={`${fa(m.focusSessions)} جلسه${report.reportedFocusSessions ? ` · ${formatMinutes(report.reportedFocusMinutes)} متمرکز (خوداظهاری)` : ""}`} />
        <Stat label="میانگین خواب" value={formatMinutes(report.sleepStats.avgDuration)} hint={`${fa(m.sleepNights)} شب ثبت‌شده${report.sleepStats.bedtimeStdDev !== null ? ` · ثبات ±${formatMinutes(report.sleepStats.bedtimeStdDev)}` : ""}`} />
        <Stat label="تکمیل عادت‌ها" value={m.habitEligible ? formatPercent((m.habitCompleted / m.habitEligible) * 100) : "—"} hint={m.habitEligible ? `${fa(m.habitCompleted)} از ${fa(m.habitEligible)} نوبت روزانه` : "داده‌ای نیست"} />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card title="برنامه در برابر واقعیت">
          <dl className="grid grid-cols-2 gap-4 text-sm">
            <div><dt className="text-xs muted">زمان برنامه‌ریزی‌شده (بلوک‌ها)</dt><dd className="font-semibold">{formatMinutes(report.plannedMinutes)}</dd></div>
            <div><dt className="text-xs muted">زمان ثبت‌شده (فعالیت‌ها، بدون خواب)</dt><dd className="font-semibold">{formatMinutes(report.actualMinutes)}</dd></div>
            <div><dt className="text-xs muted">تمرکز/مطالعهٔ برنامه‌ریزی‌شده</dt><dd className="font-semibold">{formatMinutes(report.plannedFocusMinutes)}</dd></div>
            <div><dt className="text-xs muted">یادگیری ثبت‌شده + تمرکز تایمر</dt><dd className="font-semibold">{formatMinutes(report.learningMinutes)} + {formatMinutes(m.focusMinutes)}</dd></div>
          </dl>
          <p className="hint mt-3">زمان ثبت‌نشده به معنی زمان هدررفته نیست.</p>
        </Card>
        <Card title="رایج‌ترین وقفه‌ها">
          {report.topInterruptions.length === 0 ? <p className="text-sm muted">وقفه‌ای ثبت نشده است.</p> : (
            <ul className="space-y-1.5 text-sm">{report.topInterruptions.map((i) => <li key={i.reason} className="flex justify-between"><span>{i.reason}</span><span className="muted">{fa(i.count)} بار</span></li>)}</ul>
          )}
          <h3 className="mb-2 mt-5 text-sm font-semibold">کارهایی که چند بار جابه‌جا شده‌اند</h3>
          {m.postponedTasks.length === 0 ? <p className="text-sm muted">موردی نیست.</p> : (
            <ul className="space-y-1.5 text-sm">{m.postponedTasks.map((p) => <li key={p.title} className="flex justify-between"><span>{p.title}</span><span className="muted">{fa(p.count)} بار</span></li>)}</ul>
          )}
        </Card>
        <Card title="پیشرفت اهداف و پروژه‌ها">
          {report.goalChanges.length === 0 && report.projectTime.length === 0 ? <p className="text-sm muted">تغییری در این هفته ثبت نشده است.</p> : (
            <ul className="space-y-1.5 text-sm">
              {report.goalChanges.map((g) => <li key={g.title} className="flex justify-between"><span>◎ {g.title}</span><span className="muted">{g.from === null ? "" : `${fa(g.from)}٪ ← `}{fa(g.to)}٪</span></li>)}
              {report.projectTime.map((p) => <li key={p.name} className="flex justify-between"><span>▦ {p.name}</span><span className="muted">{formatMinutes(p.minutes)} · {fa(p.progress)}٪</span></li>)}
            </ul>
          )}
        </Card>
        <Card title="عادت‌ها در این هفته">
          {report.habitBreakdown.length === 0 ? <p className="text-sm muted">عادتی تعریف نشده است.</p> : (
            <ul className="space-y-1.5 text-sm">{report.habitBreakdown.map((h) => <li key={h.name} className="flex justify-between"><span>{h.name}</span><span className="muted">{formatPercent(h.rate)}</span></li>)}</ul>
          )}
        </Card>
      </div>

      <Card title="پیشنهادها">
        {suggestions.filter((s) => s.status !== "dismissed").length === 0 ? (
          <p className="text-sm muted">برای ارائهٔ پیشنهاد، دادهٔ کافی در این هفته وجود ندارد یا همه چیز در محدودهٔ مطلوب است. پیشنهادها فقط وقتی ظاهر می‌شوند که شواهد کافی وجود داشته باشد.</p>
        ) : (
          <ul className="space-y-2">{suggestions.map((s) => <SuggestionCard key={s.id} weekStart={weekStart} s={s} />)}</ul>
        )}
        <p className="hint mt-3">پیشنهادها قانون‌محور و شفاف هستند (نه هوش مصنوعی) و شواهد هرکدام نمایش داده می‌شود.</p>
      </Card>

      <Card title="بازتاب هفتگی شما">
        <ActionForm action={saveWeeklyReview} key={weekStart}>
          <input type="hidden" name="weekStart" value={weekStart} />
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="موفقیت‌های این هفته"><textarea name="wins" rows={3} defaultValue={review?.wins ?? ""} className="input" /></Field>
            <Field label="چالش‌ها"><textarea name="challenges" rows={3} defaultValue={review?.challenges ?? ""} className="input" /></Field>
            <Field label="بازتاب و درس‌ها" className="sm:col-span-2"><textarea name="reflection" rows={3} defaultValue={review?.reflection ?? ""} className="input" /></Field>
            <Field label="تمرکز هفتهٔ آینده" className="sm:col-span-2"><input name="nextWeekFocus" defaultValue={review?.nextWeekFocus ?? ""} className="input" /></Field>
          </div>
        </ActionForm>
      </Card>

      {past.length > 0 && (
        <Card title="گزارش‌های قبلی">
          <div className="flex flex-wrap gap-2">{past.map((p) => <Link key={p.weekStart} href={`/weekly?week=${p.weekStart}`} className={`chip py-1 ${p.weekStart === weekStart ? "border-accent-500" : ""}`}>هفتهٔ {formatDayMonth(p.weekStart, mode)}</Link>)}</div>
        </Card>
      )}
    </div>
  );
}
