import Link from "next/link";
import { and, desc, eq, gte, lt } from "drizzle-orm";
import { db } from "@/db";
import { dailyReviews, focusSessions, interruptions, tasks } from "@/db/schema";
import { requireContext } from "@/lib/auth";
import { saveDailyReview } from "@/app/actions/reviews";
import { fa, formatDateLong, formatMinutes } from "@/lib/format";
import { addDays, dayBoundsUtc, isIsoDate, todayIn } from "@/lib/time";
import { Card, PageHeader } from "@/components/ui";
import { ActionForm, Field, RatingInput } from "@/components/forms";

type SP = Promise<Record<string, string | undefined>>;

export default async function DailyReviewPage({ searchParams }: { searchParams: SP }) {
  const sp = await searchParams;
  const { user, tz, mode } = await requireContext();
  const today = todayIn(tz);
  const date = isIsoDate(sp.date) && sp.date <= today ? sp.date : today;
  const { start, end } = dayBoundsUtc(date, tz);
  const [existing, history, dayTasks, sessions, ints] = await Promise.all([
    db.select().from(dailyReviews).where(and(eq(dailyReviews.userId, user.id), eq(dailyReviews.date, date))).limit(1),
    db.select().from(dailyReviews).where(eq(dailyReviews.userId, user.id)).orderBy(desc(dailyReviews.date)).limit(30),
    db.select({ status: tasks.status }).from(tasks).where(and(eq(tasks.userId, user.id), eq(tasks.dueDate, date))),
    db.select({ sec: focusSessions.elapsedSeconds }).from(focusSessions).where(and(eq(focusSessions.userId, user.id), eq(focusSessions.status, "completed"), gte(focusSessions.startedAt, start), lt(focusSessions.startedAt, end))),
    db.select({ reason: interruptions.reason }).from(interruptions).where(and(eq(interruptions.userId, user.id), gte(interruptions.occurredAt, start), lt(interruptions.occurredAt, end))),
  ]);
  const r = existing[0];
  const done = dayTasks.filter((x) => x.status === "done").length;
  const focus = sessions.reduce((a, s) => a + (s.sec ?? 0), 0) / 60;

  return (
    <div className="space-y-6">
      <PageHeader title="مرور روزانه" subtitle="کوتاه و اختیاری — همهٔ سؤال‌ها را لازم نیست جواب دهید." />
      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <Card
            title={formatDateLong(date, mode, true)}
            action={
              <div className="flex gap-1">
                <Link href={`/review?date=${addDays(date, -1)}`} className="btn btn-sm">روز قبل</Link>
                {date < today && <Link href={`/review?date=${addDays(date, 1)}`} className="btn btn-sm">روز بعد</Link>}
              </div>
            }
          >
            <p className="mb-4 rounded-xl bg-zinc-50 px-3 py-2 text-xs muted dark:bg-zinc-800/50">
              دادهٔ ثبت‌شدهٔ این روز: {fa(done)} از {fa(dayTasks.length)} کار انجام شد · {sessions.length ? `${formatMinutes(focus)} تمرکز در ${fa(sessions.length)} جلسه` : "جلسهٔ تمرکزی ثبت نشده"}
              {ints.length > 0 ? ` · وقفه‌ها: ${ints.slice(0, 4).map((i) => i.reason).join("، ")}` : ""}
            </p>
            <ActionForm action={saveDailyReview} key={date}>
              <input type="hidden" name="date" value={date} />
              <div className="grid gap-4">
                <Field label="مهم‌ترین دستاورد امروز چه بود؟"><textarea name="accomplishment" rows={2} defaultValue={r?.accomplishment ?? ""} className="input" /></Field>
                <Field label="به سمت کدام هدف پیشرفت کردم؟"><input name="goalProgress" defaultValue={r?.goalProgress ?? ""} className="input" /></Field>
                <Field label="چه چیزی حواسم را پرت کرد؟"><input name="distractions" defaultValue={r?.distractions ?? ""} className="input" /></Field>
                <div className="grid gap-4 sm:grid-cols-2">
                  <Field label="چه چیزی خوب پیش رفت؟"><textarea name="wentWell" rows={2} defaultValue={r?.wentWell ?? ""} className="input" /></Field>
                  <Field label="چه چیزی را می‌توانم بهتر کنم؟"><textarea name="improve" rows={2} defaultValue={r?.improve ?? ""} className="input" /></Field>
                </div>
                <Field label="اولویت اصلی فردا"><input name="tomorrowPriority" defaultValue={r?.tomorrowPriority ?? ""} className="input" /></Field>
                <RatingInput name="energy" label="انرژی امروز" defaultValue={r?.energy} />
              </div>
            </ActionForm>
          </Card>
        </div>
        <Card title="مرورهای قبلی">
          {history.length === 0 ? (
            <p className="text-sm muted">هنوز مروری ثبت نکرده‌اید.</p>
          ) : (
            <ul className="space-y-2">
              {history.map((h) => (
                <li key={h.id}>
                  <Link href={`/review?date=${h.date}`} className={`block rounded-xl px-3 py-2 text-sm hover:bg-zinc-50 dark:hover:bg-zinc-800 ${h.date === date ? "bg-zinc-100 dark:bg-zinc-800" : ""}`}>
                    <div className="font-medium">{formatDateLong(h.date, mode, true)}</div>
                    {h.accomplishment && <div className="truncate text-xs muted">{h.accomplishment}</div>}
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>
    </div>
  );
}
