import { eq, asc } from "drizzle-orm";
import { db } from "@/db";
import { goals, milestones, tasks } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { GoalsClient, type GoalRow, type MilestoneRow } from "@/components/goals-client";
import { todayIso } from "@/lib/jalali";
import { Target } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function GoalsPage() {
  const user = await requireUser();
  const [goalRows, msRows, taskRows] = await Promise.all([
    db.select().from(goals).where(eq(goals.userId, user.id)).orderBy(asc(goals.createdAt)),
    db.select().from(milestones)
      .innerJoin(goals, eq(goals.id, milestones.goalId))
      .where(eq(goals.userId, user.id))
      .then((r) => r.map((x) => x.milestones)),
    db.select({ id: tasks.id, goalId: tasks.goalId }).from(tasks).where(eq(tasks.userId, user.id)),
  ]);

  const byGoal: Record<string, MilestoneRow[]> = {};
  for (const m of msRows) (byGoal[m.goalId] ??= []).push(m);
  for (const arr of Object.values(byGoal)) arr.sort((a, b) => Number(a.done) - Number(b.done) || a.title.localeCompare(b.title, "fa"));

  const taskCounts = new Map<string, number>();
  for (const t of taskRows) if (t.goalId) taskCounts.set(t.goalId, (taskCounts.get(t.goalId) ?? 0) + 1);

  const data: GoalRow[] = goalRows.map((g) => ({ ...g, taskCount: taskCounts.get(g.id) ?? 0 }));

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2.5">
        <Target className="size-5" style={{ color: "var(--accent)" }} />
        <div>
          <h1 className="text-lg font-extrabold tracking-tight">اهداف</h1>
          <p className="text-xs" style={{ color: "var(--fg-muted)" }}>کوتاه‌مدت، میان‌مدت و بلندمدت — با سنگ‌نما و پیشرفت تصویری</p>
        </div>
      </div>
      <GoalsClient goals={data} milestonesByGoal={byGoal} today={todayIso(user.settings.timezone)} />
    </div>
  );
}
