import Link from "next/link";
import { and, asc, eq, sql, type SQL } from "drizzle-orm";
import { db } from "@/db";
import { goals, milestones, tasks } from "@/db/schema";
import { requireContext } from "@/lib/auth";
import { fa, formatDateShort } from "@/lib/format";
import { label, options, t } from "@/lib/i18n";
import { todayIn } from "@/lib/time";
import { Badge, Card, EmptyState, PageHeader, Progress, priorityTone } from "@/components/ui";
import { NewGoalButton } from "@/components/goal-project-ui";

type SP = Promise<Record<string, string | undefined>>;

export default async function GoalsPage({ searchParams }: { searchParams: SP }) {
  const sp = await searchParams;
  const { user, tz, mode } = await requireContext();
  const today = todayIn(tz);
  const conds: SQL[] = [eq(goals.userId, user.id)];
  const status = sp.status ?? "open";
  if (status === "open") conds.push(sql`${goals.status} in ('active','paused')`);
  else if (status !== "all") conds.push(eq(goals.status, status));
  if (sp.category) conds.push(eq(goals.category, sp.category));
  if (sp.priority) conds.push(eq(goals.priority, sp.priority));
  if (sp.horizon) conds.push(eq(goals.horizon, sp.horizon));
  const order = sp.sort === "priority" ? sql`case ${goals.priority} when 'critical' then 0 when 'high' then 1 when 'medium' then 2 else 3 end` : sql`${goals.targetDate} asc nulls last`;

  const [rows, allGoals, cats, taskCounts, msCounts] = await Promise.all([
    db.select().from(goals).where(and(...conds)).orderBy(order),
    db.select({ id: goals.id, title: goals.title }).from(goals).where(eq(goals.userId, user.id)).orderBy(asc(goals.title)),
    db.selectDistinct({ c: goals.category }).from(goals).where(and(eq(goals.userId, user.id), sql`${goals.category} is not null`)),
    db
      .select({ goalId: tasks.goalId, total: sql<number>`count(*)::int`, done: sql<number>`count(*) filter (where ${tasks.status} = 'done')::int` })
      .from(tasks)
      .where(and(eq(tasks.userId, user.id), sql`${tasks.goalId} is not null`))
      .groupBy(tasks.goalId),
    db
      .select({ goalId: milestones.goalId, total: sql<number>`count(*)::int`, done: sql<number>`count(${milestones.completedAt})::int` })
      .from(milestones)
      .where(and(eq(milestones.userId, user.id), sql`${milestones.goalId} is not null`))
      .groupBy(milestones.goalId),
  ]);
  const tc = new Map(taskCounts.map((x) => [x.goalId, x]));
  const mc = new Map(msCounts.map((x) => [x.goalId, x]));
  const ids = new Set(rows.map((r) => r.id));
  const roots = rows.filter((g) => !g.parentId || !ids.has(g.parentId));
  const children = (id: string) => rows.filter((g) => g.parentId === id);

  const GoalCard = ({ g, depth }: { g: (typeof rows)[number]; depth: number }) => {
    const overdue = g.targetDate && g.targetDate < today && g.status === "active";
    return (
      <div className={depth > 0 ? "border-r-2 border-zinc-200 pr-4 dark:border-zinc-800" : ""}>
        <Link href={`/goals/${g.id}`} className="card block transition-colors hover:border-accent-300 dark:hover:border-accent-700">
          <div className="flex flex-wrap items-start justify-between gap-2">
            <div>
              <h3 className="font-semibold">{g.title}</h3>
              <div className="mt-1 flex flex-wrap gap-1.5">
                <Badge tone="accent">{label(t.horizon, g.horizon)}</Badge>
                <Badge tone={priorityTone[g.priority]}>اولویت {label(t.priority, g.priority)}</Badge>
                {g.status !== "active" && <Badge>{label(t.goalStatus, g.status)}</Badge>}
                {g.category && <span className="chip">{g.category}</span>}
              </div>
            </div>
            <div className="text-left text-xs muted">
              {g.targetDate && <div className={overdue ? "text-red-600" : ""}>هدف: {formatDateShort(g.targetDate, mode)}</div>}
            </div>
          </div>
          <div className="mt-4 flex items-center gap-3">
            <Progress value={g.progress} label={`پیشرفت ${g.title}`} />
            <span className="w-10 shrink-0 text-sm font-semibold tabular-nums">{fa(g.progress)}٪</span>
          </div>
          <div className="mt-2 flex gap-4 text-xs muted">
            {tc.get(g.id) && <span>کارها: {fa(tc.get(g.id)!.done)}/{fa(tc.get(g.id)!.total)}</span>}
            {mc.get(g.id) && <span>نقاط عطف: {fa(mc.get(g.id)!.done)}/{fa(mc.get(g.id)!.total)}</span>}
          </div>
        </Link>
        {children(g.id).length > 0 && (
          <div className="mt-3 space-y-3">
            {children(g.id).map((c) => (
              <GoalCard key={c.id} g={c} depth={depth + 1} />
            ))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div>
      <PageHeader title="اهداف" subtitle="اهداف بلندمدت، میان‌مدت و کوتاه‌مدت؛ با نقاط عطف، پروژه‌ها و کارهای مرتبط." actions={<NewGoalButton parents={allGoals} />} />
      <form className="mb-5 grid gap-2 sm:grid-cols-3 lg:grid-cols-6" action="/goals">
        <select name="status" defaultValue={status} className="input" aria-label="وضعیت">
          <option value="open">فعال و متوقف</option>
          <option value="all">همه</option>
          {options(t.goalStatus).map((o) => (
            <option key={o.value} value={o.value}>{o.label}</option>
          ))}
        </select>
        <select name="horizon" defaultValue={sp.horizon ?? ""} className="input" aria-label="افق">
          <option value="">همهٔ افق‌ها</option>
          {options(t.horizon).map((o) => (
            <option key={o.value} value={o.value}>{o.label}</option>
          ))}
        </select>
        <select name="priority" defaultValue={sp.priority ?? ""} className="input" aria-label="اولویت">
          <option value="">همهٔ اولویت‌ها</option>
          {options(t.priority).map((o) => (
            <option key={o.value} value={o.value}>{o.label}</option>
          ))}
        </select>
        <select name="category" defaultValue={sp.category ?? ""} className="input" aria-label="دسته‌بندی">
          <option value="">همهٔ دسته‌ها</option>
          {cats.map((c) => (
            <option key={c.c!} value={c.c!}>{c.c}</option>
          ))}
        </select>
        <select name="sort" defaultValue={sp.sort ?? "deadline"} className="input" aria-label="مرتب‌سازی">
          <option value="deadline">نزدیک‌ترین سررسید</option>
          <option value="priority">اولویت</option>
        </select>
        <button className="btn" type="submit">اعمال فیلتر</button>
      </form>
      {rows.length === 0 ? (
        <EmptyState title="هدفی با این فیلترها پیدا نشد" description="یک هدف بلندمدت تعریف کنید و سپس آن را به اهداف کوچک‌تر و نقاط عطف بشکنید." action={<NewGoalButton parents={allGoals} />} icon="◎" />
      ) : (
        <div className="space-y-3">
          {roots.map((g) => (
            <GoalCard key={g.id} g={g} depth={0} />
          ))}
        </div>
      )}
      <Card className="mt-6" title="دربارهٔ حذف و بایگانی">
        <p className="text-sm muted">با بایگانی یا حذف یک هدف، کارها، جلسات تمرکز، فعالیت‌ها و یادداشت‌های مرتبط حذف نمی‌شوند؛ فقط پیوندشان با هدف برداشته می‌شود.</p>
      </Card>
    </div>
  );
}
