import Link from "next/link";
import { notFound } from "next/navigation";
import { and, asc, desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { activities, goalProgressLog, goals, milestones, notes, projectGoals, projects, tasks } from "@/db/schema";
import { requireContext } from "@/lib/auth";
import { fa, formatDateShort, formatMinutes } from "@/lib/format";
import { label, t } from "@/lib/i18n";
import { getLinkOptions } from "@/lib/queries";
import { localDate } from "@/lib/time";
import { Badge, Card, PageHeader, Progress, priorityTone } from "@/components/ui";
import { GoalAdmin, Milestones, NewGoalButton, ProgressSetter } from "@/components/goal-project-ui";
import { NewTaskButton, TaskRow } from "@/components/task-ui";

export default async function GoalDetail({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!/^[0-9a-f-]{36}$/i.test(id)) notFound();
  const { user, tz, mode } = await requireContext();
  const [goal] = await db.select().from(goals).where(and(eq(goals.id, id), eq(goals.userId, user.id))).limit(1);
  if (!goal) notFound();

  const [ms, linkedTasks, linkedProjects, subGoals, parent, log, goalNotes, time, allGoals, links] = await Promise.all([
    db.select().from(milestones).where(and(eq(milestones.goalId, id), eq(milestones.userId, user.id))).orderBy(sql`${milestones.dueDate} asc nulls last`),
    db.select().from(tasks).where(and(eq(tasks.goalId, id), eq(tasks.userId, user.id))).orderBy(sql`${tasks.dueDate} asc nulls last`),
    db.select({ id: projects.id, name: projects.name, status: projects.status, progress: projects.progress }).from(projectGoals).innerJoin(projects, eq(projects.id, projectGoals.projectId)).where(and(eq(projectGoals.goalId, id), eq(projects.userId, user.id))),
    db.select().from(goals).where(and(eq(goals.parentId, id), eq(goals.userId, user.id))),
    goal.parentId ? db.select({ id: goals.id, title: goals.title }).from(goals).where(and(eq(goals.id, goal.parentId), eq(goals.userId, user.id))) : Promise.resolve([]),
    db.select().from(goalProgressLog).where(and(eq(goalProgressLog.goalId, id), eq(goalProgressLog.userId, user.id))).orderBy(desc(goalProgressLog.recordedAt)).limit(10),
    db.select({ id: notes.id, title: notes.title, updatedAt: notes.updatedAt }).from(notes).where(and(eq(notes.goalId, id), eq(notes.userId, user.id))).orderBy(desc(notes.updatedAt)).limit(10),
    db.select({ min: sql<number>`coalesce(sum(extract(epoch from (${activities.endAt} - ${activities.startAt})) / 60), 0)::float` }).from(activities).where(and(eq(activities.goalId, id), eq(activities.userId, user.id))),
    db.select({ id: goals.id, title: goals.title }).from(goals).where(eq(goals.userId, user.id)).orderBy(asc(goals.title)),
    getLinkOptions(user.id),
  ]);

  const units = ms.length + linkedTasks.filter((x) => x.status !== "cancelled").length;
  const doneUnits = ms.filter((m) => m.completedAt).length + linkedTasks.filter((x) => x.status === "done").length;
  const suggested = units > 0 ? Math.round((doneUnits / units) * 100) : null;

  return (
    <div className="space-y-6">
      <div>
        <Link href="/goals" className="text-sm muted hover:underline">→ بازگشت به اهداف</Link>
      </div>
      <PageHeader
        title={goal.title}
        subtitle={
          <span className="flex flex-wrap gap-1.5">
            <Badge tone="accent">{label(t.horizon, goal.horizon)}</Badge>
            <Badge tone={priorityTone[goal.priority]}>اولویت {label(t.priority, goal.priority)}</Badge>
            <Badge>{label(t.goalStatus, goal.status)}</Badge>
            {goal.category && <span className="chip">{goal.category}</span>}
            {parent[0] && (
              <Link href={`/goals/${parent[0].id}`} className="chip hover:underline">
                زیرمجموعهٔ: {parent[0].title}
              </Link>
            )}
          </span>
        }
        actions={<GoalAdmin goal={goal} parents={allGoals} />}
      />

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <Card>
            <ProgressSetter id={goal.id} value={goal.progress} suggested={suggested} />
            <dl className="mt-5 grid gap-4 text-sm sm:grid-cols-3">
              <div><dt className="text-xs muted">تاریخ شروع</dt><dd>{formatDateShort(goal.startDate, mode)}</dd></div>
              <div><dt className="text-xs muted">تاریخ هدف</dt><dd>{formatDateShort(goal.targetDate, mode)}</dd></div>
              <div><dt className="text-xs muted">زمان ثبت‌شده در گزارش فعالیت</dt><dd>{formatMinutes(time[0]?.min ?? 0)}</dd></div>
            </dl>
            {goal.description && <p className="mt-5 whitespace-pre-wrap text-sm">{goal.description}</p>}
            {goal.successCriteria && (
              <div className="mt-4 rounded-xl bg-zinc-50 p-3 text-sm dark:bg-zinc-800/50">
                <div className="mb-1 text-xs font-medium muted">معیار موفقیت</div>
                <p className="whitespace-pre-wrap">{goal.successCriteria}</p>
              </div>
            )}
            {goal.notes && <p className="mt-4 whitespace-pre-wrap text-sm muted">{goal.notes}</p>}
          </Card>

          <Card title="نقاط عطف">
            <Milestones items={ms} goalId={goal.id} />
          </Card>

          <Card title="کارهای مرتبط" action={<NewTaskButton links={links} defaults={{ goalId: goal.id }} className="btn btn-sm" label="کار" />}>
            {linkedTasks.length === 0 ? (
              <p className="text-sm muted">کاری به این هدف متصل نیست. کارهای روزانه را به این هدف پیوند دهید تا مسیر پیشرفت روشن شود.</p>
            ) : (
              <ul className="divide-y divide-zinc-100 dark:divide-zinc-800">
                {linkedTasks.map((task) => (
                  <TaskRow key={task.id} task={task} links={links} />
                ))}
              </ul>
            )}
          </Card>
        </div>

        <div className="space-y-6">
          <Card title="اهداف زیرمجموعه" action={<NewGoalButton parents={allGoals} defaultParent={goal.id} label="زیرهدف" className="btn btn-sm" />}>
            {subGoals.length === 0 ? (
              <p className="text-sm muted">زیرهدفی تعریف نشده است.</p>
            ) : (
              <ul className="space-y-3">
                {subGoals.map((g) => (
                  <li key={g.id}>
                    <Link href={`/goals/${g.id}`} className="flex justify-between text-sm hover:underline">
                      <span>{g.title}</span>
                      <span className="muted">{fa(g.progress)}٪</span>
                    </Link>
                    <div className="mt-1"><Progress value={g.progress} size="sm" /></div>
                  </li>
                ))}
              </ul>
            )}
          </Card>

          <Card title="پروژه‌های مرتبط">
            {linkedProjects.length === 0 ? (
              <p className="text-sm muted">از صفحهٔ پروژه می‌توانید آن را به این هدف متصل کنید.</p>
            ) : (
              <ul className="space-y-2 text-sm">
                {linkedProjects.map((p) => (
                  <li key={p.id} className="flex justify-between">
                    <Link href={`/projects/${p.id}`} className="hover:underline">{p.name}</Link>
                    <span className="muted">{label(t.projectStatus, p.status)} · {fa(p.progress)}٪</span>
                  </li>
                ))}
              </ul>
            )}
          </Card>

          <Card title="یادداشت‌های مرتبط">
            {goalNotes.length === 0 ? (
              <p className="text-sm muted">یادداشتی پیوند نشده است.</p>
            ) : (
              <ul className="space-y-1.5 text-sm">
                {goalNotes.map((n) => (
                  <li key={n.id}><Link href={`/notes?id=${n.id}`} className="hover:underline">{n.title}</Link></li>
                ))}
              </ul>
            )}
          </Card>

          <Card title="سابقهٔ پیشرفت">
            {log.length === 0 ? (
              <p className="text-sm muted">ثبتی وجود ندارد.</p>
            ) : (
              <ul className="space-y-1 text-sm">
                {log.map((l) => (
                  <li key={l.id} className="flex justify-between">
                    <span className="muted">{formatDateShort(localDate(l.recordedAt, tz), mode)}</span>
                    <span className="tabular-nums">{fa(l.progress)}٪</span>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}
