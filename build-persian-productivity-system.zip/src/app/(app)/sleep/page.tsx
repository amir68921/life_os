import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { sleepRecords } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { Card, SectionTitle, EmptyState, Chip } from "@/components/ui";
import { SleepFormButton, SleepDeleteButton, type SleepRow } from "@/components/sleep-client";
import { LineChart } from "@/components/charts";
import { faDigits, faDuration, faDateMed, faRelativeDay } from "@/lib/jalali";
import { fmtTimeInTz, todayIso } from "@/lib/jalali";
import { Moon } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function SleepPage() {
  const user = await requireUser();
  const tz = user.settings.timezone;
  const today = todayIso(tz);
  const rows = await db.select().from(sleepRecords)
    .where(eq(sleepRecords.userId, user.id))
    .orderBy(desc(sleepRecords.wakeDate)).limit(60);

  const data: SleepRow[] = rows.map((s) => ({
    id: s.id, wakeDate: s.wakeDate,
    bedTime: s.bedTime.toISOString(), wakeTime: s.wakeTime.toISOString(),
    durationMinutes: s.durationMinutes, quality: s.quality,
    morningEnergy: s.morningEnergy, awakenings: s.awakenings, notes: s.notes,
  }));

  const durations = rows.map((r) => r.durationMinutes).filter((v): v is number => v != null);
  const avg = durations.length ? Math.round(durations.reduce((a, b) => a + b, 0) / durations.length) : null;

  // ناهماهنگی زمان خواب/بیداری (انحراف معیار، با لنگر ۱۸:00 برای عبور از نیمه‌شب)
  const anchorMinutes = (d: Date) => {
    const parts = new Intl.DateTimeFormat("en-GB", { timeZone: tz, hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).format(d);
    const [h, m] = parts.split(":").map(Number);
    return ((h * 60 + m) - 18 * 60 + 1440) % 1440;
  };
  const std = (arr: number[]) => {
    if (arr.length < 2) return null;
    const mean = arr.reduce((a, b) => a + b, 0) / arr.length;
    return Math.round(Math.sqrt(arr.reduce((a, b) => a + (b - mean) ** 2, 0) / arr.length));
  };
  const bedStd = std(rows.map((r) => anchorMinutes(r.bedTime)));
  const wakeStd = std(rows.map((r) => anchorMinutes(r.wakeTime)));

  // پایبندی به هدف (اختلاف کمتر از ۳۰ دقیقه برای بیداری + رسیدن به مدت هدف)
  const [twH, twM] = user.settings.targetWakeTime.split(":").map(Number);
  const targetWakeAnchor = ((twH * 60 + twM) - 18 * 60 + 1440) % 1440;
  const wakeAdherent = rows.length
    ? Math.round((rows.filter((r) => Math.abs(anchorMinutes(r.wakeTime) - targetWakeAnchor) <= 30).length / rows.length) * 100)
    : null;
  const durAdherent = durations.length
    ? Math.round((durations.filter((v) => v >= user.settings.targetSleepMinutes).length / durations.length) * 100)
    : null;

  const chartRows = [...rows].reverse().map((r) => ({ date: r.wakeDate, value: r.durationMinutes }));

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <Moon className="size-5" style={{ color: "var(--accent)" }} />
          <div>
            <h1 className="text-lg font-extrabold tracking-tight">خواب</h1>
            <p className="text-xs" style={{ color: "var(--fg-muted)" }}>ثبت دستی و تخمینی — بدون ادعای دقت پزشکی</p>
          </div>
        </div>
        <SleepFormButton tz={tz} targets={{ bed: user.settings.targetBedTime, wake: user.settings.targetWakeTime }} />
      </div>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Card className="!p-4">
          <p className="text-[11px] font-medium" style={{ color: "var(--fg-muted)" }}>میانگین مدت خواب</p>
          <p className="mt-2 text-lg font-extrabold">{avg != null ? faDuration(avg) : "—"}</p>
          <p className="mt-0.5 text-[10px]" style={{ color: "var(--fg-faint)" }}>هدف: {faDuration(user.settings.targetSleepMinutes)}</p>
        </Card>
        <Card className="!p-4">
          <p className="text-[11px] font-medium" style={{ color: "var(--fg-muted)" }}>نظم ساعت خواب</p>
          <p className="mt-2 text-lg font-extrabold">{bedStd != null ? `±${faDigits(bedStd)}د` : "—"}</p>
          <p className="mt-0.5 text-[10px]" style={{ color: "var(--fg-faint)" }}>هرچه کمتر، منظم‌تر</p>
        </Card>
        <Card className="!p-4">
          <p className="text-[11px] font-medium" style={{ color: "var(--fg-muted)" }}>نظم ساعت بیداری</p>
          <p className="mt-2 text-lg font-extrabold">{wakeStd != null ? `±${faDigits(wakeStd)}د` : "—"}</p>
          <p className="mt-0.5 text-[10px]" style={{ color: "var(--fg-faint)" }}>هرچه کمتر، منظم‌تر</p>
        </Card>
        <Card className="!p-4">
          <p className="text-[11px] font-medium" style={{ color: "var(--fg-muted)" }}>پایبندی به اهداف</p>
          <p className="mt-2 text-sm font-extrabold">
            {durAdherent != null ? `مدت: ${faDigits(durAdherent)}٪` : "—"}
          </p>
          <p className="mt-0.5 text-[10px]" style={{ color: "var(--fg-faint)" }}>
            {wakeAdherent != null ? `بیداری سر ساعت: ${faDigits(wakeAdherent)}٪` : "داده‌ای نیست"}
          </p>
        </Card>
      </div>

      <Card>
        <SectionTitle title="روند مدت خواب" subtitle="روزهای بدون رکورد، خالی می‌مانند — صفر حساب نمی‌شوند" />
        {chartRows.length >= 2 ? (
          <LineChart data={chartRows} unit="دقیقه" target={user.settings.targetSleepMinutes} height={150} />
        ) : (
          <p className="py-6 text-center text-xs" style={{ color: "var(--fg-faint)" }}>
            برای دیدن روند، دست‌کم دو شب ثبت کن.
          </p>
        )}
      </Card>

      <Card>
        <SectionTitle title="سوابق خواب" subtitle="۶۰ رکورد اخیر" />
        {data.length === 0 ? (
          <EmptyState
            title="هنوز خوابی ثبت نکردی"
            hint="هر صبح، ساعت خوابیدن و بیدار شدنت را بنویس؛ بعد از چند روز الگوی خوابت اینجا دیده می‌شود."
          />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[640px] text-xs">
              <thead>
                <tr style={{ color: "var(--fg-faint)" }}>
                  {["روز", "خوابیدن → بیداری", "مدت", "کیفیت", "انرژی صبح", "بیدارشدن در شب", ""].map((h, i) => (
                    <th key={i} className="pb-2 text-start font-medium">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {data.map((r) => (
                  <tr key={r.id} className="border-t" style={{ borderColor: "var(--border)" }}>
                    <td className="py-2.5 pe-2">
                      <p className="font-medium">{faDateMed(r.wakeDate)}</p>
                      <p className="text-[10px]" style={{ color: "var(--fg-faint)" }}>{faRelativeDay(r.wakeDate, today)}</p>
                    </td>
                    <td className="py-2.5 pe-2" dir="ltr">
                      {fmtTimeInTz(new Date(r.bedTime), tz)} ← {fmtTimeInTz(new Date(r.wakeTime), tz)}
                    </td>
                    <td className="py-2.5 pe-2">{r.durationMinutes != null ? faDuration(r.durationMinutes) : <span className="chip">نامشخص</span>}</td>
                    <td className="py-2.5 pe-2">{r.quality != null ? `${faDigits(r.quality)}/۵` : "—"}</td>
                    <td className="py-2.5 pe-2">{r.morningEnergy != null ? `${faDigits(r.morningEnergy)}/۵` : "—"}</td>
                    <td className="py-2.5 pe-2">{r.awakenings != null ? faDigits(r.awakenings) : "—"}</td>
                    <td className="py-2.5">
                      <div className="flex gap-0.5">
                        <SleepFormButton edit={r} tz={tz} targets={{ bed: user.settings.targetBedTime, wake: user.settings.targetWakeTime }} />
                        <SleepDeleteButton id={r.id} />
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}
