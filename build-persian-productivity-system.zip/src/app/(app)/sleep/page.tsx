import { and, desc, eq, gte } from "drizzle-orm";
import { db } from "@/db";
import { sleepRecords } from "@/db/schema";
import { requireContext } from "@/lib/auth";
import { fa, formatDayMonth, formatMinutes, formatPercent } from "@/lib/format";
import { computeSleepStats } from "@/lib/sleep";
import { addDays, dateRange, localMinuteOfDay, minutesToHHMM, todayIn } from "@/lib/time";
import { Card, EmptyState, PageHeader, Stat } from "@/components/ui";
import { LineSeries } from "@/components/charts";
import { NewSleepButton, SleepRowItem } from "@/components/sleep-ui";

export default async function SleepPage() {
  const { user, prefs, tz, mode } = await requireContext();
  const today = todayIn(tz);
  const rows = await db.select().from(sleepRecords).where(and(eq(sleepRecords.userId, user.id), gte(sleepRecords.wakeDate, addDays(today, -89)))).orderBy(desc(sleepRecords.wakeDate));
  const target = { bed: prefs.sleepTargetBed, wake: prefs.sleepTargetWake, minutes: prefs.sleepTargetMinutes };
  const last7 = rows.filter((r) => r.wakeDate > addDays(today, -7));
  const last30 = rows.filter((r) => r.wakeDate > addDays(today, -30));
  const s7 = computeSleepStats(last7, tz, target);
  const s30 = computeSleepStats(last30, tz, target);
  const byDate = new Map(rows.map((r) => [r.wakeDate, r]));
  const chart = dateRange(addDays(today, 29 * -1), today).map((d) => {
    const r = byDate.get(d);
    const bed = r ? localMinuteOfDay(r.bedTime, tz) : null;
    return {
      day: formatDayMonth(d, mode),
      hours: r ? Math.round((r.durationMinutes / 60) * 10) / 10 : null,
      target: Math.round((prefs.sleepTargetMinutes / 60) * 10) / 10,
      bed: bed === null ? null : Math.round(((bed >= 720 ? bed - 1440 : bed) / 60) * 10) / 10,
      wake: r ? Math.round((localMinuteOfDay(r.wakeTime, tz) / 60) * 10) / 10 : null,
    };
  });
  const clock = (centered: number | null) => (centered === null ? "—" : fa(minutesToHHMM(Math.round(centered))));

  return (
    <div className="space-y-6">
      <PageHeader title="خواب" subtitle="ثبت دستی زمان خواب و بیداری. اعداد برآورد خودتان است و ادعای دقت پزشکی ندارد." actions={<NewSleepButton />} />
      {rows.length === 0 ? (
        <EmptyState title="هنوز خوابی ثبت نشده" description="هر صبح در چند ثانیه ساعت خواب و بیداری را ثبت کنید تا روندها نمایش داده شوند." action={<NewSleepButton />} icon="☾" />
      ) : (
        <>
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            <Stat label="میانگین خواب ۷ روز" value={formatMinutes(s7.avgDuration)} hint={`${fa(s7.count)} شب ثبت‌شده · هدف ${formatMinutes(prefs.sleepTargetMinutes)}`} />
            <Stat label="میانگین خواب ۳۰ روز" value={formatMinutes(s30.avgDuration)} hint={`${fa(s30.count)} شب ثبت‌شده`} />
            <Stat label="ثبات زمان خواب (۳۰ روز)" value={s30.bedtimeStdDev === null ? "—" : `±${formatMinutes(s30.bedtimeStdDev)}`} hint={`میانگین ${clock(s30.avgBedtime)} · بیداری ±${s30.wakeStdDev === null ? "—" : formatMinutes(s30.wakeStdDev)}`} />
            <Stat label="پایبندی به هدف (۳۰ روز)" value={formatPercent(s30.targetDurationHitRate)} hint={`ساعت خواب ${formatPercent(s30.bedtimeAdherence)} · بیداری ${formatPercent(s30.wakeAdherence)}`} />
          </div>
          <Card title="مدت خواب — ۳۰ روز اخیر (ساعت)">
            <LineSeries data={chart} xKey="day" unit="ساعت" series={[{ key: "hours", name: "مدت خواب" }, { key: "target", name: "هدف", color: "#a1a1aa" }]} />
            <p className="hint">روزهای بدون ثبت به‌صورت فاصله نمایش داده می‌شوند و صفر حساب نمی‌شوند.</p>
          </Card>
          <Card title="زمان خواب و بیداری (ساعت روز)">
            <LineSeries data={chart} xKey="day" unit="" series={[{ key: "bed", name: "رفتن به رختخواب (منفی = قبل از نیمه‌شب)" }, { key: "wake", name: "بیداری" }]} />
          </Card>
          <Card title="سابقه">
            <ul className="divide-y divide-zinc-100 dark:divide-zinc-800">
              {rows.map((r) => (
                <SleepRowItem key={r.id} r={r} />
              ))}
            </ul>
          </Card>
          <Card title="نحوهٔ محاسبه">
            <ul className="list-inside list-disc space-y-1 text-sm muted">
              <li>ثبات = انحراف معیار ساعت رفتن به رختخواب/بیداری؛ عدد کمتر یعنی منظم‌تر. زمان‌های اطراف نیمه‌شب به‌درستی مقایسه می‌شوند.</li>
              <li>پایبندی = درصد شب‌هایی که مدت خواب حداکثر ۳۰ دقیقه کمتر از هدف بوده یا ساعت خواب/بیداری در ±۳۰ دقیقهٔ هدف بوده است.</li>
              <li>فقط شب‌های ثبت‌شده محاسبه می‌شوند. اهداف را از تنظیمات تغییر دهید.</li>
            </ul>
          </Card>
        </>
      )}
    </div>
  );
}
