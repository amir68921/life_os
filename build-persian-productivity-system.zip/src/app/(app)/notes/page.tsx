import Link from "next/link";
import { and, desc, eq, ilike, or, sql, type SQL } from "drizzle-orm";
import { db } from "@/db";
import { notes } from "@/db/schema";
import { requireContext } from "@/lib/auth";
import { formatDateTime } from "@/lib/format";
import { label, options, t } from "@/lib/i18n";
import { getLinkOptions } from "@/lib/queries";
import { Card, EmptyState, PageHeader } from "@/components/ui";
import { NoteEditor } from "@/components/notes-ui";

type SP = Promise<Record<string, string | undefined>>;

export default async function NotesPage({ searchParams }: { searchParams: SP }) {
  const sp = await searchParams;
  const { user, tz, mode } = await requireContext();
  const conds: SQL[] = [eq(notes.userId, user.id)];
  if (sp.q) {
    const q = `%${sp.q.replace(/[%_]/g, "")}%`;
    conds.push(or(ilike(notes.title, q), ilike(notes.content, q), sql`array_to_string(${notes.tags}, ' ') ilike ${q}`)!);
  }
  if (sp.kind) conds.push(eq(notes.kind, sp.kind));
  if (sp.tag) conds.push(sql`${sp.tag} = any(${notes.tags})`);
  const [rows, links] = await Promise.all([db.select().from(notes).where(and(...conds)).orderBy(desc(notes.updatedAt)).limit(200), getLinkOptions(user.id)]);
  const selected = sp.id ? (await db.select().from(notes).where(and(eq(notes.id, sp.id.slice(0, 36)), eq(notes.userId, user.id))).limit(1))[0] : undefined;
  const isNew = sp.new === "1";

  return (
    <div>
      <PageHeader title="یادداشت‌ها" subtitle="درس‌های آموخته، تأملات روزانه، یادداشت‌های پروژه و ایده‌ها — با جستجوی کامل." actions={<Link href="/notes?new=1" className="btn btn-primary">+ یادداشت جدید</Link>} />
      <div className="grid gap-5 lg:grid-cols-5">
        <div className="space-y-3 lg:col-span-2">
          <form action="/notes" className="flex gap-2">
            <label className="sr-only" htmlFor="nq">جستجو</label>
            <input id="nq" name="q" defaultValue={sp.q ?? ""} placeholder="جستجو در عنوان، متن و برچسب‌ها…" className="input" />
            <select name="kind" defaultValue={sp.kind ?? ""} className="input w-36" aria-label="نوع">
              <option value="">همه</option>
              {options(t.noteKind).map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
            </select>
            <button className="btn shrink-0" type="submit">جستجو</button>
          </form>
          {sp.tag && <p className="text-sm">برچسب: <span className="chip">#{sp.tag}</span> <Link href="/notes" className="text-xs underline">حذف فیلتر</Link></p>}
          {rows.length === 0 ? (
            <EmptyState title={sp.q || sp.kind || sp.tag ? "یادداشتی پیدا نشد" : "هنوز یادداشتی ندارید"} icon="✎" />
          ) : (
            <ul className="space-y-2">
              {rows.map((n) => (
                <li key={n.id}>
                  <Link href={`/notes?id=${n.id}${sp.q ? `&q=${encodeURIComponent(sp.q)}` : ""}`} aria-current={selected?.id === n.id ? "true" : undefined} className={`card block p-3 transition-colors hover:border-accent-300 ${selected?.id === n.id ? "border-accent-500" : ""}`}>
                    <div className="flex items-center justify-between gap-2">
                      <span className="truncate font-medium">{n.title}</span>
                      <span className="chip shrink-0">{label(t.noteKind, n.kind)}</span>
                    </div>
                    <p className="mt-1 line-clamp-2 text-xs muted">{n.content.slice(0, 200) || "—"}</p>
                    <p className="mt-1 text-[11px] muted">ویرایش: {formatDateTime(n.updatedAt, tz, mode)}</p>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </div>
        <div className="lg:col-span-3">
          {selected || isNew ? (
            <Card title={selected ? "ویرایش یادداشت" : "یادداشت جدید"}>
              {selected && (
                <p className="mb-4 text-xs muted">
                  ایجاد: {formatDateTime(selected.createdAt, tz, mode)} · آخرین ویرایش: {formatDateTime(selected.updatedAt, tz, mode)}
                  {selected.tags.length > 0 && <> · {selected.tags.map((tg) => <Link key={tg} href={`/notes?tag=${encodeURIComponent(tg)}`} className="ml-1 underline">#{tg}</Link>)}</>}
                </p>
              )}
              <NoteEditor key={selected?.id ?? "new"} note={selected} links={links} />
            </Card>
          ) : (
            <EmptyState title="یک یادداشت را انتخاب کنید یا یادداشت جدید بسازید" description="جستجو بدون نیاز به سرویس هوش مصنوعی و مستقیماً روی پایگاه داده انجام می‌شود." action={<Link href="/notes?new=1" className="btn btn-sm">یادداشت جدید</Link>} />
          )}
        </div>
      </div>
    </div>
  );
}
