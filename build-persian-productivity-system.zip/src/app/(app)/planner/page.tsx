import Link from "next/link";
import { and, asc, eq, gte, lt, lte, ne } from "drizzle-orm";
import { db } from "@/db";
import { activities, tasks, timeBlocks } from "@/db/schema";
import { requireContext } from "@/lib/auth";
import { fa, formatDateLong, formatDayMonth, formatMinutes, formatTime } from "@/lib/format";
import { label, t } from "@/lib/i18n";
import { WEEKDAYS_FA } from "@/lib/jalali";
import { blocksOn, overlappingPairs } from "@/lib/overlap";
import { getLinkOptions } from "@/lib/queries";
import { addDays, dateRange, isIsoDate, rangeBoundsUtc, splitByLocalDay, startOfWeek, todayIn, weekdayOf } from "@/lib/time";
import { Card, EmptyState, PageHeader, Tabs } from "@/components/ui";
import { BlockItem, NewBlockButton } from "@/components/planner-ui";
import { QuickTaskForm, TaskRow } from "@/components/task-ui";

type SP = Promise<Record<string, string | undefined>>;

export default async function PlannerPage({ searchParams }: { searchParams: SP }) {
  const sp = await searchParams;
  const { user, prefs, tz, mode } = await requireContext();
  const today = todayIn(tz);
  const view = sp.view === "week" ? "week" : "day";
  const date = isIsoDate(sp.date) ? sp.date : today;
  const from = view === "week" ? startOfWeek(date, prefs.weekStart) : date;
  const to = view === "week" ? addDays(from, 6) : date;
  const bounds = rangeBoundsUtc(from, to, tz);

  const [blocks, dayTasks, acts, links] = await Promise.all([
    db.select().from(timeBlocks).where(eq(timeBlocks.userId, user.id)),
    db.select().from(tasks).where(and(eq(tasks.userId, user.id), gte(tasks.dueDate, from), lte(tasks.dueDate, to), ne(tasks.status, "cancelled"))).orderBy(asc(tasks.plannedStart)),
    db.select().from(activities).where(and(eq(activities.userId, user.id), lt(activities.startAt, bounds.end), gte(activities.endAt, bounds.start))).orderBy(asc(activities.startAt)),
    getLinkOptions(user.id),
  ]);

  const plannedMin = (d: string) => blocksOn(blocks, d).filter((b) => b.kind !== "break").reduce((a, b) => a + (b.endMinute - b.startMinute), 0);
  const actualMin = (d: string) =>
    acts.reduce((a, x) => a + splitByLocalDay(x.startAt, x.endAt, tz).filter((s) => s.date === d && x.category !== "sleep").reduce((m, s) => m + s.minutes, 0), 0);

  const nav = (d: string) => `/planner?view=${view}&date=${d}`;
  const step = view === "week" ? 7 : 1;

  return (
    <div className="space-y-5">
      <PageHeader title="برنامه‌ریز" subtitle="زمان برنامه‌ریزی‌شده را با زمان واقعاً ثبت‌شده مقایسه کنید. لازم نیست همهٔ دقایق روز برنامه‌ریزی شوند." actions={<NewBlockButton date={date} tasks={links.tasks} />} />
      <Tabs items={[{ key: "day", label: "روزانه", href: `/planner?view=day&date=${date}` }, { key: "week", label: "هفتگی", href: `/planner?view=week&date=${date}` }]} active={view} />
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h2 className="text-lg font-semibold">{view === "day" ? formatDateLong(date, mode, true) : `${formatDayMonth(from, mode)} تا ${formatDayMonth(to, mode)}`}</h2>
        <div className="flex gap-1">
          <Link href={nav(addDays(date, -step))} className="btn btn-sm">{view === "day" ? "روز قبل" : "هفتهٔ قبل"}</Link>
          <Link href={nav(today)} className="btn btn-sm">امروز</Link>
          <Link href={nav(addDays(date, step))} className="btn btn-sm">{view === "day" ? "روز بعد" : "هفتهٔ بعد"}</Link>
        </div>
      </div>

      {view === "day" ? (
        <>
          <div className="grid grid-cols-2 gap-3">
            <div className="card"><div className="text-xs muted">برنامه‌ریزی‌شده (بدون استراحت)</div><div className="mt-1 text-xl font-bold">{formatMinutes(plannedMin(date))}</div></div>
            <div className="card"><div className="text-xs muted">ثبت‌شده در گزارش فعالیت</div><div className="mt-1 text-xl font-bold">{formatMinutes(actualMin(date))}</div></div>
          </div>
          <div className="grid gap-5 lg:grid-cols-2">
            <Card title="برنامه (Planned)" action={<NewBlockButton date={date} tasks={links.tasks} className="btn btn-sm" />}>
              {(() => {
                const list = blocksOn(blocks, date);
                const conflicts = overlappingPairs(list.map((b) => ({ ...b, start: b.startMinute, end: b.endMinute })));
                return list.length === 0 ? (
                  <EmptyState title="بلوک زمانی برای این روز ندارید" description="بلوک‌هایی برای کار، تمرکز، استراحت یا تعهدات شخصی اضافه کنید. زمان آزاد هم مجاز است." />
                ) : (
                  <>
                    {conflicts.length > 0 && <p role="alert" className="mb-3 rounded-xl bg-amber-50 px-3 py-2 text-xs text-amber-900 dark:bg-amber-900/30 dark:text-amber-100">⚠ {fa(conflicts.length)} هم‌پوشانی در برنامهٔ این روز: {conflicts.map(([a, b]) => `«${a.title}» و «${b.title}»`).join("، ")}</p>}
                    <div className="space-y-2">{list.map((b) => <BlockItem key={b.id} block={b} tasks={links.tasks} />)}</div>
                  </>
                );
              })()}
            </Card>
            <Card title="واقعی (Actual)" action={<Link href={`/activity?date=${date}`} className="text-sm text-accent-700 hover:underline dark:text-accent-300">گزارش فعالیت</Link>}>
              {acts.length === 0 ? (
                <p className="text-sm muted">فعالیتی برای این روز ثبت نشده است. جلسات تمرکز به‌طور خودکار اینجا ظاهر می‌شوند.</p>
              ) : (
                <ul className="space-y-2">
                  {acts.map((a) => (
                    <li key={a.id} className="rounded-xl border border-dashed border-zinc-300 px-3 py-2 text-sm dark:border-zinc-700">
                      <div className="flex justify-between gap-2"><span className="font-medium">{a.title}</span><span className="text-xs muted">{label(t.activityCategory, a.category)}</span></div>
                      <div className="text-xs tabular-nums muted">{formatTime(a.startAt, tz)}–{formatTime(a.endAt, tz)} · {label(t.activitySource, a.source)}</div>
                    </li>
                  ))}
                </ul>
              )}
            </Card>
          </div>
          <Card title="کارهای این روز">
            <QuickTaskForm dueDate={date} />
            {dayTasks.length === 0 ? <p className="mt-3 text-sm muted">کاری به این روز اختصاص داده نشده است.</p> : (
              <ul className="mt-3 divide-y divide-zinc-100 dark:divide-zinc-800">{dayTasks.map((x) => <TaskRow key={x.id} task={x} links={links} showDate={false} />)}</ul>
            )}
          </Card>
        </>
      ) : (
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
          {dateRange(from, to).map((d) => {
            const list = blocksOn(blocks, d);
            const items = dayTasks.filter((x) => x.dueDate === d);
            return (
              <Card key={d} className={d === today ? "ring-1 ring-accent-400" : ""}>
                <Link href={`/planner?view=day&date=${d}`} className="flex justify-between text-sm font-semibold hover:underline">
                  <span>{WEEKDAYS_FA[weekdayOf(d)]}</span><span className="font-normal muted">{formatDayMonth(d, mode)}</span>
                </Link>
                <div className="mt-1 text-xs muted">برنامه {formatMinutes(plannedMin(d))} · واقعی {formatMinutes(actualMin(d))}</div>
                <div className="mt-3 space-y-1.5">
                  {list.map((b) => <BlockItem key={b.id} block={b} tasks={links.tasks} compact />)}
                  {list.length === 0 && <p className="text-xs muted">بدون بلوک</p>}
                </div>
                {items.length > 0 && (
                  <ul className="mt-3 space-y-1 border-t border-zinc-100 pt-2 text-xs dark:border-zinc-800">
                    {items.map((x) => <li key={x.id} className={x.status === "done" ? "text-zinc-400 line-through" : ""}>☐ {x.title}</li>)}
                  </ul>
                )}
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
