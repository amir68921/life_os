import { and, eq, gte, lte, desc } from "drizzle-orm";
import { db } from "@/db";
import { habits, habitOccurrences } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { habitStats, isScheduledOn } from "@/lib/queries";
import { HabitsClient, type HabitView, type OccRow } from "@/components/habits-client";
import { todayIso, addDaysIso, weekDaysIso } from "@/lib/jalali";
import { Repeat2 } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function HabitsPage() {
  const user = await requireUser();
  const tz = user.settings.timezone;
  const today = todayIso(tz);
  const since = addDaysIso(today, -60);

  const [habitRows, occRows] = await Promise.all([
    db.select().from(habits).where(eq(habits.userId, user.id)),
    db.select().from(habitOccurrences)
      .innerJoin(habits, eq(habits.id, habitOccurrences.habitId))
      .where(and(eq(habits.userId, user.id), gte(habitOccurrences.date, since), lte(habitOccurrences.date, today)))
      .then((r) => r.map((x) => x.habit_occurrences)),
  ]);

  const views: HabitView[] = habitRows.map((h) => {
    const mine = occRows.filter((o) => o.habitId === h.id);
    const todayOcc = mine.find((o) => o.date === today);
    return {
      habit: h,
      stats: habitStats(h, mine, today),
      todayStatus: todayOcc?.status ?? null,
      todayValue: todayOcc?.value ?? null,
      scheduledToday: isScheduledOn(h, today),
    };
  }).sort((a, b) => Number(b.scheduledToday) - Number(a.scheduledToday) || a.habit.name.localeCompare(b.habit.name, "fa"));

  const occ: OccRow[] = occRows.map((o) => ({ habitId: o.habitId, date: o.date, status: o.status, value: o.value }));

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2.5">
        <Repeat2 className="size-5" style={{ color: "var(--accent)" }} />
        <div>
          <h1 className="text-lg font-extrabold tracking-tight">عادت‌ها</h1>
          <p className="text-xs" style={{ color: "var(--fg-muted)" }}>
            زنجیره‌ها بر اساس برنامهٔ واقعی‌ات محاسبه می‌شوند — روزهای غیربرنامه یا توقفِ موقت، خسارت حساب نمی‌شوند.
          </p>
        </div>
      </div>
      <HabitsClient views={views} occ={occ} weekDays={weekDaysIso(today, user.settings.weekStart)} today={today} />
    </div>
  );
}
