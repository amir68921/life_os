import { and, asc, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { habitOccurrences, habitPauses, habits } from "@/db/schema";
import { requireContext } from "@/lib/auth";
import { fa, formatPercent } from "@/lib/format";
import { computeHabitStats, isPaused, isScheduled, type HabitStatus } from "@/lib/habits";
import { label, t } from "@/lib/i18n";
import { WEEKDAYS_FA } from "@/lib/jalali";
import { addDays, dateRange, startOfWeek, todayIn } from "@/lib/time";
import { Badge, Card, EmptyState, PageHeader } from "@/components/ui";
import { HabitActions, HabitGrid, NewHabitButton, type HabitCell } from "@/components/habit-ui";

export default async function HabitsPage() {
  const { user, prefs, tz } = await requireContext();
  const today = todayIn(tz);
  const list = await db.select().from(habits).where(eq(habits.userId, user.id)).orderBy(asc(habits.createdAt));
  const ids = list.map((h) => h.id);
  const [occ, pauses] = ids.length
    ? await Promise.all([
        db.select().from(habitOccurrences).where(and(eq(habitOccurrences.userId, user.id), inArray(habitOccurrences.habitId, ids))),
        db.select().from(habitPauses).where(inArray(habitPauses.habitId, ids)),
      ])
    : [[], []];

  const days = dateRange(addDays(today, -13), today);
  const weekFrom = startOfWeek(today, prefs.weekStart);
  const monthFrom = addDays(today, -29);

  return (
    <div>
      <PageHeader title="عادت‌ها" subtitle="روی هر خانه بزنید تا وضعیت آن روز چرخشی تغییر کند: انجام شد ← ناقص ← انجام نشد ← رد عمدی ← ثبت‌نشده." actions={<NewHabitButton />} />
      {list.length === 0 ? (
        <EmptyState title="هنوز عادتی نساخته‌اید" description="یک عادت کوچک و قابل‌انجام انتخاب کنید؛ مثلاً «۱۰ دقیقه مطالعه»." action={<NewHabitButton />} icon="↻" />
      ) : (
        <div className="space-y-4">
          {list.map((h) => {
            const hp = pauses.filter((p) => p.habitId === h.id);
            const map = new Map<string, HabitStatus>(occ.filter((o) => o.habitId === h.id).map((o) => [o.date, o.status as HabitStatus]));
            const all = computeHabitStats(h, map, hp, h.startDate, today, prefs.weekStart);
            const week = computeHabitStats(h, map, hp, weekFrom, today, prefs.weekStart);
            const month = computeHabitStats(h, map, hp, monthFrom, today, prefs.weekStart);
            const cells: HabitCell[] = days.map((d) => {
              if (isPaused(d, hp)) return { date: d, state: "paused" };
              if (!isScheduled(h, d)) return { date: d, state: "off" };
              return { date: d, state: (map.get(d) as HabitCell["state"]) ?? "none" };
            });
            const unit = all.streakUnit === "week" ? "هفته" : "روز";
            return (
              <Card key={h.id}>
                <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <h2 className="font-semibold">{h.name}</h2>
                      {h.status === "paused" && <Badge tone="amber">متوقف</Badge>}
                      {h.category && <span className="chip">{h.category}</span>}
                    </div>
                    <p className="mt-1 text-xs muted">
                      {label(t.habitFrequency, h.frequency)}
                      {h.frequency === "custom" && h.weekdays ? ` (${h.weekdays.map((d) => WEEKDAYS_FA[d]).join("، ")})` : ""}
                      {h.frequency === "weekly" ? ` — ${fa(h.timesPerWeek ?? 1)} بار` : ""}
                      {h.minTarget ? ` · حداقل ${fa(h.minTarget)} ${h.unit ?? ""}` : ""}
                      {h.idealTarget ? ` · ایده‌آل ${fa(h.idealTarget)} ${h.unit ?? ""}` : ""}
                    </p>
                  </div>
                  <HabitActions habit={h} />
                </div>
                <dl className="mt-4 grid grid-cols-2 gap-3 text-sm sm:grid-cols-5">
                  <div>
                    <dt className="text-xs muted">زنجیرهٔ فعلی</dt>
                    <dd className="font-semibold">{fa(all.currentStreak)} {unit}</dd>
                  </div>
                  <div>
                    <dt className="text-xs muted">طولانی‌ترین زنجیره</dt>
                    <dd className="font-semibold">{fa(all.longestStreak)} {unit}</dd>
                  </div>
                  <div>
                    <dt className="text-xs muted">این هفته</dt>
                    <dd className="font-semibold">{formatPercent(week.completionRate)}</dd>
                  </div>
                  <div>
                    <dt className="text-xs muted">۳۰ روز اخیر</dt>
                    <dd className="font-semibold">{formatPercent(month.completionRate)}</dd>
                  </div>
                  <div>
                    <dt className="text-xs muted">کل سابقه</dt>
                    <dd className="font-semibold">{formatPercent(all.completionRate)}</dd>
                  </div>
                </dl>
                <p className="mt-1 text-[11px] muted">
                  {fa(all.completed)} انجام · {fa(all.partial)} ناقص · {fa(all.missed)} انجام‌نشده · {fa(all.skipped)} رد عمدی · {fa(all.unrecorded)} ثبت‌نشده
                </p>
                <div className="mt-4">
                  <HabitGrid habitId={h.id} name={h.name} cells={cells} />
                </div>
              </Card>
            );
          })}
          <Card title="نحوهٔ محاسبه">
            <ul className="list-inside list-disc space-y-1 text-sm muted">
              <li>فقط روزهای برنامه‌ریزی‌شده حساب می‌شوند؛ دوره‌های توقف و «رد عمدی» خنثی هستند و شکست به حساب نمی‌آیند.</li>
              <li>نرخ تکمیل = تعداد «انجام شد» ÷ نوبت‌های قابل‌ارزیابی (شامل ناقص، انجام‌نشده و روزهای گذشتهٔ ثبت‌نشده). امروز تا ثبت نشود شکست محسوب نمی‌شود.</li>
              <li>«ناقص» زنجیره را قطع نمی‌کند ولی آن را افزایش هم نمی‌دهد. یک روز از دست رفته فقط زنجیرهٔ فعلی را تمام می‌کند؛ سابقه و طولانی‌ترین زنجیره حفظ می‌شوند.</li>
              <li>برای عادت‌های «چند بار در هفته»، هر هفته‌ای که به هدف برسد یک واحد زنجیره است و هفتهٔ جاری تا پایانش شکست محسوب نمی‌شود.</li>
            </ul>
          </Card>
        </div>
      )}
    </div>
  );
}
