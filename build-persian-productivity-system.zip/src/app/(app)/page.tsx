import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { getDashboardData, fmtSleepSummary } from "@/lib/queries";
import { Card, SectionTitle, Chip, EmptyState, ProgressBar } from "@/components/ui";
import { QuickActions, TodayTaskRow, TopTaskActions } from "@/components/dashboard-client";
import {
  faDateLong, faDigits, faDuration, faRelativeDay, faDateMed,
} from "@/lib/jalali";
import { priorityLabel, goalStatusLabel } from "@/lib/utils";
import { Timer, Moon, Repeat2, ListTodo, Sparkles, ArrowLeft } from "lucide-react";

export const dynamic = "force-dynamic";

function greeting(): string {
  const h = new Date().getHours();
  if (h < 5) return "دیر وقت بیداری؛ مواظب خوابت باش";
  if (h < 12) return "صبحت بخیر";
  if (h < 15) return "ظهرت بخیر";
  if (h < 18) return "بعدازظهرت بخیر";
  return "شبت بخیر";
}

export default async function DashboardPage() {
  const user = await requireUser();
  const d = await getDashboardData(user);
  const sleep = fmtSleepSummary(d.lastSleep, d.tz);

  return (
    <div className="stagger space-y-5">
      {/* Header */}
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-xl font-extrabold tracking-tight sm:text-2xl">
            {greeting()}، {user.displayName || user.username}
          </h1>
          <p className="mt-1 text-sm" style={{ color: "var(--fg-muted)" }}>{faDateLong(d.today)}</p>
        </div>
        {d.hasReviewToday ? (
          <Chip tone="ok">مرور امروز انجام شده</Chip>
        ) : (
          <Link href="/reviews/daily" className="btn btn-soft !min-h-9 !py-1.5 !text-xs">
            مرور روزانه را بنویس
          </Link>
        )}
      </div>

      {!d.hasAnyData && (
        <Card className="border-dashed">
          <div className="flex flex-col items-start gap-3 sm:flex-row sm:items-center">
            <div className="grid size-11 shrink-0 place-items-center rounded-full" style={{ background: "var(--accent-soft)", color: "var(--accent)" }}>
              <Sparkles className="size-5" />
            </div>
            <div className="flex-1">
              <p className="text-sm font-bold">به LIFE OS خوش آمدی</p>
              <p className="mt-1 text-xs leading-6" style={{ color: "var(--fg-muted)" }}>
                اینجا قرار نیست با دادهٔ ساختگی پر شود؛ هر چیزی که می‌بینی ثمرهٔ ثبتِ خودت است.
                برای شروع، چند وظیفهٔ امروزت را بنویس و یک جلسهٔ تمرکز کوتاه انجام بده.
              </p>
            </div>
          </div>
        </Card>
      )}

      {/* Stats */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Card className="!p-4">
          <div className="flex items-center gap-2 text-[11px] font-medium" style={{ color: "var(--fg-muted)" }}>
            <Timer className="size-3.5" /> تمرکز امروز
          </div>
          <p className="mt-2 text-lg font-extrabold">{faDuration(d.focusMinutesToday)}</p>
          <p className="mt-0.5 text-[11px]" style={{ color: "var(--fg-faint)" }}>
            {d.focusSessionsToday ? `${faDigits(d.focusSessionsToday)} جلسه` : "هنوز جلسه‌ای نداشتی"}
          </p>
        </Card>
        <Card className="!p-4">
          <div className="flex items-center gap-2 text-[11px] font-medium" style={{ color: "var(--fg-muted)" }}>
            <Moon className="size-3.5" /> خواب دیشب
          </div>
          {sleep?.duration != null ? (
            <>
              <p className="mt-2 text-lg font-extrabold">{faDuration(sleep.duration)}</p>
              <p className="mt-0.5 text-[11px]" style={{ color: "var(--fg-faint)" }} dir="ltr">{sleep.bed} ← {sleep.wake}</p>
            </>
          ) : (
            <>
              <p className="mt-2 text-lg font-extrabold">—</p>
              <Link href="/sleep" className="mt-0.5 block text-[11px] font-medium" style={{ color: "var(--accent)" }}>ثبت خواب دیشب</Link>
            </>
          )}
        </Card>
        <Card className="!p-4">
          <div className="flex items-center gap-2 text-[11px] font-medium" style={{ color: "var(--fg-muted)" }}>
            <ListTodo className="size-3.5" /> وظایف امروز
          </div>
          <p className="mt-2 text-lg font-extrabold">
            {faDigits(d.doneCount)}<span className="text-sm font-medium" style={{ color: "var(--fg-faint)" }}> / {faDigits(d.todayTasks.length)}</span>
          </p>
          <div className="mt-2">
            <ProgressBar value={d.todayTasks.length ? (d.doneCount / d.todayTasks.length) * 100 : 0} />
          </div>
        </Card>
        <Card className="!p-4">
          <div className="flex items-center gap-2 text-[11px] font-medium" style={{ color: "var(--fg-muted)" }}>
            <Repeat2 className="size-3.5" /> عادت‌های امروز
          </div>
          <p className="mt-2 text-lg font-extrabold">
            {faDigits(d.habitsDone)}<span className="text-sm font-medium" style={{ color: "var(--fg-faint)" }}> / {faDigits(d.habitsScheduled)}</span>
          </p>
          <p className="mt-0.5 text-[11px]" style={{ color: "var(--fg-faint)" }}>
            {d.habitsScheduled === 0 ? "عادتی برای امروز نیست" : d.habitsDone === d.habitsScheduled ? "همه انجام شد" : "در جریان"}
          </p>
        </Card>
      </div>

      {/* Quick actions */}
      <QuickActions goals={d.activeGoals.map((g) => ({ id: g.id, title: g.title }))} />

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-5">
        {/* Today's tasks */}
        <Card className="lg:col-span-3">
          <SectionTitle
            title="وظایف امروز"
            subtitle={d.plannedMinutesRemaining ? `زمان برنامه‌ریزی/برآورده‌شدهٔ باقی‌مانده: ${faDuration(d.plannedMinutesRemaining)}` : undefined}
            action={<Link href="/tasks" className="btn btn-ghost !min-h-0 !p-1.5 text-[11px]"><ArrowLeft className="size-3.5" /> همه</Link>}
          />
          {d.todayTasks.length === 0 ? (
            <EmptyState
              title="برای امروز وظیفه‌ای نداری"
              hint="از دکمهٔ «وظیفهٔ جدید» یا صفحهٔ برنامه‌ریزی، روزت را پر کن — یا سطلایت استراحت کنی!"
            />
          ) : (
            <div className="divide-y" style={{ borderColor: "var(--border)" }}>
              {d.todayTasks.map((t) => <TodayTaskRow key={t.id} task={t} />)}
            </div>
          )}
        </Card>

        <div className="space-y-4 lg:col-span-2">
          {/* Top priority */}
          {d.topTask && (
            <Card style={{ borderColor: "var(--accent)" }}>
              <p className="text-[11px] font-semibold" style={{ color: "var(--accent)" }}>مهم‌ترین کار امروز</p>
              <p className="mt-1.5 text-sm font-bold leading-7">{d.topTask.title}</p>
              <div className="mt-2 flex items-center gap-1.5">
                <Chip tone="danger">{`اولویت: ${priorityLabel(d.topTask.priority)}`}</Chip>
                {d.topTask.plannedStart && <Chip>{d.topTask.plannedStart}</Chip>}
              </div>
              <div className="mt-3">
                <TopTaskActions id={d.topTask.id} />
              </div>
            </Card>
          )}

          {/* Goals */}
          <Card>
            <SectionTitle
              title="اهداف فعال"
              action={<Link href="/goals" className="btn btn-ghost !min-h-0 !p-1.5 text-[11px]"><ArrowLeft className="size-3.5" /> همه</Link>}
            />
            {d.activeGoals.length === 0 ? (
              <p className="text-xs leading-6" style={{ color: "var(--fg-muted)" }}>
                هنوز هدف فعالی نداری. از صفحهٔ «اهداف» اولین هدفت را تعریف کن تا وظایف روزانه معنا پیدا کنند.
              </p>
            ) : (
              <div className="space-y-3">
                {d.activeGoals.map((g) => (
                  <div key={g.id}>
                    <div className="mb-1 flex items-center justify-between text-xs">
                      <span className="truncate font-medium">{g.title}</span>
                      <span style={{ color: "var(--fg-faint)" }}>{faDigits(g.progress)}٪</span>
                    </div>
                    <ProgressBar value={g.progress} />
                    {g.targetDate && (
                      <p className="mt-1 text-[10px]" style={{ color: "var(--fg-faint)" }}>
                        سررسید: {faDateMed(g.targetDate)} ({faRelativeDay(g.targetDate, d.today)})
                      </p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </Card>

          {/* Upcoming */}
          <Card>
            <SectionTitle title="سررسیدهای نزدیک" subtitle="۷ روز آینده" />
            {d.upcoming.length === 0 ? (
              <p className="text-xs leading-6" style={{ color: "var(--fg-muted)" }}>سررسید نزدیکی نداری.</p>
            ) : (
              <ul className="space-y-2">
                {d.upcoming.slice(0, 6).map((t) => (
                  <li key={t.id} className="flex items-center justify-between gap-2 text-xs">
                    <Link href="/tasks" className="truncate font-medium">{t.title}</Link>
                    <span className="shrink-0" style={{ color: "var(--fg-faint)" }}>{faRelativeDay(t.dueDate!, d.today)}</span>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}
