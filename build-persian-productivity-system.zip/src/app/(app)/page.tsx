import Link from "next/link";
import { and, asc, eq, gte, inArray, isNotNull, lt, lte, ne, notInArray, sql } from "drizzle-orm";
import { db } from "@/db";
import { dailyReviews, focusSessions, goals, habitOccurrences, habitPauses, habits, projects, sleepRecords, tasks, timeBlocks } from "@/db/schema";
import { requireContext } from "@/lib/auth";
import { fa, formatDateLong, formatDateShort, formatMinutes, relativeDays } from "@/lib/format";
import { isPaused, isScheduled } from "@/lib/habits";
import { label, t } from "@/lib/i18n";
import { blocksOn } from "@/lib/overlap";
import { getLinkOptions } from "@/lib/queries";
import { addDays, dayBoundsUtc, diffDays, localMinuteOfDay, minutesToHHMM, todayIn } from "@/lib/time";
import { Card, EmptyState, Progress, Stat } from "@/components/ui";
import { NewTaskButton, QuickTaskForm, TaskRow } from "@/components/task-ui";
import { HabitTodayList } from "@/components/habit-ui";

function greeting(hour: number) {
  if (hour < 5) return "شب بخیر";
  if (hour < 12) return "صبح بخیر";
  if (hour < 17) return "روز بخیر";
  return "عصر بخیر";
}

export default async function Dashboard() {
  const { user, prefs, tz, mode } = await requireContext();
  const today = todayIn(tz);
  const nowMin = localMinuteOfDay(new Date(), tz);
  const { start, end } = dayBoundsUtc(today, tz);
  const widgets = new Set(prefs.dashboardWidgets);

  const [todayTasks, overdue, sessions, active, sleep, habitRows, occ, pauses, activeGoals, upcoming, goalDeadlines, projectDeadlines, blocks, review, links] =
    await Promise.all([
      db.select().from(tasks).where(and(eq(tasks.userId, user.id), eq(tasks.dueDate, today), ne(tasks.status, "cancelled"))).orderBy(asc(tasks.plannedStart), asc(tasks.createdAt)),
      db.select({ n: sql<number>`count(*)::int` }).from(tasks).where(and(eq(tasks.userId, user.id), lt(tasks.dueDate, today), inArray(tasks.status, ["todo", "in_progress"]))),
      db.select().from(focusSessions).where(and(eq(focusSessions.userId, user.id), eq(focusSessions.status, "completed"), gte(focusSessions.startedAt, start), lt(focusSessions.startedAt, end))),
      db.select().from(focusSessions).where(and(eq(focusSessions.userId, user.id), inArray(focusSessions.status, ["running", "paused"]))).limit(1),
      db.select().from(sleepRecords).where(and(eq(sleepRecords.userId, user.id), gte(sleepRecords.wakeDate, addDays(today, -1)))).orderBy(sql`${sleepRecords.wakeDate} desc`).limit(1),
      db.select().from(habits).where(and(eq(habits.userId, user.id), eq(habits.status, "active"))),
      db.select().from(habitOccurrences).where(and(eq(habitOccurrences.userId, user.id), eq(habitOccurrences.date, today))),
      db.select({ habitId: habitPauses.habitId, startDate: habitPauses.startDate, endDate: habitPauses.endDate }).from(habitPauses).innerJoin(habits, eq(habits.id, habitPauses.habitId)).where(eq(habits.userId, user.id)),
      db.select().from(goals).where(and(eq(goals.userId, user.id), eq(goals.status, "active"))).orderBy(asc(goals.targetDate)).limit(4),
      db.select().from(tasks).where(and(eq(tasks.userId, user.id), gte(tasks.dueDate, addDays(today, 1)), lte(tasks.dueDate, addDays(today, 7)), inArray(tasks.status, ["todo", "in_progress"]))).orderBy(asc(tasks.dueDate)).limit(6),
      db.select({ id: goals.id, title: goals.title, date: goals.targetDate }).from(goals).where(and(eq(goals.userId, user.id), eq(goals.status, "active"), isNotNull(goals.targetDate), gte(goals.targetDate, today), lte(goals.targetDate, addDays(today, 14)))),
      db.select({ id: projects.id, title: projects.name, date: projects.targetDate }).from(projects).where(and(eq(projects.userId, user.id), notInArray(projects.status, ["completed", "archived"]), isNotNull(projects.targetDate), gte(projects.targetDate, today), lte(projects.targetDate, addDays(today, 14)))),
      db.select().from(timeBlocks).where(eq(timeBlocks.userId, user.id)),
      db.select({ id: dailyReviews.id }).from(dailyReviews).where(and(eq(dailyReviews.userId, user.id), eq(dailyReviews.date, today))).limit(1),
      getLinkOptions(user.id),
    ]);

  const planned = todayTasks.length;
  const completed = todayTasks.filter((x) => x.status === "done").length;
  const mit = todayTasks.find((x) => x.isMit && x.status !== "done") ?? todayTasks.filter((x) => x.status !== "done").sort((a, b) => ["critical", "high", "medium", "low"].indexOf(a.priority) - ["critical", "high", "medium", "low"].indexOf(b.priority))[0];
  const focusMin = sessions.reduce((a, s) => a + (s.elapsedSeconds ?? 0), 0) / 60;
  const reportedFocus = sessions.filter((s) => s.focusedMinutes !== null);
  const pauseMap = new Map<string, { startDate: string; endDate: string | null }[]>();
  pauses.forEach((p) => pauseMap.set(p.habitId, [...(pauseMap.get(p.habitId) ?? []), p]));
  const todaysHabits = habitRows.filter((h) => isScheduled(h, today) && !isPaused(today, pauseMap.get(h.id) ?? []));
  const occMap = Object.fromEntries(occ.map((o) => [o.habitId, o.status]));
  const habitsDone = todaysHabits.filter((h) => occMap[h.id] === "completed").length;
  const remainingBlocks = blocksOn(blocks, today).filter((b) => b.endMinute > nowMin);
  const deadlines = [
    ...upcoming.map((x) => ({ key: "t" + x.id, title: x.title, date: x.dueDate!, kind: "کار", href: "/tasks" })),
    ...goalDeadlines.map((x) => ({ key: "g" + x.id, title: x.title, date: x.date!, kind: "هدف", href: `/goals/${x.id}` })),
    ...projectDeadlines.map((x) => ({ key: "p" + x.id, title: x.title, date: x.date!, kind: "پروژه", href: `/projects/${x.id}` })),
  ].sort((a, b) => a.date.localeCompare(b.date)).slice(0, 8);
  const lastSleep = sleep[0];
  const hour = Math.floor(nowMin / 60);

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-sm muted">{formatDateLong(today, mode, true)}</p>
          <h1 className="mt-1 text-2xl font-bold tracking-tight">
            {greeting(hour)}، {user.name}
          </h1>
          <p className="mt-1 text-sm muted">
            {planned === 0 ? "هنوز کاری برای امروز برنامه‌ریزی نکرده‌اید." : `${fa(completed)} از ${fa(planned)} کار امروز انجام شده است.`}
            {overdue[0]?.n ? ` ${fa(overdue[0].n)} کار عقب‌افتاده هم دارید.` : ""}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <NewTaskButton links={links} defaults={{ dueDate: today }} />
          <Link href="/focus" className="btn">
            ◷ جلسهٔ تمرکز
          </Link>
          <Link href="/activity?new=1" className="btn">
            + فعالیت
          </Link>
        </div>
      </div>

      {active[0] && (
        <Link href="/focus" className="flex items-center justify-between rounded-2xl border border-accent-300 bg-accent-50 px-4 py-3 text-sm text-accent-900 dark:border-accent-800 dark:bg-accent-900/30 dark:text-accent-100">
          <span>
            ● یک جلسهٔ تمرکز {active[0].status === "paused" ? "متوقف‌شده" : "در حال اجرا"} دارید{active[0].objective ? `: ${active[0].objective}` : ""}
          </span>
          <span className="font-medium">ادامه ←</span>
        </Link>
      )}

      {/* Current priority */}
      <section className="card border-accent-200 dark:border-accent-900" aria-labelledby="mit-title">
        <div className="text-xs font-medium text-accent-700 dark:text-accent-300" id="mit-title">
          اولویت فعلی
        </div>
        {mit ? (
          <div className="mt-2 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <div className="text-lg font-semibold">{mit.title}</div>
              <div className="mt-0.5 text-xs muted">
                {mit.isMit ? "مهم‌ترین کار امروز" : `بالاترین اولویت امروز (${label(t.priority, mit.priority)})`}
                {mit.estimatedMinutes ? ` · تخمین ${formatMinutes(mit.estimatedMinutes)}` : ""}
              </div>
            </div>
            <Link href={`/focus?task=${mit.id}`} className="btn btn-primary">
              شروع تمرکز روی این کار
            </Link>
          </div>
        ) : (
          <p className="mt-2 text-sm muted">{planned > 0 ? "همهٔ کارهای امروز انجام شده‌اند. 🌿" : "یک کار برای امروز اضافه کنید و آن را با ☆ مهم‌ترین کار روز کنید."}</p>
        )}
      </section>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {widgets.has("tasks") && <Stat label="کارهای امروز" value={planned ? `${fa(completed)}/${fa(planned)}` : "—"} hint={planned ? "انجام‌شده از برنامه‌ریزی‌شده" : "کاری ثبت نشده"} href="/tasks?view=day" />}
        {widgets.has("focus") && (
          <Stat
            label="تمرکز امروز"
            value={sessions.length ? formatMinutes(focusMin) : "—"}
            hint={sessions.length ? `${fa(sessions.length)} جلسه · زمان ثبت‌شدهٔ تایمر${reportedFocus.length ? ` · ${formatMinutes(reportedFocus.reduce((a, s) => a + (s.focusedMinutes ?? 0), 0))} متمرکز (خوداظهاری)` : ""}` : "هنوز جلسه‌ای ثبت نشده"}
            href="/focus"
          />
        )}
        {widgets.has("sleep") && (
          <Stat
            label="خواب شب گذشته"
            value={lastSleep && lastSleep.wakeDate === today ? formatMinutes(lastSleep.durationMinutes) : "—"}
            hint={lastSleep && lastSleep.wakeDate === today ? `برآورد دستی${lastSleep.quality ? ` · کیفیت ${fa(lastSleep.quality)}/۵` : ""}` : "ثبت نشده"}
            href="/sleep"
          />
        )}
        {widgets.has("habits") && <Stat label="عادت‌های امروز" value={todaysHabits.length ? `${fa(habitsDone)}/${fa(todaysHabits.length)}` : "—"} hint={todaysHabits.length ? "انجام‌شده" : "عادتی برای امروز نیست"} href="/habits" />}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          {widgets.has("tasks") && (
            <Card title="کارهای امروز" action={<Link href="/tasks" className="text-sm text-accent-700 hover:underline dark:text-accent-300">همهٔ کارها</Link>}>
              <QuickTaskForm dueDate={today} />
              {todayTasks.length === 0 ? (
                <div className="mt-4">
                  <EmptyState title="برای امروز کاری ندارید" description="با افزودن سریع بالا شروع کنید یا کارهای عقب‌افتاده را از بخش کارها به امروز منتقل کنید." />
                </div>
              ) : (
                <ul className="mt-3 divide-y divide-zinc-100 dark:divide-zinc-800">
                  {todayTasks.map((task) => (
                    <TaskRow key={task.id} task={task} links={links} showDate={false} />
                  ))}
                </ul>
              )}
            </Card>
          )}

          <Card title="باقی‌ماندهٔ برنامهٔ امروز" action={<Link href="/planner" className="text-sm text-accent-700 hover:underline dark:text-accent-300">برنامه‌ریز</Link>}>
            {remainingBlocks.length === 0 ? (
              <p className="text-sm muted">بلوک زمانی باقی‌مانده‌ای برای امروز ندارید. زمان آزاد هم بخشی از برنامه است.</p>
            ) : (
              <ul className="space-y-2">
                {remainingBlocks.map((b) => (
                  <li key={b.id} className="flex items-center gap-3 text-sm">
                    <span className="w-24 shrink-0 tabular-nums muted">{fa(`${minutesToHHMM(b.startMinute)}–${minutesToHHMM(b.endMinute)}`)}</span>
                    <span className="font-medium">{b.title}</span>
                    <span className="chip">{label(t.blockKind, b.kind)}</span>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </div>

        <div className="space-y-6">
          {widgets.has("habits") && (
            <Card title="عادت‌های امروز">
              {todaysHabits.length === 0 ? (
                <EmptyState title="عادتی برای امروز ندارید" action={<Link href="/habits" className="btn btn-sm">ساخت عادت</Link>} />
              ) : (
                <HabitTodayList date={today} habits={todaysHabits.map((h) => ({ id: h.id, name: h.name, status: occMap[h.id] ?? null }))} />
              )}
            </Card>
          )}

          {widgets.has("goals") && (
            <Card title="پیشرفت اهداف فعال" action={<Link href="/goals" className="text-sm text-accent-700 hover:underline dark:text-accent-300">اهداف</Link>}>
              {activeGoals.length === 0 ? (
                <EmptyState title="هدف فعالی ندارید" action={<Link href="/goals" className="btn btn-sm">تعریف هدف</Link>} />
              ) : (
                <ul className="space-y-4">
                  {activeGoals.map((g) => (
                    <li key={g.id}>
                      <Link href={`/goals/${g.id}`} className="flex justify-between text-sm hover:underline">
                        <span className="font-medium">{g.title}</span>
                        <span className="tabular-nums muted">{fa(g.progress)}٪</span>
                      </Link>
                      <div className="mt-1.5">
                        <Progress value={g.progress} size="sm" label={`پیشرفت ${g.title}`} />
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </Card>
          )}

          {widgets.has("deadlines") && (
            <Card title="سررسیدهای پیش رو">
              {deadlines.length === 0 ? (
                <p className="text-sm muted">سررسیدی در روزهای آینده ندارید.</p>
              ) : (
                <ul className="space-y-2.5">
                  {deadlines.map((d) => (
                    <li key={d.key} className="flex items-center justify-between gap-2 text-sm">
                      <Link href={d.href} className="truncate hover:underline">
                        <span className="chip ml-1.5">{d.kind}</span>
                        {d.title}
                      </Link>
                      <span className="shrink-0 text-xs muted" title={formatDateShort(d.date, mode)}>
                        {relativeDays(d.date, today, diffDays(d.date, today))}
                      </span>
                    </li>
                  ))}
                </ul>
              )}
            </Card>
          )}

          <Link href="/review" className="card block transition-colors hover:border-accent-300">
            <div className="text-sm font-semibold">مرور روزانه</div>
            <p className="mt-1 text-xs muted">{review[0] ? "مرور امروز را ثبت کرده‌اید — برای ویرایش کلیک کنید." : "در کمتر از دو دقیقه روزتان را مرور کنید."}</p>
          </Link>
        </div>
      </div>
    </div>
  );
}
