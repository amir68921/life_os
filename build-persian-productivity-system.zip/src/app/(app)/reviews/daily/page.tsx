import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { dailyReviews } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { DailyReviewForm } from "@/components/reviews-client";
import { validParamDate, faDateMed } from "@/lib/review-utils";
import { todayIso } from "@/lib/jalali";
import { NotebookPen } from "lucide-react";
import Link from "next/link";

export const dynamic = "force-dynamic";

export default async function DailyReviewPage({
  searchParams,
}: {
  searchParams: Promise<{ d?: string }>;
}) {
  const user = await requireUser();
  const { d } = await searchParams;
  const tz = user.settings.timezone;
  const today = todayIso(tz);
  const date = validParamDate(d) ?? today;

  const [row, recent] = await Promise.all([
    db.select().from(dailyReviews)
      .where(and(eq(dailyReviews.userId, user.id), eq(dailyReviews.date, date))).limit(1),
    db.select({ date: dailyReviews.date }).from(dailyReviews)
      .where(eq(dailyReviews.userId, user.id)).orderBy(desc(dailyReviews.date)).limit(7),
  ]);

  const r = row[0];
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2.5">
        <NotebookPen className="size-5" style={{ color: "var(--accent)" }} />
        <div>
          <h1 className="text-lg font-extrabold tracking-tight">مرور روزانه</h1>
          <p className="text-xs" style={{ color: "var(--fg-muted)" }}>دو دقیقه صاداقی با خودت — اختیاری ولی اثرگذار</p>
        </div>
      </div>

      {recent.length > 0 && (
        <div className="flex flex-wrap items-center gap-1.5">
          <span className="text-[11px]" style={{ color: "var(--fg-faint)" }}>مرورهای اخیر:</span>
          {recent.map((x) => (
            <Link key={x.date} href={`/reviews/daily?d=${x.date}`}
              className="chip transition-all hover:scale-105"
              style={x.date === date ? { background: "var(--accent)", color: "var(--accent-fg)", borderColor: "transparent" } : {}}>
              {faDateMed(x.date)}
            </Link>
          ))}
        </div>
      )}

      <DailyReviewForm
        key={date}
        today={today}
        init={r ? {
          date,
          accomplishment: r.accomplishment ?? "", goalProgress: r.goalProgress ?? "",
          distractions: r.distractions ?? "", wentWell: r.wentWell ?? "",
          improve: r.improve ?? "", tomorrowPriority: r.tomorrowPriority ?? "",
          energy: r.energy,
        } : null}
      />
    </div>
  );
}
