import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { getWeeklyReviewData } from "@/lib/queries";
import { Card, SectionTitle, EmptyState, ProgressBar } from "@/components/ui";
import { WeeklyReflectionForm, SuggestionList } from "@/components/reviews-client";
import { validParamDate } from "@/lib/review-utils";
import { addDaysIso, faDateMed, faDigits, faDuration, weekDaysIso } from "@/lib/jalali";
import { CalendarCheck2, Timer, Moon, Repeat2, ListTodo, AlarmClockOff, Target } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function WeeklyReviewPage({
  searchParams,
}: {
  searchParams: Promise<{ w?: string }>;
}) {
  const user = await requireUser();
  const { w } = await searchParams;
  const data = await getWeeklyReviewData(user, validParamDate(w) ?? undefined);

  const weeks: string[] = [];
  for (let i = 0; i < 8; i++) weeks.push(addDaysIso(data.currentWeekStart, -7 * i));

  const completionRate = data.planned > 0 ? Math.round((data.done / data.planned) * 100) : null;

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <CalendarCheck2 className="size-5" style={{ color: "var(--accent)" }} />
          <div>
            <h1 className="text-lg font-extrabold tracking-tight">مرور هفتگی</h1>
            <p className="text-xs" style={{ color: "var(--fg-muted)" }}>
              {faDateMed(data.weekStart)} تا {faDateMed(data.weekEnd)}
            </p>
          </div>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {weeks.map((ws) => (
            <Link key={ws} href={`/reviews/weekly?w=${ws}`}
              className="chip transition-all hover:scale-105"
              style={ws === data.weekStart ? { background: "var(--accent)", color: "var(--accent-fg)", borderColor: "transparent" } : {}}>
              {ws === data.currentWeekStart ? "این هفته" : faDateMed(ws)}
            </Link>
          ))}
        </div>
      </div>

      {!data.hasData ? (
        <EmptyState
          title="برای این هفته دادهٔ کافی نیست"
          hint="وقتی وظیفه، جلسهٔ تمرکز، خواب یا عادت ثبت کنی، گزارش هفتگی همین‌جا از داده‌های واقعی‌ات ساخته می‌شود. بدون داده، حدسی زده نمی‌شود."
        />
      ) : (
        <>
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            <Card className="!p-4">
              <div className="flex items-center gap-1.5 text-[11px]" style={{ color: "var(--fg-muted)" }}><ListTodo className="size-3.5" /> وظایف</div>
              <p className="mt-2 text-lg font-extrabold">{faDigits(data.done)} / {faDigits(data.planned)}</p>
              <p className="text-[10px]" style={{ color: "var(--fg-faint)" }}>انجام‌شده / برنامه‌ریزی‌شده</p>
              {completionRate != null && <div className="mt-2"><ProgressBar value={completionRate} /></div>}
            </Card>
            <Card className="!p-4">
              <div className="flex items-center gap-1.5 text-[11px]" style={{ color: "var(--fg-muted)" }}><Timer className="size-3.5" /> تمرکز</div>
              <p className="mt-2 text-lg font-extrabold">{faDuration(data.focusMin)}</p>
              <p className="text-[10px]" style={{ color: "var(--fg-faint)" }}>{faDigits(data.focusCount)} جلسهٔ تمام‌شده</p>
            </Card>
            <Card className="!p-4">
              <div className="flex items-center gap-1.5 text-[11px]" style={{ color: "var(--fg-muted)" }}><Moon className="size-3.5" /> خواب</div>
              <p className="mt-2 text-lg font-extrabold">{data.avgSleep != null ? faDuration(data.avgSleep) : "—"}</p>
              <p className="text-[10px]" style={{ color: "var(--fg-faint)" }}>میانگین · {faDigits(data.sleepCount)} شب ثبت‌شده</p>
            </Card>
            <Card className="!p-4">
              <div className="flex items-center gap-1.5 text-[11px]" style={{ color: "var(--fg-muted)" }}><Repeat2 className="size-3.5" /> عادت‌ها</div>
              <p className="mt-2 text-lg font-extrabold">{data.habitRate != null ? `${faDigits(data.habitRate)}٪` : "—"}</p>
              <p className="text-[10px]" style={{ color: "var(--fg-faint)" }}>
                {faDigits(data.habitDone)} از {faDigits(data.habitScheduled)} نوبت برنامه‌ریزی‌شده
              </p>
            </Card>
          </div>

          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            <Card>
              <SectionTitle title="پرتکرارترین حواس‌پرتی‌ها" subtitle="از گزارش‌های پایان جلسهٔ تمرکز" />
              {data.topDistractions.length === 0 ? (
                <p className="text-xs" style={{ color: "var(--fg-muted)" }}>این هفته چیزی ثبت نشده.</p>
              ) : (
                <ul className="space-y-2">
                  {data.topDistractions.map(([name, count]) => (
                    <li key={name} className="flex items-center justify-between text-xs">
                      <span className="font-medium">{name}</span>
                      <span className="chip">{faDigits(count)} بار</span>
                    </li>
                  ))}
                </ul>
              )}
            </Card>

            <Card>
              <SectionTitle title="کارهای چندبار عقب‌افتاده" subtitle="موعدشان بیش از ۳ روز پیش گذشته" />
              {data.postponed.length === 0 ? (
                <p className="text-xs" style={{ color: "var(--fg-muted)" }}>چیزی معوق نمانده.</p>
              ) : (
                <ul className="space-y-2">
                  {data.postponed.map((t) => (
                    <li key={t.id} className="flex items-center justify-between gap-2 text-xs">
                      <span className="truncate font-medium">{t.title}</span>
                      <span className="chip" style={{ background: "var(--warn-soft)", color: "var(--warn)", borderColor: "transparent" }}>
                        <AlarmClockOff className="size-3" /> {faDateMed(t.dueDate)}
                      </span>
                    </li>
                  ))}
                </ul>
              )}
              <p className="mt-3 text-[10px]" style={{ color: "var(--fg-faint)" }}>
                هیچ‌کدام خودکار جابه‌جا نمی‌شوند؛ از صفحهٔ وظایف تاریخشان را عوض کن یا آگاهانه حذفشان کن.
              </p>
            </Card>
          </div>

          {data.goalsProgress.length > 0 && (
            <Card>
              <SectionTitle title="وضعیت اهداف فعال" />
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                {data.goalsProgress.map((g) => (
                  <div key={g.id}>
                    <div className="mb-1 flex justify-between text-xs">
                      <span className="flex items-center gap-1.5 font-medium"><Target className="size-3.5" style={{ color: "var(--accent)" }} />{g.title}</span>
                      <span style={{ color: "var(--fg-faint)" }}>{faDigits(g.progress)}٪</span>
                    </div>
                    <ProgressBar value={g.progress} />
                  </div>
                ))}
              </div>
            </Card>
          )}
        </>
      )}

      <SuggestionList suggestions={data.suggestions} weekStart={data.weekStart} dismissed={data.dismissed} />
      <WeeklyReflectionForm key={data.weekStart} weekStart={data.weekStart} initial={data.reflection} />
    </div>
  );
}
