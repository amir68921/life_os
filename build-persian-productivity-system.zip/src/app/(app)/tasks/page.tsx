import Link from "next/link";
import { and, asc, desc, eq, gte, ilike, inArray, isNotNull, lt, lte, or, sql, type SQL } from "drizzle-orm";
import { db } from "@/db";
import { focusSessions, tasks } from "@/db/schema";
import { requireContext } from "@/lib/auth";
import { fa, formatDateLong, formatDayMonth } from "@/lib/format";
import { options, t } from "@/lib/i18n";
import { isoToJalali, jalaliMonthLength, jalaliToIso, JALALI_MONTHS, WEEKDAYS_FA, WEEKDAYS_FA_SHORT } from "@/lib/jalali";
import { getLinkOptions } from "@/lib/queries";
import { addDays, dateRange, isIsoDate, startOfWeek, todayIn, weekdayOf } from "@/lib/time";
import { Card, EmptyState, PageHeader, Tabs } from "@/components/ui";
import { NewTaskButton, QuickTaskForm, TaskRow } from "@/components/task-ui";

type SP = Promise<Record<string, string | undefined>>;

export default async function TasksPage({ searchParams }: { searchParams: SP }) {
  const sp = await searchParams;
  const { user, prefs, tz, mode } = await requireContext();
  const today = todayIn(tz);
  const view = ["list", "day", "week", "calendar", "overdue", "upcoming"].includes(sp.view ?? "") ? sp.view! : "list";
  const date = isIsoDate(sp.date) ? sp.date : today;
  const links = await getLinkOptions(user.id);

  const conds: SQL[] = [eq(tasks.userId, user.id)];
  if (sp.status && sp.status !== "all") conds.push(eq(tasks.status, sp.status));
  else if (!sp.status && view === "list") conds.push(inArray(tasks.status, ["todo", "in_progress"]));
  if (sp.priority) conds.push(eq(tasks.priority, sp.priority));
  if (sp.goal) conds.push(eq(tasks.goalId, sp.goal));
  if (sp.project) conds.push(eq(tasks.projectId, sp.project));
  if (sp.q) conds.push(or(ilike(tasks.title, `%${sp.q}%`), ilike(tasks.description, `%${sp.q}%`))!);

  let from: string | null = null;
  let to: string | null = null;
  let monthMeta: { title: string; first: string; length: number; prev: string; next: string } | null = null;
  if (view === "day") from = to = date;
  if (view === "week") {
    from = startOfWeek(date, prefs.weekStart);
    to = addDays(from, 6);
  }
  if (view === "calendar") {
    if (mode === "jalali") {
      const { jy, jm } = isoToJalali(date);
      const first = jalaliToIso(jy, jm, 1);
      const length = jalaliMonthLength(jy, jm);
      monthMeta = {
        title: `${JALALI_MONTHS[jm - 1]} ${fa(jy)}`,
        first,
        length,
        prev: jm === 1 ? jalaliToIso(jy - 1, 12, 1) : jalaliToIso(jy, jm - 1, 1),
        next: addDays(first, length),
      };
    } else {
      const [y, m] = date.split("-").map(Number);
      const first = `${y}-${String(m).padStart(2, "0")}-01`;
      const length = new Date(Date.UTC(y, m, 0)).getUTCDate();
      monthMeta = { title: `${fa(y)}/${fa(m)}`, first, length, prev: addDays(first, -1).slice(0, 8) + "01", next: addDays(first, length) };
    }
    from = monthMeta.first;
    to = addDays(monthMeta.first, monthMeta.length - 1);
  }
  if (from && to) conds.push(gte(tasks.dueDate, from), lte(tasks.dueDate, to));
  if (view === "overdue") conds.push(lt(tasks.dueDate, today), inArray(tasks.status, ["todo", "in_progress"]));
  if (view === "upcoming") conds.push(gte(tasks.dueDate, today), lte(tasks.dueDate, addDays(today, 14)), inArray(tasks.status, ["todo", "in_progress"]));

  const sort = sp.sort ?? "due";
  const order =
    sort === "priority"
      ? [sql`case ${tasks.priority} when 'critical' then 0 when 'high' then 1 when 'medium' then 2 else 3 end`, asc(tasks.dueDate)]
      : sort === "created"
        ? [desc(tasks.createdAt)]
        : [sql`${tasks.dueDate} asc nulls last`, asc(tasks.plannedStart)];
  const rows = await db.select().from(tasks).where(and(...conds)).orderBy(...order).limit(500);

  const ids = rows.map((r) => r.id);
  const focus = ids.length
    ? await db
        .select({ taskId: focusSessions.taskId, sec: sql<number>`coalesce(sum(${focusSessions.elapsedSeconds}),0)::int` })
        .from(focusSessions)
        .where(and(eq(focusSessions.userId, user.id), eq(focusSessions.status, "completed"), isNotNull(focusSessions.taskId), inArray(focusSessions.taskId, ids)))
        .groupBy(focusSessions.taskId)
    : [];
  const focusMap = new Map(focus.map((f) => [f.taskId!, f.sec / 60]));

  const qs = (o: Record<string, string | undefined>) => {
    const p = new URLSearchParams();
    const merged = { ...sp, ...o };
    for (const [k, v] of Object.entries(merged)) if (v) p.set(k, v);
    return `/tasks?${p.toString()}`;
  };

  const tabs = [
    { key: "list", label: "فهرست" },
    { key: "day", label: "روزانه" },
    { key: "week", label: "هفتگی" },
    { key: "calendar", label: "تقویم" },
    { key: "overdue", label: "عقب‌افتاده" },
    { key: "upcoming", label: "سررسیدهای نزدیک" },
  ].map((x) => ({ ...x, href: `/tasks?view=${x.key}` }));

  const list = (items: typeof rows, showDate = true) =>
    items.length === 0 ? null : (
      <ul className="divide-y divide-zinc-100 dark:divide-zinc-800">
        {items.map((task) => (
          <TaskRow key={task.id} task={task} links={links} focusMinutes={focusMap.get(task.id)} showDate={showDate} />
        ))}
      </ul>
    );

  return (
    <div>
      <PageHeader title="کارها" subtitle="کارها را برنامه‌ریزی، پیگیری و به اهداف و پروژه‌ها متصل کنید." actions={<NewTaskButton links={links} defaults={{ dueDate: view === "day" ? date : undefined }} />} />
      <Tabs items={tabs} active={view} />

      <form className="mb-5 grid gap-2 sm:grid-cols-2 lg:grid-cols-6" action="/tasks">
        <input type="hidden" name="view" value={view} />
        {sp.date && <input type="hidden" name="date" value={sp.date} />}
        <label className="lg:col-span-2">
          <span className="sr-only">جستجو</span>
          <input name="q" defaultValue={sp.q ?? ""} placeholder="جستجو در کارها…" className="input" />
        </label>
        <select name="status" defaultValue={sp.status ?? ""} className="input" aria-label="وضعیت">
          <option value="">{view === "list" ? "باز (پیش‌فرض)" : "همهٔ وضعیت‌ها"}</option>
          <option value="all">همه</option>
          {options(t.taskStatus).map((o) => (
            <option key={o.value} value={o.value}>{o.label}</option>
          ))}
        </select>
        <select name="priority" defaultValue={sp.priority ?? ""} className="input" aria-label="اولویت">
          <option value="">همهٔ اولویت‌ها</option>
          {options(t.priority).map((o) => (
            <option key={o.value} value={o.value}>{o.label}</option>
          ))}
        </select>
        <select name="goal" defaultValue={sp.goal ?? ""} className="input" aria-label="هدف">
          <option value="">همهٔ اهداف</option>
          {links.goals.map((g) => (
            <option key={g.id} value={g.id}>{g.title}</option>
          ))}
        </select>
        <div className="flex gap-2">
          <select name="sort" defaultValue={sort} className="input" aria-label="مرتب‌سازی">
            <option value="due">سررسید</option>
            <option value="priority">اولویت</option>
            <option value="created">جدیدترین</option>
          </select>
          <button className="btn shrink-0" type="submit">اعمال</button>
        </div>
      </form>

      {view === "day" && (
        <Card
          title={formatDateLong(date, mode, true)}
          action={
            <div className="flex gap-1">
              <Link className="btn btn-sm" href={qs({ date: addDays(date, -1) })} aria-label="روز قبل">→</Link>
              <Link className="btn btn-sm" href={qs({ date: today })}>امروز</Link>
              <Link className="btn btn-sm" href={qs({ date: addDays(date, 1) })} aria-label="روز بعد">←</Link>
            </div>
          }
        >
          <QuickTaskForm dueDate={date} />
          <div className="mt-3">{list(rows, false) ?? <EmptyState title="برای این روز کاری ثبت نشده است" />}</div>
        </Card>
      )}

      {view === "week" && from && (
        <div>
          <div className="mb-3 flex items-center justify-between">
            <h2 className="section-title">{formatDayMonth(from, mode)} تا {formatDayMonth(to!, mode)}</h2>
            <div className="flex gap-1">
              <Link className="btn btn-sm" href={qs({ date: addDays(from, -7) })}>هفتهٔ قبل</Link>
              <Link className="btn btn-sm" href={qs({ date: today })}>این هفته</Link>
              <Link className="btn btn-sm" href={qs({ date: addDays(from, 7) })}>هفتهٔ بعد</Link>
            </div>
          </div>
          <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
            {dateRange(from, to!).map((d) => {
              const items = rows.filter((r) => r.dueDate === d);
              return (
                <Card key={d} className={d === today ? "ring-1 ring-accent-400" : ""}>
                  <Link href={`/tasks?view=day&date=${d}`} className="mb-2 flex justify-between text-sm font-semibold hover:underline">
                    <span>{WEEKDAYS_FA[weekdayOf(d)]}</span>
                    <span className="font-normal muted">{formatDayMonth(d, mode)}</span>
                  </Link>
                  {list(items, false) ?? <p className="py-2 text-xs muted">بدون کار</p>}
                </Card>
              );
            })}
          </div>
        </div>
      )}

      {view === "calendar" && monthMeta && (
        <Card
          title={monthMeta.title}
          action={
            <div className="flex gap-1">
              <Link className="btn btn-sm" href={qs({ date: monthMeta.prev })}>ماه قبل</Link>
              <Link className="btn btn-sm" href={qs({ date: today })}>امروز</Link>
              <Link className="btn btn-sm" href={qs({ date: monthMeta.next })}>ماه بعد</Link>
            </div>
          }
        >
          <div className="grid grid-cols-7 gap-1 text-center text-xs muted">
            {Array.from({ length: 7 }, (_, i) => (prefs.weekStart + i) % 7).map((d) => (
              <div key={d} className="py-1">
                <span className="hidden sm:inline">{WEEKDAYS_FA[d]}</span>
                <span className="sm:hidden">{WEEKDAYS_FA_SHORT[d]}</span>
              </div>
            ))}
          </div>
          <div className="grid grid-cols-7 gap-1">
            {Array.from({ length: (weekdayOf(monthMeta.first) - prefs.weekStart + 7) % 7 }).map((_, i) => (
              <div key={"e" + i} />
            ))}
            {dateRange(monthMeta.first, addDays(monthMeta.first, monthMeta.length - 1)).map((d) => {
              const items = rows.filter((r) => r.dueDate === d);
              const dayNum = mode === "jalali" ? isoToJalali(d).jd : Number(d.slice(8));
              return (
                <Link
                  key={d}
                  href={`/tasks?view=day&date=${d}`}
                  className={`min-h-16 rounded-lg border p-1 text-start text-xs hover:border-accent-400 sm:min-h-24 ${d === today ? "border-accent-500" : "border-zinc-200 dark:border-zinc-800"}`}
                >
                  <div className="mb-0.5 font-semibold tabular-nums">{fa(dayNum)}</div>
                  <div className="hidden space-y-0.5 sm:block">
                    {items.slice(0, 3).map((x) => (
                      <div key={x.id} className={`truncate rounded px-1 ${x.status === "done" ? "text-zinc-400 line-through" : "bg-accent-50 dark:bg-accent-900/30"}`}>{x.title}</div>
                    ))}
                    {items.length > 3 && <div className="muted">+{fa(items.length - 3)}</div>}
                  </div>
                  {items.length > 0 && <div className="sm:hidden"><span className="inline-block h-1.5 w-1.5 rounded-full bg-accent-500" aria-label={`${fa(items.length)} کار`} /></div>}
                </Link>
              );
            })}
          </div>
        </Card>
      )}

      {(view === "list" || view === "overdue" || view === "upcoming") && (
        <Card>
          {view === "list" && <div className="mb-3"><QuickTaskForm placeholder="افزودن سریع کار بدون تاریخ…" /></div>}
          {view === "overdue" && rows.length > 0 && <p className="mb-3 text-sm muted">این کارها از تاریخ سررسیدشان گذشته‌اند. هر کدام را با ⇆ آگاهانه زمان‌بندی کنید؛ هیچ کاری خودکار جابه‌جا نمی‌شود.</p>}
          {list(rows) ?? (
            <EmptyState
              title={view === "overdue" ? "کار عقب‌افتاده‌ای ندارید" : view === "upcoming" ? "سررسیدی در دو هفتهٔ آینده نیست" : "کاری پیدا نشد"}
              description={view === "list" ? "یک کار جدید بسازید یا فیلترها را تغییر دهید." : undefined}
            />
          )}
        </Card>
      )}
    </div>
  );
}
