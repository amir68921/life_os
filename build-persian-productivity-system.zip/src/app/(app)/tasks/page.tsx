import { asc } from "drizzle-orm";
import { db } from "@/db";
import { tasks, goals } from "@/db/schema";
import { eq, ne } from "drizzle-orm";
import { requireUser } from "@/lib/auth";
import { TasksClient, type TaskRow } from "@/components/tasks-client";
import { todayIso, weekDaysIso } from "@/lib/jalali";
import { ListTodo } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function TasksPage() {
  const user = await requireUser();
  const [rows, goalRows] = await Promise.all([
    db.select().from(tasks).where(eq(tasks.userId, user.id)).orderBy(asc(tasks.createdAt)),
    db.select({ id: goals.id, title: goals.title }).from(goals)
      .where(eq(goals.userId, user.id)).orderBy(asc(goals.title)),
  ]);
  const today = todayIso(user.settings.timezone);
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2.5">
        <ListTodo className="size-5" style={{ color: "var(--accent)" }} />
        <div>
          <h1 className="text-lg font-extrabold tracking-tight">وظایف</h1>
          <p className="text-xs" style={{ color: "var(--fg-muted)" }}>مدیریت کامل وظایف: لیست، روزانه و هفتگی</p>
        </div>
      </div>
      <TasksClient
        tasks={rows as TaskRow[]}
        goals={goalRows.filter((g) => g.id)}
        today={today}
        weekDays={weekDaysIso(today, user.settings.weekStart)}
      />
    </div>
  );
}
